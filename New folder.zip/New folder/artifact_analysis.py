
import argparse
import logging
from generate_token import GenerateToken

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

class SSCException(Exception):
    """Custom exception for SSC API errors."""
    pass

class ArtifactAnalysis(GenerateToken):
    def __init__(self, application_name, version):
        self.application_name = application_name
        self.app_version = version
        super().__init__()
        super().update_unified_token()
        self.headers = {"Authorization": f"FortifyToken {self.SSC_ACCESS_TOKEN}"}
        self.base_url: str = self.SSC_URL
        self.checkin_id = None

    def filter_project_version_of_application(self):
        path = "projectVersions"
        output = self._request("GET", path)
        result = next((data for data in output["data"] if data["name"] == self.app_version and data["project"]["name"]==self.application_name), None)
        return result

    def retrieve_filterset_of_artifact(self)->dict:
        self.checkin_id = self.filter_project_version_of_application()["id"]
        path = f"projectVersions/{self.checkin_id}/filterSets"
        output = self._request("GET", path)
        result = {item["title"]: item["guid"] for item in output["data"]}
        return result

    def retrieve_audit_issues(self):
        print("------------------------------------|------------------------------------------------")
        print("                          Please find analysis below                                 ")
        print("------------------------------------|------------------------------------------------")
        print(f"Application Name > {self.application_name}")
        print(f"Version > {self.app_version}")
        result = self.retrieve_filterset_of_artifact()
        for key,value in result.items():
            response = self._request("GET", f"projectVersions/{self.checkin_id}/issueGroups?qm=issues&filterset={value}"
                                            "&showhidden=false&showremoved=false&showsuppressed=false&showshortfilenames=true&groupingtype=FOLDER")
            print(f"------------------------- {key} analysis--------------------------")
            if response["count"] ==0:
                # print(f"------------------------- {key} --------------------------")
                print("                  No issue to display                      ")
            else:
                header = ["Filter", "Total Count", "Critical", "High", "Medium", "Low"]
                print("\n|" + "|".join(header) + "|")

                total = sum(item["totalCount"] for item in response["data"])
                critical = next((item["totalCount"] for item in response["data"] if item["id"] == "Critical"), 0)
                high = next((item["totalCount"] for item in response["data"] if item["id"] == "High"), 0)
                medium = next((item["totalCount"] for item in response["data"] if item["id"] == "Medium"), 0)
                low = next((item["totalCount"] for item in response["data"] if item["id"] == "Low"), 0)

                print(f"|{key}|{total}|{critical}|{high}|{medium}|{low}|")
                print(f"Find `{key}` analysis on > https://sast.mahabank.co.in:8082/ssc/html/ssc/version/{self.checkin_id}/audit?filterset={value}&orderby=friority&viewTab=code\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Create or update application in SSC for scanning.")
    parser.add_argument("--app_name", required=True, help="Application name.")
    parser.add_argument("--version",required=True, help="provide version.")

    args = parser.parse_args()

    pc = ArtifactAnalysis(application_name=args.app_name,version=args.version)
    pc.retrieve_audit_issues()

# aa =ArtifactAnalysis("Report Library Portal", "1.1")
# aa.retrieve_audit_issues()