import json
import socket
import logging
from datetime import datetime, timezone, timedelta
import requests
import configparser
from typing import Optional

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

class SSCException(Exception):
    """Custom exception for SSC API errors."""
    pass

class GenerateToken:
    def __init__(self, config_file: str = "config.properties"):
        self.config = configparser.ConfigParser()
        self.config.read(config_file)

        self.URI = self.config['DEFAULT'].get('URL')
        self.SSC_URL = f"{self.URI}/api/v1/"
        self.basic_auth = self.config['DEFAULT'].get('SSC_AUTH')

        self.headers: Optional[dict] = None
        self.SSC_ACCESS_TOKEN: Optional[str] = None

        try:
            ip_address = socket.gethostbyname("sast.mahabank.co.in")
            logging.info(f"The IP address of `sast.mahabank.co.in` is {ip_address}")
        except socket.gaierror:
            logging.warning("Unable to resolve host `sast.mahabank.co.in`.")

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """Generic request handler with error handling."""
        url = f"{self.SSC_URL}{path}"
        response = requests.request(method, url, headers=self.headers, **kwargs)
        if response.status_code not in (200, 201):
            logging.error(f"API Error: {response.text}")
            raise SSCException(response.text)
        return response.json()

    def update_unified_token(self):
        """Updates or creates a UnifiedLoginToken for SSC."""
        self.headers = {"Authorization": f"Basic {self.basic_auth}"}
        path = "tokens"

        logging.info("Fetching existing tokens...")
        output = self._request("GET", path)
        current_time = datetime.now(timezone.utc)

        for token_data in output.get("data", []):
            if token_data.get("type") == "UnifiedLoginToken" and "Automation_SP" in token_data.get("description"):
                terminal_date = datetime.fromisoformat(token_data['terminalDate'])
                if current_time < terminal_date and (terminal_date-current_time)>timedelta(minutes=5):
                    logging.info("Unified Token already exists and is valid.")
                    self.SSC_ACCESS_TOKEN = token_data.get("description").replace("Automation_SP", "")
                    return self.SSC_ACCESS_TOKEN
                else:
                    logging.info("Unified Token expired. Deleting...")
                    self._request("DELETE", f"{path}/{token_data.get('id')}")

        logging.info("Creating new Unified Token...")
        payload = {"description": "Automation_SP", "type": "UnifiedLoginToken"}
        response = self._request("POST", path, json=payload)

        new_token = response["data"]["token"]
        token_id = str(response["data"]["id"])
        self.SSC_ACCESS_TOKEN = new_token

        update_payload = {"description": f"Automation_SP{new_token}", "type": "UnifiedLoginToken"}
        self._request("PUT", f"{path}/{token_id}", json=update_payload)

        logging.info("Unified token generated successfully.")
