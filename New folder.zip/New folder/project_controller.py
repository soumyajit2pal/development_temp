import json
import os
import argparse
import logging
import requests
from typing import List, Dict, Optional
from get_ldap_user import GetLdapUser
from generate_token import GenerateToken

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

class SSCException(Exception):
    """Custom exception for SSC API errors."""
    pass

class ProjectController(GenerateToken):
    def __init__(self):
        super().__init__()
        super().update_unified_token()
        self.headers = {"Authorization": f"FortifyToken {self.SSC_ACCESS_TOKEN}"}
        self.checkin_id: Optional[str] = None
        self.version: str = "1"
        self.template: str = "Prioritized-HighRisk-Project-Template"
        self.base_url: str = self.SSC_URL
        self.application_name = None

    def check_application_present(self, application_name: str) -> bool:
        path = "projects/action/test"
        payload = {"applicationName": application_name}
        logging.info(f"Checking if application '{application_name}' exists...")
        output = self._request("POST", path, json=payload)
        return output["data"]["found"]

    def get_all_applications(self) -> List[Dict]:
        path = "projects"
        logging.info("Fetching all applications...")
        output = self._request("GET", path)
        return output["data"]

    def filter_project_version_of_application(self):
        path = "projectVersions"
        output = self._request("GET", path)
        result = next((data for data in output["data"] if data["name"] == self.version and data["project"]["name"]==self.application_name), None)
        return result

    def get_project_data_of_application(self, application_name: str) -> Optional[Dict]:
        for data in self.get_all_applications():
            if data["name"] == application_name:
                return data
        logging.warning(f"Application '{application_name}' not found.")
        return None

    def get_latest_application_version_present(self, application_name: str) -> float:
        path = "projectVersions"
        output = self._request("GET", path)
        versions = [float(project["name"]) for project in output["data"] if project["project"]["name"] == application_name]
        if versions:
            logging.info(f"Existing versions for '{application_name}': {versions}")
            return max(versions)
        return 1

    def create_new_application_or_append_version(self, application_name: str, reuse_same_version: str,
                                                 project_description: str = "", version_descriptions: str = "") -> str:
        self.application_name = application_name
        path = "projectVersions"
        if self.check_application_present(application_name):
            if reuse_same_version.lower() == "no":
                # self.version = str(round(self.get_latest_application_version_present(application_name) + 0.1, 2))
                self.version = str(int(self.get_latest_application_version_present(application_name) + 1))
                application_data = self.get_project_data_of_application(application_name)
                payload = {
                    "name": self.version,
                    "description": version_descriptions,
                    "active": True,
                    "committed": False,
                    "project": {
                        "name": application_data["name"],
                        "description": None,
                        "issueTemplateId": self.template,
                        "id": application_data["id"]
                    },
                    "issueTemplateId": self.template
                }
            else:
                self.version = str(self.get_latest_application_version_present(application_name))
                logging.info(f"Reuse flag set as `{reuse_same_version}`, hence scanning will be performed on latest existing Version: {self.version}")
                self.checkin_id = self.filter_project_version_of_application()["id"]
                return self.checkin_id
        else:
            payload = {
                "name": self.version,
                "description": version_descriptions,
                "active": True,
                "committed": False,
                "project": {
                    "name": application_name,
                    "description": project_description,
                    "issueTemplateId": self.template
                },
                "issueTemplateId": self.template
            }
        output = self._request("POST", path, json=payload)
        self.checkin_id = output["data"]["id"]
        logging.info(f"Created version '{self.version}' for application '{application_name}'.")
        return self.checkin_id

    def set_version_attribute_and_access(self, access_id: List[str]):
        logging.info(f"Version attribute and access....")
        ldap_obj = GetLdapUser(self.SSC_URL, self.SSC_ACCESS_TOKEN)
        post_data = [{"id": ldap_obj.get_entity_id_by_entity_name(pf_id), "isLdap": True} for pf_id in access_id]
        payload = {
            "requests": [
                {
                    "uri": f"{self.base_url}projectVersions/{self.checkin_id}/attributes",
                    "httpVerb": "PUT",
                    "postData": self._get_attribute_payload()
                },
                {
                    "uri": f"{self.base_url}projectVersions/{self.checkin_id}/authEntities",
                    "httpVerb": "PUT",
                    "postData": post_data
                },
                {
                    "uri": f"{self.base_url}projectVersions/{self.checkin_id}?hideProgress=true",
                    "httpVerb": "PUT",
                    "postData": {"committed": True}
                }
            ]
        }
        self._request("POST", "bulk", json=payload)
        logging.info("Attributes and access have been set successfully.")

    def update_processing_rules(self):
        path = f"projectVersions/{self.checkin_id}/resultProcessingRules"
        payload = [
                  {
                    "displayName": "Require approval if the Build Project is different between scans.",
                    "identifier": "com.fortify.manager.BLL.processingrules.BuildProjectProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Check external metadata file versions in scan against versions on server.",
                    "identifier": "com.fortify.manager.BLL.processingrules.ExternalListVersionProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Require approval if file count differs by more than 10%.",
                    "identifier": "com.fortify.manager.BLL.processingrules.FileCountProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Require approval if result has Fortify Java Annotations.",
                    "identifier": "com.fortify.manager.BLL.processingrules.FortifyAnnotationsProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Require approval if line count differs by more than 10%.",
                    "identifier": "com.fortify.manager.BLL.processingrules.LOCCountProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Require approval if the engine version of a scan is newer than the engine version of the previous scan.",
                    "identifier": "com.fortify.manager.BLL.processingrules.NewerEngineVersionProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Ignore SCA quick scan results and SCA speed dial results performed with a setting of less than four.",
                    "identifier": "com.fortify.manager.BLL.processingrules.QuickScanProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Require approval if the rulepacks used in the scan do not match the rulepacks used in the previous scan.",
                    "identifier": "com.fortify.manager.BLL.processingrules.RulePackVersionProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Require approval if the rulepacks used in the scan are older than the rulepacks installed in SSC.",
                    "identifier": "com.fortify.manager.BLL.processingrules.SscRulePackVersionMatchProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Require approval if SCA or WebInspect Agent scan does not have valid certification.",
                    "identifier": "com.fortify.manager.BLL.processingrules.ValidCertificationProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Require approval if result has analysis warnings.",
                    "identifier": "com.fortify.manager.BLL.processingrules.WarningProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Perform Force Instance ID migration on upload.",
                    "identifier": "com.fortify.manager.BLL.processingrules.ForceMigrationProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Automatically perform Instance ID migration on upload.",
                    "identifier": "com.fortify.manager.BLL.processingrules.MigrationProcessingRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Warn if audit information includes unknown custom tag.",
                    "identifier": "com.fortify.manager.BLL.processingrules.UnknownOrDisallowedAuditedAttrChecker",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Require the issue audit permission to upload audited analysis files.",
                    "identifier": "com.fortify.manager.BLL.processingrules.AuditedAnalysisRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Disallow upload of analysis results that change values of hidden tags.",
                    "identifier": "com.fortify.manager.BLL.processingrules.HiddenTagAuditsAnalysisRule",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Disallow upload of analysis results if there is one pending approval.",
                    "identifier": "com.fortify.manager.BLL.processingrules.PendingApprovalChecker",
                    "enabled": False,
                    "displayable": True
                  },
                  {
                    "displayName": "Disallow approval for processing if an earlier artifact requires approval. When unchecked, the approval of latest artifacts will cause older scans to automatically get approved and processed.",
                    "identifier": "com.fortify.manager.BLL.processingrules.VetoCascadingApprovalProcessingRule",
                    "enabled": False,
                    "displayable": True
                  }
        ]
        logging.info(f"Initiating Processing rules update....")
        self._request("PUT", path, json=payload)
        for display in payload:logging.warning(display["displayName"] + " >>  "+str(display["enabled"]))
        logging.info("Processing rule update completed successfully.")

    def _get_attribute_payload(self) -> List[Dict]:
        """Return attribute payload dynamically (can be moved to config)."""
        return [
            {"values": [{"guid": "Active"}], "attributeDefinitionId": 5},
            {"values": [{"guid": "Internal"}], "attributeDefinitionId": 6},
            {"values": [{"guid": "internalnetwork"}], "attributeDefinitionId": 7},
            {"values": [], "attributeDefinitionId": 1},
            {"values": [], "attributeDefinitionId": 2},
            {"values": [], "attributeDefinitionId": 3},
            {"values": [], "attributeDefinitionId": 4},
            {"values": [{"guid": "App"}], "attributeDefinitionId": 8},
            {"values": [{"guid": "Windows"}], "attributeDefinitionId": 9}
        ]

    def project_controller(self, application_name: str, reuse_same_version: str, access_id: List[str],
                           project_description: str = "", version_descriptions: str = ""):
        for i in range(53):
            self.create_new_application_or_append_version(application_name, reuse_same_version,
                                                          project_description, version_descriptions)
            self.set_version_attribute_and_access(access_id)
            print(f"Version To Be Scan: {self.version}")
            self.update_processing_rules()
            logging.info("Project Controller execution Completed Successfully")

# if __name__ == "__main__":
#     parser = argparse.ArgumentParser(description="Create or update application in SSC for scanning.")
#     parser.add_argument("--app_name", required=True, help="Application name.")
#     parser.add_argument("--reuse_same_version", default="No", help="Yes to reuse latest version, No for new version.")
#     parser.add_argument("--pf_number", required=True, help="Comma-separated PF numbers for access.")
#     parser.add_argument("--project_descriptions",default="", help="Provide project descriptions.")
#     parser.add_argument("--version_descriptions", default="", help="Provide version descriptions.")
#     args = parser.parse_args()
#
#     pc = ProjectController()
#     pc.project_controller(application_name=args.app_name,
#                           reuse_same_version=args.reuse_same_version,
#                           access_id=args.pf_number.replace(" ", "").split(","), project_description=args.project_descriptions, version_descriptions=args.version_descriptions)
#
