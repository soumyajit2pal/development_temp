# Mahabank automation framework — enhanced edition

Java 17, Maven, Playwright Java, TestNG, OWNER, Apache POI and Extent Reports.
Original author: Soumyajit Pal. This edition preserves the CBS, CPA, IB,
InwardOutward and OTAPI application code while strengthening the framework core.

## Start here

Install a JDK 17+ and Maven 3.9+. From the project directory:

```sh
mvn test
```

The default suite runs 77 local framework regression cases, including embedded H2
database checks. It does not launch a browser or call a banking service. Tests validate configuration, reporting,
JSON and Excel readers, exact decimal amounts, HTTP/JSON contracts, prepared SQL,
portable upload paths, cleanup, thread isolation and expected lifecycle failures.
The lifecycle probes use separate JVMs so expected failures don't fail the parent suite.

For local UI examples, install a matching Playwright browser first:

```sh
mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java -Dexec.mainClass=com.microsoft.playwright.CLI -Dexec.args="install chromium"
mvn test -DsuiteXmlFile=TestSuite/framework-ui.xml
```

For the API example (requires permission to bind a loopback socket):

```sh
mvn test -DsuiteXmlFile=TestSuite/framework-api.xml
```

For an existing application suite, configure its non-production test environment:

```sh
mvn test -DsuiteXmlFile=TestSuite/CBS/CBS1.xml
mvn test -DsuiteXmlFile=TestSuite/CPA/cpa1.xml
mvn test -DsuiteXmlFile=TestSuite/IB/ib1.xml
mvn test -DsuiteXmlFile=TestSuite/InwardOutward/inwardoutward1.xml
mvn test -DsuiteXmlFile=TestSuite/OTAPI/otapi.xml
```

`-DsuiteXmlFile=...` is the supported suite selector. The previous missing
`TestDeposit` class reference is gone; `testng.xml` also selects the core checks.

## Configuration and credentials

Precedence is JVM properties, environment variables, then classpath properties.
Application keys are qualified with the application directory name. Punctuation
becomes underscores and names become uppercase for environment variables:

| Classpath key | JVM property | Environment variable |
| --- | --- | --- |
| browser | browser | BROWSER |
| headless | headless | HEADLESS |
| enable.tracing | enable.tracing | ENABLE_TRACING |
| CBS/app.properties: app.url.base | CBS.app.url.base | CBS_APP_URL_BASE |
| CBS/app.properties: app.password | CBS.app.password | CBS_APP_PASSWORD |
| CBS/app.properties: app.password.CHECKER | CBS.app.password.CHECKER | CBS_APP_PASSWORD_CHECKER |
| IB/app.properties: app.password | IB.app.password | IB_APP_PASSWORD |
| OTAPI/app.properties: app.api.url.base | OTAPI.app.api.url.base | OTAPI_APP_API_URL_BASE |

Use an approved CI secret store or environment injection for passwords. Password
properties and JSON password fields in this copy are blank. CBS transaction tests
now obtain the maker password from CBSConfig. Saved login state, downloads and
machine-specific Maven settings are excluded. Other supplied application fixtures,
identifiers, URLs and upload samples are preserved; review them before sharing.

Default settings are headless Chromium, METHOD sessions, zero slow motion,
tracing enabled, video disabled and HTTPS certificate verification enabled.
For a test environment with a self-signed certificate, opt in explicitly:

```sh
mvn test -DsuiteXmlFile=TestSuite/CBS/CBS1.xml -Dignore.https.errors=true
```

TestNG XML browser/session parameters take precedence over those corresponding
framework properties. Available browsers: chromium, chrome, edge, firefox,
webkit; safari is an alias for webkit. Chrome and Edge require installed channels.
For changes between complete runs, use `ConfigurationManager.clearCache()`;
configuration is otherwise cached and must not be changed mid-suite.

Framework settings are validated before they enter the cache. Unknown browsers,
session scopes and report themes, misspelled booleans, invalid integers, zero or
negative timeouts, and negative/nonfinite action delays fail with the property key.
Timeouts must be positive; pauses, action delay and the legacy retry setting may be
zero. Report themes accept light, standard or dark. Invalid settings are never cached.

## Session ownership and isolation

METHOD creates a fresh Playwright session, browser, context and page per test.
API tests extend `ApiProjectHooks`; they create Playwright without a browser.
Their subclass `@BeforeMethod` calls `setRequestContext(baseUrl)`.

CLASS is a compatibility option for serial stateful scenarios. It rejects
`parallel="methods"` and checks that the session stays on its creating thread.
Register logout actions only when the application needs explicit logout;
registered actions run after each test and are always cleared.

New independent tests can use `setScenarioData` / `getScenarioData` for
thread-confined state that is cleared after every method. Legacy `setGlobalData`
remains suite-wide for existing cross-test account workflows and is cleared at
suite boundaries. Keep those workflows serial until their data and ordering are
made explicit. Browser thread isolation alone does not make banking data safe
for concurrent use. No automatic retries of banking transactions were added.

## Reports and debugging

Reports appear under `target/reports/<run-id>/ExecutionReport.html`.
Test methods get an automatic report node. Existing `startTestCase(...)` calls
rename that node and add the description/categories instead of duplicating it.
A failed method saves a full-page PNG and, when tracing is enabled, a trace ZIP
under that run's `artifacts/<test-id>/` directory. Successful steps do not take
screenshots. API tests do not attempt browser screenshots.

```sh
mvn org.codehaus.mojo:exec-maven-plugin:3.5.0:java -Dexec.mainClass=com.microsoft.playwright.CLI -Dexec.args="show-trace PATH_TO_TRACE_ZIP"
```

Typed input values are omitted from routine step reports. Screenshots, traces,
API captures and exception diagnostics can still contain application data; handle
those artifacts according to your existing test-data policy. Teardown errors fail
configuration checks instead of silently passing the suite.

## Combine execution reports across runs

Every new run saves `ExtentResults.json` beside `ExecutionReport.html`. Keep the
JSON archive and the run's `artifacts` directory. After executing a first batch,
then another batch or rerunning failed cases, merge the completed run directories
in order from oldest to newest:

```sh
mvn -Pmerge-reports compile -Dreport.inputs=target/reports/RUN_1,target/reports/RUN_2
```

Replace `RUN_1` and `RUN_2` with the actual run directory names. Multiple directories
are comma-separated. This command generates `target/reports/merged/ExecutionReport.html`
and does not execute tests. Choose another output with
`-Dreport.output=target/reports/my-combined-report`.

By default, each unique test has one entry with its latest result. A failure followed
by a pass is PASS; a pass followed by a failure is FAIL. Expand the **Execution history**
section in that test's logs to inspect its earlier outcomes, step messages and screenshot
links. Earlier failures are historical information and do not count as current failures.
Screenshots, traces and videos are copied into the merged report directory.

For example, 10 executions followed by 15 executions produce 25 total attempts.
If two of the second batch rerun cases from the first batch, the latest dashboard
contains 23 unique test cases. If all 15 cases are new, it contains 25 unique cases.
To display all 25 attempts as separate entries instead, use:

```sh
mvn -Pmerge-reports compile -Dreport.inputs=target/reports/RUN_1,target/reports/RUN_2 -Dreport.merge.mode=all
```

Normal lifecycle tests use the full Java method signature and a hash of simple
DataProvider parameters as their identity. Friendly `startTestCase(...)` names can
change without changing that identity. Strings, numbers, booleans, arrays, lists,
maps and JSON nodes are supported. For a business case ID or complex/custom data
objects, assign an explicit, globally unique ID in the test before logging results:

```java
setReportTestId("CBS.deposit." + testData.caseId());
```

Opaque objects receive distinct identities to avoid accidentally combining different
cases. Merge runs from the same environment and test variant; include the environment
or browser in an explicit ID when combining several variants. Identical parameters
and IDs represent the same logical case; repeated attempts remain available in history.

The merged directory also contains `MergeSummary.json`, selected results in
`ExtentResults.json`, and every attempt in `ExecutionHistory.json`. A merged directory
can be an input to a later merge; its full history is retained and repeated attempt IDs
are counted once. Input reports are preserved. The output must be outside the input
run directories. Archives without framework IDs use their test names as identities.

Older reports containing only HTML cannot be merged through this workflow. Run the
updated framework to export JSON archives, or use JSON archives retained separately
from those executions. HTML pages are not a reliable source of the original test models.

`FrameworkReportMergeSelfTest` creates a 10-plus-15 example at
`target/report-merge-demo/merged/ExecutionReport.html`, including two recovered failures.
This implementation uses Extent's official
[JSON archive/import support](https://extentreports.com/docs/versions/5/java/index.html).

## Add a test

Place application page objects in `src/main/java/mahabank/automation/e2e/<App>`
and tests in `src/test/java/mahabank/automation/<App>`. Existing inherited wrapper
methods are preserved. Prefer Playwright role/label/test-id locators, retrying
assertions and `waitForResponse(..., action)` over fixed delays.

`isVisible` now performs an immediate visibility query without its old five-second
sleep. Use `verifyDisplayed` or an explicit locator wait when appearance is required.
`verifyExactText` now uses Playwright's whitespace-normalized text assertion.
Legacy pause methods remain for compatibility and should be migrated by scenario.

`ReadDynamicJson.getObject(caseId)` rejects missing or non-object cases.
Use `ReadDynamicJson.requireText(node, key)` for mandatory nonblank string fields.
Duplicate keys, trailing JSON documents and required fields of the wrong type are rejected.
Both file paths and `classpath:fixtures/name.json` are supported. Existing data
paths stay in place for compatibility; new fixtures should live in test resources.

Use an instance `ExcelUtil.readRow(...)`; the old static reader is a deprecated
thread-confined adapter. Formulas are evaluated and display formats are preserved
(for example, an account identifier formatted as 0000 retains leading zeroes).

The `.github/workflows/framework.yml` template runs core checks, local API examples
and UI examples, then uploads reports. CI preserves Surefire output in separate
`target/surefire-reports/core`, `api` and `ui` directories. Select a report directory
with `-Dtest.report.directory=target/surefire-reports/core`.

## Wrapper review and behavior

The framework review covers browser/action wrappers, API helpers, lifecycle cleanup,
configuration, data readers, JDBC, report export/merging and application callers.
`FrameworkWrapperSelfTest` adds local regression coverage; the UI suite exercises
wrappers against browser-local HTML and mocked responses.

- Action wrappers log failures and throw an assertion carrying the original cause.
  Required `waitForAppearance` now fails the test on timeout. Immediate `isVisible`,
  `isEnabled` and `isDisabled` remain boolean queries.
- `type` uses a single fill. `typeAndEnter`, `typeAndTab` and `clickAndType` replace
  previous input, then send keyboard events. Successful steps omit typed values.
- `selectByIndex` and `selectByIndexInFrame` use native zero-based index selection,
  including options with duplicate values and options inside groups. Negative or
  unavailable indexes cannot fall back to random values. Use `selectByRandomIndex`
  explicitly; it excludes the first placeholder and requires a further option.
- `selectByClick` selects an exact option name and rejects ambiguous matches.
  `setChecked(selector, boolean, name)` sets either checkbox state; `check` and
  `uncheck` delegate to it. The IB terms-and-conditions helper now supports unchecking.
- Select a frame with `setFrameLocator(selector)`. Changing pages clears the old
  frame; `switchToOpenedPage` waits for that page's popup. Repeated `AcceptDialog`
  calls install one handler per page, detached during resource cleanup.
- Nonempty assertions support text elements and inputs without reading input values.
  Downloads retain their original extension, reserve filenames atomically, and add
  numeric suffixes on collisions. Download names must not contain directory paths.
- API capture is passive and scoped to the current thread/page. It does not override
  mock routes. Initialization is idempotent, latest means arrival order, and captured
  response maps are immutable. Counts are per exact URL; ambiguous wildcard/count
  lookups fail with guidance to use an exact URL. Reset clears patterns and results;
  register interception patterns again before the next capture. Disposal detaches
  the listener. Unreadable bodies remain errors instead of fabricated response data.
- Spreadsheet row maps are defensive immutable snapshots. CBS balance comparisons
  ignore decimal scale; missing linked accounts, invalid dates, unsupported cash
  denominations, invalid nominee counts and invalid percentage allocations fail.
  The current nominee helper supports adult nominees (`N`); minor nominees require
  a separate workflow supplying DOB and guardian details. Repeated nominees now
  validate their corresponding fields.
- Login helpers wait for their controls. Unconditional debugger pauses were removed,
  IB landing-page validation now asserts visibility, and the empty withdrawal test
  is disabled until it has executable steps and outcome assertions.

The UI suite also runs an expected-failure probe in a separate JVM, checking that
failure screenshots are readable PNGs, traces are valid ZIPs and JSON records FAIL.
Live banking selectors, CAPTCHA/OTP integration and maker/checker outcomes still
require controlled application tests. Legacy application-specific fixed waits remain
for that migration; the review does not establish live environment behavior.

Native selection and checkbox behavior follow the official
[Locator API](https://playwright.dev/java/docs/api/class-locator), and popup handling
uses the [Page popup API](https://playwright.dev/java/docs/api/class-page#wait-for-popup).

## Page objects with explicit dependencies

New page objects can extend `mahabank.automation.pages.BasePage` and receive the
current `Page` in their constructor. The test extends `ProjectHooks` and owns the
session, report and cleanup. Construct a page object within each test, after setup,
and keep it on the Playwright owner thread. The local `FrameworkUiExample` shows
this pattern with role locators and a retrying assertion:

```java
final class LoginPage extends mahabank.automation.pages.BasePage {
    LoginPage(com.microsoft.playwright.Page page) { super(page); }

    void login(String username, String password) {
        page.getByLabel("Username").fill(username);
        page.getByLabel("Password").fill(password);
        page.getByRole(com.microsoft.playwright.options.AriaRole.BUTTON,
            new com.microsoft.playwright.Page.GetByRoleOptions().setName("Sign in").setExact(true)).click();
    }
}

// Inside a test extending ProjectHooks:
new LoginPage(getPage()).login(username, password);
```

Existing application page objects remain compatible with inherited wrapper methods.
Migrate them one scenario at a time with controlled application smoke checks.

## Explicit API response contracts

`ApiResponseChecks` works with both `APIResponse` and browser `Response`, independently
of reporting or lifecycle classes. Choose the status required by the endpoint contract,
then check Content-Type and typed fields using JSON Pointers:

```java
var response = get("/health");
try {
    ApiResponseChecks.assertThat(response)
        .hasStatus(200)
        .hasJsonContentType()
        .hasText("/status", "UP");
} finally {
    response.dispose();
}
```

Also available: `hasField`, `hasBoolean`, `hasNumber` with `BigDecimal`, and
`hasArraySize`. Missing/null fields, wrong JSON types, duplicate keys, trailing JSON
documents and malformed bodies fail assertions. Field mismatch messages omit values
and response bodies. Checks read and parse the body lazily; the caller owns response
disposal. The API example includes an explicit 401 error contract.

API calls without an initialized request context now give a setup error naming
`setRequestContext`. That method requires an absolute HTTP(S) URL and an initialized
Playwright session. Existing OTAPI calls retain their current success check until
its endpoint-specific response contract is supplied.

## Database operations and amounts

`DatabaseClient` is a standalone component. It opens and closes a connection for
each operation, binds `?` parameters using prepared statements, applies a query
timeout (30 seconds by default), and closes result sets and statements on success
or failure. Results are detached, immutable lists:

```java
DatabaseClient database = new DatabaseClient(jdbcUrl, username, password);
List<String> accounts = database.query(
    "SELECT account_number FROM accounts WHERE customer_id = ?",
    row -> row.getString("account_number"), customerId);
```

A `ConnectionProvider` constructor supports a DataSource such as
`new DatabaseClient(dataSource::getConnection, 10)`. The provider must return a
connection owned by the operation. Each update follows that connection's transaction
settings; use an auto-commit provider for standalone updates. There is no transaction
spanning multiple client calls. SQLExceptions propagate with their JDBC causes;
query text and parameter values are not written to step reports.

The inherited `DatabaseManager` is deprecated. Its query methods return a disconnected
`CachedRowSet`; its update methods delegate to `DatabaseClient`. Both accept optional
bound parameters. Its deprecated raw `getConnection()` is a separate, manager-owned
connection; close the manager with try-with-resources. Raw connection transaction
settings do not apply to the delegated operations. New tests should use the standalone
client. Enable optional MySQL/SQL Server runtime drivers with `-Pdatabase`.
H2 is a test-only dependency, used without a server or loopback socket.

`Utils` formats amounts directly from `BigDecimal`, preserving decimal digits and
trailing zeros with consistent comma grouping regardless of machine locale. Amount
validation compares numeric value, so `10.0` equals `10.00`. Required amount inputs
reject blank/null values; the legacy display formatter still returns `0.00` for them.

`resolveUploadDocument` joins fixture filenames with the configured upload directory,
normalizes legacy Windows separators, and checks the file exists. CPA now uses it.
`upload.path` accepts project-relative directories and native absolute directories;
the original `/src/...` setting retains its project-relative meaning.

## Validation performed and limits

Validation on 6 October 2026 used JDK 17 and Maven with the standard POM dependency
graph: Playwright 1.60.0, TestNG 7.12.0, Extent Reports 5.1.2, POI 5.4.0,
Jackson 2.17.3 and test-only H2 2.3.232. All 84 Java sources compiled and all 77 core
cases passed. Both local API examples and all 13 headless Chromium checks passed.
The UI suite uses two parallel method workers. API checks require permission to
bind a loopback port; browser checks require permission to launch Chromium.

Logging-provider warnings are still emitted; they do not fail these checks.
Dependency vulnerability auditing, CI execution on Linux, live banking endpoints,
and end-to-end maker/checker scenarios were not exercised. `validation.json`
records the local results.

The optional `cached-validation` profile keeps the earlier Playwright 1.50.0,
TestNG 7.10.2 versions for compatibility checks, with Extent Reports 5.1.2.
The older Extent 5.0.9 JSON exporter fails on Java 17, so the profile now keeps the
standard reporter version. All 77 core cases also passed with this profile:

```sh
mvn -Pcached-validation test
```

For this local run Chromium was installed under `target/playwright-browsers`.
To reuse that installation from the project directory:

```sh
PLAYWRIGHT_BROWSERS_PATH="$PWD/target/playwright-browsers" mvn test -DsuiteXmlFile=TestSuite/framework-ui.xml
```

## Follow-on improvements

1. Validate one controlled smoke scenario per application, including failure
   screenshots, trace creation and logout behaviour.
2. Move application fixtures to test resources, replace fixed waits and interactive
   pauses, and validate required data fields.
3. Give each banking workflow its own generated data and cleanup before enabling
   parallel execution.
4. Migrate inherited application page objects to the explicit-Page pattern as each
   scenario is verified against its test environment.
5. Define endpoint-specific OTAPI contracts, then add negative and authorization
   cases using deterministic fixtures.
6. Run dependency vulnerability auditing and the CI workflow on Linux.

The browser ownership and isolated-context choices follow the official
[Playwright threading guidance](https://playwright.dev/java/docs/multithreading)
and [test-runner guidance](https://playwright.dev/java/docs/test-runners).
Locator migration follows the official
[locator documentation](https://playwright.dev/java/docs/locators).

The page-object approach follows the official
[Playwright page object guidance](https://playwright.dev/java/docs/pom).
Prepared query parameters follow the official
[JDBC prepared statement guidance](https://docs.oracle.com/javase/tutorial/jdbc/basics/prepared.html).
