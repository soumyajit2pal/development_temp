package mahabank.automation.base;

import com.microsoft.playwright.*;
import mahabank.automation.config.ConfigurationManager;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Each Playwright session is owned by its creating thread. */
public class BrowserFactory {
    protected static final ThreadLocal<BrowserContext> context = new ThreadLocal<>();
    protected static final ThreadLocal<Browser.NewContextOptions> contextOptions = new ThreadLocal<>();
    protected static final ThreadLocal<Page> page = new ThreadLocal<>();
    protected static final ThreadLocal<Page> secondPage = new ThreadLocal<>();
    protected static final ThreadLocal<FrameLocator> frameLocator = new ThreadLocal<>();
    protected static final ThreadLocal<Playwright> playwright = new ThreadLocal<>();
    protected static final ThreadLocal<Browser> driver = new ThreadLocal<>();
    protected static final ThreadLocal<Map<Page, java.util.function.Consumer<Dialog>>> dialogHandlers =
            ThreadLocal.withInitial(IdentityHashMap::new);
    // Compatibility for existing dependent workflows; these suites must stay serial.
    private static final Map<String, Object> globalData = new ConcurrentHashMap<>();
    private static final ThreadLocal<Map<String,Object>> scenarioData = ThreadLocal.withInitial(HashMap::new);
    public static void setGlobalData(String key, Object value) { globalData.put(key, value); }
    public static Object getGlobalData(String key) { return globalData.get(key); }
    public static boolean containsKeyGlobalData(String key) { return globalData.containsKey(key); }
    public static void clearGlobalData() { globalData.clear(); }
    public static void setScenarioData(String key, Object value) { scenarioData.get().put(key,value); }
    public static Object getScenarioData(String key) { return scenarioData.get().get(key); }
    public static void clearScenarioData() { scenarioData.remove(); }

    public static String normalizeBrowser(String value) {
        if (value == null) throw new IllegalArgumentException("Browser must be configured");
        return switch (value.trim().toLowerCase(Locale.ROOT)) {
            case "chromium", "chrome", "edge", "firefox" -> value.trim().toLowerCase(Locale.ROOT);
            case "webkit", "safari" -> "webkit";
            default -> throw new IllegalArgumentException("Unsupported browser: " + value);
        };
    }
    public void setDriver(String browser, boolean headless) {
        String name = normalizeBrowser(browser);
        playwright.set(Playwright.create());
        try {
            BrowserType.LaunchOptions options = new BrowserType.LaunchOptions()
                .setHeadless(headless).setSlowMo(ConfigurationManager.configuration().slowMotion());
            BrowserType type = switch (name) {
                case "firefox" -> getPlaywright().firefox();
                case "webkit" -> getPlaywright().webkit();
                default -> getPlaywright().chromium();
            };
            if (name.equals("chrome")) options.setChannel("chrome");
            if (name.equals("edge")) options.setChannel("msedge");
            driver.set(type.launch(options));
        } catch (RuntimeException e) {
            try { closeBrowserResources(); } catch (RuntimeException cleanup) { e.addSuppressed(cleanup); }
            throw e;
        }
    }
    public Browser getDriver() { return driver.get(); }
    public BrowserContext getContext() { return context.get(); }
    public Browser.NewContextOptions getContextOptions() { return contextOptions.get(); }
    public Page getPage() { return page.get(); }
    public void setPage(Page newPage) {
        Objects.requireNonNull(newPage, "Page is required");
        if (page.get() != newPage) frameLocator.remove();
        page.set(newPage);
    }
    public Page getSecondPage() { return secondPage.get(); }
    public FrameLocator getFrameLocator() {
        FrameLocator current = frameLocator.get();
        if (current == null) throw new IllegalStateException("Frame is not selected; call setFrameLocator(selector) first");
        return current;
    }
    public void setFrameLocator(String selector) {
        if (selector == null || selector.isBlank()) throw new IllegalArgumentException("Frame selector must not be blank");
        if (getPage() == null) throw new IllegalStateException("Create a browser page before selecting a frame");
        frameLocator.set(getPage().frameLocator(selector));
    }
    public void clearFrameLocator() { frameLocator.remove(); }
    public Playwright getPlaywright() { return playwright.get(); }

    protected static RuntimeException attemptClose(RuntimeException error, Runnable action) {
        try { action.run(); } catch (RuntimeException e) {
            if (error == null) error = new IllegalStateException("Resource cleanup failed");
            error.addSuppressed(e);
        }
        return error;
    }
    protected void closeBrowserResources() {
        RuntimeException error = null;
        try {
            for (var entry : dialogHandlers.get().entrySet()) {
                error = attemptClose(error, () -> {
                    if (!entry.getKey().isClosed()) entry.getKey().offDialog(entry.getValue());
                });
            }
            if (getContext() != null) error = attemptClose(error, getContext()::close);
            if (getDriver() != null) error = attemptClose(error, getDriver()::close);
            if (getPlaywright() != null) error = attemptClose(error, getPlaywright()::close);
        } finally {
            page.remove(); secondPage.remove(); frameLocator.remove(); context.remove();
            contextOptions.remove(); driver.remove(); playwright.remove(); clearScenarioData();
            dialogHandlers.remove();
        }
        if (error != null) throw error;
    }
}
