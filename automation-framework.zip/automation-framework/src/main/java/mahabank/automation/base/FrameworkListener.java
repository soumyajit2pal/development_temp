package mahabank.automation.base;
import org.testng.*;
/** Configuration failures must appear even when the test body never starts. */
public final class FrameworkListener implements IConfigurationListener {
    @Override public void onConfigurationFailure(ITestResult result) {
        if(result.getInstance() instanceof ProjectHooks hooks) {
            hooks.startTestCase(result.getTestClass().getName()+" configuration", "");
            if(result.getThrowable()!=null) hooks.getTest().fail(result.getThrowable());
            hooks.endResultSnapshot();
        }
    }
}
