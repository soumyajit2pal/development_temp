package mahabank.automation.base;

import com.microsoft.playwright.Download;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.SelectOption;
import com.microsoft.playwright.options.WaitForSelectorState;
import mahabank.automation.config.ConfigurationManager;
import mahabank.automation.utility.HtmlReporter;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.Locator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import mahabank.automation.database.DatabaseClient;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;

/**
 * @author Soumyajit Pal
 */

public abstract class PlaywrightWrapper extends HtmlReporter {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightWrapper.class);
    /**
     * Load the URL on the browser launched
     *
     * @param url The http(s) URL that to be loaded on the browser
     * @return true if the load is successful else false
     */
    public boolean navigate(String url) {
        try {
            getPage().navigate(url);
            reportStep("Page navigation completed", "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;
    }

    public void AcceptDialog(){
        Page current = java.util.Objects.requireNonNull(getPage(), "Dialog handling requires a browser page");
        if (dialogHandlers.get().containsKey(current)) return;
        java.util.function.Consumer<com.microsoft.playwright.Dialog> handler = dialog -> {
            dialog.accept();
            reportStep(String.format("Dialog message: %s", dialog.message()), "INFO");
        };
        current.onDialog(handler);
        dialogHandlers.get().put(current, handler);
    }
    /**
     * Maximize the browser based on screen size
     * Presently there is no built-in method to invoke.
     */
    public void maximize() {
        try {
            GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
            getPage().setViewportSize(gd.getDisplayMode().getWidth(), gd.getDisplayMode().getHeight());
        } catch (HeadlessException e) {

        }
    }

    /**
     * Maximize the browser based on screen size
     * Presently there is no built-in method to invoke.
     */
    public void maximize(Page page) {
        try {
            GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
            page.setViewportSize(gd.getDisplayMode().getWidth(), gd.getDisplayMode().getHeight());
        } catch (HeadlessException e) {

        }
    }

    public void waitForTimeout(double timeout) {
        getPage().waitForTimeout(timeout);
    }

    /**
     * Query visibility immediately. Use waitForAppearance when appearance is required.
     *
     * @param locator The css / xpath / or playwright supported locator
     * @return true if the element is visible else false
     */
    public boolean isVisible(String locator) {
        return getPage().locator(locator).isVisible();
    }

    /**
     * Replace the value of an editable element.
     *
     * @param locator The locator to identify the element
     * @param value   The value to be entered in the text
     * @param name    The name of the text field (label)
     * @return true if the value is typed else false
     */
    public boolean type(String locator, String value, String name) {
        try {
            getPage().locator(locator).fill(value);
            reportStep("Filled field: " + name, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;
    }

    /**
     * Use this method to typing into an element, which may set its value.
     *
     * @param locator The locator to identify the element
     * @param value   The value to be entered in the text
     * @param name    The name of the text field (label)
     * @param index    The index of the locator
     * @return true if the value is typed else false
     */
    public boolean type(String locator, String value, String name, int index) {
        try {
            getPage().locator(locator).nth(index).fill(value);
            reportStep("Filled field: " + name, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;
    }

    /**
     * Use this method to typing into an element inside a frame, which may set its value.
     *
     * @param locator The locator to identify the element
     * @param value   The value to be entered in the text
     * @param name    The name of the text field (label)
     * @return true if the value is typed else false
     */
    public boolean typeInFrame(String locator, String value, String name) {
        try {
            getFrameLocator().locator(locator).fill(value);
            reportStep("Filled field: " + name, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;
    }

    /**
     * Use this method to typing into an element and perform <ENTER> key.
     *
     * @param locator The locator to identify the element
     * @param value   The value to be entered in the text
     * @param name    The name of the text field (label)
     * @return true if the value is typed else false
     */
    public boolean typeAndEnter(String locator, String value, String name) {
        try {
            Locator loc = getPage().locator(locator);
            loc.fill("");
            loc.pressSequentially(value);
            loc.press("Enter");
            reportStep("Filled field: " + name, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    public boolean typeAndTab(String locator, String value, String name) {
        try {
            Locator loc = getPage().locator(locator);
            loc.fill("");
            loc.pressSequentially(value);
            loc.press("Tab");
            reportStep("Filled field: " + name, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to upload a file into the chosen field.
     *
     * @param locator  The locator to identify the element where need to upload
     * @param fileName The file name (relative or absolute)
     * @param name     The name of the upload field (label)
     * @return true if the file is uploaded else false
     */
    public boolean uploadFile(String locator, String fileName, String name) {
        try {
            getPage().locator(locator).setInputFiles(Paths.get(fileName));
            reportStep("The text box: " + name + " is uploaded with file: " + fileName, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to click a button.
     *
     * @param locator The locator to identify the element
     * @param name    The name of the button field (label)
     * @return true if the button is clicked else false
     */
    public boolean click(String locator, String name) {
        return click(locator, name, "button");
    }

    public Locator getByText(String text) {
        Locator locator = getPage().getByText(text);
        reportStep("Getting Value By Text: " + text + " to perform action.", "pass");
        return locator;
    }

    /**
     * Use this method to click an element.
     *
     * @param locator The locator to identify the element
     * @param name    The name of the element field (label)
     * @param type    The type of the element such as link, element etc
     * @return true if the element is clicked else false
     */
    public boolean click(String locator, String name, String type) {
        try {
//            getPage().locator(locator).scrollIntoViewIfNeeded();
            getPage().locator(locator).click();
            reportStep("The " + type + " : " + name + " is clicked", "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to click an element.
     *
     * @param locator The locator to identify the element
     * @param name    The name of the element field (label)
     * @param type    The type of the element such as link, element etc
     * @param index    The index of the locator
     * @return true if the element is clicked else false
     */
    public boolean click(String locator, String name, String type, int index) {
        try {
//            getPage().locator(locator).nth(index).scrollIntoViewIfNeeded();
            getPage().locator(locator).nth(index).click();
            reportStep("The " + type + " : " + name + " is clicked", "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to click an element within a frame.
     *
     * @param locator The locator to identify the element
     * @param name    The name of the element field (label)
     * @param 'click' The type of the element such as link, element etc
     * @return true if the element is clicked else false
     */
    public boolean clickInFrame(String locator, String name) {
        try {
//            getFrameLocator().locator(locator).scrollIntoViewIfNeeded();
            getFrameLocator().locator(locator).click();
            reportStep("The button : " + name + " is clicked", "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;
    }

    /**
     * Use this method to check a checkbox.
     *
     * @param locator The locator to identify the checkbox
     * @param name    The name of the checkbox field (label)
     * @return true if the checkbox is checked else false
     */
    public boolean check(String locator, String name) {
        return setChecked(locator, true, name);
    }

    public boolean uncheck(String locator, String name) {
        return setChecked(locator, false, name);
    }

    public boolean setChecked(String locator, boolean checked, String name) {
        try {
            getPage().locator(locator).setChecked(checked);
            reportStep("The checkbox: " + name + (checked ? " is checked" : " is unchecked"), "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;
    }

    /**
     * Use this method to select a dropdown after click on dropdown and select by its text.
     *
     * @param locator The locator to identify the dropdown
     * @param text    The text to be selected in the dropdown
     * @param name    The name of the dropdown field (label)
     * @return true if the dropdown is selected else false
     */
    public boolean selectByClick(String locator, String text, String name) {
        try {
            click(locator, name);
            getPage().getByRole(AriaRole.OPTION, new Page.GetByRoleOptions().setName(text).setExact(true)).click();
            reportStep("The drop down : " + name + " is selected with text : <b>" + text+"</b>", "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to select a dropdown by its text.
     *
     * @param locator The locator to identify the dropdown
     * @param text    The text to be selected in the dropdown
     * @param name    The name of the dropdown field (label)
     * @return true if the dropdown is selected else false
     */
    public boolean selectByText(String locator, String text, String name) {
        try {
            getPage().locator(locator).selectOption(new SelectOption().setLabel(text));
            reportStep("The drop down : " + name + " is selected with text : " + text, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to select a dropdown by its text.
     *
     * @param locator The locator to identify the dropdown
     * @param text    The text to be selected in the dropdown
     * @param name    The name of the dropdown field (label)
     * @param index   index of the locator
     * @return true if the dropdown is selected else false
     */
    public boolean selectByText(String locator, String text, int index, String name) {
        try {
            getPage().locator(locator).nth(index).selectOption(new SelectOption().setLabel(text));
            reportStep("The drop down : " + name + " is selected with text : " + text, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to select a dropdown by its text.
     *
     * @param locator The locator to identify the dropdown
     * @param text    The text to be selected in the dropdown
     * @param name    The name of the dropdown field (label)
     * @param force
     * @return true if the dropdown is selected else false
     */
    public boolean selectByText(String locator, String text, String name, boolean force) {
        try {
            getPage().locator(locator).selectOption(new SelectOption().setLabel(text), new Locator.SelectOptionOptions().setForce(force));
            reportStep("The drop down : " + name + " is selected by Text : <b>" + text+"</b>", "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to select a dropdown by its value.
     *
     * @param locator The locator to identify the dropdown
     * @param value   The value based on which it to be selected in the dropdown
     * @param name    The name of the dropdown field (label)
     * @return true if the dropdown is selected else false
     */
    public boolean selectByValue(String locator, String value, String name) {
        try {
            getPage().locator(locator).selectOption(value);
            reportStep("The drop down : " + name + " is selected with value as : <b>" + value+"</b>", "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to select a dropdown by its value.
     *
     * @param locator The locator to identify the dropdown
     * @param value   The value based on which it to be selected in the dropdown
     * @param name    The name of the dropdown field (label)
     * @param index   index of the locator
     * @return true if the dropdown is selected else false
     */
    public boolean selectByValue(String locator, String value, int index, String name) {
        try {
            getPage().locator(locator).nth(index).selectOption(value);
            reportStep("The drop down : " + name + " is selected with value as : <b>" + value+"</b>", "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to select a dropdown by its index.
     *
     * @param 'locator' The locator to identify the dropdown
     * @param index     The index to be selected in the dropdown (starts at 0)
     * @param name      The name of the dropdown field (label)
     * @return true if the dropdown is selected else false
     */
    public boolean selectByIndex(String locatorId, int index, String name) {
        if (index < 0) throw new IllegalArgumentException("Dropdown index must not be negative; use selectByRandomIndex for random selection");
        try {
            getPage().locator(locatorId).selectOption(new SelectOption().setIndex(index));
            reportStep("The drop down : " + name + " is selected with index : " + index, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to select a dropdown by its index inside a frame.
     *
     * @param 'locator' The locator to identify the dropdown
     * @param index     The index to be selected in the dropdown (starts at 0)
     * @param name      The name of the dropdown field (label)
     * @return true if the dropdown is selected else false
     */
    public boolean selectByIndexInFrame(String locatorId, int index, String name) {
        if (index < 0) throw new IllegalArgumentException("Dropdown index must not be negative");
        try {
            getFrameLocator().locator(locatorId).selectOption(new SelectOption().setIndex(index));
            reportStep("The drop down : " + name + " is selected with index : " + index, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;

    }

    /**
     * Use this method to select a dropdown by the random index.
     *
     * @param locator The locator to identify the dropdown
     * @param name    The name of the dropdown field (label)
     * @return true if the dropdown is selected else false
     */
    public boolean selectByRandomIndex(String locator, String name) {
        Locator options = getPage().locator(locator).locator("option");
        options.first().waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.ATTACHED));
        int count = options.count();
        if (count < 2) throw new IllegalArgumentException("Random selection requires an option after the first placeholder");
        return selectByIndex(locator, ThreadLocalRandom.current().nextInt(1, count), name);
    }

    /**
     * Use this method to type and choose an element (that looks like dropdown)
     *
     * @param ddLocator     The Dropdown locator to identify the main select element
     * @param optionLocator The Option locator to identify the item element
     * @param option        The option to be entered in the text area
     * @param name          The name of the dropdown field (label)
     * @return true if the option is selected else false
     */
    public boolean clickAndType(String ddLocator, String optionLocator, String option, String name) {
        try {
            getPage().locator(ddLocator).click();
            Locator input = getPage().locator(optionLocator);
            input.fill("");
            input.pressSequentially(option);
            input.press("Enter");
            reportStep("The drop down : " + name + " is selected with value :" + option, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;
    }

    /**
     * Use this method to click and choose an element (that looks like dropdown)
     *
     * @param ddLocator     The Dropdown locator to identify the main select element
     * @param optionLocator The Option locator to identify the item element
     * @param option        The option to be selected in the dropdown
     * @param name          The name of the dropdown field (label)
     * @return true if the option is selected else false
     */
    public boolean clickAndChoose(String ddLocator, String optionLocator, String option, String name) {
        try {
            getPage().locator(ddLocator).click();
            getPage().locator(optionLocator).click();
            reportStep("The drop down : " + name + " is selected with value :" + option, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;
    }

    /**
     * Use this method to click and choose an element (that looks like dropdown) inside a frame
     *
     * @param ddLocator     The Dropdown locator to identify the main select element
     * @param optionLocator The Option locator to identify the item element
     * @param option        The option to be selected in the dropdown
     * @param name          The name of the dropdown field (label)
     * @return true if the option is selected else false
     */
    public boolean clickAndChooseInFrame(String ddLocator, String optionLocator, String option, String name) {
        try {
            getFrameLocator().locator(ddLocator).click();
            getFrameLocator().locator(optionLocator).click();
            reportStep("The drop down : " + name + " is selected with value :" + option, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;
    }

    /**
     * Use this method to mouse over an element
     *
     * @param locator The locator to identify the element
     * @param name    The name of the element (label)
     * @return true if the mouse over is done else false
     */
    public boolean mouseOver(String locator, String name) {
        try {
            getPage().locator(locator).hover();
            reportStep("The element : " + name + " is moused over successfully", "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Browser action failed: " + e.getMessage(), e);
        }
        return false;
    }

    /**
     * Use this method to get inner text of an element
     *
     * @param locator The locator to identify the element
     * @param 'name'  The name of the element (label)
     * @return true if the mouse over is done else false
     */
    public String getInnerText(String locator, int index) {
        return getPage().locator(locator).nth(index).innerText().trim();
    }
    public String getInnerText(String locator) {
        return getInnerText(locator, 0);
    }

    /**
     * Use this method to check if the element is enabled
     *
     * @param locator The locator to identify the element
     * @param 'name'  The name of the element (label)
     * @return true if the element is enabled else false
     */
    public boolean isEnabled(String locator) {
        return getPage().locator(locator).isEnabled();
    }

    /**
     * Use this method to check if the element is disabled
     *
     * @param locator The locator to identify the element
     * @return true if the element is disabled else false
     */
    public boolean isDisabled(String locator) {
        return getPage().locator(locator).isDisabled();
    }

    /**
     * Use this method to report if the element is disabled
     *
     * @param locator The locator to identify the element
     * @param 'name'  The name of the element (label)
     * @return true if the element is disabled else false
     */
    public boolean verifyDisabled(String locator, String label) {
        assertThat(getPage().locator(locator)).isDisabled();
        reportStep("Element is disabled: " + label, "pass");
        return true;
    }

    /**
     * Use this method to wait for the element to disappear
     *
     * @param locator The locator to identify the element
     * @return true if the element is disappeared else false
     */
    public boolean waitForDisappearance(String locator) {
        try {
            getPage().locator(locator).waitFor(new Locator.WaitForOptions().setTimeout(ConfigurationManager.configuration().timeout()).setState(WaitForSelectorState.HIDDEN));
            reportStep(String.format("Element <b>`%s`</b> is disappeared successfully", locator), "pass");
            return true;
        } catch (Exception e) {
            reportFailure("Element did not disappear: " + locator, e);
        }
        return false;
    }

    /**
     * Use this method to wait for the element to appear
     *
     * @param locator The locator to identify the element
     * @return true if the element is appeared else false
     */
    public boolean waitForAppearance(String locator) {
        try {
            getPage().locator(locator).waitFor(new Locator.WaitForOptions().setTimeout(ConfigurationManager.configuration().timeout()).setState(WaitForSelectorState.VISIBLE));
            reportStep("Element appeared: " + locator, "pass");
            return true;
        } catch (PlaywrightException e) {
            reportFailure("Element did not appear: " + locator, e);
        }
        return false;
    }

    /**
     * Use this method to report the correctness of the title
     *
     * @param title The title of the browser
     * @return true if the title matches the partial content else false
     */
    public boolean verifyTitle(String title) {
        assertThat(getPage()).hasTitle(java.util.regex.Pattern.compile(".*"+java.util.regex.Pattern.quote(title)+".*", java.util.regex.Pattern.DOTALL));
        reportStep("Title verified", "pass");
        return true;
    }

    /**
     * Use this method to report the correctness of the inner text (Exact Match)
     *
     * @param locator      The locator to identify the element
     * @param expectedText The expected text to be verified
     * @return true if the inner text matches else false
     */
    public boolean verifyExactText(String locator, String expectedText) {
        assertThat(getPage().locator(locator)).hasText(expectedText);
        reportStep("Text verified", "pass");
        return true;
    }

    /**
     * Use this method to report the correctness of the inner text (Partial Match)
     *
     * @param locator      The locator to identify the element
     * @param expectedText The expected text to be verified
     * @return true if the inner text matches the partial content else false
     */
    public boolean verifyPartialText(String locator, String expectedText) {
        assertThat(getPage().locator(locator)).containsText(expectedText);
        reportStep("Partial text verified", "pass");
        return true;
    }

    /**
     * Use this method return the text typed within a textbox/area
     *
     * @param locator The locator to identify the element
     * @return Returns the text typed
     */
    public String getInputText(String locator) {
        return getPage().locator(locator).inputValue();
    }


    /**
     * Use this method to report the correctness of the typed text (Partial Match)
     *
     * @param locator      The locator to identify the element
     * @param expectedText The expected text to be verified
     * @return true if the typed text matches the partial content else false
     */
    public boolean verifyInputText(String locator, String expectedText) {
        assertThat(getPage().locator(locator)).hasValue(expectedText);
        reportStep("Input verified", "pass");
        return true;
    }

    /**
     * Use this method to get the attribute of the element
     *
     * @param locator   The locator to identify the element
     * @param attribute The attribute of the element
     * @return The attribute value of the located element
     */
    public String getAttribute(String locator, String attribute) {
        return getPage().locator(locator).getAttribute(attribute);
    }

    /**
     * Use this method to verify attribute of the element (Partial Match)
     *
     * @param locator      The locator to identify the element
     * @param attribute    The attribute of the element
     * @param expectedText The expected attribute value of the located element
     * @return true if the attribute matches the partial content else false
     */
    public boolean verifyAttribute(String locator, String attribute, String expectedText) {
        assertThat(getPage().locator(locator)).hasAttribute(attribute, java.util.regex.Pattern.compile(".*"+java.util.regex.Pattern.quote(expectedText)+".*", java.util.regex.Pattern.DOTALL));
        reportStep("Attribute verified", "pass");
        return true;
    }

    /**
     * Use this method to verify attribute of the element (Partial Match) inside a frame
     *
     * @param locator      The locator to identify the element
     * @param attribute    The attribute of the element
     * @param expectedText The expected attribute value of the located element
     * @return true if the attribute matches the partial content else false
     */
    public boolean verifyAttributeInFrame(String locator, String attribute, String expectedText) {
        assertThat(getFrameLocator().locator(locator)).hasAttribute(attribute, java.util.regex.Pattern.compile(".*"+java.util.regex.Pattern.quote(expectedText)+".*", java.util.regex.Pattern.DOTALL));
        reportStep("Frame attribute verified", "pass");
        return true;
    }

//    private boolean reportVisibleSuccess(String locator, String name) {
////        getPage().locator(locator).scrollIntoViewIfNeeded();
//        reportStep("The element : " + name + " displayed as expected", "pass");
//        return true;
//    }
//
//    private boolean reportVisibleSuccess(Locator locator, String name) {
////        locator.scrollIntoViewIfNeeded();
//        reportStep("The element : " + name + " displayed as expected", "pass");
//        return true;
//    }

    /**
     * Use this method to verify visibility of the element
     *
     * @param locator The locator to identify the element
     */
    public void verifyDisplayed(String locator, String name) {
        assertThat(getPage().locator(locator)).isVisible();
        reportStep("The element :<b>"+name+"</b> is displayed as expected", "pass");
    }


    public void verifyDisplayed(Locator locator, String name) {
        assertThat(locator).isVisible();
        reportStep("The element :<b>"+name+"</b> is displayed as expected", "pass");
//
    }

    /**
     * Use this method to verify invisibility of the element
     *
     * @param locator The locator to identify the element
     * @param name    The name of the element field (label)
     */
    public void verifyNotDisplayed(String locator, String name) {
        assertThat(getPage().locator(locator)).not().isVisible();
        reportStep("The element :"+name+" is not displayed as expected", "pass");
    }

    public void verifyNotDisplayed(Locator locator, String name) {
        assertThat(locator).not().isVisible();
        reportStep("The element :"+name+" is not displayed as expected", "pass");
    }

    public void verifyIsEmpty(Locator locator, String name) {
        assertThat(locator).isEmpty();
        reportStep("The element :"+name+" is empty as expected", "pass");
    }

    public void verifyNotEmpty(Locator locator, String name) {
        assertThat(locator).not().isEmpty();
        reportStep("The element :"+name+" is not empty as expected", "pass");
    }

    /**
     * Use this method to manage the wait between actions with sleep
     *
     * @param type The type of wait - allowed : low, medium, high
     */
    @Deprecated
    protected void pause(String type) {
        long delay = switch (type.toLowerCase(java.util.Locale.ROOT)) {
            case "medium" -> ConfigurationManager.configuration().pauseMedium();
            case "high" -> ConfigurationManager.configuration().pauseHigh();
            default -> ConfigurationManager.configuration().pauseLow();
        };
        // Compatibility only; new tests should wait for a locator or response.
        getPage().waitForTimeout(delay);
    }

    /**
     * Use this while waiting for new page to open on performing action like click etc.
     *
     * @param currentPage - provide current page
     * @param action      - pass runnable action like `page.locator(locator).click()`
     *                    newPage for newly opened page
     *                    oldPage for previously opened page
     */

    public Map<String, Page> switchToOpenedPage(Page currentPage, Runnable action) {
        Page newPage = currentPage.waitForPopup(action);
        setPage(newPage);
        newPage.bringToFront();
        Map<String, Page> pageMap = new HashMap<>();
        pageMap.put("newPage", newPage);
        pageMap.put("oldPage", currentPage);
        return pageMap;
    }

//    public boolean handleDownloadOnClick(String _locator){
//        try {
//            Download download = getPage().waitForDownload(() -> {
//                click(_locator, "Download");
//            });
//            download.saveAs(Paths.get(System.getProperty("user.dir")+"\\download", download.suggestedFilename()));
//            reportStep("Download file saved, "+System.getProperty("user.dir")+"\\download\\"+download.suggestedFilename(), "pass");
//            return true;
//        } catch (PlaywrightException e) {
//            reportFailure("Browser action failed: " + e.getMessage(), e);
//        }
//        return false;
//    }


    /**
     * If the new name does not end with the original extension, append it.
     */
    private String ensureExtension(String originalName, String newName) {
        int dot = originalName.lastIndexOf('.');
        if (dot > 0) {
            String ext = originalName.substring(dot); // includes dot (e.g., ".xlsx")
            if (!newName.toLowerCase(Locale.ROOT).endsWith(ext.toLowerCase(Locale.ROOT))) {
                return newName + ext;
            }
        }
        return newName;
    }

    /**
     * If the target path already exists, appending a numeric suffix to avoid overwriting.
     * Example: "file.xlsx" → "file (1).xlsx", "file (2).xlsx", ...
     */
    private Path reserveUniqueDownloadPath(Path target) throws IOException {
        String fileName = target.getFileName().toString();
        Path dir = target.getParent();

        String base = fileName;
        String ext = "";
        int dot = fileName.lastIndexOf('.');
        if (dot > 0) {
            base = fileName.substring(0, dot);
            ext = fileName.substring(dot);
        }

        Path candidate = target;
        for (int i = 1; ; i++) {
            try { return Files.createFile(candidate); }
            catch (java.nio.file.FileAlreadyExistsException e) {
                candidate = dir.resolve(String.format(Locale.ROOT, "%s (%d)%s", base, i, ext));
            }
        }
    }


    public boolean handleDownloadOnClick(String locator, String desiredBaseName) {
        if (desiredBaseName == null || desiredBaseName.isBlank() || desiredBaseName.equals(".")
                || desiredBaseName.equals("..") || desiredBaseName.contains("/") || desiredBaseName.contains("\\"))
            throw new IllegalArgumentException("Download name must be a filename without directory separators");
        Path reserved = null;
        try {
            Download download = getPage().waitForDownload(() -> {
                click(locator, "Download");
            });

            String original = download.suggestedFilename();
            Path downloadDir = Paths.get(System.getProperty("user.dir"), "download");
            Files.createDirectories(downloadDir);
            String targetName = ensureExtension(original, desiredBaseName);
            Path targetPath = downloadDir.resolve(targetName);
            targetPath = reserveUniqueDownloadPath(targetPath);
            reserved = targetPath;
            download.saveAs(targetPath);
            reportStep("Download file saved: " + targetPath, "pass");
            return true;
        } catch (PlaywrightException | IOException e) {
            if (reserved != null) {
                try { Files.deleteIfExists(reserved); }
                catch (IOException cleanup) { e.addSuppressed(cleanup); }
            }
            reportFailure("Download failed: " + e.getMessage(), e);
            return false;
        }
    }


    /** Compatibility adapter; new tests should use the standalone DatabaseClient. */
    @Deprecated
    public class DatabaseManager implements AutoCloseable {
        private final String dbUrl;
        private final String dbUsername;
        private final String dbPassword;
        private final DatabaseClient client;
        private Connection connection;

        private DatabaseManager(String dbUrl, String dbUsername, String dbPassword) {
            this.dbUrl = dbUrl;
            this.dbUsername = dbUsername;
            this.dbPassword = dbPassword;
            client = new DatabaseClient(dbUrl, dbUsername, dbPassword);
        }

        /** Raw connection compatibility only; close the manager using try-with-resources. */
        @Deprecated
        public Connection getConnection() {
            try {
                if (connection == null || connection.isClosed()) {
                    connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
                }
                return connection;
            } catch (SQLException e) {
                throw new IllegalStateException("Database connection failed", e);
            }
        }

        /** Returns disconnected rows; connection and statement close before this method returns. */
        public ResultSet executeQuery(String query) { return executeQuery(query, new Object[0]); }

        public ResultSet executeQuery(String query, Object... parameters) {
            try {
                ResultSet rows = client.queryRows(query, parameters);
                reportStep("Database query completed", "pass");
                return rows;
            } catch (SQLException e) {
                throw new IllegalStateException("Database query failed", e);
            }
        }

        public int executeUpdate(String query) { return executeUpdate(query, new Object[0]); }

        public int executeUpdate(String query, Object... parameters) {
            try {
                int count = client.update(query, parameters);
                reportStep("Database update completed", "pass");
                return count;
            } catch (SQLException e) {
                throw new IllegalStateException("Database update failed", e);
            }
        }

        @Override public void close() {
            try {
                if (connection != null) connection.close();
            } catch (SQLException e) {
                throw new IllegalStateException("Database connection cleanup failed", e);
            } finally {
                connection = null;
            }
        }
    }

    @Deprecated
    public DatabaseManager getDatabaseManager(String dbUrl, String dbUsername, String dbPassword) {
        return new DatabaseManager(dbUrl, dbUsername, dbPassword);
    }
}
