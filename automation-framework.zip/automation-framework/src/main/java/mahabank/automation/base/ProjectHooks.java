package mahabank.automation.base;

import com.microsoft.playwright.*;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import mahabank.automation.config.ConfigurationManager;
import mahabank.automation.utility.ExcelUtil;
import mahabank.automation.utility.HtmlReporter;
import mahabank.automation.utility.TestCaseIdentity;
import org.testng.*;
import org.testng.annotations.*;
import java.lang.reflect.Method;
import java.nio.file.*;
import java.util.*;

@Listeners(FrameworkListener.class)
public class ProjectHooks extends PlaywrightWrapper {
    public static final String SANITY="Sanity", REGRESSION="Regression", SMOKE="Smoke";
    public static final String SEVERITY_P1="P1", SEVERITY_P2="P2", SEVERITY_P3="P3";
    public static final String DEPOSIT_ACCOUNT_OPENING="DEPOSIT_ACCOUNT_OPENING";
    public static final String DEPOSIT_TRANSACTIONS="DEPOSIT_TRANSACTION", CIF_HANDLE="CUSTOMER_ONBOARDING";
    protected static final ThreadLocal<Runnable> logoutAction = new ThreadLocal<>();
    private String browser;
    private boolean headless;
    private SessionScope sessionScope = SessionScope.METHOD;
    private long ownerThread;
    private final ThreadLocal<Path> artifactDirectory = new ThreadLocal<>();
    protected void registerLogoutAction(Runnable action) { logoutAction.set(action); }
    protected boolean requiresBrowser() { return true; }
    @BeforeSuite(alwaysRun=true)
    public void initSuite() { clearGlobalData(); startReport(); }
    @BeforeClass(alwaysRun=true)
    @Parameters({"browser","sessionScope"})
    public void setupBrowserConfig(@org.testng.annotations.Optional("") String browserParam, @org.testng.annotations.Optional("") String scopeParam, ITestContext testContext) {
        var config = ConfigurationManager.configuration();
        browser = BrowserFactory.normalizeBrowser(browserParam.isBlank() ? config.browser() : browserParam);
        headless = config.headless();
        String scope = scopeParam.isBlank() ? config.sessionScope() : scopeParam;
        try { sessionScope = SessionScope.valueOf(scope.trim().toUpperCase(Locale.ROOT)); }
        catch (RuntimeException e) { throw new IllegalArgumentException("sessionScope must be METHOD or CLASS",e); }
        if (sessionScope == SessionScope.CLASS) {
            var parallel = testContext.getCurrentXmlTest().getParallel();
            if (parallel == org.testng.xml.XmlSuite.ParallelMode.METHODS)
                throw new IllegalArgumentException("CLASS sessions cannot use parallel methods");
            ownerThread = Thread.currentThread().getId();
            createSession();
        }
    }
    public void init(Method method) {
        init(method, new Object[0]);
    }
    @BeforeMethod(alwaysRun=true)
    public void init(Method method, Object[] parameters) {
        HtmlReporter.clearTestReport(); clearScenarioData();
        startTestCase(method.getDeclaringClass().getSimpleName()+"."+method.getName(), "");
        setReportTestId(TestCaseIdentity.forMethod(method, parameters));
        try {
            artifactDirectory.set(Files.createDirectories(reportDirectory().resolve("artifacts").resolve(UUID.randomUUID().toString())));
            if (sessionScope == SessionScope.METHOD) createSession();
            else if (ownerThread != Thread.currentThread().getId())
                throw new IllegalStateException("CLASS session changed owner thread; use METHOD scope");
            if (getContext()!=null && ConfigurationManager.configuration().enableTracing())
                getContext().tracing().start(new Tracing.StartOptions().setScreenshots(true).setSnapshots(true).setSources(true));
        } catch (Exception e) {
            if (getTest()!=null) getTest().fail("Setup failed: "+escapeHtml(e.getClass().getSimpleName()));
            if (sessionScope == SessionScope.METHOD) try { closeResources(); } catch (RuntimeException cleanup) { e.addSuppressed(cleanup); }
            throw new IllegalStateException("Test setup failed",e);
        }
    }
    private void createSession() {
        try {
            if (requiresBrowser()) { initializeBrowser(browser); setupContextAndPage(); }
            else playwright.set(Playwright.create());
            PlaywrightAssertions.setDefaultAssertionTimeout(ConfigurationManager.configuration().timeoutAssertion());
        } catch (RuntimeException e) {
            try { closeResources(); } catch (RuntimeException cleanup) { e.addSuppressed(cleanup); }
            throw e;
        }
    }
    public void initializeBrowser(String name) { setDriver(name,headless); }
    protected void setupContextAndPage() {
        var config=ConfigurationManager.configuration();
        Browser.NewContextOptions options=new Browser.NewContextOptions()
            .setIgnoreHTTPSErrors(config.ignoreHttpsErrors()).setViewportSize(1440,900);
        if(config.enableVideoRecord()) options.setRecordVideoDir(reportDirectory().resolve("videos"));
        contextOptions.set(options); context.set(getDriver().newContext(options));
        getContext().setDefaultTimeout(config.timeout());
        setPage(getContext().newPage());
    }
    public void setRequestContext(String url) {
        java.net.URI base;
        try { base = java.net.URI.create(url); }
        catch (IllegalArgumentException | NullPointerException e) { throw new IllegalArgumentException("API base URL must be an absolute HTTP or HTTPS URL"); }
        if (base.getHost() == null || !("http".equalsIgnoreCase(base.getScheme()) || "https".equalsIgnoreCase(base.getScheme())))
            throw new IllegalArgumentException("API base URL must be an absolute HTTP or HTTPS URL");
        if (getPlaywright() == null) throw new IllegalStateException("Playwright session is not initialized; create the API context during test setup");
        APIRequestContext previous = getRequestContext();
        requestContext.remove(); baseURI_API.remove();
        if (previous != null) previous.dispose();
        requestContext.set(getPlaywright().request().newContext(new APIRequest.NewContextOptions()
            .setBaseURL(url).setTimeout(ConfigurationManager.configuration().timeout())
            .setIgnoreHTTPSErrors(ConfigurationManager.configuration().ignoreHttpsErrors())
            .setExtraHTTPHeaders(Map.of("Content-Type","application/json","Accept","application/json"))));
        baseURI_API.set(url);
    }
    @Override public String takeSnap() {
        if(getPage()==null || getPage().isClosed()) return null;
        return Base64.getEncoder().encodeToString(getPage().screenshot());
    }
    @AfterMethod(alwaysRun=true)
    public void tearDown(ITestResult result) {
        RuntimeException error=null;
        try {
            if(getTest()!=null) {
                if(result.getStatus()==ITestResult.FAILURE) getTest().fail(result.getThrowable());
                else if(result.getStatus()==ITestResult.SKIP) getTest().skip("Test skipped; inspect TestNG configuration results");
                else getTest().pass("Test completed");
            }
            if(result.getStatus()==ITestResult.FAILURE && getPage()!=null && !getPage().isClosed()) {
                error=attemptClose(error,()-> {
                    getPage().screenshot(new Page.ScreenshotOptions().setPath(artifactDirectory.get().resolve("failure.png")).setFullPage(true));
                    if(getTest()!=null) getTest().addScreenCaptureFromPath("artifacts/"+artifactDirectory.get().getFileName()+"/failure.png");
                });
            }
            if(getContext()!=null && ConfigurationManager.configuration().enableTracing()) {
                error=attemptClose(error,()-> {
                    if(result.getStatus()==ITestResult.FAILURE && artifactDirectory.get()!=null)
                        getContext().tracing().stop(new Tracing.StopOptions().setPath(artifactDirectory.get().resolve("trace.zip")));
                    else getContext().tracing().stop();
                });
            }
            Runnable logout=logoutAction.get();
            if(logout!=null) error=attemptClose(error,logout);
        } finally {
            logoutAction.remove(); artifactDirectory.remove(); clearScenarioData(); ExcelUtil.clearLegacyReader();
            if(sessionScope==SessionScope.METHOD) error=attemptClose(error,this::closeResources);
            if(error!=null && getTest()!=null) getTest().fail("Teardown failed: "+escapeHtml(error.toString()));
            HtmlReporter.clearTestReport();
        }
        if(error!=null) throw error;
    }
    @AfterClass(alwaysRun=true)
    public void classLevelCleanup() { if(sessionScope==SessionScope.CLASS) closeResources(); }
    protected void closeResources() { disposeResources(); }
    @AfterSuite(alwaysRun=true)
    public void generateReport() { try { endResult(); } finally { clearGlobalData(); } }
    public String getUploadDocumentPath() {
        String configured=ConfigurationManager.configuration().uploadDocumetPath();
        if (configured == null || configured.isBlank()) throw new IllegalArgumentException("upload.path must not be blank");
        String portable = configured.replace('\\', '/');
        Path directory = Path.of(portable);
        // Preserve the original '/src/...' project-relative setting.
        if (!directory.isAbsolute() || portable.startsWith("/src/"))
            directory = Path.of(System.getProperty("user.dir")).resolve(portable.replaceFirst("^/+", ""));
        return directory.toAbsolutePath().normalize().toString();
    }
    public Path resolveUploadDocument(String filename) {
        if (filename == null || filename.isBlank()) throw new IllegalArgumentException("Upload filename must not be blank");
        Path directory = Path.of(getUploadDocumentPath());
        String relative = filename.replace('\\', '/').replaceFirst("^/+", "");
        Path document = directory.resolve(relative).normalize();
        if (!document.startsWith(directory)) throw new IllegalArgumentException("Upload document must be within upload.path");
        if (!Files.isRegularFile(document)) throw new IllegalArgumentException("Upload document does not exist: " + document);
        return document;
    }
    public enum SessionScope { METHOD, CLASS }
}
