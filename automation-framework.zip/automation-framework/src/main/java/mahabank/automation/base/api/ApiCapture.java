package mahabank.automation.base.api;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.Response;
import java.util.*;
import java.util.function.Consumer;

/** Passive response capture, confined to the current thread and browser page. */
public abstract class ApiCapture extends ApiMocker {
    private static final ThreadLocal<CaptureState> capture = new ThreadLocal<>();

    private record Captured(long sequence, Map<String, Object> details, RuntimeException bodyError) {}
    private static final class CaptureState {
        final Page page;
        final Set<String> patterns = new LinkedHashSet<>();
        final Map<String, Integer> counters = new HashMap<>();
        final List<Captured> responses = new ArrayList<>();
        final Consumer<Response> listener = this::recordResponse;
        long sequence;

        CaptureState(Page page) { this.page = page; }
        void recordResponse(Response response) {
            String url = response.url();
            if (patterns.stream().noneMatch(pattern -> url.matches(globRegex(pattern)))) return;
            long order = ++sequence;
            int count = counters.merge(url, 1, Integer::sum);
            String body = "";
            RuntimeException bodyError = null;
            try { body = response.text(); }
            catch (RuntimeException e) { bodyError = e; }
            responses.add(new Captured(order, Map.of("status", response.status(), "url", url,
                    "body", body, "counter", count), bodyError));
        }
    }

    public void initApiInterception() {
        currentCapture();
        reportStep("API interception initialized", "pass");
    }

    public void interceptApi(String urlPattern) {
        requirePattern(urlPattern);
        currentCapture().patterns.add(urlPattern);
        // Listening to responses must not install a route that bypasses existing mocks.
        reportStep("Started API interception for: " + urlPattern, "pass");
    }

    public Map<String, Object> getApiResponse(String urlPattern, Integer count) {
        requirePattern(urlPattern);
        if (count != null && count <= 0) throw new IllegalArgumentException("Response count must be greater than zero");
        CaptureState state = capture.get();
        if (state == null || state.page != getPage()) throw new IllegalStateException("No API capture exists for the current page");
        List<Captured> matches = state.responses.stream()
                .filter(item -> ((String) item.details().get("url")).matches(globRegex(urlPattern)))
                .filter(item -> count == null || Objects.equals(item.details().get("counter"), count))
                .toList();
        if (matches.isEmpty()) throw new IllegalStateException("No API response found for the requested pattern/count");
        if (count != null && matches.size() > 1)
            throw new IllegalArgumentException("Response count is per URL; use an exact URL when the pattern matches several URLs");
        Captured latest = matches.stream().max(Comparator.comparingLong(Captured::sequence)).orElseThrow();
        if (latest.bodyError() != null) throw new IllegalStateException("Unable to read captured response body", latest.bodyError());
        return latest.details();
    }

    public Response waitForApi(String urlContains, int expectedStatus, Runnable action) {
        if (urlContains == null || urlContains.isBlank()) throw new IllegalArgumentException("URL fragment must not be blank");
        if (expectedStatus < 100 || expectedStatus > 599) throw new IllegalArgumentException("Status must be from 100 to 599");
        return getPage().waitForResponse(response -> response.url().contains(urlContains)
                && response.status() == expectedStatus, Objects.requireNonNull(action, "API action is required"));
    }

    public void resetApiCapture() {
        CaptureState state = capture.get();
        if (state != null) {
            state.patterns.clear(); state.counters.clear(); state.responses.clear(); state.sequence = 0;
        }
        reportStep("API capture data reset", "pass");
    }

    /** Called before browser/request disposal; detaches the response listener as well as clearing data. */
    public static void clearApiCapture() {
        CaptureState state = capture.get();
        try {
            if (state != null && !state.page.isClosed()) state.page.offResponse(state.listener);
        } finally { capture.remove(); }
    }

    private CaptureState currentCapture() {
        Page currentPage = Objects.requireNonNull(getPage(), "API response capture requires a browser page");
        CaptureState state = capture.get();
        if (state == null || state.page != currentPage) {
            clearApiCapture();
            state = new CaptureState(currentPage);
            currentPage.onResponse(state.listener);
            capture.set(state);
        }
        return state;
    }

    private static void requirePattern(String pattern) {
        if (pattern == null || pattern.isBlank()) throw new IllegalArgumentException("API URL pattern must not be blank");
    }

    /** Supported URL glob subset: '*' stays within a path segment; '**' crosses '/'. */
    public static String globRegex(String glob) {
        Objects.requireNonNull(glob, "URL glob is required");
        StringBuilder regex = new StringBuilder("^");
        for (int i = 0; i < glob.length(); i++) {
            char c = glob.charAt(i);
            if (c == '*') {
                if (i + 1 < glob.length() && glob.charAt(i + 1) == '*') { regex.append(".*"); i++; }
                else regex.append("[^/]*");
            } else regex.append(java.util.regex.Pattern.quote(String.valueOf(c)));
        }
        return regex.append('$').toString();
    }
}
