package mahabank.automation.base.api;

import com.microsoft.playwright.APIRequestContext;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.options.RequestOptions;
import mahabank.automation.base.BrowserFactory;

import java.util.Map;


public class ApiFactory extends BrowserFactory {

    protected static final ThreadLocal<APIRequestContext> requestContext = new ThreadLocal<APIRequestContext>();
    protected static final ThreadLocal<String> baseURI_API = new ThreadLocal<String>();

    public String getBaseURIAPI(){
        return baseURI_API.get();
    }

    public APIRequestContext getRequestContext() {
        return requestContext.get();
    }


    public APIResponse get(String endpoint) {

        return requireRequestContext().get(endpoint);
    }

    public APIResponse get(String endpoint,
                           Map<String, String> headers) {
        RequestOptions options = RequestOptions.create();
        headers.forEach(options::setHeader);
        return requireRequestContext().get(
                endpoint,
               options);
    }

    public APIResponse post(String endpoint,
                            String payload) {

        return requireRequestContext().post(
                endpoint,
                RequestOptions.create()
                        .setData(payload)
        );
    }

    public APIResponse put(String endpoint,
                           String payload) {

        return requireRequestContext().put(
                endpoint,
                RequestOptions.create()
                        .setData(payload)
        );
    }

    public APIResponse delete(String endpoint) {

        return requireRequestContext().delete(endpoint);
    }

    private APIRequestContext requireRequestContext() {
        APIRequestContext current = getRequestContext();
        if (current == null) throw new IllegalStateException("API request context is not initialized; call setRequestContext(baseUrl) during test setup");
        return current;
    }

    protected void disposeResources() {
        RuntimeException error = null;
        try {
            error = attemptClose(error, ApiCapture::clearApiCapture);
            if (getRequestContext() != null) error = attemptClose(error, getRequestContext()::dispose);
        } finally {
            requestContext.remove(); baseURI_API.remove();
            error = attemptClose(error, this::closeBrowserResources);
        }
        if (error != null) throw error;
    }
}
