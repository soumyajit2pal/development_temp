package mahabank.automation.base.api;

import com.microsoft.playwright.Route;

import java.nio.file.Files;
import java.nio.file.Path;

public abstract class ApiMocker extends ApiValidator {

    public void mockApi(String urlPattern, String jsonResponse) {
        getPage().route(urlPattern, route -> route.fulfill(
                new Route.FulfillOptions()
                        .setStatus(200)
                        .setContentType("application/json")
                        .setBody(jsonResponse)
        ));

        reportStep("Mocking API with URL pattern: " + urlPattern, "pass");
    }

    public void mockApiFromFile(String urlPattern, String filePath) {
        String body;
        try { body = Files.readString(Path.of(filePath)); }
        catch (java.io.IOException e) {
            reportFailure("Unable to read mock JSON file: " + filePath, e);
            return;
        }
        mockApi(urlPattern, body);
    }

    public void conditionalMock(String urlPattern, String contains, String responseIfMatch, String responseElse) {
        getPage().route(urlPattern, route -> {
            String requestUrl = route.request().url();
            String responseBody = requestUrl.contains(contains) ? responseIfMatch : responseElse;

            route.fulfill(new Route.FulfillOptions()
                    .setStatus(200)
                    .setContentType("application/json")
                    .setBody(responseBody));
        });

        reportStep("Conditional mock added for URL pattern: " + urlPattern, "pass");
    }

    public void mockErrorResponse(String urlPattern, int statusCode, String errorBody) {
        getPage().route(urlPattern, route -> route.fulfill(
                new Route.FulfillOptions()
                        .setStatus(statusCode)
                        .setContentType("application/json")
                        .setBody(errorBody)
        ));

        reportStep("Mocking error response for URL pattern: " + urlPattern, "pass");
    }

    public void allowRealApi(String urlPattern) {
        getPage().route(urlPattern, Route::resume);
        reportStep("Allowing real API for URL pattern: " + urlPattern, "pass");
    }
}

