package mahabank.automation.base.api;
import mahabank.automation.base.ProjectHooks;
/** API tests create Playwright's request engine without launching a browser. */
public class ApiProjectHooks extends ProjectHooks {
    @Override protected boolean requiresBrowser() { return false; }
}
