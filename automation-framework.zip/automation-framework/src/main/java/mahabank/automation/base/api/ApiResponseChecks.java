package mahabank.automation.base.api;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Response;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;

/** Exact HTTP and typed JSON assertions, usable without lifecycle or reporting inheritance. */
public final class ApiResponseChecks {
    private static final ObjectMapper JSON = new ObjectMapper()
            .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
            .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
            .enable(JsonParser.Feature.STRICT_DUPLICATE_DETECTION);

    private final int status;
    private final Map<String, String> headers;
    private final Supplier<String> body;
    private JsonNode document;

    private ApiResponseChecks(int status, Map<String, String> headers, Supplier<String> body) {
        this.status = status;
        this.headers = Map.copyOf(headers);
        this.body = body;
    }

    /** Caller retains ownership of the response and must dispose it when finished. */
    public static ApiResponseChecks assertThat(APIResponse response) {
        Objects.requireNonNull(response, "API response is required");
        return new ApiResponseChecks(response.status(), response.headers(), response::text);
    }

    public static ApiResponseChecks assertThat(Response response) {
        Objects.requireNonNull(response, "Browser response is required");
        return new ApiResponseChecks(response.status(), response.headers(), response::text);
    }

    public ApiResponseChecks hasStatus(int expected) {
        if (expected < 100 || expected > 599) throw new IllegalArgumentException("Expected status must be from 100 to 599");
        if (status != expected) throw new AssertionError("Expected HTTP status " + expected + " but received " + status);
        return this;
    }

    public ApiResponseChecks hasJsonContentType() {
        String mediaType = headers.entrySet().stream()
                .filter(entry -> entry.getKey().equalsIgnoreCase("Content-Type"))
                .map(Map.Entry::getValue).findFirst().orElse("")
                .split(";", 2)[0].trim().toLowerCase(Locale.ROOT);
        if (!mediaType.equals("application/json") && !(mediaType.startsWith("application/") && mediaType.endsWith("+json"))) {
            throw new AssertionError("Expected a JSON Content-Type header");
        }
        return this;
    }

    /** Requires a present, non-null field at a JSON Pointer, e.g. /data/accounts/0/id. */
    public ApiResponseChecks hasField(String pointer) {
        field(pointer);
        return this;
    }

    public ApiResponseChecks hasText(String pointer, String expected) {
        Objects.requireNonNull(expected, "Expected text is required");
        JsonNode value = field(pointer);
        if (!value.isTextual() || !value.textValue().equals(expected)) throw mismatch(pointer, "string");
        return this;
    }

    public ApiResponseChecks hasNumber(String pointer, BigDecimal expected) {
        Objects.requireNonNull(expected, "Expected number is required");
        JsonNode value = field(pointer);
        if (!value.isNumber() || value.decimalValue().compareTo(expected) != 0) throw mismatch(pointer, "number");
        return this;
    }

    public ApiResponseChecks hasBoolean(String pointer, boolean expected) {
        JsonNode value = field(pointer);
        if (!value.isBoolean() || value.booleanValue() != expected) throw mismatch(pointer, "boolean");
        return this;
    }

    public ApiResponseChecks hasArraySize(String pointer, int expected) {
        if (expected < 0) throw new IllegalArgumentException("Expected array size must not be negative");
        JsonNode value = field(pointer);
        if (!value.isArray() || value.size() != expected) throw mismatch(pointer, "array of size " + expected);
        return this;
    }

    private JsonNode field(String pointer) {
        if (pointer == null || (!pointer.isEmpty() && !pointer.startsWith("/"))) {
            throw new IllegalArgumentException("Use a JSON Pointer beginning with '/', or an empty pointer for the root");
        }
        if (document == null) {
            try {
                document = JSON.readTree(body.get());
            } catch (IOException e) {
                // Parser diagnostics can include body fragments; assertion messages omit payload data.
                throw new AssertionError("Response body is not a single valid JSON document");
            }
            if (document == null) throw new AssertionError("Response body is empty");
        }
        JsonNode value = document.at(pointer);
        if (value.isMissingNode() || value.isNull()) throw new AssertionError("Required JSON field is missing or null at '" + pointer + "'");
        return value;
    }

    private static AssertionError mismatch(String pointer, String type) {
        return new AssertionError("JSON field at '" + pointer + "' must match the expected " + type);
    }
}
