package mahabank.automation.base.api;

import com.microsoft.playwright.Response;
import mahabank.automation.utility.HtmlReporter;
import org.json.JSONObject;

public abstract class ApiValidator extends HtmlReporter {

    public String getResponseBody(Response response) {
        try {
            return response.text();
        } catch (Exception e) {
            throw new RuntimeException("Unable to read response body", e);
        }
    }

    public String getValueFromJson(String json, String key) {
        JSONObject obj = new JSONObject(json);

        if (!obj.has(key)) {
            throw new RuntimeException("Key not found in JSON: " + key);
        }

        return String.valueOf(obj.get(key));
    }

    public boolean isKeyPresent(String json, String key) {
        JSONObject obj = new JSONObject(json);
        return obj.has(key);
    }

    public int getStatusCode(Response response) {
        return response.status();
    }

    public boolean isStatusCode(Response response, int expectedStatusCode) {
        return response.status() == expectedStatusCode;
    }
}

