package mahabank.automation.base.api;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class ApiWrapper extends ApiCapture {
    private static final Logger log = LoggerFactory.getLogger(ApiWrapper.class);

    @Override
    public String takeSnap() {
        return null;
    }
}
