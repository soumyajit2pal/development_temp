package mahabank.automation.config.CBS;

import org.aeonbits.owner.Config;

@Config.Sources({"classpath:CBS/app.properties"})
public interface CBSConfig extends Config {
    @Key("app.url.base")
    String baseUrl();

    @Key("app.username")
    String appUserName();

    @Key("app.password")
    String appPassword();

    @Key("app.branchname")
    String appBranchName();

    @Key("app.username.CHECKER")
    String appUserNameChecker();

    @Key("app.password.CHECKER")
    String appPasswordChecker();

    @Key("app.branchname.CHECKER")
    String appBranchNameChecker();

}
