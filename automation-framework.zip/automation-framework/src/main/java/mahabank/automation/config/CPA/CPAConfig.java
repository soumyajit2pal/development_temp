package mahabank.automation.config.CPA;
import org.aeonbits.owner.Config;


@Config.Sources({"classpath:CPA/app.properties"})
public interface CPAConfig extends Config{
    @Key("app.url.base")
    String baseUrl();

    @Key("app.username.Maker")
    String appMakerPf();

    @Key("app.username.Checker")
    String appCheckerPf();

    @Key("app.zoneCode.Maker")
    String appZoneCodeMaker();

    @Key("app.zoneCode.Checker")
    String appZoneCodeChecker();

    @Key("app.branchCode.Maker")
    String appBranchCodeMaker();

    @Key("app.branchCode.Checker")
    String appBranchCodeChecker();
}
