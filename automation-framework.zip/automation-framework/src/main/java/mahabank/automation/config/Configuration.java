package mahabank.automation.config;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Accessible;
import org.aeonbits.owner.Config.LoadPolicy;
import org.aeonbits.owner.Config.LoadType;

/**
 * @author Soumyajit Pal
 */

@LoadPolicy(LoadType.MERGE)
@Config.Sources({
        "classpath:base.properties",
        "classpath:report.properties"})
public interface Configuration extends Accessible {
    @Key("ignore.https.errors")
    @DefaultValue("false")
    boolean ignoreHttpsErrors();

    @Key("browser")
    String browser();

    @Key("headless")
    Boolean headless();

    @Key("timeout")
    int timeout();

    @Key("timeout.assertion")
    int timeoutAssertion();

    @Key("faker.locale")
    String faker();

    @Key("auto.login")
    boolean autoLogin();

    @Key("enable.tracing")
    boolean enableTracing();

    @Key("action.delay")
    double slowMotion();

    @Key("pause.low")
    long pauseLow();

    @Key("pause.medium")
    long pauseMedium();

    @Key("pause.high")
    long pauseHigh();

    @Key("max.retry")
    int maxRetry();

    @Key("report.title")
    String reportTitle();

    @Key("report.name")
    String reportName();

    @Key("report.theme")
    String reportTheme();

    @Key("session.scope")
    String sessionScope();

    @Key("upload.path")
    String uploadDocumetPath();

    @Key("video.record")
    boolean enableVideoRecord();
}
