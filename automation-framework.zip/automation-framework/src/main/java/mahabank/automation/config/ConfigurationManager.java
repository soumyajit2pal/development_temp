package mahabank.automation.config;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.ConfigFactory;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.lang.reflect.Method;

/** Precedence: JVM property, environment, then classpath defaults. */
public final class ConfigurationManager {
    private static final Map<Class<? extends Config>, Config> instances = new ConcurrentHashMap<>();
    private ConfigurationManager() {}
    public static Configuration configuration() { return getOrCreate(Configuration.class); }
    public static <T extends Config> T getOrCreate(Class<T> type) {
        return type.cast(instances.computeIfAbsent(type, ConfigurationManager::create));
    }
    private static Config create(Class<? extends Config> type) {
        Map<String,String> overrides = new HashMap<>();
        Config.Sources sources = type.getAnnotation(Config.Sources.class);
        String app = "";
        if (sources != null) for (String source : sources.value()) {
            String file = source.replace("classpath:", "");
            if (file.contains("/")) { app = file.substring(0,file.indexOf('/')); break; }
        }
        for (Method method : type.getMethods()) {
            Config.Key annotation = method.getAnnotation(Config.Key.class);
            if (annotation == null) continue;
            String key = annotation.value();
            String qualified = app.isEmpty() ? key : app + "." + key;
            String envKey = qualified.replaceAll("[^A-Za-z0-9]", "_").toUpperCase(Locale.ROOT);
            String value = System.getProperty(qualified);
            if (value == null && !qualified.equals(key)) value = System.getProperty(key);
            if (value == null) value = System.getenv(envKey);
            if (value != null) overrides.put(key,value);
        }
        Config config = ConfigFactory.create(type, overrides);
        if (config instanceof Configuration framework) ConfigurationValidator.validate(framework);
        return config;
    }
    /** For controlled reconfiguration between runs; don't call during a parallel suite. */
    public static void clearCache() { instances.clear(); }
}
