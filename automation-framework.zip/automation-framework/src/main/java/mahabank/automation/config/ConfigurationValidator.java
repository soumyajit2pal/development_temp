package mahabank.automation.config;

import java.util.Locale;
import java.util.Set;

/** Validates framework settings before a report or Playwright session is created. */
final class ConfigurationValidator {
    private ConfigurationValidator() {}

    static void validate(Configuration config) {
        requireChoice(config, "browser", Set.of("chromium", "chrome", "edge", "firefox", "webkit", "safari"));
        requireChoice(config, "session.scope", Set.of("method", "class"));
        requireChoice(config, "report.theme", Set.of("light", "standard", "dark"));
        for (String key : Set.of("headless", "auto.login", "enable.tracing", "video.record", "ignore.https.errors")) {
            String value = config.getProperty(key);
            if (!"true".equalsIgnoreCase(value) && !"false".equalsIgnoreCase(value)) {
                throw invalid(key, "must be true or false");
            }
        }
        requireInteger(config, "timeout", 1, Integer.MAX_VALUE);
        requireInteger(config, "timeout.assertion", 1, Integer.MAX_VALUE);
        requireInteger(config, "pause.low", 0, Long.MAX_VALUE);
        requireInteger(config, "pause.medium", 0, Long.MAX_VALUE);
        requireInteger(config, "pause.high", 0, Long.MAX_VALUE);
        requireInteger(config, "max.retry", 0, Integer.MAX_VALUE);
        try {
            double delay = Double.parseDouble(config.getProperty("action.delay"));
            if (!Double.isFinite(delay) || delay < 0) throw invalid("action.delay", "must be a finite, nonnegative number");
        } catch (NullPointerException | NumberFormatException e) {
            throw invalid("action.delay", "must be a finite, nonnegative number");
        }
    }

    private static void requireChoice(Configuration config, String key, Set<String> choices) {
        String value = config.getProperty(key);
        if (value == null || !choices.contains(value.trim().toLowerCase(Locale.ROOT))) {
            throw invalid(key, "has an unsupported value");
        }
    }

    private static void requireInteger(Configuration config, String key, long minimum, long maximum) {
        try {
            long value = Long.parseLong(config.getProperty(key));
            if (value < minimum || value > maximum) throw invalid(key, "must be an integer from " + minimum + " to " + maximum);
        } catch (NumberFormatException e) {
            throw invalid(key, "must be an integer from " + minimum + " to " + maximum);
        }
    }

    private static IllegalArgumentException invalid(String key, String requirement) {
        return new IllegalArgumentException("Configuration '" + key + "' " + requirement);
    }
}
