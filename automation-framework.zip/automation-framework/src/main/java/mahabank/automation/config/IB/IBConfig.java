package mahabank.automation.config.IB;

import org.aeonbits.owner.Config;

@Config.Sources({"classpath:IB/app.properties"})
public interface IBConfig extends Config {
    @Key("app.url.base")
    String baseUrl();

    @Key("app.username")
    String appUserName();

    @Key("app.password")
    String appPassword();
}
