package mahabank.automation.config.InwardOutward;
import org.aeonbits.owner.Config;


@Config.Sources({"classpath:InwardOutward/app.properties"})
public interface InwardOutwardConfig extends Config{
    @Config.Key("app.url.base")
    String baseUrl();

    @Config.Key("app.username")
    String appUserName();

    @Config.Key("app.password")
    String appPassword();
}
