package mahabank.automation.config.OTAPI;
import org.aeonbits.owner.Config;

@Config.Sources({"classpath:OTAPI/app.properties"})
public interface  OTAPIConfig extends Config{
    @Config.Key("app.api.url.base")
    String baseAPIUrl();
}
