package mahabank.automation.data.dynamic;

import net.datafaker.Faker;
import java.util.Locale;
import static mahabank.automation.config.ConfigurationManager.configuration;

public class TestDataGenerator {

    private final Faker faker;

    public TestDataGenerator() {
        this.faker = new Faker(new Locale(configuration().faker()));
    }

    public String getFullName() {
        return (faker.name().firstName()+ " "+faker.name().lastName()).replace(".", "");
    }

    public String getAddress() {
        return faker.address().fullAddress();
    }

    public String getPhoneNumber() {
        return faker.phoneNumber().cellPhone();
    }

    public String getEmail() {
        return faker.internet().emailAddress();
    }

    public String getCompanyName() {
        return faker.company().name();
    }

    public String getJobTitle() {
        return faker.job().title();
    }

    public String getCity() {
        return faker.address().city();
    }

    public String getState() {
        return faker.address().state();
    }

    public String getCreditCard() {
        return faker.finance().creditCard();
    }

    public String getUniversity() {
        return faker.university().name();
    }

    public String getBankAccountNumber(int _length) {
        return "" + faker.number().randomNumber(_length, true);
    }

    // New method: Generate a random refusal reason
    public String getRefusalReason() {
        String[] reasons = {
                "Incomplete documentation",
                "Failed background check",
                "Insufficient credit score",
                "Eligibility criteria not met",
                "Duplicate application",
                "Policy violation",
                "Missing mandatory fields",
                "Invalid identification",
                "Exceeded submission limit",
                "Suspicious activity detected"
        };
        return reasons[faker.random().nextInt(reasons.length)];
    }
}

