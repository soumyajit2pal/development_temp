package mahabank.automation.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.sql.rowset.CachedRowSet;
import javax.sql.rowset.RowSetProvider;

/** Parameterized JDBC operations with a fresh connection and bounded resource lifetime. */
public final class DatabaseClient {
    @FunctionalInterface
    public interface ConnectionProvider {
        /** Return a connection owned by this operation; the client always closes it. */
        Connection open() throws SQLException;
    }

    @FunctionalInterface
    public interface RowMapper<T> {
        /** Map the current row to a detached value; do not retain the ResultSet. */
        T map(ResultSet row) throws SQLException;
    }

    private final ConnectionProvider connections;
    private final int queryTimeoutSeconds;

    public DatabaseClient(String url, String username, String password) {
        this(jdbcConnections(url, username, password), 30);
    }

    public DatabaseClient(ConnectionProvider connections, int queryTimeoutSeconds) {
        this.connections = Objects.requireNonNull(connections, "Connection provider is required");
        if (queryTimeoutSeconds <= 0) throw new IllegalArgumentException("Query timeout must be greater than zero");
        this.queryTimeoutSeconds = queryTimeoutSeconds;
    }

    private static ConnectionProvider jdbcConnections(String url, String username, String password) {
        if (url == null || !url.startsWith("jdbc:")) throw new IllegalArgumentException("A JDBC URL is required");
        return () -> DriverManager.getConnection(url, username, password);
    }

    public <T> List<T> query(String sql, RowMapper<T> mapper, Object... parameters) throws SQLException {
        Objects.requireNonNull(mapper, "Row mapper is required");
        requireSql(sql, parameters);
        try (Connection connection = connections.open();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            configure(statement, parameters);
            try (ResultSet rows = statement.executeQuery()) {
                List<T> result = new ArrayList<>();
                while (rows.next()) result.add(Objects.requireNonNull(mapper.map(rows), "Row mapper returned null"));
                return List.copyOf(result);
            }
        }
    }

    /** Compatibility with callers that require a ResultSet: returned rows have no live connection. */
    public CachedRowSet queryRows(String sql, Object... parameters) throws SQLException {
        requireSql(sql, parameters);
        CachedRowSet result = RowSetProvider.newFactory().createCachedRowSet();
        try (Connection connection = connections.open();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            configure(statement, parameters);
            try (ResultSet rows = statement.executeQuery()) {
                result.populate(rows);
            }
        } catch (SQLException | RuntimeException e) {
            try { result.close(); } catch (SQLException cleanup) { e.addSuppressed(cleanup); }
            throw e;
        }
        return result;
    }

    /** One update per connection using the connection provider's transaction settings. */
    public int update(String sql, Object... parameters) throws SQLException {
        requireSql(sql, parameters);
        try (Connection connection = connections.open();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            configure(statement, parameters);
            return statement.executeUpdate();
        }
    }

    private void configure(PreparedStatement statement, Object[] parameters) throws SQLException {
        statement.setQueryTimeout(queryTimeoutSeconds);
        for (int index = 0; index < parameters.length; index++) statement.setObject(index + 1, parameters[index]);
    }

    private static void requireSql(String sql, Object[] parameters) {
        if (sql == null || sql.isBlank()) throw new IllegalArgumentException("SQL must not be blank");
        Objects.requireNonNull(parameters, "Use an explicit (Object) null for a null SQL parameter");
    }
}
