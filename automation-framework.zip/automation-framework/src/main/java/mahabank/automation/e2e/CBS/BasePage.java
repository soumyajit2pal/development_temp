package mahabank.automation.e2e.CBS;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.options.WaitForSelectorState;
import mahabank.automation.base.ProjectHooks;
import mahabank.automation.utility.Utils;
import org.testng.Assert;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static mahabank.automation.e2e.CBS.CBSConstant.*;

public class BasePage extends ProjectHooks {
    //Queue Search
    public String executeQueueSearch = "#searchButton";
    public String authorise = "#UIPage_QueueSearch_authorise";
    public String queueAccept = "#UIPage_QueueSearch_accept";
    public String OK = "css=#ok-button";
    public String transmit = "xpath=//button[contains(text(), \"Transmit\")]";
    public String closePopup = "css=button[title=\"Close Pop-up\"] p";
    public String loader = "css=#loader";
    //    Customer Creation Alert
    public String alert = "ul li[role=\"alert\"]";
    public String queueItemNumber = "[name=\"multipleEnqTbl\"] p[name=\"queueItemID\"]";
    public String alertWindow = "//div[@class=\"modal-header\"]//div[text()=\"Alerts\"]";

    String userConsent = "css=#UIPage_Wiz_062001Personal_UserConsentbtn";
    String aggreeUserConsent = "css=#UIPage_UserConsent_chceckbox";
    String form61Consent = "#UIPage_UserConsent_cb_form60_61";
    String submitUserConsent = "css=#UIPage_UserConsent_submit";
    String alertMessageUserConsent = "//*[@id=\"UIPage_UserConsent_lblIAlertmsg\"]//..//..//input";

    public void waitForLoaderComplete() {
        getPage().locator(loader).waitFor(new Locator.WaitForOptions()
                .setState(WaitForSelectorState.HIDDEN)
                .setTimeout(55000));
    }

    public void validateBreadCrumbPageTitle(String title){
        String loc = "//h1[@class='page-title']";
        verifyDisplayed(getPage().locator(loc).filter(new Locator.FilterOptions().setHasText(title)), title);;
    }

    public void expandSideMenuOperations(String menu){
//        String loc = String.format("//a[@title='%s']/following-sibling::i", menu);
        String loc = String.format("//a[@title='%s']", menu);
        click(loc, menu);

    }

    public void clickMenuToOpenAndPerformActions(String action){
        String loc = String.format("//li//a[@title='%s']", action);
        click(loc, action);
    }

    public void submitTransmit() {
        click(transmit, "Submit Transmit");
    }

    public void clickFetchButton() {
        this.getByText("Fetch").click();
    }

    public void closePopUp() {
        if (getPage().locator(closePopup).isVisible()) {
            click(closePopup, "Close Popup");
        }
    }

    // Navigate to Tab
    public void navigateToTab(String tabname) {
        String tab = "[title*=\"" + tabname + "\"]:nth-child(1)";
        click(tab, "Tab: " + tabname);
    }

    public void clickOkay(){

        if(getPage().locator(alertWindow).isVisible()){
            verifyDisplayed(alertWindow, "Alert");
            click(OK, "OK");
        }
    }

    public void checkForm61Consent() {
        check(form61Consent, "Checkbox form61/61 form, from the customer.");
    }

    public void clickUserConsent() {
        click(userConsent, "User Consent");
    }

    public void checkAggreeUserConsent() {
        check(aggreeUserConsent, "Aggree User Consent");
    }

    public void checkAlertMessage(){
        check(alertMessageUserConsent, "Alert Message");
    }

    public void submitUserConsent() {
        click(submitUserConsent, "Submit User Consent");
    }

    public void completeUserConsent() {
        clickUserConsent();
        checkAggreeUserConsent();
    }

    public void completeUserConsentWhileNoPAN() {
        clickUserConsent();
        checkAggreeUserConsent();
        checkForm61Consent();
    }

    public String retrieveQueueAfterCreation() {
        verifyDisplayed(alertWindow, "Alert");
        String innerText = getInnerText(alert);
        reportStep(innerText, "INFO");
        return innerText;
    }

    /**
     * Use this while you want to grab queue number only from queue string.
     *
     * @param input - provide queue string
     */

    public String grabQueueNumberFromAlertMsg(String input) {
        ;
        Pattern pattern = Pattern.compile("Queue Reference: (\\d+)");
        Matcher matcher = pattern.matcher(input);
        String extractedNumber = "";
        if (matcher.find()) {
            extractedNumber = matcher.group(1);
            reportStep("Queue Number: " + extractedNumber, "Pass");
            clickOkay();
        }
        else {
            reportStep(String.format("Queue Number not found due to pattern mismatch. -> %s", input), "fail");
            clickOkay();
        }
        return extractedNumber;
    }

    /**
     * Use this while you want to grab account number only from alert success string.
     *
     * @param input - provide alert success string
     */
    public String grabAccountNumber(String input) {

        Pattern pattern = Pattern.compile("\\b(\\d{10}-\\d)\\b");
        Matcher matcher = pattern.matcher(input);
        String extracted = "";
        if (matcher.find()) {
            extracted = matcher.group(1).replace("-", "");
            reportStep("Account Number: " + extracted, "Pass");
            clickOkay();
//            System.out.println("Account Number Extracted: " + extracted);
        }
        else {
            reportStep(String.format("Account Number not found due to pattern mismatch. -> %s", input), "fail");
            clickOkay();
        }
        return extracted;
    }

    public void clickOnQueueNumber(String queueNumber) {
        getPage().locator(this.queueItemNumber).getByText(queueNumber).click();
    }

    public void authoriseQueueNumber(String queue){
        click(executeQueueSearch, EXECUTE);
        clickOnQueueNumber(queue);
        click(authorise, AUTHORISE);
        waitForLoaderComplete();
        selfOverRideForSuperviseOverride();
    }
    public String AuthoriseQueueAndGetAccountNumber(String queue){
        authoriseQueueNumber(queue);
        String accountNumber = grabAccountNumber(retrieveQueueAfterCreation());
        closePopUp();
        return accountNumber;
    }
    public void handleDoNotProcessEmailCheckbox(String locator){
        getPage().waitForTimeout(1500);
        if (getPage().locator(locator).isEnabled()){
            check(locator, "I do not possess email/ I Do not want to share email id with Bank");
        }
    }
    public void selfOverRideForSuperviseOverride(){
        String loc = "#UIPage_SupervisorOverrideRequired_self";
        if (isVisible(loc)){
            reportStep(String.format("Self Override Window opened, Message: %s", getInnerText("#supmsg")), "info");
            click(loc, "Self Override");
        }
    }

    public void validateJournalNumberGenerated(String queue){
        authoriseQueueNumber(queue);
//        selfOverRideForSuperviseOverride();
        String msg = retrieveQueueAfterCreation();

        Pattern pattern = Pattern.compile("^7001: .*\\[Journal Number-\\s*\\d+\\]$");
        Matcher matcher = pattern.matcher(msg);
        if (matcher.find()){
            reportStep("Operation Successful, journal number generated. Alert message: "+msg, "pass");
            clickOkay();
        }
        else{
            reportStep(String.format("Journal Number generated message not found due to pattern mismatch. Message-> %s", msg), "fail");
            clickOkay();
        }
        closePopUp();
    }

    public void validateJournalNumberGeneratedWithoutQueue(){
        String msg = retrieveQueueAfterCreation();
        Pattern pattern = Pattern.compile("^7001: .*\\[Journal Number-\\s*\\d+\\]$");
        Matcher matcher = pattern.matcher(msg);
        if (matcher.find()){
            reportStep("Operation Successful, journal number generated. Alert message: "+msg, "pass");
            clickOkay();
        }
        else{
            reportStep(String.format("Journal Number generated message not found due to pattern mismatch. Message-> %s", msg), "fail");
            clickOkay();
        }
        closePopUp();
    }

    public void validateNewTotalBalanceAfterDeposit(String oldTotalBalance, String amountDeposited, String newTotalBalance, String cashHandlingCharge){

        BigDecimal total = Utils.formatAmountToDecimal(oldTotalBalance)
                .add(Utils.formatAmountToDecimal(amountDeposited))
                .subtract(Utils.formatAmountToDecimal(cashHandlingCharge));

        BigDecimal newTotal =Utils.formatAmountToDecimal(newTotalBalance);
        reportStep(String.format("Sum of Old Total Balance(%s) + Amount deposited by cash (%s) - GST (%s) : Total %s", oldTotalBalance, amountDeposited, cashHandlingCharge, total), "info");

        Assert.assertEquals(newTotal.compareTo(total), 0,
                String.format("Amount mismatch. Expected=%s, Actual=%s",
                        total, newTotalBalance));
        reportStep("Total balance verified", "pass");
    }


}
