package mahabank.automation.e2e.CBS;

public interface CBSConstant {

    String CONNECTION_ISSUE = "Cannot establish connection with server. Please try again.";
    String EXECUTE = "Execute";
    String AUTHORISE = "Authorise";
    String ENQUIRIES = "Enquiries";
    String CUSTOMER_MANAGEMENT = "Customer Management";
    String MNRL_SUCCESS_MSG = "Mobile Number is Valid Continue with CIF creation .";
    String CREATE_PERSONAL_WIZARD = "Create Personal Customer Wizard";
    String IDENTIFICATION_DETAILS = "Identification Details";
    String NON_PERSONAL_DETAILS = "Non Personal Details";
    String INTERNET_BANKING_DETAILS = "Internet Banking Details";
    String OCCUPATION_DETAILS = "Occupation Details";
    String DEPOSIT_CC_OD_ACCOUNTS = "Deposit/CC/OD Accounts";
    String TRANSACTION_POSTING = "Transactions Posting";
    String TERM_AC_OPTIONS = "Term A/c Options";
    String NOMINEE_DETAILS = "Nominee Details";
    String LINKED_ACCOUNTS = "Linked Accounts";

    String ROLLOVER_DETAILS = "\\\\Scr:007025:Rollover details";
    String ROLLOVER_WINDOW_NUMBER = "007025";
}
