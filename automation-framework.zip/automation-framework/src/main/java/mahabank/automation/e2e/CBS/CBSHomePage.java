package mahabank.automation.e2e.CBS;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

import static mahabank.automation.e2e.CBS.CBSConstant.*;

public class CBSHomePage extends CBSLoginPage {

    public String homeButton = "css=.homeDiv";
    String logoutButton = "css=.logOutDiv";
    String makerButton = "css=#widget_13_box";
    public String bogMsg = "css=#UIPage_BogMsg_Ok";
    public String navigator = "css=#appSearch";
    public void isConnectionErrorRendering(){
        waitForTimeout(5000);
        boolean isVisible = getPage().locator(alert).filter(new Locator.FilterOptions().setHasText(CONNECTION_ISSUE)).isVisible();
//        System.out.println(isVisible);
        if (isVisible){
            clickOkay();
        }
    }

    public void BogMsgHandle(){
        waitForTimeout(2000);
        if (isVisible(bogMsg)) {
            click(bogMsg, "Ok - > BogMsg");
        }
    }

    public void validateHomePageRenderedAndWorkOnAnyFalseError(){
        isConnectionErrorRendering();
        BogMsgHandle();
        validateCBSHomeLoaded();
    }

    public CBSHomePage validateCBSHomeLoaded() {
        verifyDisplayed(homeButton, "Home Button");
//        click(homeButton, "Home Button");
        return this;
    }

    public CBSHomePage clickOnCard(String cardName) {
        this.waitForTimeout(3000);
        Locator cardlocator = getPage().locator(String.format("//i[contains(@title,\"%s\")]//..//div[@class=\"label\"]",cardName));
        verifyDisplayed(cardlocator, cardName);
        cardlocator.click();
        reportStep("The element : " + cardName + " displayed as expected and clicked", "pass");
        return this;
    }

    public CBSHomePage clickOnCard(String cardName, boolean exact) {
        this.waitForTimeout(3000);
        verifyDisplayed(getPage().getByText(cardName, new Page.GetByTextOptions().setExact(exact)).first(), cardName);
        getPage().getByText(cardName, new Page.GetByTextOptions().setExact(exact)).first().click();
        reportStep("The element : " + cardName + " displayed as expected and clicked", "pass");
        return this;
    }

    public CBSHomePage ClickOnMaker() {
        click(makerButton, "MAKER");
        return this;
    }

    public CBSHomePage doLogOut() {
        click(logoutButton, "Logout");
        validateLogout();
        return this;
    }

    public void doLogOutException() {
        clickOkay();
        closePopUp();
        if (isVisible(logoutButton)){
            click(logoutButton, "Logout");
            validateLogout();
        }
    }

    public void navigatorToWindow(String window){
        typeAndEnter(navigator,window, "Screen number");
    }
}
