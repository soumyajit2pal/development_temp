package mahabank.automation.e2e.CBS;

import com.microsoft.playwright.BrowserContext;
import mahabank.automation.config.ConfigurationManager;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;


public class CBSLoginPage extends BasePage {


    String username = "css=#login-username";
    String password = "css=#password";
    String branchname = "css=#login-branch";
    String loginButton = "css=#bmaLogin";

    public CBSLoginPage typeUserName(String username) {
        type(this.username, username, "Username");
        return this;
    }

    public CBSLoginPage typePassword(String password) {
        type(this.password, password, "Password");
        return this;
    }

    public CBSLoginPage typeBranchName(String BranchName) {
        type(this.branchname, BranchName, "Branch Name");
        return this;
    }

    public CBSLoginPage clickLogin() {
        click(loginButton, "Login");
        return this;
    }

    public CBSLoginPage doLogin(String username, String password, String branchname) {
        verifyDisplayed(loginButton, "CBS login");

        typeUserName(username)
                .typePassword(password)
                .typeBranchName(branchname)
                .clickLogin();
        return this;
    }

    public void validateLogout(){
        verifyDisplayed(getByText("You have successfully logged out."), "Logout message");
    }
}
