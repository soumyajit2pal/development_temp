package mahabank.automation.e2e.CBS.CIF.PersonalCustomer;

import mahabank.automation.e2e.CBS.CBSHomePage;

public class CustomerCreation extends CBSHomePage {

    /*
    // Personal Deatils
//    String firstname = "css=#UIPage_Wiz062001Personal_defaultString1";
//    String fathername = "css=#UIPage_Wiz062001Personal_defaultString17";
//    String customerType = "css=#UIPage_Wiz062001Personal_defaultString26";
//    String titlePrefix = "css=#UIPage_Wiz062001Personal_title1";
//    String permanentAddress1 = "css=#UIPage_Wiz062001Personal_permAddress1";
//    String permanentAddress2 = "css=#UIPage_Wiz062001Personal_permAddress2";
//    String permanentAddress3 = "css=#UIPage_Wiz062001Personal_permAddress3";
//    String cityNamePermanentAddress = "css=#UIPage_Wiz062001Personal_permCityname";
//    String cityCodePermananentAddress = "css=#UIPage_Wiz062001Personal_permCitycode";
//    String pinCodePermananentAddress = "css=#UIPage_Wiz062001Personal_permPincode";
//    String isCurrentSameAsPermanent = "css=#UIPage_Wiz062001Personal_checkboxes_personaltab";
//    String mobileNumber = "css=#UIPage_Wiz062001Personal_defaultString12";
//    String fetchButtonPermanentAddress = "css=#div-UIPage_060044_fetch_permDistPinCode";
//    String dOBCalender = "css=#span-UIPage_Wiz062001Personal_date2";
//    String yearDOBCalender = "css=.ui-datepicker-year";
//    String monthDOBCalender = "css=.ui-datepicker-month";
//    String placeCityOfBirth = "css=[name=\"placeCityBirth\"]";
//    String language = "css=[name=\"languagecode1\"]";
//    String gender = "css=#UIPage_Wiz062001Personal_defaultString23";
//    String maritalStatus = "css=#UIPage_Wiz062001Personal_defaultString24";
//    String userConsent = "css=#UIPage_Wiz_062001Personal_UserConsentbtn";

//    String submitUserConsent = "css=#UIPage_UserConsent_submit";
//    String submit = "xpath=//button[contains(text(), \"Submit\")]";
//    String relativeCode = "css=#UIPage_Wiz062001Personal_defaultString19";
//    String validateMobileNumber = "css=#UIPage_Wiz062001Personal_validateNumber";
//    String provideOTP = "css=#UIPage_Wiz062001Personal_otpNumber";
//    String validatePersonalOTP = "css=#UIPage_Wiz062001Personal_validateOTP";
//    String residentStatus = "#UIPage_Wiz062001Personal_defaultString20";
//    String primaryId = "#UIPage_Wiz062001Personal_id_type1";
    //  Identification Details
    String primaryIdNumber = "#UIPage_Wiz062001Personal_defaultString13";
    String currentAddressProof = "#UIPage_Wiz062001Personal_id_type2";
    String currentAddressProofNumber = "#UIPage_Wiz062001Personal_defaultString40";
    String ovddocumentUpload = "input#UIPage_Wiz062001Personal_ovdDocument";
    String ovddocumentUploadButton = "css=#UIPage_Wiz062001Personal_ovdDocumentUpload";
    String validateName = "#UIPage_Wiz_062001Personal_nameScreening";
    String segmentCode = "#UIPage_Wiz062001Personal_segm_code1";

//    Non Personal Details
    String bsr4OrgCode = "#UIPage_Wiz062001Personal_defaultString21";
    String constitutaionCode = "#UIPage_Wiz062001Personal_defaultString22";
    String panOrForm = "#UIPage_Wiz062001Personal_pANDD";
    String minorityFlag = "#UIPage_Wiz062001Personal_minorityflag";
    String religionOrCaste = "#UIPage_Wiz062001Personal_socialAttr_2";
    String form61Consent = "#UIPage_UserConsent_cb_form60_61";
    //    Internet Banking Details
    String requestForIB = "#UIPage_Wiz062001Personal_defaultString41";
    String emailAddress = "#UIPage_Wiz062001Personal_defaultString43";
    String reasonForIB = "#UIPage_Wiz062001Personal_defaultString44";
    //    Occupation Details
    String occupationDescrptions = "#UIPage_Wiz062001Personal_occ_Desc";
    String occupationCode = "#UIPage_Wiz062001Personal_occpn_code";
    String ex_Serviceman = "#UIPage_Wiz062001Personal_exServiceman";
    String manualScavenge = "#UIPage_Wiz062001Personal_mScavenger";
    String politicallyExpose = "#UIPage_Wiz062001Personal_politExpoPerson";
    String personDisablity = "#UIPage_Wiz062001Personal_pwd";
    String annualIncome = "#UIPage_Wiz062001Personal_annum2";
    String corporateCode = "#UIPage_Wiz062001Personal_CorporateCode";
    String corporateCodeFetchButton = "#UIPage_Wiz062001Personal_fetch";
    String employeeOfficialEmailAddress = "#UIPage_Wiz062001Personal_EmployeeOfficialEmailAdreess";
    String operationsEmailAddress = "#UIPage_Wiz062001Personal_OperationsEmailAddress";
    String employeeCode = "#UIPage_Wiz062001Personal_EmployeeCode";
    String EPFONumber = "#UIPage_Wiz062001Personal_EPFONumber";



//    Identification Details

    public void selectPrimaryId(String primaryId) {
        selectByText(this.primaryId, primaryId, "Primary ID");
    }

    public void setPrimaryIdNumber(String primaryIdNumber) {
        type(this.primaryIdNumber, primaryIdNumber, "Primary ID Number");
    }

    public void selectCurrentAddressProof(String currentAddressProof) {
        selectByText(this.currentAddressProof, currentAddressProof, "Current Add Proof");
    }

    public void setCurrentAddressProofNumber(String currentAddressProofNumber) {
        type(this.currentAddressProofNumber, currentAddressProofNumber, "Current Add Proof No");
    }

    public void setOvddocumentUpload(String path) {
        uploadFile(ovddocumentUpload, path, "OVD File Upload");
    }

    public void clickOvddocumentUploadButton() {
        click(ovddocumentUploadButton, "OVD Upload Button");
    }

    public void clickOnValidateName() {
    public void clickOnValidateName() {
        click(validateName, "Validate Name");
    }

// Non-Personal Details

    public void selectSegmentCode(String segmentCode) {
        selectByText(this.segmentCode, segmentCode, "Segment Code");
    }

    public void selectBSR4OrgCode(String bsr4OrgCode) {
        selectByText(this.bsr4OrgCode, bsr4OrgCode, "BSR-4 Org Code");
    }

    public void selectConstitutionCode(String constitutaionCode) {
        selectByText(this.constitutaionCode, constitutaionCode, "Constitution code");
    }

    public void selectMinorityFlag(String minorityFlag) {
        selectByText(this.minorityFlag, minorityFlag, "Minority Flag");
    }

    public void selectPanOrForm60(String panOrForm) {
        selectByText(this.panOrForm, panOrForm, "PAN OR Form 60/61");
    }

    public void selectReligionCasteCode(String religionOrCaste) {
        selectByText(this.religionOrCaste, religionOrCaste, "Religion/Caste Code");
    }

    public void checkForm61Consent() {
        check(form61Consent, "Checkbox form61/61 form, from the customer.");
    }

//    Internet Banking Details

    public void selectRequestForIB(String requestForIB) {
        selectByText(this.requestForIB, requestForIB, "Request for IB");
    }

    public void setEmailAddress(String emailAddress) {
        type(this.emailAddress, emailAddress, "Email Address");
    }

    public void selectReasonOnIB(String reasonForIB) {
        selectByText(this.reasonForIB, reasonForIB, "Reason");
    }

    //    Occupation Details

    public void selectOccupationDescrptions(String occupationDescrptions) {
        selectByText(this.occupationDescrptions, occupationDescrptions, "Occupation Description");
    }

    public void selectOccupationCode(String occupationCode) {
        selectByText(this.occupationCode, occupationCode, "Occupation Code");
    }

    public void setAnnualIncome(String annualIncome) {
        type(this.annualIncome, annualIncome, "Annual Income");
    }

    public void selectEx_Serviceman(String exServiceman) {
        selectByText(this.ex_Serviceman, exServiceman, "Whether Ex-Serviceman");
    }

    public void selectManualScavenge(String manualScavenge) {
        selectByText(this.manualScavenge, manualScavenge, "Whether Manual Scavengern");
    }

    public void selectPoliticallyExpose(String politicallyExpose) {
        selectByText(this.politicallyExpose, politicallyExpose, "Politically Exposed Person");
    }

    public void selecttPersonDisablity(String personDisablity) {
        selectByText(this.personDisablity, personDisablity, "Whether Persons with Disabilities");
    }

    public void setCorporateCode(String corporateCode) {
        type(this.corporateCode, corporateCode, "Corporate Code");
    }

    public void clickCorporateFetch() {
        click(corporateCodeFetchButton, "Corporate Code Fetch Button");
    }

    public void setEmployeeCorporateDetails(String employeeOfficialEmailAddress, String operationsEmailAddress, String employeeCode, String EPFONumber) {
        type(this.employeeOfficialEmailAddress, employeeOfficialEmailAddress, "EmployeeOfficial Email Adreess");
        type(this.operationsEmailAddress, operationsEmailAddress, "Operations Email Address");
        type(this.employeeCode, employeeCode, "Employee Code");
        type(this.EPFONumber, EPFONumber, "EPFO Number");
    }
// Common Operations

    public void submitButton() {
        click(submit, "Submit");
    }

    public void completeUserConsent() {
        getUserConsent();
        checkAggreeUserConsent();
        submitUserConsent();
    }

    public void completeUserConsentWhileNoPAN() {
        getUserConsent();
        checkAggreeUserConsent();
        checkForm61Consent();
        submitUserConsent();
    }
*/
}

