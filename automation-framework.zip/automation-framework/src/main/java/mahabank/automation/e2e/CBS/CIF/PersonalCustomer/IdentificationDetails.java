package mahabank.automation.e2e.CBS.CIF.PersonalCustomer;

import mahabank.automation.e2e.CBS.CBSHomePage;

public class IdentificationDetails extends CBSHomePage {

    //  Identification Details
    String primaryId = "#UIPage_Wiz062001Personal_id_type1";
    String primaryIdNumber = "#UIPage_Wiz062001Personal_defaultString13";
    String currentAddressProof = "#UIPage_Wiz062001Personal_id_type2";
    String currentAddressProofNumber = "#UIPage_Wiz062001Personal_defaultString40";
    String ovddocumentUpload = "input#UIPage_Wiz062001Personal_ovdDocument";
    String ovddocumentUploadButton = "css=#UIPage_Wiz062001Personal_ovdDocumentUpload";
    String validateName = "#UIPage_Wiz_062001Personal_nameScreening";

    //    Identification Details

    public void selectPrimaryId(String primaryId) {
        selectByText(this.primaryId, primaryId, "Primary ID");
    }

    public void setPrimaryIdNumber(String primaryIdNumber) {
        type(this.primaryIdNumber, primaryIdNumber, "Primary ID Number");
    }

    public void selectCurrentAddressProof(String currentAddressProof) {
        selectByText(this.currentAddressProof, currentAddressProof, "Current Add Proof");
    }

    public void setCurrentAddressProofNumber(String currentAddressProofNumber) {
        type(this.currentAddressProofNumber, currentAddressProofNumber, "Current Add Proof No");
    }

    public void setOvddocumentUpload(String path) {
        uploadFile(ovddocumentUpload, path, "OVD File Upload");
    }

    public void clickOvddocumentUploadButton() {
        click(ovddocumentUploadButton, "OVD Upload Button");
    }

    public void clickOnValidateName() {
        click(validateName, "Validate Name");
    }

}
