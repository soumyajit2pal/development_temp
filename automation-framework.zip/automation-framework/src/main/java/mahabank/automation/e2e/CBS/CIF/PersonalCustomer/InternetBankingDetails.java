package mahabank.automation.e2e.CBS.CIF.PersonalCustomer;

import mahabank.automation.e2e.CBS.CBSHomePage;

public class InternetBankingDetails extends CBSHomePage {
    String requestForIB = "#UIPage_Wiz062001Personal_defaultString41";
    String emailAddress = "#UIPage_Wiz062001Personal_defaultString43";
    String reasonForIB = "#UIPage_Wiz062001Personal_defaultString44";
    String noEmail = "#UIPage_Wiz062001Personal_checkboxes_43";

    public void selectRequestForIB(String requestForIB) {
        selectByText(this.requestForIB, requestForIB, "Request for IB");
    }

    public void setEmailAddress(String emailAddress) {
        type(this.emailAddress, emailAddress, "Email Address");
    }

    public void selectReasonOnIB(String reasonForIB) {
        selectByText(this.reasonForIB, reasonForIB, "Reason");
    }
    public void checkNoEmailShare(){
        check(noEmail, "I do not possess email/ I Do not want to share email id with Bank");
    }
}
