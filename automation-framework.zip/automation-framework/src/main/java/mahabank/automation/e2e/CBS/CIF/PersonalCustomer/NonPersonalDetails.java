package mahabank.automation.e2e.CBS.CIF.PersonalCustomer;

import mahabank.automation.e2e.CBS.CBSHomePage;

public class NonPersonalDetails extends CBSHomePage {
    //    Non Personal Details
    String bsr4OrgCode = "#UIPage_Wiz062001Personal_defaultString21";
    String constitutaionCode = "#UIPage_Wiz062001Personal_defaultString22";
    String panOrForm = "#UIPage_Wiz062001Personal_pANDD";
    String minorityFlag = "#UIPage_Wiz062001Personal_minorityflag";
    String religionOrCaste = "#UIPage_Wiz062001Personal_socialAttr_2";
    String form61Consent = "#UIPage_UserConsent_cb_form60_61";
    String segmentCode = "#UIPage_Wiz062001Personal_segm_code1";
    String ewsCategory = "#UIPage_Wiz062001Personal_category";

    // Non-Personal Details

    public void selectSegmentCode(String segmentCode) {
        selectByText(this.segmentCode, segmentCode, "Segment Code");
    }

    public void selectBSR4OrgCode(String bsr4OrgCode) {
        selectByText(this.bsr4OrgCode, bsr4OrgCode, "BSR-4 Org Code");
    }

    public void selectConstitutionCode(String constitutaionCode) {
        selectByText(this.constitutaionCode, constitutaionCode, "Constitution code");
    }

    public void selectMinorityFlag(String minorityFlag) {
        selectByText(this.minorityFlag, minorityFlag, "Minority Flag");
    }

    public void selectPanOrForm60(String panOrForm) {
        selectByText(this.panOrForm, panOrForm, "PAN OR Form 60/61");
    }

    public void selectReligionCasteCode(String religionOrCaste) {
        selectByText(this.religionOrCaste, religionOrCaste, "Religion/Caste Code");
    }

    public void selectEWSCategory(String ewsCategory)
    {
        selectByText(this.ewsCategory, ewsCategory, "EWS Category");
    }
    public void checkForm61Consent() {
        check(form61Consent, "Checkbox form61/61 form, from the customer.");
    }
}
