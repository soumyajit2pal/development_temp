package mahabank.automation.e2e.CBS.CIF.PersonalCustomer;

import mahabank.automation.e2e.CBS.CBSHomePage;

public class OccupationDetails extends CBSHomePage {

    //    Occupation Details
    String occupationDescrptions = "#UIPage_Wiz062001Personal_occ_Desc";
    String occupationCode = "#UIPage_Wiz062001Personal_occpn_code";
    String ex_Serviceman = "#UIPage_Wiz062001Personal_exServiceman";
    String manualScavenge = "#UIPage_Wiz062001Personal_mScavenger";
    String politicallyExpose = "#UIPage_Wiz062001Personal_politExpoPerson";
    String personDisablity = "#UIPage_Wiz062001Personal_pwd";
    String annualIncome = "#UIPage_Wiz062001Personal_annum2";
    String validateName = "#UIPage_Wiz_062001Personal_nameScreening";
//    String corporateCode = "#UIPage_Wiz062001Personal_CorporateCode";
//    String corporateCodeFetchButton = "#UIPage_Wiz062001Personal_fetch";
//    String employeeOfficialEmailAddress = "#UIPage_Wiz062001Personal_EmployeeOfficialEmailAdreess";
//    String operationsEmailAddress = "#UIPage_Wiz062001Personal_OperationsEmailAddress";
//    String employeeCode = "#UIPage_Wiz062001Personal_EmployeeCode";
//    String EPFONumber = "#UIPage_Wiz062001Personal_EPFONumber";

    //    Occupation Details

    public void selectOccupationDescrptions(String occupationDescrptions) {
        selectByText(this.occupationDescrptions, occupationDescrptions, "Occupation Description");
    }

    public void selectOccupationCode(String occupationCode) {
        selectByText(this.occupationCode, occupationCode, "Occupation Code");
    }

    public void setAnnualIncome(String annualIncome) {
        type(this.annualIncome, annualIncome, "Annual Income");
    }

    public void selectEx_Serviceman(String exServiceman) {
        selectByText(this.ex_Serviceman, exServiceman, "Whether Ex-Serviceman");
    }

    public void selectManualScavenge(String manualScavenge) {
        selectByText(this.manualScavenge, manualScavenge, "Whether Manual Scavengern");
    }

    public void selectPoliticallyExpose(String politicallyExpose) {
        selectByText(this.politicallyExpose, politicallyExpose, "Politically Exposed Person");
    }

    public void selectPersonDisability(String personDisability) {
        selectByText(this.personDisablity, personDisability, "Whether Persons with Disabilities");
    }

    public void clickOnValidateName() {
        click(validateName, "Validate Name");
    }

//    public void setCorporateCode(String corporateCode) {
//        type(this.corporateCode, corporateCode, "Corporate Code");
//    }
//
//    public void clickCorporateFetch() {
//        click(corporateCodeFetchButton, "Corporate Code Fetch Button");
//    }

//    public void setEmployeeCorporateDetails(String employeeOfficialEmailAddress, String operationsEmailAddress, String employeeCode, String EPFONumber) {
//        type(this.employeeOfficialEmailAddress, employeeOfficialEmailAddress, "EmployeeOfficial Email Adreess");
//        type(this.operationsEmailAddress, operationsEmailAddress, "Operations Email Address");
//        type(this.employeeCode, employeeCode, "Employee Code");
//        type(this.EPFONumber, EPFONumber, "EPFO Number");
//    }
}
