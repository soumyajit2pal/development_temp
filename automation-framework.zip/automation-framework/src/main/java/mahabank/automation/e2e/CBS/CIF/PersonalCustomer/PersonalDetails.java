package mahabank.automation.e2e.CBS.CIF.PersonalCustomer;

import com.microsoft.playwright.Locator;
import mahabank.automation.e2e.CBS.CBSHomePage;

import static mahabank.automation.e2e.CBS.CBSConstant.MNRL_SUCCESS_MSG;

public class PersonalDetails extends CBSHomePage {

    String firstname = "css=#UIPage_Wiz062001Personal_defaultString1";
    String fathername = "css=#UIPage_Wiz062001Personal_defaultString17";
    String customerType = "css=#UIPage_Wiz062001Personal_defaultString26";
    String titlePrefix = "css=#UIPage_Wiz062001Personal_title1";
    String permanentAddress1 = "css=#UIPage_Wiz062001Personal_permAddress1";
    String permanentAddress2 = "css=#UIPage_Wiz062001Personal_permAddress2";
    String permanentAddress3 = "css=#UIPage_Wiz062001Personal_permAddress3";
    String cityNamePermanentAddress = "css=#UIPage_Wiz062001Personal_permCityname";
    String cityCodePermananentAddress = "css=#UIPage_Wiz062001Personal_permCitycode";
    String pinCodePermananentAddress = "css=#UIPage_Wiz062001Personal_permPincode";
    String isCurrentSameAsPermanent = "css=#UIPage_Wiz062001Personal_checkboxes_personaltab";
    String mobileNumber = "css=#UIPage_Wiz062001Personal_defaultString12";
    String fetchButtonPermanentAddress = "css=#div-UIPage_060044_fetch_permDistPinCode";
    String fetchButtonCurrentAddress = "css=#div-UIPage_060044_fetch";
    String dOBCalender = "css=#span-UIPage_Wiz062001Personal_date2";
    String yearDOBCalender = "css=.ui-datepicker-year";
    String monthDOBCalender = "css=.ui-datepicker-month";
    String placeCityOfBirth = "css=[name=\"placeCityBirth\"]";
    String language = "css=[name=\"languagecode1\"]";
    String gender = "css=#UIPage_Wiz062001Personal_defaultString23";
    String maritalStatus = "css=#UIPage_Wiz062001Personal_defaultString24";
    String aggreeUserConsent = "css=#UIPage_UserConsent_chceckbox";
    String submitUserConsent = "css=#UIPage_UserConsent_submit";
    String submit = "xpath=//button[contains(text(), \"Submit\")]";
    String relativeCode = "css=#UIPage_Wiz062001Personal_defaultString19";
    String validateMobileNumber = "css=#UIPage_Wiz062001Personal_validateNumber";
    String provideOTP = "css=#UIPage_Wiz062001Personal_otpNumber";
    String validatePersonalOTP = "css=#UIPage_Wiz062001Personal_validateOTP";
    String residentStatus = "#UIPage_Wiz062001Personal_defaultString20";
    String MNRLId = "#UIPage_Wiz062001Personal_validatemnrl";

    String dateDOBCalender(int month, String day) {
        return "xpath=//td[@data-handler=\"selectDay\" and @data-month=\"" + month + "\"]//a[text()=\"" + day + "\"]";
    }

    public void enterFirstName(String firstname) {
        type(this.firstname, firstname, "Cutomer Firstname");
    }

    public void enterFatherName(String fathername) {
        type(this.fathername, fathername, "Customer Father name");
    }

    public void setRelativeCode(String relativeCode) {
        selectByText(this.relativeCode, relativeCode, "Relative Code");
    }

    public void selectCustomerType(String customertype) {
        selectByText(customerType, customertype, "Customer Type");
    }


    public void selectTitlePrefix(String titleprefix) {
        selectByText(this.titlePrefix, titleprefix, "Title Prefix");
    }

    public void setPermanentAddress1(String permanentAddress1) {
        type(this.permanentAddress1, permanentAddress1, "Permanent Address 1");
    }

    public void setPermanentAddress2(String permanentAddress2) {
        type(this.permanentAddress2, permanentAddress2, "Permanent Address 2");
    }

    public void setPermanentAddress3(String permanentAddress3) {
        type(this.permanentAddress3, permanentAddress3, "Permanent Address 3");
    }

    public void setCityCodePermanentAddress(String cityCodePermanentAddress) {
        type(this.cityCodePermananentAddress, cityCodePermanentAddress, "City Code Permanent Address");
    }

    public void setCityNamePermanentAddress(String cityNamePermanentAddress) {
        type(this.cityNamePermanentAddress, cityNamePermanentAddress, "City Name Permanent Address");
    }

    public void setPinCodePermanentAddress(String pinCodePermanentAddress) {
        type(this.pinCodePermananentAddress, pinCodePermanentAddress, "Pin Code Permanent Address");
    }

    public void checkIsCurrentSameAsPermanent(boolean check) {
        if (check) {
            check(this.isCurrentSameAsPermanent, "Is Current Same As Permanent Address");
        }
    }

    public void clickFetchButtonPermanentAddress() {
        click(fetchButtonPermanentAddress, "Fetch button permanent address");
    }
    public void clickFetchButtonCurrentAddress() {
        click(fetchButtonCurrentAddress, "Fetch button Current address");
    }

    public void setMobileNumber(String mobileNumber) {
        type(this.mobileNumber, mobileNumber, "Mobile Number");
    }

    public void ValidateMNRL(){
        click(MNRLId, "MNRL");
        Locator message = getPage().locator(alert).filter(new Locator.FilterOptions().setHasText(MNRL_SUCCESS_MSG));
        verifyDisplayed(message, MNRL_SUCCESS_MSG);
        clickOkay();
    }
    public void validateMobileNumber() {
        click(validateMobileNumber, "Validate Mobile Number");
        clickOkay();
    }

    public void setOTP() {
        type(provideOTP, "123456", "OTP");
    }

    public void validateOTPonMobileNumber() {
        click(validatePersonalOTP, "Validate OTP");
        click(OK, "OK");
    }

    public void openCalender() {
        click(dOBCalender, "Calender");
    }

    public void selectDOB(String date) {
        java.time.LocalDate birthDate;
        try {
            birthDate = java.time.LocalDate.parse(date, java.time.format.DateTimeFormatter.ofPattern("d/M/uuuu")
                    .withResolverStyle(java.time.format.ResolverStyle.STRICT));
        } catch (java.time.DateTimeException | NullPointerException e) {
            throw new IllegalArgumentException("Date of birth must be a valid day/month/year", e);
        }
        int month = birthDate.getMonthValue() - 1;
        openCalender();
        selectByText(yearDOBCalender, String.valueOf(birthDate.getYear()), "Year of Birth");
        selectByIndex(monthDOBCalender, month, "Month of Birth");
        click(dateDOBCalender(month, String.valueOf(birthDate.getDayOfMonth())), "Date Of Birth");
    }

    public void setPlaceCityOfBirth(String placeCityOfBirth) {
        type(this.placeCityOfBirth, placeCityOfBirth, "Place Of Birth");
    }

    public void selectGender(String gender) {
        selectByText(this.gender, gender, "Gender");
    }

    public void selectMaritalStatus(String maritalStatus) {
        selectByText(this.maritalStatus, maritalStatus, "MaritalStatus");
    }

    public void selectLanguage(String language) {
        selectByText(this.language, language, "Language");
    }

    public void checkAggreeUserConsent() {
        check(aggreeUserConsent, "Aggree User Consent");
    }

    public void submitUserConsent() {
        click(submitUserConsent, "Submit User Consent");
    }

    public void selectResidentStatus(String residentStatus) {
        selectByText(this.residentStatus, residentStatus, "Resident Status");
    }
}
