package mahabank.automation.e2e.CBS.DEPOSIT;

import com.microsoft.playwright.assertions.PlaywrightAssertions;
import mahabank.automation.data.dynamic.TestDataGenerator;
import mahabank.automation.e2e.CBS.CBSHomePage;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;

public class DepositAccount extends NomineeDetailsDPAc {
    String extCifAccountNumber = "#UIPage_002000pmt_accntNumber1";
    String RDInfoAfterAccount = "#UIPage_000901_accntNumber2";
    public String doNotProcessEmailCheckbox = "#UIPage_002000pmt_checkboxes";

    public void setExtCifAccountNumber(String extCifAccountNumber) {
        PlaywrightAssertions.assertThat(getPage().locator(this.extCifAccountNumber)).isEnabled();
        type(this.extCifAccountNumber, extCifAccountNumber, "Existing CIF/Account No:");
    }

    public String retrieveAccountNumberFromRDInfo(){
        return this.getAttribute(this.RDInfoAfterAccount, "value");
    }

}

class CoreOption extends CBSHomePage {
    public String custNumber = "#UIPage_002000_accntNumber4";
    public String accountSegCode = "#UIPage_002000_unsigned1";
    public String product = "#UIPage_002000_defInteger21";
    public String productType = "#UIPage_002000_defInteger22";
    public String customerCat = "#UIPage_002000_defInteger23";
    public String locationTerm = "#UIPage_002000_defInteger24";
    public String currency = "#UIPage_002000_defInteger25";
    public String bsrActivityCode = "#UIPage_002000_bsrcode1"; //10001:GROWING OF PADDY
    public String nocFromOtherBank = "#UIPage_002000_defInteger16"; //0012:BANK OF BARODA
    public String declarationObtained = "#UIPage_002000_declobt"; //N:No
    public String creditFacilityfromOtherbank = "#UIPage_002000_defaultString211"; //Y:Yes
    public String interestPaymentmethod = "#UIPage_002000_intpcode1"; // "T:Transfer"
    public String interestTransferAccountNumber = "#UIPage_002000_accntNumber2";
    public String verifyEligibilty = "#UIPage_002000_VerifyEligibilty";


    public void provideDetailsOfCoreOptionsForCurrentAccount(String accountSegCode, String productName, String productType, String customerCategory,
                                                             String locationTerm, String currency, String bsrActivityCode, String creditFacilityFromOtherBank, String declarationObtained){

        selectByText(this.accountSegCode, accountSegCode, "Account Seg Code");
        selectByText(this.product, productName, "Product Name");
        selectByText(this.productType, productType, "Product Type");
        selectByText(this.customerCat, customerCategory, "Customer Category");
        selectByText(this.locationTerm, locationTerm, "Location Term");
        selectByText(this.currency, currency, "Currency");
        clickValidateEligibility();
        selectByText(this.bsrActivityCode,bsrActivityCode, "BSR Activity Code" );
        selectByText(this.creditFacilityfromOtherbank, creditFacilityFromOtherBank, "Credit Facility From Other Bank");
        selectByText(this.declarationObtained, declarationObtained, "Declaration Obtained");
        clickOkay();
    }


    public void validateCustomerNumber(String custNumber) {
        assertThat(getPage().locator(this.custNumber)).hasValue(custNumber);
    }

    public void clickValidateEligibility(){
        click(verifyEligibilty, "Verify Eligibility");
        clickOkay();
    }
}

class TermAcOptionsDPAc extends CoreOption {
    public String siRequired = "#UIPage_002000_SIRequired";
    public String modeOperation = "#UIPage_002000_mop";
    public String termMonth = "#UIPage_002000_defInteger17";
    public String termYears = "#UIPage_002000_defInteger18";
    public String termValueDeposited = "#UIPage_002000_amount2";
    public String rdExpectedInstallment = "#UIPage_002000_amount1";

    public void provideRDInstallment(String installment){
        this.type(rdExpectedInstallment, installment, "RD Expected Installment");
    }

    public void provideRDTermOfInstallment(String termMonth){
        this.type(this.termMonth, termMonth, "Term Months");
    }
}

class NomineeDetailsDPAc extends TermAcOptionsDPAc {
    public String nomineeRegFlag = "#UIPage_002000_nomRegflag";
    public String refusalReason = "#UIPage_002000_refusalReason";
    public String nomineeTitle = "#UIPage_002000_nomTitle";
    public String nomineeName = "#UIPage_002000_nomineeName";
    public String nomineeAge = "#UIPage_002000_nomAge";
    public String nomineeRelationship = "#UIPage_002000_nomRelation";
    public String nomineeAddress = "#UIPage_002000_nomAddress";
    public String nomineeMinorDOB = "#UIPage_002000_nomineeDoB";
    public String nomineeIsMinor = "#UIPage_002000_isMinor";
    public String nomineeGuardianName = "#UIPage_002000_gaurdNameAdd";
    public String nomineeTelephoneNumber = "#UIPage_002000_phoneNo";
    public String typeOfNomination = "#UIPage_002000_typeOfNomination";
    public String numberOfNomination = "//h2[contains(text(), \"Nominee\")]";
    public String percentageOfNominee = "#UIPage_002000_nomPercentage";


    public void ValidationOfNomineeRegistrationWhileNomineeFlagNo(String nomineeRequiredFlag){
            selectByText(this.nomineeRegFlag, nomineeRequiredFlag, "Nomination registration flag");
            type(this.refusalReason, new TestDataGenerator().getRefusalReason(), "Refusal Reason");
    }

//    public void ValidationOfNomineeRegistrationWhileNomineeFlagYes(String nomineeRequiredFlag, String typeOfNomination, int numberOfNomination, String nomineeTitle, String nominee_name, String nominee_age, String nominee_relationship,
//                                     String nominee_address, String nomineeTelephoneNumber, String isMinorNominee, String percentageOfNominee){
//
//        selectByText(this.nomineeRegFlag, nomineeRequiredFlag, "Nomination registration flag");
//
//        selectByText(this.nomineeTitle,
//                nomineeTitle,
//                "Nominee Title");
//
//        type(this.nomineeName,
//                nominee_name,
//                "Nominee Name");
//
//        type(this.nomineeAge,
//                nominee_age,
//                "Nominee Age");
//
//        selectByText(this.nomineeRelationship,
//                nominee_relationship,
//                "Nominee Relationship");
//
//        type(this.nomineeAddress,
//                nominee_address,
//                "Nominee Address");
//        assertThat(getPage().locator(this.nomineeIsMinor)).not().isEditable();
//        assertThat(getPage().locator(this.nomineeGuardianName)).not().isEditable();
//
//        type(this.nomineeTelephoneNumber,
//                nomineeTelephoneNumber,"Nominee telephone number");
//
//        selectByText(this.typeOfNomination,
//                typeOfNomination,
//                "Nomination Type");
//
//        if (nomineeRequiredFlag.equalsIgnoreCase("1:Successive")){
//            assertThat(getPage().locator(this.numberOfNomination)).hasCount(4);
//            if (numberOfNomination >1){
//                for (int i =1; i< numberOfNomination; i++){
//                    selectByText(this.nomineeTitle+i,
//                            nomineeTitle,
//                            "Nominee Title for "+i);
//
//                    type(this.nomineeName+i,
//                            nominee_name,
//                            "Nominee Name");
//
//                    type(this.nomineeAge+i,
//                            nominee_age,
//                            "Nominee Age");
//
//                    selectByText(this.nomineeRelationship+i,
//                            nominee_relationship,
//                            "Nominee Relationship");
//
//                    type(this.nomineeTelephoneNumber+i,
//                            nomineeTelephoneNumber,"Nominee telephone number");
//
//                    assertThat(getPage().locator(this.nomineeIsMinor)).not().isEditable();
//                    assertThat(getPage().locator(this.nomineeGuardianName)).not().isEditable();
//
//                }
//            }
//        }
//        else if (nomineeRequiredFlag.equalsIgnoreCase("2:Simultaneous")){
//            if (numberOfNomination >1){
//                for (int i =1; i< numberOfNomination; i++){
//                    selectByText(this.nomineeTitle+i,
//                            nomineeTitle,
//                            "Nominee Title for "+i);
//
//                    type(this.nomineeName+i,
//                            nominee_name,
//                            "Nominee Name");
//
//                    type(this.nomineeAge+i,
//                            nominee_age,
//                            "Nominee Age");
//
//                    selectByText(this.nomineeRelationship+i,
//                            nominee_relationship,
//                            "Nominee Relationship");
//
//                    type(this.nomineeTelephoneNumber+i,
//                            nomineeTelephoneNumber,"Nominee telephone number");
//
//                    type(this.percentageOfNominee+i, percentageOfNominee, "Percentage");
//                    assertThat(getPage().locator(this.nomineeIsMinor)).not().isEditable();
//                    assertThat(getPage().locator(this.nomineeGuardianName)).not().isEditable();
//                }
//            }
//        }
//
//
//    }

    private List<String> validateAndGetPercentages(String percentageOfNominee,
                                                   int numberOfNomination) {

        if (percentageOfNominee == null || percentageOfNominee.isBlank())
            throw new IllegalArgumentException("Nominee percentages must not be blank");

        List<String> percentages = Arrays.stream(percentageOfNominee.split(","))
                .map(String::trim)
                .collect(Collectors.toList());

        if (percentages.size() > 4) {
            throw new IllegalArgumentException("Maximum 4 nominees are allowed.");
        }

        if (percentages.size() != numberOfNomination) {
            throw new IllegalArgumentException(
                    "Number of nominees (" + numberOfNomination +
                            ") does not match percentage count (" + percentages.size() + ").");
        }

        int total = percentages.stream()
                .mapToInt(Integer::parseInt)
                .peek(value -> {
                    if (value <= 0 || value > 100) throw new IllegalArgumentException("Each nominee percentage must be from 1 to 100");
                })
                .sum();

        if (total != 100) {
            throw new IllegalArgumentException(
                    "Total percentage must be 100. Current total : " + total);
        }

        return percentages;
    }

    public void ValidationOfNomineeRegistrationWhileNomineeFlagYes(
            String nomineeRequiredFlag,
            String typeOfNomination,
            int numberOfNomination,
            String nomineeTitle,
            String nomineeName,
            String nomineeAge,
            String nomineeRelationship,
            String nomineeAddress,
            String nomineeTelephoneNumber,
            String isMinorNominee,
            String percentageOfNominee) {

        if (numberOfNomination < 1 || numberOfNomination > 4)
            throw new IllegalArgumentException("Number of nominees must be from 1 to 4");
        if (!"N".equalsIgnoreCase(isMinorNominee))
            throw new IllegalArgumentException("This nominee helper supports adults (N); minor nominees require DOB and guardian details");

        boolean isSimultaneous =
                "2:Simultaneous".equalsIgnoreCase(typeOfNomination);

        List<String> nomineePercentages = Collections.emptyList();

        if (isSimultaneous) {
            nomineePercentages =
                    validateAndGetPercentages(
                            percentageOfNominee,
                            numberOfNomination);
        }

        // First nominee
        selectByText(this.nomineeRegFlag,
                nomineeRequiredFlag,
                "Nomination registration flag");

        selectByText(this.typeOfNomination,
                typeOfNomination,
                "Nomination Type");

        selectByText(this.nomineeTitle,
                nomineeTitle,
                "Nominee Title");

        type(this.nomineeName,
                nomineeName,
                "Nominee Name");

        type(this.nomineeAge,
                nomineeAge,
                "Nominee Age");

        selectByText(this.nomineeRelationship,
                nomineeRelationship,
                "Nominee Relationship");

        type(this.nomineeAddress,
                nomineeAddress,
                "Nominee Address");

        type(this.nomineeTelephoneNumber,
                nomineeTelephoneNumber,
                "Nominee Telephone Number");

        assertThat(getPage().locator(this.nomineeIsMinor))
                .not()
                .isEditable();

        assertThat(getPage().locator(this.nomineeGuardianName))
                .not()
                .isEditable();

        // Percentage only for Simultaneous
        if (isSimultaneous) {
            typeAndTab(this.percentageOfNominee,
                    nomineePercentages.get(0),
                    "Percentage");
        }

        // Successive specific validation
        if ("1:Successive".equalsIgnoreCase(typeOfNomination)) {
            assertThat(getPage().locator(this.numberOfNomination))
                    .hasCount(4);
        }

        // Additional nominees
        for (int i = 1; i < numberOfNomination; i++) {
            selectByText(this.nomineeTitle + i,
                    nomineeTitle,
                    "Nominee Title " + i);

            type(this.nomineeName + i,
                    nomineeName,
                    "Nominee Name " + i);

            type(this.nomineeAge + i,
                    nomineeAge,
                    "Nominee Age " + i);

            selectByText(this.nomineeRelationship + i,
                    nomineeRelationship,
                    "Nominee Relationship " + i);

            type(this.nomineeTelephoneNumber + i,
                    nomineeTelephoneNumber,
                    "Nominee Telephone Number " + i);

            type(this.nomineeAddress +i,
                    nomineeAddress,
                    "Nominee Address");

            assertThat(getPage().locator(this.nomineeIsMinor + i))
                    .not()
                    .isEditable();

            assertThat(getPage().locator(this.nomineeGuardianName + i))
                    .not()
                    .isEditable();

            // Percentage only for Simultaneous nominations
            if (isSimultaneous) {
                typeAndTab(this.percentageOfNominee + i,
                        nomineePercentages.get(i),
                        "Percentage " + i);
            }
        }
    }
}
