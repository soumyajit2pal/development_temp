package mahabank.automation.e2e.CBS.DEPOSIT;

import mahabank.automation.e2e.CBS.CBSHomePage;

import static mahabank.automation.e2e.CBS.CBSConstant.*;

public class RollOverDetails extends CBSHomePage {

    public String rolloverAccountNumber7025 = "#UIPage_007025_accntNumber1";
    public String optionsForRolloverLocator = "#UIPage_007025_createEnquire";
    public String manualRolloverOptionsLocator = "#UIPage_007025_defaultString1";
    public String rolloverOfAccountNumber2070 = "#UIPage_002070_accntNumber1";
    public String rolloverToFromAccount2070 = "#UIPage_002070_accntNumber3";
    public String fetchCustomerNameRollover = "#UIPage_002070_FetchPAN";
    public String toVerifyBeforeSubmitLocator = "#UIPage_002070_accheck";


    public void submitTransmit(String window) {
        click(String.format("#UIPage_%s_submit", window), "Transmit");
    }

    public void enterRollOverToOrFromAccount(String accountNumber){
        type(rolloverToFromAccount2070, accountNumber, "To/From Acct no");
        fetchCustomerNameOfToFromAccountNumber();
        check(toVerifyBeforeSubmitLocator, "Click on checkbox to verify before submit");
        AcceptDialog();
        submitTransmit("002070");
    }
    public void validateRolloverDetailsWindowsOpened(){
        verifyDisplayed(getPage().locator("//h2[@class=\"panel-title\"]").getByText(ROLLOVER_DETAILS), "ROLLOVER DETAILS");
    }

    public void selectOptionsForRollover(String option){
        selectByText(optionsForRolloverLocator, option, "Option for rollover");
    }

    public void selectManualOptionsForRollover(String option){
        selectByText(manualRolloverOptionsLocator, option, "Manual Option for rollover");
    }

    public String retrieveAccountNumberFromRollover(){
        return this.getAttribute(this.rolloverAccountNumber7025, "value");
    }

    public void enterAccountNumberForRollover(String accountNumber){
        type(this.rolloverAccountNumber7025, accountNumber, "Account number");
    }

    public void fetchCustomerNameOfToFromAccountNumber(){
        click(fetchCustomerNameRollover, "Fetch customer name");
    }

    public void createRollOverInstructions(String accountNumber, String rolloverOption){
        validateRolloverDetailsWindowsOpened();
        enterAccountNumberForRollover(accountNumber);
        selectOptionsForRollover("1:Create");
        selectManualOptionsForRollover(rolloverOption); //1:Term-Deposit auto rollover and close,Amount will transfer to SB acct || 7:Auto Rollover
        submitTransmit("007025");
    }
}
