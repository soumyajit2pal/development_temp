package mahabank.automation.e2e.CBS;

import com.microsoft.playwright.Locator;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;
import static mahabank.automation.e2e.CBS.CBSConstant.*;

public class EnquiriesPage extends CBSHomePage {

    public String accountNumber = "#UIPage_060450_accntNumber1";
    public String customerOrAccount = "#UIPage_060450_custAccount1";
    public String accountDetailsCIF = "#UIPage_060451_defInteger8";
    public String linkedAccounts = "p[name=\"accntNumber1\"]";

    public void enterCIFOrAccount(String detail) {
        type(this.accountNumber, detail, "Existing CIF/Account No ");
        this.submitTransmit();
        this.waitForLoaderComplete();
    }

    public void selectCustomerOrAccount(String cmd) {
        selectByText(this.customerOrAccount, cmd, "Customer/Account ");
    }

    public void validateAccountNumberIsCreated(String cifNumber, String accountNumber){
        this.enterCIFOrAccount(accountNumber);
        assertThat(getPage().locator(this.accountDetailsCIF)).hasValue(cifNumber);
        navigateToTab(LINKED_ACCOUNTS);
        verifyDisplayed(getPage().locator(linkedAccounts).getByText(accountNumber), "Account number "+accountNumber);
        assertThat(getPage().locator(linkedAccounts).getByText(accountNumber)).isVisible();
    }

    public String getCIFLevelTotalBalance(){
        String totalBalance = getInputText("#UIPage_060451_defaultString20").trim();
        reportStep("Total Balance On account is "+ totalBalance, "pass");
        return totalBalance;
    }

    public String getAccountLevelTotalBalance(String accountNumber){
        try {
            Locator accounts = getPage().locator("//p[@name=\"accntNumber1\"]");
            int count = accounts.count();
            for (int i = 0; i < count; i++) {
                String acc = accounts.nth(i).innerText().trim();
                if (acc.equals(accountNumber)) {
                    String totalBalance = getInnerText(String.format("#UIPage_060451_TotalBalanceRow_CollectionD%s", i+1)); // Matching index found
                    reportStep(String.format("Total Balance On account %s is %s.", accountNumber, totalBalance), "pass");
                    return totalBalance;
                }
            }
        } catch (Exception e) {
                reportStep(String.format("Total Balance On account %s is Failed due to %s.", accountNumber, e), "fail");
        }
        reportFailure("Account was not found in linked accounts", null);
        throw new AssertionError("Account was not found in linked accounts");
        }
    }
