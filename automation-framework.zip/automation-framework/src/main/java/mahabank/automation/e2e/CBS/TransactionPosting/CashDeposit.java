package mahabank.automation.e2e.CBS.TransactionPosting;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.options.AriaRole;
import mahabank.automation.e2e.CBS.BasePage;
import mahabank.automation.utility.Utils;
import org.testng.Assert;

import java.math.BigDecimal;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class CashDeposit extends BasePage {

    String cashDepositAccountNumberLocator1010 = "css=#UIPage_001010_accntNumber1";
    String customerNameLocator ="css=#UIPage_001010_DefaultString93";
    String amountToDepositLocator = "css=#UIPage_001010_Amount1";
    String getAmountToDepositVerifyLocator = "#UIPage_020066_popup";

    String panNumberFetchLocator = "css=#UIPage_001010_FetchPAN";
    String productDescriptionsLocator = "css=#UIPage_001010_Desc1";
    String MOPLocatorLocator = "css=#UIPage_001010_DefaultString94";
    String statementNarrativeLocator = "css=#UIPage_001010_stmtsec";

    String denomIn2000CashDrawerLocator = "#ct_swapDenominationNotesTable_denomInRow_cashDrawerNotesTable1";
    String denomIn500CashDrawerLocator = "#ct_swapDenominationNotesTable_denomInRow_cashDrawerNotesTable2";
    String denomIn200CashDrawerLocator = "#ct_swapDenominationNotesTable_denomInRow_cashDrawerNotesTable3";
    String denomIn100CashDrawerLocator = "#ct_swapDenominationNotesTable_denomInRow_cashDrawerNotesTable4";

    String summeryTransactionAmountLocator = "#ct_swapDenomination_transactionAmount";


    public void submitTransmitInCashDeposit() {
        click("#UIPage_001010_submit", "Transmit");
    }

    public void submitTransmitInCashDrawer(){
        getPage().getByLabel("Cash Drawer : Issue and").getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName("Transmit")).click();
    }

    @Override
    public void clickFetchButton() {
        click("#UIPage_001010_FetchPAN", "Fetch PAN number");
    }

    public void enterDenomIn(String denomination, String denomIn){
        if (denomination == null || !java.util.Set.of("2000", "500", "200", "100").contains(denomination))
            throw new IllegalArgumentException("Unsupported cash denomination");
        if (denomination.equalsIgnoreCase("2000")){
            typeAndTab(denomIn2000CashDrawerLocator, denomIn, denomination);
        }
        else if (denomination.equalsIgnoreCase("500")){
            typeAndTab(denomIn500CashDrawerLocator, denomIn, denomination);
        }
        else if (denomination.equalsIgnoreCase("200")){
            typeAndTab(denomIn200CashDrawerLocator, denomIn, denomination);
        }
        else if (denomination.equalsIgnoreCase("100")){
            typeAndTab(denomIn100CashDrawerLocator, denomIn, denomination);
        }
    }

    public void validateTransactionAmountSummery(String transactionAmount){
        verifyExactText(summeryTransactionAmountLocator, transactionAmount);
    }

    public void performCashDeposit(String accountNumber, String amountToDeposit){
        typeAndTab(cashDepositAccountNumberLocator1010, accountNumber, "Account Number");
        reportStep("Account number "+accountNumber+" typed.", "pass");

        typeAndTab(amountToDepositLocator, amountToDeposit, "Amount to deposit");
        clickFetchButton();
        type(statementNarrativeLocator, "self", "Statement Narrative");
        verifyNotEmpty(getPage().locator(productDescriptionsLocator), "Product Descriptions");
        verifyNotEmpty(getPage().locator(MOPLocatorLocator), "MOP Locator");
        submitTransmitInCashDeposit();
    }

    public void summeryTransactionAmountInDenomIn(String amountToDeposit){
        Utils.validateAmount(getPage().locator(summeryTransactionAmountLocator).innerText(),
                Utils.formatAmountToString(amountToDeposit));
    }
}
