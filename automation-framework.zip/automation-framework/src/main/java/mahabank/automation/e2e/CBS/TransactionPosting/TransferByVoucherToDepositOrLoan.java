package mahabank.automation.e2e.CBS.TransactionPosting;

import mahabank.automation.e2e.CBS.BasePage;

public class TransferByVoucherToDepositOrLoan extends BasePage {

    public String doNotProcessEmailCheckbox = "#UIPage_001045_mobileNumber_cb";

    public void enterFromAccountNumber(String account){
        typeAndTab("#UIPage_001045_accntNumber1", account, "From Account Number");
    }

    public void enterToAccountNumber(String account){
        typeAndTab("#UIPage_001045_accntNumber2", account, "To Account Number");
    }

    public void clickFetchPanNumber(){
        click("#UIPage_001045_FetchPAN", "Fetch PAN number");
    }

    public void enterAmountToTransfer(String amount){
        typeAndTab("#UIPage_001045_Amount1", amount,"Amount");
    }

    public void provideStatementNarrative(){
        type("#UIPage_001045_stmtnrtv1","Transfer testing during automation testing", "Statement Narrative");
    }

    @Override
    public void submitTransmit() {
        click("#UIPage_001045_submit", "Transmit");
    }

    public void Validate001045DepositTransferOfFunds(String fromAccountNumber, String toAccountNumber, String amountToTransfer){
        enterFromAccountNumber(fromAccountNumber);
        clickFetchPanNumber();
        enterAmountToTransfer(amountToTransfer);
        enterToAccountNumber(toAccountNumber);
        provideStatementNarrative();
        submitTransmit();
    }
}
