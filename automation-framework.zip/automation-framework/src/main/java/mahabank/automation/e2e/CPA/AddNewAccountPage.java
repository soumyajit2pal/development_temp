package mahabank.automation.e2e.CPA;

public class AddNewAccountPage extends BasePage{


    public String addNewAccBtn = "xpath=//*[text()='Add New Account']";

    String accNo= "xpath=//input[@placeholder='Account Number']";
    String cIF= "xpath=//input[@placeholder='CIF']";
    String customerName= "xpath=//input[@placeholder='Customer Name']";
    String OpeningDate= "xpath=//input[@placeholder='Opening Date']";
    String branchName= "xpath=//input[@placeholder='Branch Name']";
    String loanAmount= "xpath=//input[@placeholder='Loan Amount']";
    String addAccountBtn= "xpath=//*[text()='Add Account']";
    String checkAndSubmitBtn= "xpath=//*[text()='Check and Submit']";

    public void provideAccountDetails(String placeholder, String parameter){
            type(String.format("xpath=//input[@placeholder='%s']", placeholder), parameter, placeholder);
    }


    public void addAccountDetails(String accountNumber, String cIFNo, String customerName, String openingDate, String branchName, String loanAmount){
        provideAccountDetails("Account Number", accountNumber);
        provideAccountDetails("CIF", cIFNo);
        provideAccountDetails("Customer Name", customerName);
        provideAccountDetails("Opening Date", openingDate);
        provideAccountDetails("Branch Name", branchName);
        provideAccountDetails("Loan Amount", loanAmount);
        click(this.addAccountBtn, "Add Account");
        click(this.checkAndSubmitBtn,"Check And Submit");
    }

}
