package mahabank.automation.e2e.CPA;

import mahabank.automation.config.CPA.CPAConfig;
import mahabank.automation.config.ConfigurationManager;
import mahabank.automation.base.ProjectHooks;


public class BasePage extends ProjectHooks {

    String searchByLoanAccNo = "//input[@placeholder='Search By Loan Account No ']";
    String searchButton= "//span[@class='pi pi-search p-input-icon']";
    String editOptionBtn= "//td//button";

    CPAConfig inwardOutwardConfig =
            ConfigurationManager.getOrCreate(CPAConfig.class);

    public void loginAs(String loginas ){
        click(String.format("xpath=//*[text()='%s']", loginas), loginas);
    }

    public void loginAccountType(String loginaccounttype) {
        click(String.format("xpath=//*[text()='%s']", loginaccounttype), loginaccounttype);
    }

    public void validateToastMessage(String msg){
        verifyDisplayed(String.format("//*[@class=\"p-toast-detail\" and text()=\"%s\"]", msg), msg);
        waitForDisappearance(String.format("//*[@class=\"p-toast-detail\" and text()=\"%s\"]", msg));
        }

    public void searchLoanAccountNo(String accountNo){
        type(searchByLoanAccNo, accountNo, "Search By Loan Account No ");
        click(this.searchButton, "Search Button");
    }

    public void clickEditOptionButton() {
        click(this.editOptionBtn, "Edit Option Button");
    }
}

