package mahabank.automation.e2e.CPA;

public class CPAHomePage extends BasePage{

    String pFNo = "css=#username";
    String role = "css=#role";
    String name = "css=#name";
    String zoneCode = "css=#zoneCode";
    String branchCode = "css=#branchCode";
    String cader = "css=#cader";
    String submitBtn = "xpath=//span[text()='Submit']";

    public void doMakerLogin(String pfNo, String zoneCODE, String branchCODE){
        verifyDisplayed(submitBtn, "CPA login");
        type(this.pFNo, pfNo, "PF Number");
        type(this.zoneCode, zoneCODE, "Zone Code");
        type(this.branchCode, branchCODE, "Branch Code");
        click(submitBtn, "Submit");
    }

    public void doCheckerLogin(String pfNo, String zoneCODE, String branchCODE){
        verifyDisplayed(submitBtn, "CPA login");
        type(this.pFNo, pfNo, "PF Number");
        type(this.zoneCode, zoneCODE, "Zone Code");
        type(this.branchCode, branchCODE, "Branch Code");
        click(submitBtn, "Submit");
    }


}
