package mahabank.automation.e2e.CPA;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

import java.nio.file.Path;
import java.util.regex.Pattern;

public class PrePendingAccountList extends BasePage{


    //String cader = "css=#cader";

    String checkerBtn="//div[text()='Checker']";

    // Sanction Authority Section
    String selectOffice="//span[text()='Select Office']";
    String selectAuthority= "//span[text()='Select Authority']";
    String saveAndNextBtn="//*[text()='Save & Next']";

    // Application Section
    String selectDropdownOnApplSection="//*[@class=\"question_question_font__wcHEj\"]//..//select";
    String uploadDocBtn="//*[text()='Upload Document']";
    String downloadFileOnUpload = "button[aria-label=\"Download\"]";

    // Document Upload Section
    String submitBtn= "//span[text()='Submit']";
    public String noAccountPending = "//*[text()='No Account Pending.']";
    public String sanctionAuthorityErrHeader="//*[text()='Sanction Authority Error']";
    public String selectBothDropdownErrMsg="//*[text()='Please select both dropdown']";

//    public void searchLoanAccountNo(String accountNo){
//        type(searchByLoanAccNo, accountNo, "Search By Loan Account No ");
//        click(this.searchButton, "Search Button");
////        waitForTimeout(5000);
//        click(this.editOptionBtn, "Edit Option Button");
//    }

    public void sanctionAuthoritySelection(){
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[1]", "Branch", "Select Office");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[2]", "BRANCH_HEADED_BY_SCALE_2", "Select Authority");
        saveAndNextBtnAction();
       // click(this.saveAndNextBtn, "Clicked on Save & Next button");
    }

    public void saveAndNextBtnAction(){
        click(this.saveAndNextBtn, "Clicked on Save & Next button");
    }

    public void applicationSection(){
        //getPage().pause();
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[1]", "Yes", "1. CPTMS Number & " +
                                                                        "Loan sanction status is updated in system");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[2]", "Yes", "2. Application form duly filled on record");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[3]", "Yes", "3. Application form signed " +
                                            "by borrower/guarantor held on branch record");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[4]", "Yes", "4. Self-attested copy of Asset & Liability" +
                " of Borrower/Guarantors (dully filled) on record");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[5]", "Yes", "5. Duly filled Personal " +
                                                            "Information Form of Borrower(s)/" +
                                                                "Guarantors(s) along with self-attested copies of KYC/ITR/CMA/Audited Financial " +
                                                                "Statements, Income Tax/ " +
                                                    "GST Papers/ Certified Copy of Memorandum and Articles of Association/ other" +
                                                    " financial statement etc. are on record");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[6]", "Yes", "6. For " +
                                                                            "partnership firm, whether the firm is registered & " +
                                                                            "resolution is kept on record. For Company, whether Board resolution is kept on record");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[7]", "Yes", "7. CIC Copy / CRILIC Report " +
                                                                "/ Compository / Third Party " +
                                                                "Due Diligence (Bank Empanelled)/ECGC report/RBI Defaulter List has been verified");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[8]", "Yes", "8. Firm/Company /Proprietor / Partners / Directors " +
                                                                            "are in the Central Fraud Registry (CFR) list");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[9]", "Yes", "9. Report obtained from " +
                                                        "Central Economic Intelligence Bureau " +
                                                                "(CEIB) for prospective borrower (exposure of Rs.50 crore and more) and it is satisfactory");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[10]", "Yes", "10. Whether Search on CERSAI/ROC/CGTMSE etc. " +
                                                                "for the property to be mortgaged & company is done & kept on record");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[11]", "Yes", "11. Whether applicable, " +
                                                                "two Valuation reports as per loan policy have been obtained");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[12]", "Yes", "12. Pre-Sanction Visit of the borrower/guarantor, " +
                                                                "primary and collateral security carried out & Report is on record");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[13]", "Yes", "13. Valuation " +
                                                                "concurrences by Branch Manager kept on record");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[14]", "Yes", "14. Whether appraisal " +
                                                                                    "note from the respective sanctioning authority is on record");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[15]", "Yes", "15. Whether " +
                                                                        "the Bank's panel advocate has cleared Title Deeds unconditionally");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[16]", "Yes", "16. Wherever applicable, " +
                                                                    "two Title Search reports as per loan policy have been obtained");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[17]", "Yes", "17. The Bank's Panel Engineer " +
                                                                "/ Valuer have duly valued properties with geo tagging");
        saveAndNextBtnAction();
        //click(this.saveAndNextBtn, "Clicked on Save & Next button");
    }

    public void sanctionSection(){
        //getPage().pause();
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[1]", "Yes", "1. Whether unconditional acceptance of Sanction and Terms " +
                                         "& Conditions from Borrower/Guarantor kept on record");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[2]", "Yes", "2. The loan account is opened through LLMS");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[3]", "Yes", "3. Loan Documents have been duly filled in and are adequately stamped with " +
                                    "the Firm's / Company's / Common Seal affixed on documents");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[4]", "Yes", "4. Whether Paper Security is properly discharged " +
                                             "by the borrower & lien/assignment is marked in CBS");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[5]", "Yes", "5. Whether Letter of Holding of documents from the " +
                                                "executing Branch is on record");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[6]", "Yes", "6. Primary & Collateral Security/Guarantee Cover obtained (CGTMSE/CGFMU/CSSI, etc)");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[7]", "Yes", "7. Whether mortgage created as per sanction for the properties obtained as security");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[8]", "Yes", "8. Charge Creation with the Registrar of Companies is completed (wherever applicable)");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[9]", "Yes", "9. Charge Creation with CERSAI is completed (wherever applicable)");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[10]", "Yes", "10. Charge Creation with RTO/ VAHAN (In case of vehicle loans) is completed");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[11]", "Yes", "11. Charge Creation with Revenue Authorities/Societies/Association " +
                                                "is completed (wherever applicable)");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[12]", "Yes", "12. Whether modification/satisfaction of " +
                                        "charge filed in ROC/CERSAI is on record (if applicable)");
        saveAndNextBtnAction();
        //click(this.saveAndNextBtn, "Clicked on Save & Next button");
    }

    public void complianceSection(){
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[1]", "Yes", "1. Whether legal Vetting of documents done by empanelled advocate/Law officer");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[2]", "Yes", "2. Whether Correct codes viz., Product Code and BSR Code (Activity Code) " +
                                "have been mentioned in the proposal under Borrower Profile to ensure correct classification of advance accounts");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[3]", "Yes", "3. Rate of Interest has been correctly given in the system as per latest Sanction");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[4]", "Yes", "4. Whether Processing fees and other charges " +
                                    "are recovered as per Sanction Letter / Head Office guidelines");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[5]", "Yes", "5. Whether Disbursement is allowed in Pre-Disbursement Authorization portal");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[6]", "Yes", "6. Whether Current Account in other Banks have been closed as per sanction " +
                                    "(if applicable) & Current Account-Need for Discipline guidelines have been followed");
        saveAndNextBtnAction();
        //click(this.saveAndNextBtn, "Clicked on Save & Next button");
    }

    public void takeoverNormsCompliance(){
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[1]", "Yes", "1. Status Report from " +
                                "the Bank from which account is taken over obtained and is satisfactory");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[2]", "Yes", "2. Standard status " +
                                "of account with that Bank is ascertained");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[3]", "Yes", "3. Approval of takeover " +
                                "is obtained from Competent Authority");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[4]", "Yes", "4. Approval of Competent Authority " +
                                "is obtained for deviation, if any, in CR/DER/DSCR(Financial ratios) and overall credit rating");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[5]", "Yes", "5. Pre-disbursement " +
                                "inspection conducted so as to ensure adequacy of security/availability of drawing " +
                                "power and ownership of assets being charged to the Bank");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[6]", "Yes", "6. Financial Statements " +
                                "for the last 3 years have been reviewed for assessing reasons for switchover from the Bank/FI");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[7]", "Yes", "7. Latest sanction " +
                                "of previous Bank is perused and securities provided to earlier Bank is not diluted while considering for takeover");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[8]", "Yes", "8. Review of Bank statement for " +
                                "the last 12 months is done and while scrutinizing the Bank statement, " +
                                "among other things, the below mentioned parameters are looked into");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[9]", "Yes", "9. Cheque returns if any");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[10]", "Yes", "10. LC development, if any");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[11]", "Yes", "11. Turnover in the " +
                                "account is commensurate with the sales mentioned in the Balance Sheet");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[12]", "Yes", "12. Frequent cash withdrawals, if any");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[13]", "Yes", "13. Frequent over drawings/exceeding, if any");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[14]", "Yes", "14. Whether cap of working " +
                                "capital limit beyond 25% of the existing limits has been followed");
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[15]", "Yes", "15. In respect of " +
                                "Take-over accounts eligible for Stock and Receivables Audit, whether the same is conducted prior " +
                                "to disbursement of any credit facilities above Rs. 5.00 Cr except for units having External Credit Rating of “A-” and better. " +
                                "(This is also applicable even for borrowers who are not covered by Mandatory External Rating)");
        saveAndNextBtnAction();
        //click(this.saveAndNextBtn, "Clicked on Save & Next button");
    }


    public void documentUploadSection(String documentType, String filePath){
        selectByClick("(//*[@data-pc-name=\"dropdown\"])[1]", documentType, "Sanction Letter (Mandatory)");
        type("//*[@id=\"username\"]","Test Demo","Document Narration*");
        uploadFile("//*[text()='Choose Document']//..//input", resolveUploadDocument(filePath).toString(),"Choose Document & Upload");
        click(this.uploadDocBtn,"Upload Document Button");
    }

    public void validateDocumentUploadCompleted(){
        waitForDisappearance("//*[contains(text(), 'File uploading...')]");
        validateToastMessage("Document uploaded successfully");
    }


    public void validateDownloadFileOnUpload(String documentType){
        String downloadFileOnUpload = String.format("//*[text()='%s']//..//span[text()=\"Download\"]", documentType);
        handleDownloadOnClick(downloadFileOnUpload, documentType);
    }


    public void setSubmitBtn(){
        click(submitBtn,"Submit");
        validateToastMessage("Maker Submission done successfully");
    }

}
