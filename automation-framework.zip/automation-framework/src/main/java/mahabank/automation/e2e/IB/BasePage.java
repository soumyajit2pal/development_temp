package mahabank.automation.e2e.IB;

import mahabank.automation.base.ProjectHooks;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class BasePage extends ProjectHooks {

    public String logOut = "xpath=//li[@role=\"listitem\"]//a[@id=\"mainform:logout\"]";
    public String skipAndLogoff = "css=button[id=\"mainform:skipAndlogout\"]";

    public void navigateToPage(String pageName){
        click(String.format("//span[text()=\"%s\"]", pageName), pageName);
    }
    public void  doLogOut(){
        waitForTimeout(1200);
        click(logOut, "Logout");
        verifyDisplayed(skipAndLogoff, "Skip and Logoff");
        click(skipAndLogoff, "Skip and Log Off");
    }

    public void uiMessagevalidation(String msg){
       assertThat(getPage().locator("//div[contains(@class, \"ui-messages\")]//span").getByText(msg).first()).isVisible();
    }
}
