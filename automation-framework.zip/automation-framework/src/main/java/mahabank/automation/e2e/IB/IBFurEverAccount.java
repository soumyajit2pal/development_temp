package mahabank.automation.e2e.IB;

import com.microsoft.playwright.Locator;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class IBFurEverAccount extends BasePage{

    String termsAndConditionsAgreebox = "//input[@name=\"agreeBox\"]";
    String submitRequestForRequestPage = "[id=\"mainform:GlobalEdgeAcctOpenSubmitButton\"]";
    String mandatoryWindowForRequestPage = "[id=\"mainform:errorDialogId\"]";
    String messageDialogTextContent = "p[class=\"ui-state-error\"]";
    String closeWarningPoUp ="//*[@id=\"mainform:errorDialogId\"]/div[1]/a";
    public String nomineeSkipReason = "[id=\"mainform:nomineeRefuseReson\"]";
    String petName = "[id=\"mainform:petName\"]";
    String requestConfirmationHeader = "[id=\"mainform:txnPanel_header\"]";

    public void validateFurEverAccountLanded(String text){
        verifyDisplayed(getPage().locator("h3").getByText(text), text);
    }

    public void OpenFureverAccount(String text){
        getPage().waitForTimeout(5000);
        click("//*[@id=\"mainform:retailSideMenu\"]/ul/li[3]/a/span", "Open/Maintain Global Edge Furever Account");
        getPage().waitForTimeout(5000);
    }

    public void checkUncheckOfTermsAndConditions(boolean shouldBeChecked){
        setChecked(termsAndConditionsAgreebox, shouldBeChecked, "Terms & Conditions");
    }

    public void checkUncheckOfTermsAndConditionsValidation(boolean check){
        assertThat(getPage().locator(termsAndConditionsAgreebox)).isVisible();
        if (check){
            assertThat(getPage().locator(termsAndConditionsAgreebox)).isChecked();
        }else{
            assertThat(getPage().locator(termsAndConditionsAgreebox)).not().isChecked();
        }
    }

    public void clickSubmitRequestForRequestPage(){
        click(submitRequestForRequestPage, "Submit Request");
    }

    public void selectNomineeRequires(String value){
        String locator = String.format("//input[@name=\"mainform:nomieeRequiredflag\" and @value=\"%s\"]", value);
        check(locator, "Nominee required");
    }

    public void nomineeSectionLabelValidation(){
        verifyDisplayed("//span[text()=\"Nominee Title *\"]", "Nominee Title");
        verifyDisplayed("//span[text()=\"Nominee Name *\"]", "Nominee Name");
        verifyDisplayed("//span[text()=\"Nominee Address *\"]", "Nominee Address");
        verifyDisplayed("//span[text()=\"Nominee Relationship *\"]", "Nominee Relationship");
        verifyDisplayed("//span[text()=\"Nominee Age *\"]", "Nominee Age");
        verifyDisplayed("//span[text()=\"Telephone *\"]", "Telephone");
    }

    public void enterReasonForNomineeSetAsNo(String text){
        type(nomineeSkipReason, text, "Reason to skip nominee");
    }

    public void enterPetName(String petName){
        type(this.petName, petName, "Pet Name");
    }
    public void verifyConfirmationWindow(String pageheader){
        verifyDisplayed(requestConfirmationHeader, pageheader);
        verifyExactText(requestConfirmationHeader, pageheader);
    }


//    -----------------------------------------------------------------------
    public void validateWindowPopUp(){
        verifyDisplayed(mandatoryWindowForRequestPage, "Window Message");
    }

    public void validateDialogPopupMessage(String text){
        verifyExactText(messageDialogTextContent, text);
        getInnerText(messageDialogTextContent);
    }

    public void closeWarningPoUp(){
        click(closeWarningPoUp, "Close Warning pop-up");
    }

}
