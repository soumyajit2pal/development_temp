package mahabank.automation.e2e.IB;

public class IBHomePage extends IBLoginPage{

    String welcomeMessage = "xpath=(//*[@role=\"banner\"]//span[@class=\"ui-outputlabel-label\"])[1]";

    public void validateLoginSuccesFull(String username){
        verifyDisplayed(welcomeMessage, "Welcome Message");
        getInnerText(welcomeMessage);
        verifyPartialText(welcomeMessage, username);
        getPage().waitForTimeout(5000);
    }
}
