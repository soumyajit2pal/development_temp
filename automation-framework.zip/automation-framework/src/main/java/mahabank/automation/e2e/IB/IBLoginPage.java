package mahabank.automation.e2e.IB;

public class IBLoginPage extends BasePage{

    public String username = "css=[id=\"userLogin:userName\"]";
    String password = "css=[id=\"userLogin:password\"]";
    String login = "css=button[id=\"userLogin:loginButton\"]";

//    OTP Verification Login Page
    String otpVerificationAfterLogin ="css=[id=\"userOTP:OTPPanel_header\"]";
    String enterOtp = "css=[id=\"userOTP:OTPEntered\"]";
    String otpReferenceNo = "css=[id=\"userOTP:OTPReferenceNo\"]";
    String otpConfirmButton = "css=[id=\"userOTP:confirmButton1\"]";

    public void typeUserName(String username){
        type(this.username, username, "IB Username");
    }

    public void typePassWord(String password){
        type(this.password, password, "IB Password");
    }

    public void doLogin(String username, String password){
        verifyDisplayed(login, "IB login");

        typeUserName(username);
        typePassWord(password);
        click(login, "IB Login");
    }

    public void submitOtpVerification(){
        verifyDisplayed(otpVerificationAfterLogin, "User Otp Verification");
        type(enterOtp,"123456", "OTP");
        verifyDisplayed(otpReferenceNo, "OTP Reference Number");
        getInputText(otpReferenceNo);
        click(otpConfirmButton, "OTP Submit");
    }
}
