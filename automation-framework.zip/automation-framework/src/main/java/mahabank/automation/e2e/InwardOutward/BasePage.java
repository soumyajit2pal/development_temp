package mahabank.automation.e2e.InwardOutward;

import mahabank.automation.base.ProjectHooks;

public class BasePage extends ProjectHooks {
    public void linkToOpenModule(String module)
    {
        click(String.format("//*[.=\"%s\"]//..//a", module), module);
    }
}
