package mahabank.automation.e2e.InwardOutward;

import org.testng.annotations.Optional;

public class IOLoginPage extends BasePage {
    String username = "css=#txtusrname";
    String password = "css=#txtpassword";
    String signInButton = "css=[name=\"btnlogin\"]";
    String submitSignin =  "css=[name=\"btnFinalLogin\"]";

    public void doLogin(String username, String password, String capcha){
        verifyDisplayed(signInButton, "Sign in");

        type(this.username,username, "Username");
        type(this.password,password, "Password");
        click(signInButton, "Sign In");
//            TODO FOR CAPTCHA
        waitForTimeout(10000);
//            TODO FOR CAPTCHA
        click(submitSignin, "Sign In to Landing Page");
    }
}
