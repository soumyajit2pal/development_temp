package mahabank.automation.e2e.InwardOutward;

public class LetterManagementDashboard extends BasePage{
    /**
     * Validate Letter Management landing page i.e Dashboard page launched.
     */
    public void validateLMLanded(){
        verifyDisplayed("//h2[normalize-space()=\"Letter Management\"]","Letter Management" );
    }
    /**
     * Click side Tab/menu button to navigate to particular page
     */
    public void doNavigation(String navigationWindow){
        click(String.format("//span[.=\"%s\"]", navigationWindow),navigationWindow);
    }

//    Outward letter

}
