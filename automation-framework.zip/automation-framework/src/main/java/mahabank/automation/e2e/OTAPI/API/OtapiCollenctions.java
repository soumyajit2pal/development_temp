package mahabank.automation.e2e.OTAPI.API;

import com.microsoft.playwright.APIResponse;
import mahabank.automation.base.api.ApiWrapper;

import static org.testng.Assert.*;

public class OtapiCollenctions extends ApiWrapper {

    String scoremeEndpoint = "/OTAPI/ScoreMe/cifLongEnquiry";
    String payload = "{\n" +
            "\n" +
            "    \"reqTimestamp\": \"2019062051505172\",\n" +
            "\n" +
            "    \"vendor\": \"ScoreMe\",\n" +
            "\n" +
            "    \"requestId\": \"req_2019062051505172\",\n" +
            "\n" +
            "    \"client\": \"bom\",\n" +
            "\n" +
            "    \"chksum\": \"chksum\",\n" +
            "\n" +
            "    \"data\": {\n" +
            "\n" +
            "        \"requestType\": \"CIF Long Enquiry\",\n" +
            "\n" +
            "        \"requestId\": \"req_2019062051505172\",\n" +
            "\n" +
            "        \"requestMaker\": \"16146\",\n" +
            "\n" +
            "        \"requestChecker1\": \"16146\",\n" +
            "\n" +
            "        \"requestBranch\": \"1\",\n" +
            "\n" +
            "        \"customerNumber\": \"00000015068163570\"\n" +
            "\n" +
            "    }\n" +
            "\n" +
            "}";


    public void getcifLongEnquiry(){
        APIResponse response = post(scoremeEndpoint, payload);
        try { assertTrue(response.ok(), "Unexpected HTTP status: " + response.status()); }
        finally { response.dispose(); }
    }
}
