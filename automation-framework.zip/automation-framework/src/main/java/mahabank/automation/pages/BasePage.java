package mahabank.automation.pages;

import com.microsoft.playwright.Page;

import java.util.Objects;

/**
 * Base for new page objects. Tests own sessions, reporting and cleanup; pages own UI behavior.
 * Construct a new page object for each test's Page, on the Playwright owner thread.
 */
public abstract class BasePage {
    protected final Page page;

    protected BasePage(Page page) {
        this.page = Objects.requireNonNull(page, "A page object requires a Page");
    }
}
