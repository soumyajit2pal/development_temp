package mahabank.automation.utility;
import org.apache.poi.ss.usermodel.*;
import java.nio.file.Path;
import java.io.IOException;
import java.util.*;

/** Instance reader. Deprecated static adapter is thread-confined for old tests. */
public final class ExcelUtil {
    private final Path path;
    private final String sheetName;
    private static final ThreadLocal<ExcelUtil> legacyReader = new ThreadLocal<>();
    public ExcelUtil(String path, String sheetName) {
        this.path=Path.of(path); this.sheetName=sheetName; legacyReader.set(this);
    }
    @Deprecated public static RowData getRowDataByColumns(int row, String... columns) {
        ExcelUtil reader=legacyReader.get();
        if(reader==null) throw new IllegalStateException("Construct an ExcelUtil on this thread first");
        return reader.readRow(row,columns);
    }
    public static void clearLegacyReader() { legacyReader.remove(); }
    public RowData readRow(int rowIndex, String... columns) {
        try (Workbook workbook=WorkbookFactory.create(path.toFile())) {
            Sheet sheet=workbook.getSheet(sheetName);
            if(sheet==null) throw new IllegalArgumentException("Sheet not found: "+sheetName);
            Row header=sheet.getRow(0), row=sheet.getRow(rowIndex);
            if(header==null || row==null) throw new IllegalArgumentException("Missing header or row "+rowIndex);
            DataFormatter formatter=new DataFormatter(Locale.ROOT);
            FormulaEvaluator evaluator=workbook.getCreationHelper().createFormulaEvaluator();
            Map<String,Integer> indexes=new HashMap<>();
            for(Cell cell:header) {
                String name=formatter.formatCellValue(cell).trim();
                if(indexes.put(name,cell.getColumnIndex())!=null) throw new IllegalArgumentException("Duplicate header: "+name);
            }
            Map<String,String> values=new LinkedHashMap<>();
            for(String column:columns) {
                Integer index=indexes.get(column);
                if(index==null) throw new IllegalArgumentException("Column not found: "+column);
                values.put(column,formatter.formatCellValue(row.getCell(index),evaluator));
            }
            return new RowData(values);
        } catch(IOException e) { throw new IllegalStateException("Cannot read workbook: "+path,e); }
    }
}
