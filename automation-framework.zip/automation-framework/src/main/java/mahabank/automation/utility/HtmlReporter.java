package mahabank.automation.utility;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.JsonFormatter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import mahabank.automation.base.api.ApiFactory;
import mahabank.automation.config.ConfigurationManager;
import java.nio.file.*;
import java.io.IOException;
import java.util.UUID;

public abstract class HtmlReporter extends ApiFactory {
    private static final ThreadLocal<ExtentTest> parentTest = new ThreadLocal<>();
    private static final ThreadLocal<ExtentTest> test = new ThreadLocal<>();
    private static final ThreadLocal<String> testName = new ThreadLocal<>();
    private static final Object REPORT_LOCK = new Object();
    private static ExtentReports extent;
    private static Path reportDirectory;
    public static String createFolder(String base) {
        try { return Files.createDirectories(Path.of(base,UUID.randomUUID().toString())).toString(); }
        catch (IOException e) { throw new IllegalStateException("Cannot create report directory",e); }
    }
    public void startReport() {
        synchronized (REPORT_LOCK) {
            if (extent != null) return;
            reportDirectory = Path.of(createFolder("target/reports"));
            ExtentSparkReporter spark = new ExtentSparkReporter(reportDirectory.resolve("ExecutionReport.html").toString());
            var config = ConfigurationManager.configuration();
            spark.config().setTheme("dark".equalsIgnoreCase(config.reportTheme().trim()) ? Theme.DARK : Theme.STANDARD);
            spark.config().setDocumentTitle(config.reportTitle());
            spark.config().setReportName(config.reportName());
            JsonFormatter archive = new JsonFormatter(reportDirectory.resolve("ExtentResults.json").toString());
            extent = new ExtentReports(); extent.attachReporter(archive, spark);
        }
    }
    public static Path reportDirectory() {
        synchronized (REPORT_LOCK) {
            if (reportDirectory == null) throw new IllegalStateException("Report is not initialized");
            return reportDirectory;
        }
    }
    public void startTestCase(String name, String description, String... categories) {
        startReport();
        synchronized (REPORT_LOCK) {
            if (parentTest.get() == null) {
                ExtentTest parent = extent.createTest(name,description);
                parent.getModel().getInfoMap().put(ReportMerger.CASE_ID, name);
                parent.getModel().getInfoMap().put(ReportMerger.ATTEMPT_ID, UUID.randomUUID().toString());
                parent.getModel().getInfoMap().put(ReportMerger.RUN_ID, reportDirectory.getFileName().toString());
                parentTest.set(parent); test.set(parent.createNode("Test Steps"));
            } else {
                parentTest.get().getModel().setName(name);
                parentTest.get().getModel().setDescription(description);
            }
            parentTest.get().assignCategory(categories); testName.set(name);
        }
    }
    public ExtentTest getTest() { return test.get(); }
    /** Override the merge identity for a business case or a DataProvider containing opaque objects. */
    public void setReportTestId(String id) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Report test ID must not be blank");
        if (parentTest.get() == null) throw new IllegalStateException("Start a test report before assigning its ID");
        parentTest.get().getModel().getInfoMap().put(ReportMerger.CASE_ID, id);
    }
    public ExtentTest getParentTest() { return parentTest.get(); }
    public String getTestName() { return testName.get(); }
    public abstract String takeSnap();
    public static String escapeHtml(String value) {
        return value == null ? "" : value.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");
    }
    public void reportStep(String description, String status) {
        if (test.get() == null) startTestCase("Framework setup", "");
        String text = escapeHtml(description);
        switch (status.toLowerCase(java.util.Locale.ROOT)) {
            case "pass" -> test.get().pass(text);
            case "fail" -> { test.get().fail(text); throw new AssertionError(description); }
            case "warning" -> test.get().warning(text);
            case "skipped" -> test.get().skip(text);
            case "info" -> test.get().info(text);
            default -> throw new IllegalArgumentException("Unknown report status: " + status);
        }
    }
    /** Log an action failure and preserve the original exception for TestNG diagnostics. */
    public void reportFailure(String description, Throwable cause) {
        if (test.get() == null) startTestCase("Framework setup", "");
        test.get().fail(escapeHtml(description));
        throw new AssertionError(description, cause);
    }
    public static void clearTestReport() { parentTest.remove(); test.remove(); testName.remove(); }
    public void endResultSnapshot() { synchronized (REPORT_LOCK) { if(extent!=null) extent.flush(); } }
    public void endResult() {
        try {
            synchronized (REPORT_LOCK) {
                try { if (extent != null) extent.flush(); }
                finally { extent = null; }
            }
        } finally {
            clearTestReport();
        }
    }
}
