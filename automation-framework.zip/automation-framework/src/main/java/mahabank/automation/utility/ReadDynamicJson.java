package mahabank.automation.utility;
import com.fasterxml.jackson.databind.*;
import java.nio.file.*;
import java.io.*;

public final class ReadDynamicJson {
    private static final ObjectMapper MAPPER=new ObjectMapper()
            .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
            .enable(com.fasterxml.jackson.core.JsonParser.Feature.STRICT_DUPLICATE_DETECTION);
    private final JsonNode root;
    private final String path;
    public ReadDynamicJson(String path) {
        this.path=path;
        try (InputStream stream=path.startsWith("classpath:")
                ? ReadDynamicJson.class.getClassLoader().getResourceAsStream(path.substring(10))
                : Files.newInputStream(Path.of(path))) {
            if(stream==null) throw new IllegalArgumentException("JSON resource not found: "+path);
            root=MAPPER.readTree(stream);
            if(root==null || !root.isObject()) throw new IllegalArgumentException("JSON root must be an object: "+path);
        } catch(IOException e) { throw new IllegalArgumentException("Cannot read JSON: "+path,e); }
    }
    public JsonNode getObject(String key) {
        JsonNode node=root.get(key);
        if(node==null || node.isNull()) throw new IllegalArgumentException("Missing JSON test case '"+key+"' in "+path);
        if(!node.isObject()) throw new IllegalArgumentException("Test case must be an object: "+key);
        return node;
    }
    public JsonNode getRoot() { return root; }
    public static String requireText(JsonNode object, String key) {
        if (object == null || !object.isObject()) throw new IllegalArgumentException("Required fields need a JSON object");
        JsonNode value=object.get(key);
        if(value==null || !value.isTextual() || value.textValue().isBlank())
            throw new IllegalArgumentException("Missing or blank required field: "+key);
        return value.asText();
    }
}
