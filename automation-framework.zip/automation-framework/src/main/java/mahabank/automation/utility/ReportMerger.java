package mahabank.automation.utility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.model.Log;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Combine finished Extent JSON archives, in caller-supplied order from oldest to newest. */
public final class ReportMerger {
    public static final String CASE_ID = "framework.case.id";
    public static final String ATTEMPT_ID = "framework.attempt.id";
    public static final String RUN_ID = "framework.run.id";
    private static final ObjectMapper JSON = new ObjectMapper().enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS);
    public enum Mode { LATEST, ALL }
    public record Result(Path report, int executions, int uniqueTests, int sourceRuns, Mode mode) {}
    private record Source(Path archive, Path directory, List<ObjectNode> tests) {}
    private record Attempt(ObjectNode test, String caseId, String attemptId, String runId) {}
    private ReportMerger() {}

    public static Result merge(List<Path> inputs, Path outputDirectory, Mode mode) throws IOException {
        if (inputs == null || inputs.isEmpty()) throw new IllegalArgumentException("Provide at least one report directory or JSON archive");
        Objects.requireNonNull(mode, "Merge mode is required");
        Path output = canonicalOutput(outputDirectory);
        List<Source> sources = new ArrayList<>();
        for (Path input : inputs) {
            Source source = readSource(input);
            if (output.startsWith(source.directory())) throw new IllegalArgumentException("Merged output must be outside each input report directory");
            sources.add(source);
        }
        LinkedHashMap<String, Attempt> distinctAttempts = new LinkedHashMap<>();
        Set<String> runIds = new LinkedHashSet<>();
        Files.createDirectories(output);
        for (int sourceIndex = 0; sourceIndex < sources.size(); sourceIndex++) {
            Source source = sources.get(sourceIndex);
            Path prefix = Path.of("artifacts", String.format(Locale.ROOT, "source-%03d", sourceIndex + 1));
            boolean copied = false;
            for (int testIndex = 0; testIndex < source.tests().size(); testIndex++) {
                ObjectNode test = source.tests().get(testIndex);
                ObjectNode info = test.withObject("/infoMap");
                String caseId = info.path(CASE_ID).asText(test.path("name").asText());
                String attemptId = info.path(ATTEMPT_ID).asText(source.archive() + "#" + testIndex);
                String runId = info.path(RUN_ID).asText(source.directory().getFileName().toString());
                if (distinctAttempts.containsKey(attemptId)) continue;
                if (!copied) { copyArtifacts(source.directory(), output.resolve(prefix)); copied = true; }
                rebaseMedia(test, source.directory(), output, prefix);
                info.put(CASE_ID, caseId).put(ATTEMPT_ID, attemptId).put(RUN_ID, runId);
                distinctAttempts.put(attemptId, new Attempt(test, caseId, attemptId, runId));
                runIds.add(runId);
            }
        }
        if (distinctAttempts.isEmpty()) throw new IllegalArgumentException("Input archives contain no test executions");
        Map<String, List<Attempt>> histories = new LinkedHashMap<>();
        Map<String, Attempt> latest = new LinkedHashMap<>();
        for (Attempt attempt : distinctAttempts.values()) {
            histories.computeIfAbsent(attempt.caseId(), ignored -> new ArrayList<>()).add(attempt);
            latest.put(attempt.caseId(), attempt);
        }
        List<Attempt> selected = new ArrayList<>(mode == Mode.LATEST ? latest.values() : distinctAttempts.values());
        ArrayNode archive = JSON.createArrayNode(), history = JSON.createArrayNode();
        selected.forEach(attempt -> archive.add(attempt.test()));
        distinctAttempts.values().forEach(attempt -> history.add(attempt.test()));
        Path archivePath = output.resolve("ExtentResults.json");
        JSON.writerWithDefaultPrettyPrinter().writeValue(archivePath.toFile(), archive);
        JSON.writerWithDefaultPrettyPrinter().writeValue(output.resolve("ExecutionHistory.json").toFile(), history);

        ExtentReports extent = new ExtentReports();
        extent.createDomainFromJsonArchive(archivePath.toFile());
        var models = extent.getReport().getTestList();
        if (models.size() != selected.size()) throw new IOException("Extent import did not preserve the selected executions");
        for (int index = 0; index < models.size(); index++) {
            Attempt attempt = selected.get(index);
            var model = models.get(index);
            if (mode == Mode.LATEST && histories.get(attempt.caseId()).size() > 1) {
                model.addLog(Log.builder().status(Status.INFO).timestamp(new Date()).seq(model.getLogs().size())
                        .details(historyHtml(histories.get(attempt.caseId()))).build());
            } else if (mode == Mode.ALL) {
                model.setName(model.getName() + " [execution " + (index + 1) + "]");
            }
        }
        extent.setSystemInfo("Merge mode", mode.name());
        extent.setSystemInfo("Total executions", String.valueOf(distinctAttempts.size()));
        extent.setSystemInfo("Unique test cases", String.valueOf(latest.size()));
        extent.setSystemInfo("Source runs", String.valueOf(runIds.size()));
        Path report = output.resolve("ExecutionReport.html");
        ExtentSparkReporter spark = new ExtentSparkReporter(report.toString());
        spark.config().setDocumentTitle("Merged execution report");
        spark.config().setReportName(mode == Mode.LATEST ? "Merged report — latest results" : "Merged report — all executions");
        extent.attachReporter(spark);
        extent.flush();
        if (!Files.isRegularFile(report) || Files.size(report) == 0) throw new IOException("Merged HTML report was not generated");

        ObjectNode summary = JSON.createObjectNode();
        summary.put("mode", mode.name()).put("inputArchives", sources.size()).put("sourceRuns", runIds.size())
                .put("executions", distinctAttempts.size()).put("uniqueTests", latest.size()).put("displayedTests", selected.size());
        ObjectNode counts = summary.putObject("latestStatuses");
        for (Attempt attempt : latest.values()) {
            String status = attempt.test().path("status").asText(); counts.put(status, counts.path(status).asInt() + 1);
        }
        JSON.writerWithDefaultPrettyPrinter().writeValue(output.resolve("MergeSummary.json").toFile(), summary);
        return new Result(report, distinctAttempts.size(), latest.size(), runIds.size(), mode);
    }

    private static Source readSource(Path input) throws IOException {
        Path archive = input.toAbsolutePath().normalize();
        if (Files.isDirectory(archive)) {
            archive = archive.resolve(Files.isRegularFile(archive.resolve("ExecutionHistory.json")) ? "ExecutionHistory.json" : "ExtentResults.json");
        }
        if (!Files.isRegularFile(archive)) throw new IOException("Missing JSON archive: " + archive + ". HTML-only reports cannot be merged; retain ExtentResults.json from new runs.");
        archive = archive.toRealPath();
        JsonNode root = JSON.readTree(archive.toFile());
        if (root == null || !root.isArray()) throw new IOException("Expected an Extent JSON array: " + archive);
        List<ObjectNode> tests = new ArrayList<>();
        for (JsonNode test : root) {
            if (!test.isObject() || !test.path("name").isTextual() || test.path("name").asText().isBlank()
                    || !test.path("status").isTextual()) throw new IOException("Invalid test entry in " + archive);
            try { Status.valueOf(test.path("status").asText()); }
            catch (IllegalArgumentException e) { throw new IOException("Unknown test status in " + archive, e); }
            JsonNode info = test.get("infoMap");
            if (info != null && !info.isObject()) throw new IOException("Invalid test metadata in " + archive);
            if (info != null) for (String key : List.of(CASE_ID, ATTEMPT_ID, RUN_ID)) {
                JsonNode value = info.get(key);
                if (value != null && (!value.isTextual() || value.asText().isBlank()))
                    throw new IOException("Invalid test identity '" + key + "' in " + archive);
            }
            tests.add(((ObjectNode) test).deepCopy());
        }
        return new Source(archive, archive.getParent(), tests);
    }

    private static Path canonicalOutput(Path directory) throws IOException {
        Path existing = Objects.requireNonNull(directory, "Output directory is required").toAbsolutePath().normalize();
        Deque<Path> missing = new ArrayDeque<>();
        while (!Files.exists(existing)) {
            missing.addFirst(existing.getFileName()); existing = existing.getParent();
        }
        Path result = existing.toRealPath();
        for (Path part : missing) result = result.resolve(part);
        return result;
    }

    private static void copyArtifacts(Path source, Path destination) throws IOException {
        for (String folder : List.of("artifacts", "videos")) {
            Path root = source.resolve(folder);
            if (!Files.isDirectory(root)) continue;
            try (var paths = Files.walk(root)) {
                for (Path file : paths.filter(Files::isRegularFile).toList()) {
                    if (!file.toRealPath().startsWith(source)) throw new IOException("Artifact is outside the source report: " + file);
                    Path target = destination.resolve(source.relativize(file));
                    Files.createDirectories(target.getParent()); Files.copy(file, target, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
    }

    private static void rebaseMedia(JsonNode node, Path source, Path output, Path prefix) throws IOException {
        if (node.isObject()) {
            String type = node.path("type").asText();
            if ((type.equals("SCREENCAPTURE") || type.equals("VIDEO")) && node.path("path").isTextual()) {
                String value = node.path("path").asText();
                if (!value.isBlank() && !value.startsWith("http://") && !value.startsWith("https://") && !value.startsWith("data:")) {
                    Path media = source.resolve(value.replace('\\', '/')).normalize();
                    if (!Files.isRegularFile(media)) throw new IOException("Missing report media: " + media);
                    media = media.toRealPath();
                    if (!media.startsWith(source)) throw new IOException("Report media must be inside the source report: " + media);
                    Path relative = prefix.resolve(source.relativize(media));
                    Path target = output.resolve(relative);
                    Files.createDirectories(target.getParent()); Files.copy(media, target, StandardCopyOption.REPLACE_EXISTING);
                    ((ObjectNode) node).put("path", relative.toString().replace('\\', '/')).remove("resolvedPath");
                }
            }
            Iterator<JsonNode> values = node.elements();
            while (values.hasNext()) rebaseMedia(values.next(), source, output, prefix);
        } else if (node.isArray()) {
            for (JsonNode value : node) rebaseMedia(value, source, output, prefix);
        }
    }

    private static String historyHtml(List<Attempt> attempts) {
        StringBuilder html = new StringBuilder("<details><summary>Execution history (" + attempts.size() + " attempts)</summary>");
        for (int index = 0; index < attempts.size(); index++) {
            Attempt attempt = attempts.get(index);
            html.append("<details><summary>Attempt ").append(index + 1).append(" — ")
                    .append(escape(attempt.test().path("status").asText())).append(" — run ").append(escape(attempt.runId()))
                    .append("</summary><p>").append(escape(attempt.test().path("startTime").asText())).append("</p><ul>");
            appendHistorySteps(attempt.test(), html);
            html.append("</ul></details>");
        }
        return html.append("</details>").toString();
    }

    private static void appendHistorySteps(JsonNode test, StringBuilder html) {
        for (JsonNode log : test.path("logs")) {
            html.append("<li>").append(escape(log.path("status").asText())).append(": ")
                    .append(escape(log.path("details").asText())).append("</li>");
            appendMediaLink(log.path("media"), html);
        }
        for (JsonNode media : test.path("media")) appendMediaLink(media, html);
        for (JsonNode child : test.path("children")) appendHistorySteps(child, html);
    }

    private static void appendMediaLink(JsonNode media, StringBuilder html) {
        if (media.path("path").isTextual() && !media.path("path").asText().isBlank())
            html.append("<li><a href=\"").append(escape(media.path("path").asText())).append("\">View artifact</a></li>");
    }

    private static String escape(String value) { return HtmlReporter.escapeHtml(value); }

    public static void main(String[] args) throws IOException {
        String inputs = null;
        Path output = Path.of("target/reports/merged");
        Mode mode = Mode.LATEST;
        for (int index = 0; index < args.length; index += 2) {
            if (index + 1 >= args.length) throw new IllegalArgumentException("Expected --inputs paths, --output directory, or --mode latest|all");
            switch (args[index]) {
                case "--inputs" -> inputs = args[index + 1];
                case "--output" -> output = Path.of(args[index + 1]);
                case "--mode" -> mode = Mode.valueOf(args[index + 1].toUpperCase(Locale.ROOT));
                default -> throw new IllegalArgumentException("Unknown merge option: " + args[index]);
            }
        }
        if (inputs == null || inputs.isBlank()) throw new IllegalArgumentException("Set report.inputs to comma-separated report directories, oldest first");
        List<Path> paths = Arrays.stream(inputs.split(",", -1)).map(String::trim).map(value -> {
            if (value.isEmpty()) throw new IllegalArgumentException("Report input paths must not be empty");
            return Path.of(value);
        }).toList();
        Result result = merge(paths, output, mode);
        System.out.println("Merged " + result.executions() + " executions for " + result.uniqueTests() + " unique tests: " + result.report());
    }
}
