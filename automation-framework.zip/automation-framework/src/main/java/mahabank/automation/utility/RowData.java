package mahabank.automation.utility;

import java.util.Map;

public class RowData {
    private final Map<String, String> data;

    public RowData(Map<String, String> data) {
        this.data = java.util.Collections.unmodifiableMap(new java.util.LinkedHashMap<>(data));
    }

    public String  get(String columnName) {
        return data.getOrDefault(columnName, null);
    }

    public Map<String, String> getAll() {
        return data;
    }

    @Override
    public String toString() {
        return "RowData{" +
                "data=" + data +
                '}';
    }
}
