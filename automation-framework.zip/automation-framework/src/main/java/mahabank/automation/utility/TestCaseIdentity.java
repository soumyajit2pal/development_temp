package mahabank.automation.utility;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

/** Stable method/parameter identity; argument values are hashed, never written to reports. */
public final class TestCaseIdentity {
    private static final ObjectMapper JSON = new ObjectMapper();
    private TestCaseIdentity() {}

    public static String forMethod(Method method, Object[] parameters) {
        String methodId = method.toGenericString();
        if (parameters == null || parameters.length == 0) return methodId;
        ArrayNode arguments = JSON.createArrayNode();
        for (Object parameter : parameters) arguments.add(canonical(parameter));
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(arguments.toString().getBytes(StandardCharsets.UTF_8));
            return methodId + "#" + HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is unavailable", e);
        }
    }

    private static JsonNode canonical(Object value) {
        ObjectNode node = JSON.createObjectNode();
        if (value == null) return node.put("type", "null");
        if (value instanceof Map<?, ?> map) {
            node.put("type", "map");
            List<ObjectNode> entries = new ArrayList<>();
            map.forEach((key, item) -> {
                ObjectNode entry = JSON.createObjectNode();
                entry.set("key", canonical(key)); entry.set("value", canonical(item)); entries.add(entry);
            });
            entries.sort(Comparator.comparing(entry -> entry.get("key").toString()));
            ArrayNode values = node.putArray("value"); entries.forEach(values::add);
        } else if (value instanceof List<?> list) {
            node.put("type", "list");
            ArrayNode values = node.putArray("value"); list.forEach(item -> values.add(canonical(item)));
        } else if (value.getClass().isArray()) {
            node.put("type", value.getClass().getName());
            ArrayNode values = node.putArray("value");
            for (int index = 0; index < Array.getLength(value); index++) values.add(canonical(Array.get(value, index)));
        } else if (value instanceof JsonNode json) {
            node.put("type", "json"); node.set("value", sortedJson(json));
        } else if (value instanceof CharSequence || value instanceof Number || value instanceof Boolean
                || value instanceof Character || value instanceof UUID || value instanceof Enum<?>) {
            node.put("type", value.getClass().getName()).put("value", value instanceof Enum<?> item ? item.name() : value.toString());
        } else {
            // Opaque/injected objects must not accidentally collapse distinct cases. Supply an explicit ID for them.
            node.put("type", value.getClass().getName()).put("opaque", UUID.randomUUID().toString());
        }
        return node;
    }

    private static JsonNode sortedJson(JsonNode value) {
        if (value.isObject()) {
            ObjectNode result = JSON.createObjectNode();
            TreeSet<String> names = new TreeSet<>(); value.fieldNames().forEachRemaining(names::add);
            for (String name : names) result.set(name, sortedJson(value.get(name)));
            return result;
        }
        if (value.isArray()) {
            ArrayNode result = JSON.createArrayNode(); value.forEach(item -> result.add(sortedJson(item))); return result;
        }
        return value.deepCopy();
    }
}
