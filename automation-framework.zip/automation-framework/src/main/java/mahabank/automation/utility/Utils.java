package mahabank.automation.utility;

import org.testng.Assert;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public final class Utils {
    private Utils() {}

    /** Compare numeric amounts regardless of display scale (10.0 and 10.00 are equal). */
    public static void validateAmount(String actualAmount, String expectedAmount) {
        BigDecimal actual = formatAmountToDecimal(actualAmount);
        BigDecimal expected = formatAmountToDecimal(expectedAmount);
        Assert.assertEquals(actual.compareTo(expected), 0,
                "Amount mismatch. Expected=" + expected.toPlainString() + ", Actual=" + actual.toPlainString());
    }

    /** Preserve all decimal digits without converting through binary floating point. */
    public static String formatAmountToString(String amount) {
        if (amount == null || amount.isBlank()) return "0.00";
        BigDecimal value = formatAmountToDecimal(amount);
        int decimalPlaces = Math.max(0, value.scale());
        DecimalFormat format = new DecimalFormat("#,##0", DecimalFormatSymbols.getInstance(Locale.ROOT));
        format.setMinimumFractionDigits(decimalPlaces);
        format.setMaximumFractionDigits(decimalPlaces);
        return format.format(value);
    }

    public static BigDecimal formatAmountToDecimal(String amount) {
        if (amount == null || amount.isBlank()) throw new IllegalArgumentException("Amount must not be blank");
        return new BigDecimal(amount.replace(",", "").trim());
    }
}
