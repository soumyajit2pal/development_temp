package mahabank.automation.CBS;

import mahabank.automation.base.ProjectHooks;
import mahabank.automation.config.CBS.CBSConfig;
import mahabank.automation.config.ConfigurationManager;

public class BaseTest extends ProjectHooks {
    public CBSConfig cbsConfig = ConfigurationManager.getOrCreate(CBSConfig.class);
}
