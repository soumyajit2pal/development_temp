package mahabank.automation.CBS.CIF;

import mahabank.automation.CBS.BaseTest;
import mahabank.automation.e2e.CBS.CBSHomePage;
import mahabank.automation.e2e.CBS.CBSLoginPage;
import mahabank.automation.e2e.CBS.CBSConstant;
import mahabank.automation.e2e.CBS.CIF.PersonalCustomer.*;
import mahabank.automation.utility.ExcelUtil;
import mahabank.automation.utility.RowData;
import org.testng.annotations.Test;

public class TestCIFCreation extends BaseTest implements CBSConstant {
    String testdataPath = "src/main/java/mahabank/automation/data/CBS/cif_creation.xlsx";

    @Test(groups = {SANITY, REGRESSION})
    public void testCreationOnCIF() {
        String testcaseName = "TC01 - Customer Create Account";
        String testDescription = "Create New Account With Mandatory Fields";
        startTestCase(testcaseName, testDescription, SANITY, REGRESSION);
        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());

        new CBSHomePage().validateHomePageRenderedAndWorkOnAnyFalseError();
        CBSHomePage homePage = new CBSHomePage();
        registerLogoutAction(homePage::doLogOutException);

        new CBSHomePage().clickOnCard(CUSTOMER_MANAGEMENT);
        new CBSHomePage().clickOnCard("Create");
        verifyDisplayed(getByText(CREATE_PERSONAL_WIZARD), CREATE_PERSONAL_WIZARD);

        new ExcelUtil(testdataPath, "Personal Details");
        PersonalDetails pd = new PersonalDetails();

        // Personal Details
        RowData rowData = ExcelUtil.getRowDataByColumns(2, "First Name", "Father Name", "Relative Code", "Customer Type", "Title", "Permanent Address 1",
                "Permanent Address 2", "Permanent Address 3", "Permanent City Name", "Permanent City Code", "Permanent Pin Code", "Mobile Number", "Date Of Birth", "Place/City of birth",
                "Gender Code", "Marital Status", "Resident Status", "Language");

        String firstname = rowData.get("First Name");
        String fathername = rowData.get("Father Name");
        String relativecode = rowData.get("Relative Code");
        String customerType = rowData.get("Customer Type");
        String customerprefix = rowData.get("Title");
        String pAddress1 = rowData.get("Permanent Address 1");
        String pAddress2 = rowData.get("Permanent Address 2");
        String pAddress3 = rowData.get("Permanent Address 3");
        String pCityName = rowData.get("Permanent City Name");
        String pCityCode = rowData.get("Permanent City Code");
        String pPinCode = rowData.get("Permanent Pin Code");
        String pMobileNumber = rowData.get("Mobile Number");

        String DOB = rowData.get("Date Of Birth");
        String placeOfBirth = rowData.get("Place/City of birth");
        String gender = rowData.get("Gender Code");
        String maritalStatus = rowData.get("Marital Status");
        String language = rowData.get("Language");
        String residentStatus = rowData.get("Resident Status");

        pd.enterFirstName(firstname);
        pd.enterFatherName(fathername);
        pd.setRelativeCode(relativecode);
        pd.selectCustomerType(customerType);
        pd.selectTitlePrefix(customerprefix);

        pd.setMobileNumber(pMobileNumber);
        pd.ValidateMNRL();
        pd.validateMobileNumber();
        pd.setOTP();
        pd.validateOTPonMobileNumber();

        pd.setPermanentAddress1(pAddress1);
        pd.setPermanentAddress2(pAddress2);
        pd.setPermanentAddress3(pAddress3);
        pd.setCityNamePermanentAddress(pCityName);
        pd.setCityCodePermanentAddress(pCityCode);
        pd.setPinCodePermanentAddress(pPinCode);
        pd.checkIsCurrentSameAsPermanent(true);
        pd.clickFetchButtonPermanentAddress();
        pd.clickFetchButtonCurrentAddress();

        pd.selectDOB(DOB);
        pd.setPlaceCityOfBirth(placeOfBirth);
        pd.selectGender(gender);
        pd.selectLanguage(language);
        pd.selectMaritalStatus(maritalStatus);
        pd.selectResidentStatus(residentStatus);
//        cc.completeUserConsent();
//        cc.submitTransmit();



        IdentificationDetails id = new IdentificationDetails();

        id.navigateToTab(IDENTIFICATION_DETAILS);
        rowData = ExcelUtil.getRowDataByColumns(2, "Primary ID", "Primary ID Number", "Current Add Proof", "Current Add Proof No");
        String primaryId = rowData.get("Primary ID");
        String primaryIDNumber = rowData.get("Primary ID Number");
        String currentAddProof = rowData.get("Current Add Proof");
        String current_add_proof_no = rowData.get("Current Add Proof No");

        id.selectPrimaryId(primaryId);
        id.setPrimaryIdNumber(primaryIDNumber);
        id.selectCurrentAddressProof(currentAddProof);
        id.setCurrentAddressProofNumber(current_add_proof_no);

////        Identification Details
//        cc.navigateToTab(IDENTIFICATION_DETAILS);
//        rowData = ExcelUtil.getRowDataByColumns(2, "Primary ID", "Primary ID Number", "Current Add Proof", "Current Add Proof No");
//        String primaryId = rowData.get("Primary ID");
//        String primaryIDNumber = rowData.get("Primary ID Number");
//        String currentAddProof = rowData.get("Current Add Proof");
//        String current_add_proof_no = rowData.get("Current Add Proof No");
//
//        cc.selectPrimaryId(primaryId);
//        cc.setPrimaryIdNumber(primaryIDNumber);
//        cc.selectCurrentAddressProof(currentAddProof);
//        cc.setCurrentAddressProofNumber(current_add_proof_no);
////        cc.clickOnValidateName();
////        cc.setOvddocumentUpload("src/main/java/mahabank/automation/data/upload/test.jpeg");
////        cc.clickOvddocumentUploadButton();
//
////        cc.completeUserConsent();
////        cc.submitTransmit();
//
////      Non-Personal Details
        NonPersonalDetails npd = new NonPersonalDetails();
        npd.navigateToTab(NON_PERSONAL_DETAILS);
        rowData = ExcelUtil.getRowDataByColumns(2, "Segment Code", "BSR-4 Org Code", "Constitution code", "PAN OR Form 60/61", "Minority Flag",
                "Religion/Caste Code", "EWS Category");
        String segmentCode = rowData.get("Segment Code");
        String bsr4OrgCode = rowData.get("BSR-4 Org Code");
        String constitutionCode = rowData.get("Constitution code");
        String panOrForm = rowData.get("PAN OR Form 60/61");
        String minorityFlag = rowData.get("Minority Flag");
        String religionCaste = rowData.get("Religion/Caste Code");
        String ewsCategory = rowData.get("EWS Category");

        npd.selectSegmentCode(segmentCode);
        npd.selectBSR4OrgCode(bsr4OrgCode);
        npd.selectConstitutionCode(constitutionCode);
        npd.selectPanOrForm60(panOrForm);
        npd.selectMinorityFlag(minorityFlag);
        npd.selectReligionCasteCode(religionCaste);
        npd.selectEWSCategory(ewsCategory);

////        cc.completeUserConsentWhileNoPAN();
////        cc.submitTransmit();
//
////   Internet Banking Details
        InternetBankingDetails ibd = new InternetBankingDetails();
        ibd.navigateToTab(INTERNET_BANKING_DETAILS);
        rowData = ExcelUtil.getRowDataByColumns(2, "Request for IB", "Reason");

        String requestForIb = rowData.get("Request for IB");
        String reason = rowData.get("Reason");

        ibd.selectRequestForIB(requestForIb);
        ibd.selectReasonOnIB(reason);
        ibd.checkNoEmailShare();

////        cc.completeUserConsentWhileNoPAN();
////        cc.submitTransmit();
//
////   Occupation Details
        OccupationDetails od = new OccupationDetails();
        od.navigateToTab(OCCUPATION_DETAILS);
        rowData = ExcelUtil.getRowDataByColumns(2, "Occupation Description", "Whether Ex-Serviceman", "Whether Manual Scavenger", "Occupation Code"
                , "Annual Income", "Politically Exposed Person", "Whether Persons with Disabilities");
        String occupationDescriptions = rowData.get("Occupation Description");
        String exServiceMan = rowData.get("Whether Ex-Serviceman");
        String manualScavenger = rowData.get("Whether Manual Scavenger");
        String occupationCode = rowData.get("Occupation Code");
        String annualIncome = rowData.get("Annual Income");
        String politicallyExposedPerson = rowData.get("Politically Exposed Person");
        String whetherPersonsWithDisabilities = rowData.get("Whether Persons with Disabilities");

        od.selectOccupationDescrptions(occupationDescriptions);
        od.selectEx_Serviceman(exServiceMan);
        od.selectManualScavenge(manualScavenger);
        od.selectPoliticallyExpose(politicallyExposedPerson);
        od.selectPersonDisability(whetherPersonsWithDisabilities);

        od.selectOccupationCode(occupationCode);
        od.setAnnualIncome(annualIncome);
        od.clickOnValidateName();


        od.clickOkay();

        od.completeUserConsentWhileNoPAN();
        od.checkAlertMessage();
        od.submitUserConsent();
        od.retrieveQueueAfterCreation();

//        od.submitButton();
//
//        cc.retrieveQueueAfterCreation();
        new CBSHomePage().doLogOut();
    }

//    @Test
//    public void testCreationOfCorporateCIF(){
//    String testcaseName = "TC02 - Corporate Customer Create Account";
//    String testDescription = "Create Corporate New Account With Mandatory Fields";
//    String authors = "Soumyajit Pal";
//    String category = "Sanity";
//    startTestCase(testcaseName, testDescription, authors, category);
//    navigate(cbsConfig.baseUrl());
//    new CBSLoginPage().doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());
//
//    new CBSHomePage().validateCBSHomeLoaded();
//    new CBSHomePage().clickOnCard(CUSTOMER_MANAGEMENT);
//    new CBSHomePage().clickOnCard("Create");
//    verifyDisplayed(getByText(CREATE_PERSONAL_WIZARD), CREATE_PERSONAL_WIZARD);
//
//    new ExcelUtil(testdataPath,"Personal Details" );
//    CustomerCreation cc = new CustomerCreation();
//
//    // Personal Details
//   RowData rowData = ExcelUtil.getRowDataByColumns(3, "First Name", "Father Name", "Relative Code");
//
//        String firstname = ExcelUtil.getValueByColumnName(3, "First Name");
//    String fathername = ExcelUtil.getValueByColumnName(3, "Father Name");
//    String relativecode = ExcelUtil.getValueByColumnName(3, "Relative Code");
//    String customerType =  ExcelUtil.getValueByColumnName(3, "Customer Type");
//    String customerprefix =  ExcelUtil.getValueByColumnName(3, "Title");
//    String pAddress1 =  ExcelUtil.getValueByColumnName(3, "Permanent Address 1");
//    String pAddress2 =  ExcelUtil.getValueByColumnName(3, "Permanent Address 2");
//    String pAddress3 =  ExcelUtil.getValueByColumnName(3, "Permanent Address 3");
//    String pCityName = 	ExcelUtil.getValueByColumnName(3, "Permanent City Name");
//    String pCityCode = 	ExcelUtil.getValueByColumnName(3, "Permanent City Code");
//    String pPinCode = 	ExcelUtil.getValueByColumnName(3, "Permanent Pin Code");
//    String pMobileNumber = 	ExcelUtil.getValueByColumnName(3, "Mobile Number");
//
//    String DOB = ExcelUtil.getValueByColumnName(3, "Date Of Birth");
//    String placeOfBirth = ExcelUtil.getValueByColumnName(3, "Place/City of birth");
//    String gender = ExcelUtil.getValueByColumnName(3, "Gender Code");
//    String maritalStatus = ExcelUtil.getValueByColumnName(3, "Marital Status");
//    String language = ExcelUtil.getValueByColumnName(3, "Language");
//    String residentStatus = ExcelUtil.getValueByColumnName(3, "Resident Status");
//
//    cc.enterFirstName(firstname);
//    cc.enterFatherName(fathername);
//    cc.setRelativeCode(relativecode);
//    cc.selectCustomerType(customerType);
//    cc.selectTitlePrefix(customerprefix);
//
//    cc.setPermanentAddress1(pAddress1);
//    cc.setPermanentAddress2(pAddress2);
//    cc.setPermanentAddress3(pAddress3);
//    cc.setCityNamePermananentAddress(pCityName);
//    cc.setCityCodePermananentAddress(pCityCode);
//    cc.setPinCodePermananentAddress(pPinCode);
//    cc.checkIsCurrentSameAsPermanent(true);
//    cc.clickFetchButtonPermanentAddress();
//
//    cc.setMobileNumber(pMobileNumber);
////        cc.validateMobileNumber();
////        cc.setOTP();
////        cc.validateOTPonMobileNumber();
//
//    cc.selectDOB(DOB);
//    cc.setPlaceCityOfBirth(placeOfBirth);
//    cc.selectGender(gender);
//    cc.selectLanguage(language);
//    cc.selectMaritalStatus(maritalStatus);
//    cc.selectResidentStatus(residentStatus);
////        cc.completeUserConsent();
////        cc.submitTransmit();
//
////        Identification Details
//    cc.navigateToTab(IDENTIFICATION_DETAILS);
//    String primaryId = ExcelUtil.getValueByColumnName(3, "Primary ID");
//    String primaryIDNumber = ExcelUtil.getValueByColumnName(3, "Primary ID Number");
//    String currentAddProof = ExcelUtil.getValueByColumnName(3, "Current Add Proof");
//    String current_add_proof_no = ExcelUtil.getValueByColumnName(3, "Current Add Proof No");
//
//    cc.selectPrimaryId(primaryId);
//    cc.setPrimaryIdNumber(primaryIDNumber);
//    cc.selectCurrentAddressProof(currentAddProof);
//    cc.setCurrentAddressProofNumber(current_add_proof_no);
////        cc.clickOnValidateName();
////        cc.setOvddocumentUpload("src/main/java/mahabank/automation/data/upload/test.jpeg");
////        cc.clickOvddocumentUploadButton();
//
////        cc.completeUserConsent();
////        cc.submitTransmit();
//
////      Non-Personal Details
//    cc.navigateToTab(NON_PERSONAL_DETAILS);
//    String segmentCode = ExcelUtil.getValueByColumnName(3, "Segment Code");
//    String bsr4OrgCode = ExcelUtil.getValueByColumnName(3, "BSR-4 Org Code");
//    String constitutionCode = ExcelUtil.getValueByColumnName(3, "Constitution code");
//    String panOrForm = ExcelUtil.getValueByColumnName(3, "PAN OR Form 60/61");
//    String minorityFlag = ExcelUtil.getValueByColumnName(3, "Minority Flag");
//    String religionCaste = ExcelUtil.getValueByColumnName(3, "Religion/Caste Code");
//
//    cc.selectSegmentCode(segmentCode);
//    cc.selectBSR4OrgCode(bsr4OrgCode);
//    cc.selectConstitutionCode(constitutionCode);
//    cc.selectPanOrForm60(panOrForm);
//    cc.selectMinorityFlag(minorityFlag);
//    cc.selectReligionCasteCode(religionCaste);
////        cc.completeUserConsentWhileNoPAN();
////        cc.submitTransmit();
//
////   Internet Banking Details
//    cc.navigateToTab(INTERNET_BANKING_DETAILS);
//    String requestForIb = ExcelUtil.getValueByColumnName(3, "Request for IB");
//    String emailAddress = ExcelUtil.getValueByColumnName(3, "Email Address");
//    String reason = ExcelUtil.getValueByColumnName(3, "Reason");
//
//    cc.selectRequestForIB(requestForIb);
//    cc.setEmailAddress(emailAddress);
//    cc.selectReasonOnIB(reason);
////        cc.completeUserConsentWhileNoPAN();
////        cc.submitTransmit();
//
////   Occupation Details
//    cc.navigateToTab(OCCUPATION_DETAILS);
//    String occupationDescriptions = ExcelUtil.getValueByColumnName(3, "Occupation Description");
//    String exServiceMan = ExcelUtil.getValueByColumnName(3, "Whether Ex-Serviceman");
//    String manualScavenger = ExcelUtil.getValueByColumnName(3, "Whether Manual Scavenger");
//    String occupationCode = ExcelUtil.getValueByColumnName(3, "Occupation Code");
//    String annualIncome = ExcelUtil.getValueByColumnName(3, "Annual Income");
//    String politicallyExposedPerson = ExcelUtil.getValueByColumnName(3, "Politically Exposed Person");
//    String whetherPersonsWithDisabilities = ExcelUtil.getValueByColumnName(3, "Whether Persons with Disabilities");
//    String corporateCode = ExcelUtil.getValueByColumnName(3, "Corporate Code");
//
//    String officialEmailAdreess = ExcelUtil.getValueByColumnName(3, "EmployeeOfficial Email Adreess");
//    String operationsEmailAddress = ExcelUtil.getValueByColumnName(3, "Operations Email Address");
//    String employeeCode = ExcelUtil.getValueByColumnName(3, "Employee Code");
//    String epfoNumber = ExcelUtil.getValueByColumnName(3, "EPFO Number");
//
//
//    cc.selectOccupationDescrptions(occupationDescriptions);
//    cc.selectEx_Serviceman(exServiceMan);
//    cc.selectManualScavenge(manualScavenger);
//    cc.selectPoliticallyExpose(politicallyExposedPerson);
//    cc.selecttPersonDisablity(whetherPersonsWithDisabilities);
//
//    cc.selectOccupationCode(occupationCode);
//    cc.setAnnualIncome(annualIncome);
//    cc.setCorporateCode(corporateCode);
//    cc.clickCorporateFetch();
//    cc.setEmployeeCorporateDetails(officialEmailAdreess, operationsEmailAddress, employeeCode, epfoNumber);
//    cc.completeUserConsentWhileNoPAN();
//    cc.submitButton();
//    cc.retrieveQueueAfterCreation();
//    new CBSHomePage().doLogOut();
//    }
}
