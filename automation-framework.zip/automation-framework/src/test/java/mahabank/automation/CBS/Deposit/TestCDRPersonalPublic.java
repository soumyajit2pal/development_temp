package mahabank.automation.CBS.Deposit;

import com.fasterxml.jackson.databind.JsonNode;
import mahabank.automation.CBS.BaseTest;
import mahabank.automation.data.dynamic.TestDataGenerator;
import mahabank.automation.e2e.CBS.CBSConstant;
import mahabank.automation.e2e.CBS.CBSHomePage;
import mahabank.automation.e2e.CBS.CBSLoginPage;
import mahabank.automation.e2e.CBS.DEPOSIT.DepositAccount;
import mahabank.automation.e2e.CBS.DEPOSIT.RollOverDetails;
import mahabank.automation.e2e.CBS.EnquiriesPage;
import mahabank.automation.utility.ReadDynamicJson;
import org.testng.annotations.Test;

public class TestCDRPersonalPublic extends BaseTest implements CBSConstant {

    String testdataPath = "src/main/java/mahabank/automation/data/CBS/deposit_test_data.json";
    ReadDynamicJson rawdata = new ReadDynamicJson(testdataPath);

    //    GLOBAL DATA STORED HERE
//    KEY1 -> CDR_ACCOUNT_ID_AUTO_CLOSURE  -> used for Transaction posting testcases
//    KEY2 -> CDR_DEPOSIT_AMOUNT -> Used for Transaction posting
    @Test(groups = {REGRESSION, DEPOSIT_ACCOUNT_OPENING})
    public void testNewCumulativeDepositTermYearWise(){
        rawdata = new ReadDynamicJson(testdataPath);
        JsonNode testData = rawdata.getObject("TC05_CREATE_NEW_CUMULATIVE_DEPOSIT_TERM_YR_CLOSE_ON_MATURITY");
        String testcaseName =
                "TC05 - Create Cumulative Deposit Account with Nominee Declined, Rollover Instruction Setup as Close om maturity and Account Validation";
        String testDescription =
                "Objective:<br/>" +
                        "Verify successful creation and authorization of a Cumulative Deposit Account with nominee registration declined, " +
                        "creation of rollover instructions, authorization of rollover setup, and validation of account linkage through enquiry.<br/><br/>" +

                        "Pre-Requisites:<br/>" +
                        "1. Valid CIF exists in CBS.<br/>" +
                        "2. Maker and Checker users are available.<br/>" +
                        "3. User has account opening, rollover setup, and authorization privileges.<br/>" +
                        "4. Eligible rollover destination/source account exists.<br/><br/>" +

                        "Test Steps:<br/>" +
                        "1. Login to CBS using Maker credentials.<br/>" +
                        "2. Navigate to Deposit / CC / OD Accounts module.<br/>" +
                        "3. Select Create Account option.<br/>" +
                        "4. Search and select the customer CIF.<br/>" +
                        "5. Fetch and verify customer details.<br/>" +
                        "6. Enter all mandatory Core Account details.<br/>" +
                        "7. Complete Term Account related information.<br/>" +
                        "8. Select required Mode of Operation.<br/>" +
                        "9. Enter Term Deposit amount and tenure details.<br/>" +
                        "10. Navigate to Nominee Details section.<br/>" +
                        "11. Select Nominee Registration as Declined.<br/>" +
                        "12. Enter refusal reason for nominee registration.<br/>" +
                        "13. Submit the account opening request.<br/>" +
                        "14. Capture the generated Queue Number.<br/>" +
                        "15. Logout from Maker session.<br/>" +
                        "16. Login to CBS using Checker credentials.<br/>" +
                        "17. Retrieve the submitted Queue Number.<br/>" +
                        "18. Verify account details and authorize the request.<br/>" +
                        "19. Capture the generated Deposit Account Number.<br/>" +
//                        "20. Logout from CBS.<br/>" +
//                        "21. Login again using Maker credentials.<br/>" +
//                        "22. Navigate to Rollover Maintenance window.<br/>" +
//                        "23. Create rollover instructions for the newly created account.<br/>" +
//                        "24. Configure rollover option and rollover destination account.<br/>" +
//                        "25. Submit the rollover instruction setup.<br/>" +
//                        "26. Capture the generated Queue Number for rollover setup.<br/>" +
//                        "27. Logout from Maker session.<br/>" +
//                        "28. Login to CBS using Checker credentials.<br/>" +
//                        "29. Retrieve the rollover setup Queue Number.<br/>" +
//                        "30. Verify rollover details and authorize the request.<br/>" +
//                        "31. Navigate to Customer Management -> Enquiries.<br/>" +
                        "20. Search the customer CIF.<br/>" +
                        "21. Validate the newly created account under linked accounts.<br/>" +
                        "22. Logout from CBS.<br/><br/>";
        startTestCase(testcaseName, testDescription, DEPOSIT_ACCOUNT_OPENING, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());

        CBSHomePage homePage = new CBSHomePage();
        registerLogoutAction(homePage::doLogOutException);

        homePage.waitForLoaderComplete();
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(DEPOSIT_CC_OD_ACCOUNTS);

        //System.out.println("<<<<<<< Card Clicked >>>>>>>");
        homePage.clickOnCard("Create");
        DepositAccount depositAccount = new DepositAccount();
        String cifNumber = testData.path("cif").asText();
        depositAccount.setExtCifAccountNumber(cifNumber);
        depositAccount.clickFetchButton();
        depositAccount.handleDoNotProcessEmailCheckbox(depositAccount.doNotProcessEmailCheckbox);
        depositAccount.submitTransmit();

        depositAccount.waitForLoaderComplete();
//        this.waitForTimeout(35000);
        depositAccount.validateCustomerNumber(cifNumber);
//      Core Options
        String accountSegCode = testData.path("account_segment_code").asText();
        depositAccount.selectByText(depositAccount.accountSegCode, accountSegCode, "Account Seg Code");

        String productName = testData.path("product").asText();
        depositAccount.selectByText(depositAccount.product, productName, "Product");

        String productType = testData.path("product_type").asText();
        depositAccount.selectByText((depositAccount.productType), productType, "Product Type");

        String customerCat = testData.path("customer_cat").asText();
        depositAccount.selectByText((depositAccount.customerCat), customerCat, "Customer Category");

        String locationTerm = testData.path("location_term").asText();
        depositAccount.selectByText((depositAccount.locationTerm), locationTerm, "Location Term");

        String currency = testData.path("currency").asText();
        depositAccount.selectByText((depositAccount.currency), currency, "Currency");
        depositAccount.clickValidateEligibility();
//        Term A/C Options
        depositAccount.navigateToTab(TERM_AC_OPTIONS);
        String siRequired = testData.path("si_required").asText();
        depositAccount.selectByText(depositAccount.siRequired, siRequired, "SI Required");

        String modeOfOperation = testData.path("mode_operation").asText();
        depositAccount.selectByText(depositAccount.modeOperation, modeOfOperation, "Mode Of Operation");

        String termValueDeposited = testData.path("term_value_deposited").asText();
        depositAccount.type(depositAccount.termValueDeposited, termValueDeposited, "Term Value Deposited ");

        String termYears = testData.path("term_years").asText();
        depositAccount.type(depositAccount.termYears, termYears, "Term Years");

//      Nominee Details
        depositAccount.navigateToTab(NOMINEE_DETAILS);
        String nomineeRegFlag = testData.path("nominee_reg_flag").asText();
        depositAccount.selectByText(depositAccount.nomineeRegFlag, nomineeRegFlag, "Nomination registration flag");
//        TestDataGenerator dummydata = new TestDataGenerator();
//        depositAccount.type(depositAccount.refusalReason, dummydata.getRefusalReason(), "Refusal Reason");
        depositAccount.submitTransmit();
        depositAccount.waitForLoaderComplete();

        String queue1 = depositAccount.grabQueueNumberFromAlertMsg(depositAccount.retrieveQueueAfterCreation());
        homePage.doLogOut();
//
////        *****************         Checker     ********************************* //
        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.ClickOnMaker();
        String accountNumber = depositAccount.AuthoriseQueueAndGetAccountNumber(queue1);
        setGlobalData("CDR_ACCOUNT_ID_AUTO_CLOSURE", accountNumber);
        setGlobalData("CDR_DEPOSIT_AMOUNT", testData.path("term_value_deposited").asText());

        // Roll Over [May be temporary will remove after fix]
//        homePage.doLogOut();
//        homePage.doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());
//        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
//
//        RollOverDetails rollOverDetails = new RollOverDetails();
//        rollOverDetails.navigatorToWindow(ROLLOVER_WINDOW_NUMBER);// This is temporary as defect is present
//        rollOverDetails.createRollOverInstructions(accountNumber, testData.path("rollover_manual_option").asText());
//        rollOverDetails.enterRollOverToOrFromAccount(testData.path("savings_account").asText());
//
//        String queue2 = depositAccount.grabQueueNumberFromAlertMsg(depositAccount.retrieveQueueAfterCreation());
//        homePage.doLogOut();
//
//        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
//        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
//        homePage.ClickOnMaker();
//        homePage.validateJournalNumberGenerated(queue2);

//      ********************** Account Enquiry Validation **************** //
        click(homePage.homeButton, "Home button");
        homePage.validateCBSHomeLoaded();
        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        homePage.clickOnCard(ENQUIRIES, true);
        EnquiriesPage ep = new EnquiriesPage();
        ep.validateAccountNumberIsCreated(cifNumber, accountNumber);
        homePage.doLogOut();
    }

    @Test(groups = {REGRESSION, DEPOSIT_ACCOUNT_OPENING})
    public void testNewCumulativeDepositTermYearWiseSimultaneousNominee(){
        rawdata = new ReadDynamicJson(testdataPath);
        JsonNode testData = rawdata.getObject("TC07_CREATE_NEW_CUMULATIVE_DEPOSIT_TERM_YR_CLOSE_ON_MATURITY_NOM_AS_Simultaneous");
        String testcaseName =
                "TC07 - Create Cumulative Deposit Account with Nominee as Simultaneous, Rollover Instruction Setup as Close om maturity and Account Validation";
        String testDescription =
                "Objective:<br/>" +
                        "Verify successful creation and authorization of a Cumulative Deposit Account with nominee registration as Simultaneous, " +
                        "creation of rollover instructions, authorization of rollover setup, and validation of account linkage through enquiry.<br/><br/>" +

                        "Pre-Requisites:<br/>" +
                        "1. Valid CIF exists in CBS.<br/>" +
                        "2. Maker and Checker users are available.<br/>" +
                        "3. User has account opening, rollover setup, and authorization privileges.<br/>" +
                        "4. Eligible rollover destination/source account exists.<br/><br/>" +

                        "Test Steps:<br/>" +
                        "1. Login to CBS using Maker credentials.<br/>" +
                        "2. Navigate to Deposit / CC / OD Accounts module.<br/>" +
                        "3. Select Create Account option.<br/>" +
                        "4. Search and select the customer CIF.<br/>" +
                        "5. Fetch and verify customer details.<br/>" +
                        "6. Enter all mandatory Core Account details.<br/>" +
                        "7. Complete Term Account related information.<br/>" +
                        "8. Select required Mode of Operation.<br/>" +
                        "9. Enter Term Deposit amount and tenure details.<br/>" +
                        "10. Navigate to Nominee Details section.<br/>" +
                        "11. Select Nominee Registration as Declined.<br/>" +
                        "12. Enter refusal reason for nominee registration.<br/>" +
                        "13. Submit the account opening request.<br/>" +
                        "14. Capture the generated Queue Number.<br/>" +
                        "15. Logout from Maker session.<br/>" +
                        "16. Login to CBS using Checker credentials.<br/>" +
                        "17. Retrieve the submitted Queue Number.<br/>" +
                        "18. Verify account details and authorize the request.<br/>" +
                        "19. Capture the generated Deposit Account Number.<br/>" +
//                        "20. Logout from CBS.<br/>" +
//                        "21. Login again using Maker credentials.<br/>" +
//                        "22. Navigate to Rollover Maintenance window.<br/>" +
//                        "23. Create rollover instructions for the newly created account.<br/>" +
//                        "24. Configure rollover option and rollover destination account.<br/>" +
//                        "25. Submit the rollover instruction setup.<br/>" +
//                        "26. Capture the generated Queue Number for rollover setup.<br/>" +
//                        "27. Logout from Maker session.<br/>" +
//                        "28. Login to CBS using Checker credentials.<br/>" +
//                        "29. Retrieve the rollover setup Queue Number.<br/>" +
//                        "30. Verify rollover details and authorize the request.<br/>" +
                        "20. Navigate to Customer Management -> Enquiries.<br/>" +
                        "21. Search the customer CIF.<br/>" +
                        "22. Validate the newly created account under linked accounts.<br/>" +
                        "23. Logout from CBS.<br/><br/>";
        startTestCase(testcaseName, testDescription, DEPOSIT_ACCOUNT_OPENING, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());

        CBSHomePage homePage = new CBSHomePage();
        registerLogoutAction(homePage::doLogOutException);

        homePage.waitForLoaderComplete();
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(DEPOSIT_CC_OD_ACCOUNTS);

        //System.out.println("<<<<<<< Card Clicked >>>>>>>");
        homePage.clickOnCard("Create");
        DepositAccount depositAccount = new DepositAccount();
        String cifNumber = testData.path("cif").asText();
        depositAccount.setExtCifAccountNumber(cifNumber);
        depositAccount.clickFetchButton();
        depositAccount.handleDoNotProcessEmailCheckbox(depositAccount.doNotProcessEmailCheckbox);
        depositAccount.submitTransmit();

        depositAccount.waitForLoaderComplete();
//        this.waitForTimeout(35000);
        depositAccount.validateCustomerNumber(cifNumber);
//      Core Options
        String accountSegCode = testData.path("account_segment_code").asText();
        depositAccount.selectByText(depositAccount.accountSegCode, accountSegCode, "Account Seg Code");

        String productName = testData.path("product").asText();
        depositAccount.selectByText(depositAccount.product, productName, "Product");

        String productType = testData.path("product_type").asText();
        depositAccount.selectByText((depositAccount.productType), productType, "Product Type");

        String customerCat = testData.path("customer_cat").asText();
        depositAccount.selectByText((depositAccount.customerCat), customerCat, "Customer Category");

        String locationTerm = testData.path("location_term").asText();
        depositAccount.selectByText((depositAccount.locationTerm), locationTerm, "Location Term");

        String currency = testData.path("currency").asText();
        depositAccount.selectByText((depositAccount.currency), currency, "Currency");

        depositAccount.clickValidateEligibility();
//        Term A/C Options
        depositAccount.navigateToTab(TERM_AC_OPTIONS);
        String siRequired = testData.path("si_required").asText();
        depositAccount.selectByText(depositAccount.siRequired, siRequired, "SI Required");

        String modeOfOperation = testData.path("mode_operation").asText();
        depositAccount.selectByText(depositAccount.modeOperation, modeOfOperation, "Mode Of Operation");

        String termValueDeposited = testData.path("term_value_deposited").asText();
        depositAccount.type(depositAccount.termValueDeposited, termValueDeposited, "Term Value Deposited ");

        String termYears = testData.path("term_years").asText();
        depositAccount.type(depositAccount.termYears, termYears, "Term Years");

//      Nominee Details
        depositAccount.navigateToTab(NOMINEE_DETAILS);
        String nomineeRegFlag = testData.path("nominee_reg_flag").asText();
        depositAccount.selectByText(depositAccount.nomineeRegFlag, nomineeRegFlag, "Nomination registration flag");
//        TestDataGenerator dummydata = new TestDataGenerator();

        depositAccount.ValidationOfNomineeRegistrationWhileNomineeFlagYes(testData.path("nominee_reg_flag").asText(), testData.path("type_of_nomination").asText(),
                testData.path("number_of_nominee").asInt(),testData.path("nominee_tile").asText(),new TestDataGenerator().getFullName(),
                testData.path("nominee_age").asText(), testData.path("nominee_relationship").asText(),
                testData.path("nominee_address").asText(), testData.path("nominee_telephone_number").asText(),
                null
                , testData.path("percentage").asText());
//        depositAccount.type(depositAccount.refusalReason, dummydata.getRefusalReason(), "Refusal Reason");
        depositAccount.submitTransmit();
        depositAccount.waitForLoaderComplete();

        String queue1 = depositAccount.grabQueueNumberFromAlertMsg(depositAccount.retrieveQueueAfterCreation());
        homePage.doLogOut();
//
////        *****************         Checker     ********************************* //
        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.ClickOnMaker();
        String accountNumber = depositAccount.AuthoriseQueueAndGetAccountNumber(queue1);
//        // Roll Over [May be temporary will remove after fix]
//        homePage.doLogOut();
//        homePage.doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());
//        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
//
//        RollOverDetails rollOverDetails = new RollOverDetails();
//        rollOverDetails.navigatorToWindow(ROLLOVER_WINDOW_NUMBER);// This is temporary as defect is present
//        rollOverDetails.createRollOverInstructions(accountNumber, testData.path("rollover_manual_option").asText());
//        rollOverDetails.enterRollOverToOrFromAccount(testData.path("savings_account").asText());
//
//        String queue2 = depositAccount.grabQueueNumberFromAlertMsg(depositAccount.retrieveQueueAfterCreation());
//        homePage.doLogOut();
//
//        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
//        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
//        homePage.ClickOnMaker();
//        homePage.validateJournalNumberGenerated(queue2);

//      ********************** Account Enquiry Validation **************** //
        click(homePage.homeButton, "Home button");
        homePage.validateCBSHomeLoaded();
        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        homePage.clickOnCard(ENQUIRIES, true);
        EnquiriesPage ep = new EnquiriesPage();
        ep.validateAccountNumberIsCreated(cifNumber, accountNumber);
        homePage.doLogOut();
    }

    @Test(groups = {REGRESSION, DEPOSIT_ACCOUNT_OPENING})
    public void testNewCumulativeDepositTermYearWiseNomineeDeclinedAutoRollover(){
        rawdata = new ReadDynamicJson(testdataPath);
        JsonNode testData = rawdata.getObject("TC09_CREATE_NEW_CUMULATIVE_DEPOSIT_TERM_YR_CLOSE_ON_MATURITY_NOM_DECLINED_AUTOROLLOVER");
        String testcaseName =
                "TC09 - Create Cumulative Deposit Account with Nominee Declined, Rollover Instruction Setup as Auto Rollover and Account Validation";
        String testDescription =
                "Objective:<br/>" +
                        "Verify successful creation and authorization of a Cumulative Deposit Account with nominee registration declined, " +
                        "creation of rollover instructions, authorization of rollover setup, and validation of account linkage through enquiry.<br/><br/>" +

                        "Pre-Requisites:<br/>" +
                        "1. Valid CIF exists in CBS.<br/>" +
                        "2. Maker and Checker users are available.<br/>" +
                        "3. User has account opening, rollover setup, and authorization privileges.<br/>" +
                        "4. Eligible rollover destination/source account exists.<br/><br/>" +

                        "Test Steps:<br/>" +
                        "1. Login to CBS using Maker credentials.<br/>" +
                        "2. Navigate to Deposit / CC / OD Accounts module.<br/>" +
                        "3. Select Create Account option.<br/>" +
                        "4. Search and select the customer CIF.<br/>" +
                        "5. Fetch and verify customer details.<br/>" +
                        "6. Enter all mandatory Core Account details.<br/>" +
                        "7. Complete Term Account related information.<br/>" +
                        "8. Select required Mode of Operation.<br/>" +
                        "9. Enter Term Deposit amount and tenure details.<br/>" +
                        "10. Navigate to Nominee Details section.<br/>" +
                        "11. Select Nominee Registration as Declined.<br/>" +
                        "12. Enter refusal reason for nominee registration.<br/>" +
                        "13. Submit the account opening request.<br/>" +
                        "14. Capture the generated Queue Number.<br/>" +
                        "15. Logout from Maker session.<br/>" +
                        "16. Login to CBS using Checker credentials.<br/>" +
                        "17. Retrieve the submitted Queue Number.<br/>" +
                        "18. Verify account details and authorize the request.<br/>" +
                        "19. Capture the generated Deposit Account Number.<br/>" +
//                        "20. Logout from CBS.<br/>" +
//                        "21. Login again using Maker credentials.<br/>" +
//                        "22. Navigate to Rollover Maintenance window.<br/>" +
//                        "23. Create rollover instructions for the newly created account.<br/>" +
//                        "24. Configure rollover option as Auto-Rollover<br/>" +
                        "20. Navigate to Customer Management -> Enquiries.<br/>" +
                        "21. Search the customer CIF.<br/>" +
                        "22. Validate the newly created account under linked accounts.<br/>" +
                        "23. Logout from CBS.<br/><br/>";
        startTestCase(testcaseName, testDescription, DEPOSIT_ACCOUNT_OPENING, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());

        CBSHomePage homePage = new CBSHomePage();
        registerLogoutAction(homePage::doLogOutException);

        homePage.waitForLoaderComplete();
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(DEPOSIT_CC_OD_ACCOUNTS);

        //System.out.println("<<<<<<< Card Clicked >>>>>>>");
        homePage.clickOnCard("Create");
        DepositAccount depositAccount = new DepositAccount();
        String cifNumber = testData.path("cif").asText();
        depositAccount.setExtCifAccountNumber(cifNumber);
        depositAccount.clickFetchButton();
        depositAccount.handleDoNotProcessEmailCheckbox(depositAccount.doNotProcessEmailCheckbox);
        depositAccount.submitTransmit();

        depositAccount.waitForLoaderComplete();
//        this.waitForTimeout(35000);
        depositAccount.validateCustomerNumber(cifNumber);
//      Core Options
        String accountSegCode = testData.path("account_segment_code").asText();
        depositAccount.selectByText(depositAccount.accountSegCode, accountSegCode, "Account Seg Code");

        String productName = testData.path("product").asText();
        depositAccount.selectByText(depositAccount.product, productName, "Product");

        String productType = testData.path("product_type").asText();
        depositAccount.selectByText((depositAccount.productType), productType, "Product Type");

        String customerCat = testData.path("customer_cat").asText();
        depositAccount.selectByText((depositAccount.customerCat), customerCat, "Customer Category");

        String locationTerm = testData.path("location_term").asText();
        depositAccount.selectByText((depositAccount.locationTerm), locationTerm, "Location Term");

        String currency = testData.path("currency").asText();
        depositAccount.selectByText((depositAccount.currency), currency, "Currency");
        depositAccount.clickValidateEligibility();
//        Term A/C Options
        depositAccount.navigateToTab(TERM_AC_OPTIONS);
        String siRequired = testData.path("si_required").asText();
        depositAccount.selectByText(depositAccount.siRequired, siRequired, "SI Required");

        String modeOfOperation = testData.path("mode_operation").asText();
        depositAccount.selectByText(depositAccount.modeOperation, modeOfOperation, "Mode Of Operation");

        String termValueDeposited = testData.path("term_value_deposited").asText();
        depositAccount.type(depositAccount.termValueDeposited, termValueDeposited, "Term Value Deposited ");

        String termYears = testData.path("term_years").asText();
        depositAccount.type(depositAccount.termYears, termYears, "Term Years");

//      Nominee Details
        depositAccount.navigateToTab(NOMINEE_DETAILS);
        String nomineeRegFlag = testData.path("nominee_reg_flag").asText();
        depositAccount.selectByText(depositAccount.nomineeRegFlag, nomineeRegFlag, "Nomination registration flag");
//        TestDataGenerator dummydata = new TestDataGenerator();
//        depositAccount.type(depositAccount.refusalReason, dummydata.getRefusalReason(), "Refusal Reason");
        depositAccount.submitTransmit();
        depositAccount.waitForLoaderComplete();

        String queue1 = depositAccount.grabQueueNumberFromAlertMsg(depositAccount.retrieveQueueAfterCreation());
        homePage.doLogOut();
//
////        *****************         Checker     ********************************* //
        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.ClickOnMaker();
        String accountNumber = depositAccount.AuthoriseQueueAndGetAccountNumber(queue1);
//        // Roll Over [May be temporary will remove after fix]
//        homePage.doLogOut();
//        homePage.doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());
//        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
//
//        RollOverDetails rollOverDetails = new RollOverDetails();
//        rollOverDetails.navigatorToWindow(ROLLOVER_WINDOW_NUMBER);// This is temporary as defect is present
//        rollOverDetails.createRollOverInstructions(accountNumber, testData.path("rollover_manual_option").asText());
//        rollOverDetails.validateJournalNumberGeneratedWithoutQueue();
//      ********************** Account Enquiry Validation **************** //
        click(homePage.homeButton, "Home button");
        homePage.validateCBSHomeLoaded();
        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        homePage.clickOnCard(ENQUIRIES, true);
        EnquiriesPage ep = new EnquiriesPage();
        ep.validateAccountNumberIsCreated(cifNumber, accountNumber);
        homePage.doLogOut();
    }
}
