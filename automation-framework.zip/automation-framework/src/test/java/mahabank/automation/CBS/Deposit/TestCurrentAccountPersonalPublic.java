package mahabank.automation.CBS.Deposit;

import com.fasterxml.jackson.databind.JsonNode;
import mahabank.automation.CBS.BaseTest;
import mahabank.automation.e2e.CBS.CBSConstant;
import mahabank.automation.e2e.CBS.CBSHomePage;
import mahabank.automation.e2e.CBS.CBSLoginPage;
import mahabank.automation.e2e.CBS.DEPOSIT.DepositAccount;
import mahabank.automation.e2e.CBS.EnquiriesPage;
import mahabank.automation.utility.ReadDynamicJson;
import org.testng.annotations.Test;

public class TestCurrentAccountPersonalPublic  extends BaseTest implements CBSConstant {

    public String testdataPath = "src/main/java/mahabank/automation/data/CBS/deposit_test_data.json";
    ReadDynamicJson rawdata = new ReadDynamicJson(testdataPath);

    @Test(groups = {REGRESSION, DEPOSIT_ACCOUNT_OPENING})
    public void testNewCurrentAccountSinglyOperatingNomineeAsDeclined(){

        JsonNode testData = rawdata.getObject("TC04_NEW_CURRENT_ACCOUNT_OPERATING_SINGLY_NOMI_DECLINED");
        String testcaseName =
                "TC04 - Create New Current Account, Nominee Declined, Single Operating Mode";
        String testDescription =
                "Objective:<br/>" +
                        "Verify successful creation and authorization of a Current Account for an individual customer with " +
                        "Single Operating Mode and Nominee Registration declined.<br/><br/>" +

                        "Pre-Requisites:<br/>" +
                        "1. Valid non-personal CIF exists in CBS.<br/>" +
                        "2. Maker and Checker users are available.<br/>" +
                        "3. User has account opening and authorization privileges.<br/><br/>" +

                        "Test Steps:<br/>" +
                        "1. Login to CBS using Maker credentials.<br/>" +
                        "2. Navigate to Deposit/CC -> Account Opening.<br/>" +
                        "3. Search and select the customer CIF.<br/>" +
                        "4. Select Current Account as the account product.<br/>" +
                        "5. Enter all mandatory account opening details.<br/>" +
                        "6. Select Operating Mode as Singly.<br/>" +
                        "7. Select Nominee Registration as No.<br/>" +
                        "8. Complete all remaining mandatory fields required for account opening.<br/>" +
                        "9. Submit the account opening request.<br/>" +
                        "10. Capture the generated Queue Number.<br/>" +
                        "11. Logout from Maker session.<br/>" +
                        "12. Login to CBS using Checker credentials.<br/>" +
                        "13. Retrieve the submitted Queue Number.<br/>" +
                        "14. Verify account details and authorize the request.<br/>" +
                        "15. Capture the generated Account Number.<br/>" +
                        "16. Navigate to Customer/Account Inquiry screen.<br/>" +
                        "17. Search using CIF or Account Number.<br/>" +
                        "18. Open the Linked Accounts tab.<br/>" +
                        "19. Verify the newly created account is available under Linked Accounts.<br/><br/>";
        startTestCase(testcaseName, testDescription, DEPOSIT_ACCOUNT_OPENING, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());

        CBSHomePage homePage = new CBSHomePage();
        registerLogoutAction(homePage::doLogOutException);

        homePage.waitForLoaderComplete();
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(DEPOSIT_CC_OD_ACCOUNTS);

        homePage.clickOnCard("Create");
        DepositAccount depositAccount = new DepositAccount();
        String cifNumber = testData.path("cif").asText();
        depositAccount.setExtCifAccountNumber(cifNumber);
        depositAccount.clickFetchButton();
        depositAccount.handleDoNotProcessEmailCheckbox(depositAccount.doNotProcessEmailCheckbox);
        depositAccount.submitTransmit();

        depositAccount.waitForLoaderComplete();
        depositAccount.validateCustomerNumber(cifNumber);

//      Core Options
        depositAccount.provideDetailsOfCoreOptionsForCurrentAccount(testData.path("account_segment_code").asText(), testData.path("product").asText(),
                testData.path("product_type").asText(),  testData.path("customer_cat").asText(), testData.path("location_term").asText(),
                testData.path("currency").asText(), testData.path("bsr_activity_code").asText(), testData.path("credit_facility_from_other_bank").asText(),
                testData.path("declaration_obtained").asText());

//        Term A/C Options
        depositAccount.navigateToTab(TERM_AC_OPTIONS);
        String siRequired = testData.path("si_required").asText();
        depositAccount.selectByText(depositAccount.siRequired, siRequired, "SI Required");

        String modeOfOperation = testData.path("mode_operation").asText();
        depositAccount.selectByText(depositAccount.modeOperation, modeOfOperation, "Mode Of Operation");

//      Nominee Details
        depositAccount.navigateToTab(NOMINEE_DETAILS);
        depositAccount.ValidationOfNomineeRegistrationWhileNomineeFlagNo(
                testData.path("nominee_reg_flag").asText()
        );
        depositAccount.submitTransmit();
        depositAccount.waitForLoaderComplete();

        String queue1 = depositAccount.grabQueueNumberFromAlertMsg(depositAccount.retrieveQueueAfterCreation());
        homePage.doLogOut();

//        *****************         Checker     ********************************* //
        new CBSLoginPage().doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.ClickOnMaker();

        String accountNumber = depositAccount.AuthoriseQueueAndGetAccountNumber(queue1);

//      ********************** Account Enquiry Validation **************** //
        click(homePage.homeButton, "Home Button");
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        //System.out.println("<<<<<<< Card Clicked >>>>>>>");
        homePage.clickOnCard(ENQUIRIES, true);
        EnquiriesPage ep = new EnquiriesPage();
        ep.validateAccountNumberIsCreated(cifNumber, accountNumber);
        homePage.doLogOut();
    }

}
