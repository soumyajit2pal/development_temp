package mahabank.automation.CBS.Deposit;

import com.fasterxml.jackson.databind.JsonNode;
import mahabank.automation.CBS.BaseTest;
import mahabank.automation.e2e.CBS.CBSHomePage;
import mahabank.automation.e2e.CBS.CBSLoginPage;
import mahabank.automation.e2e.CBS.CBSConstant;
import mahabank.automation.e2e.CBS.DEPOSIT.DepositAccount;
import mahabank.automation.e2e.CBS.DEPOSIT.RollOverDetails;
import mahabank.automation.e2e.CBS.EnquiriesPage;
import mahabank.automation.utility.ReadDynamicJson;
import mahabank.automation.data.dynamic.TestDataGenerator;
import org.testng.annotations.Test;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;

public class TestMIDSPersonalPublic extends BaseTest implements CBSConstant {

    String testdataPath = "src/main/java/mahabank/automation/data/CBS/deposit_test_data.json";
    ReadDynamicJson rawdata = new ReadDynamicJson(testdataPath);
 //    GLOBAL DATA STORED HERE
//    KEY1 -> MIDS_ACCOUNT_ID_AUTO_CLOSURE  -> used for Transaction posting testcases
//    KEY2 -> MIDS_DEPOSIT_AMOUNT -> Used for Transaction posting
    @Test(groups = {REGRESSION, DEPOSIT_ACCOUNT_OPENING})
    public void testNewMIDSAccountCreation(){
        ReadDynamicJson rawdata = new ReadDynamicJson(testdataPath);
        JsonNode testData = rawdata.getObject("TC06_CREATE_NEW_MIDS_TERM_YR_CLOSE_ON_MATURITY");
        String testcaseName =
                "TC05 - Create New MIDS Account with Nominee Declined, Close on Maturity Instruction and Account Validation";
        String testDescription =
                "Objective:<br/>" +
                        "Verify successful creation and authorization of a Monthly Interest Deposit Scheme (MIDS) account with nominee registration declined, " +
                        "monthly interest payout configuration, setup of rollover instructions as Close on Maturity, and validation of the account through enquiry.<br/><br/>" +

                        "Pre-Requisites:<br/>" +
                        "1. Valid CIF exists in CBS.<br/>" +
                        "2. Maker and Checker users are available.<br/>" +
                        "3. User has account opening, rollover maintenance, and authorization privileges.<br/>" +
                        "4. Valid Savings Account is available for monthly interest credit.<br/><br/>" +

                        "Test Steps:<br/>" +
                        "1. Login to CBS using Maker credentials.<br/>" +
                        "2. Navigate to Deposit / CC / OD Accounts module.<br/>" +
                        "3. Select Create Account option.<br/>" +
                        "4. Search and select the customer CIF.<br/>" +
                        "5. Fetch and verify customer details.<br/>" +
                        "6. Enter all mandatory account opening details.<br/>" +
                        "7. Select Monthly Interest Deposit Scheme (MIDS) as the deposit product.<br/>" +
                        "8. Configure monthly interest payout details and interest credit account.<br/>" +
                        "9. Complete Term Account related information.<br/>" +
                        "10. Select the required Mode of Operation.<br/>" +
                        "11. Enter deposit amount and tenure details.<br/>" +
                        "12. Navigate to Nominee Details section.<br/>" +
                        "13. Select Nominee Registration as Declined.<br/>" +
                        "14. Enter refusal reason for nominee registration.<br/>" +
                        "15. Submit the account opening request.<br/>" +
                        "16. Capture the generated Queue Number.<br/>" +
                        "17. Logout from Maker session.<br/>" +
                        "18. Login to CBS using Checker credentials.<br/>" +
                        "19. Retrieve the submitted Queue Number.<br/>" +
                        "20. Verify account details and authorize the request.<br/>" +
                        "21. Capture the generated MIDS Account Number.<br/>" +
//                        "22. Logout from CBS.<br/>" +
//                        "23. Login again using Maker credentials.<br/>" +
//                        "24. Navigate to Rollover Maintenance window.<br/>" +
//                        "25. Create rollover instructions for the newly created account.<br/>" +
//                        "26. Configure rollover instruction as 'Close on Maturity'.<br/>" +
//                        "27. Submit the rollover setup request.<br/>" +
//                        "28. Capture the generated Queue Number for rollover setup.<br/>" +
//                        "29. Logout from Maker session.<br/>" +
//                        "30. Login to CBS using Checker credentials.<br/>" +
//                        "31. Retrieve the rollover Queue Number.<br/>" +
//                        "32. Verify rollover details and authorize the request.<br/>" +
                        "21. Navigate to Customer Management -> Enquiries.<br/>" +
                        "22. Search the customer CIF.<br/>" +
                        "23. Validate the newly created MIDS account under Linked Accounts.<br/>" +
                        "24. Logout from CBS.<br/><br/>";
        startTestCase(testcaseName, testDescription, DEPOSIT_ACCOUNT_OPENING, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());

        CBSHomePage homePage = new CBSHomePage();
        registerLogoutAction(homePage::doLogOutException);

        homePage.waitForLoaderComplete();
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(DEPOSIT_CC_OD_ACCOUNTS);

        //System.out.println("<<<<<<< Card Clicked >>>>>>>");
        homePage.clickOnCard("Create");
        DepositAccount depositAccount = new DepositAccount();
        String cifNumber = testData.path("cif").asText();
        depositAccount.setExtCifAccountNumber(cifNumber);
        depositAccount.clickFetchButton();
        depositAccount.handleDoNotProcessEmailCheckbox(depositAccount.doNotProcessEmailCheckbox);
        depositAccount.submitTransmit();

        depositAccount.waitForLoaderComplete();
//        this.waitForTimeout(35000);
        depositAccount.validateCustomerNumber(cifNumber);
//      Core Options
        String accountSegCode = testData.path("account_segment_code").asText();
        depositAccount.selectByText(depositAccount.accountSegCode, accountSegCode, "Account Seg Code");

        String productName = testData.path("product").asText();
        depositAccount.selectByText(depositAccount.product, productName, "Product"); //"product": "37:MIDS",

        String productType = testData.path("product_type").asText();
        depositAccount.selectByText((depositAccount.productType), productType, "Product Type");

        String customerCat = testData.path("customer_cat").asText();
        depositAccount.selectByText((depositAccount.customerCat), customerCat, "Customer Category");

        String locationTerm = testData.path("location_term").asText();
        depositAccount.selectByText((depositAccount.locationTerm), locationTerm, "Location Term");

        String currency = testData.path("currency").asText();
        depositAccount.selectByText((depositAccount.currency), currency, "Currency");
        depositAccount.clickValidateEligibility();

        String interestPaymentMethod = testData.path("interest_payment_method").asText();
        depositAccount.selectByText(depositAccount.interestPaymentmethod, interestPaymentMethod, "Interest Pay Method");

        String transferAccountNumber = testData.path("savings_account").asText();
        depositAccount.type(depositAccount.interestTransferAccountNumber, transferAccountNumber, "Transfer Account Number ");

//        Term A/C Options
        depositAccount.navigateToTab(TERM_AC_OPTIONS);
        String siRequired = testData.path("si_required").asText();
        depositAccount.selectByText(depositAccount.siRequired, siRequired, "SI Required");

        String modeOfOperation = testData.path("mode_operation").asText();
        depositAccount.selectByText(depositAccount.modeOperation, modeOfOperation, "Mode Of Operation");

        String termValueDeposited = testData.path("term_value_deposited").asText();
        depositAccount.type(depositAccount.termValueDeposited, termValueDeposited, "Term Value Deposited ");

        String termYears = testData.path("term_years").asText();
        depositAccount.type(depositAccount.termYears, termYears, "Term Years");

//      Nominee Details
        depositAccount.navigateToTab(NOMINEE_DETAILS);
        String nomineeRegFlag = testData.path("nominee_reg_flag").asText();
        depositAccount.selectByText(depositAccount.nomineeRegFlag, nomineeRegFlag, "Nomination registration flag");
//
        depositAccount.submitTransmit();
        depositAccount.waitForLoaderComplete();

        String queue1 = depositAccount.grabQueueNumberFromAlertMsg(depositAccount.retrieveQueueAfterCreation());
        homePage.doLogOut();
//
////        *****************         Checker     ********************************* //
        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.ClickOnMaker();
        String accountNumber = depositAccount.AuthoriseQueueAndGetAccountNumber(queue1);
        setGlobalData("MIDS_ACCOUNT_ID_AUTO_CLOSURE", accountNumber);
        setGlobalData("MIDS_DEPOSIT_AMOUNT", testData.path("term_value_deposited").asText());

        // Roll Over [May be temporary will remove after fix]
//        homePage.doLogOut();
//        homePage.doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());
//        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
//
//        RollOverDetails rollOverDetails = new RollOverDetails();
//        rollOverDetails.navigatorToWindow(ROLLOVER_WINDOW_NUMBER);// This is temporary as defect is present
//        rollOverDetails.createRollOverInstructions(accountNumber, testData.path("rollover_manual_option").asText());
//        rollOverDetails.enterRollOverToOrFromAccount(testData.path("savings_account").asText());
//
//        String queue2 = depositAccount.grabQueueNumberFromAlertMsg(depositAccount.retrieveQueueAfterCreation());
//        homePage.doLogOut();
//
//        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
//        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
//        homePage.ClickOnMaker();
//        homePage.validateJournalNumberGenerated(queue2);

//      ********************** Account Enquiry Validation **************** //
        click(homePage.homeButton, "Home button");
        homePage.validateCBSHomeLoaded();
        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        homePage.clickOnCard(ENQUIRIES, true);
        EnquiriesPage ep = new EnquiriesPage();
        ep.validateAccountNumberIsCreated(cifNumber, accountNumber);
        homePage.doLogOut();
    }
}
