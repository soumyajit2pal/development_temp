package mahabank.automation.CBS.Deposit;

import com.fasterxml.jackson.databind.JsonNode;
import mahabank.automation.CBS.BaseTest;
import mahabank.automation.data.dynamic.TestDataGenerator;
import mahabank.automation.e2e.CBS.CBSConstant;
import mahabank.automation.e2e.CBS.CBSHomePage;
import mahabank.automation.e2e.CBS.CBSLoginPage;
import mahabank.automation.e2e.CBS.DEPOSIT.DepositAccount;
import mahabank.automation.e2e.CBS.EnquiriesPage;
import mahabank.automation.utility.ReadDynamicJson;
import org.testng.annotations.Test;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class TestRDPersonalPublic extends BaseTest implements CBSConstant {

    String testdataPath = "src/main/java/mahabank/automation/data/CBS/deposit_test_data.json";
    ReadDynamicJson rawdata = new ReadDynamicJson(testdataPath);

    @Test(enabled = false, groups = {SANITY})
    public void testNewRecurringDeposit(){
        String testdataPath = "src/main/java/mahabank/automation/data/CBS/deposit_test_data.json";
        ReadDynamicJson rawdata = new ReadDynamicJson(testdataPath);
        JsonNode testData = rawdata.getObject("TC03_CREATE_NEW_RECURRING_DEPOSIT");
        String testcaseName = "TC03 - Create A New RD Account";
        String testDescription = "Create a recurring deposit account\n" +
                "Steps:\n" +
                "1. Login in to CBS as maker\n" +
                "2. Search CIF id under 'Deposit/CC' title\n" +
                "3. Provide all core details like product type, customer category etc\n" +
                "4. Submit and retrieve queue number\n" +
                "5. Now login as checker\n" +
                "6. authorise the respective queue number\n" +
                "7. Retrieve the account number\n" +
                "8. Now query the same account and validate under linked accounts tab account number is present";
        startTestCase(testcaseName, testDescription, SANITY);

//        **************** Testcase Execution Started **************************** //

        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());

//        this.waitForTimeout(15000);
        new CBSHomePage().waitForLoaderComplete();
        new CBSHomePage().validateCBSHomeLoaded();
        new CBSHomePage().clickOnCard(DEPOSIT_CC_OD_ACCOUNTS, false);
        //System.out.println("<<<<<<< Card Clicked >>>>>>>");
        new CBSHomePage().clickOnCard("Create");
        DepositAccount depositAccount = new DepositAccount();
        String cifNumber = testData.path("cif").asText();
        depositAccount.setExtCifAccountNumber(cifNumber);
        depositAccount.clickFetchButton();
        depositAccount.submitTransmit();

        depositAccount.waitForLoaderComplete();
//        this.waitForTimeout(35000);
        depositAccount.validateCustomerNumber(cifNumber);
//      Core Options
        String accountSegCode = testData.path("account_segment_code").asText();
        depositAccount.selectByText(depositAccount.accountSegCode, accountSegCode, "Account Seg Code");

        String productName = testData.path("product").asText();
        depositAccount.selectByText(depositAccount.product, productName, "Product");

        String productType = testData.path("product_type").asText();
        depositAccount.selectByText((depositAccount.productType), productType, "Product Type");

        String customerCat = testData.path("customer_cat").asText();
        depositAccount.selectByText((depositAccount.customerCat), customerCat, "Customer Category");

        String locationTerm = testData.path("location_term").asText();
        depositAccount.selectByText((depositAccount.locationTerm), locationTerm, "Location Term");

        String currency = testData.path("currency").asText();
        depositAccount.selectByText((depositAccount.currency), currency, "Currency");

//        Term A/C Options
        depositAccount.navigateToTab(TERM_AC_OPTIONS);
        String siRequired = testData.path("si_required").asText();
        depositAccount.selectByText(depositAccount.siRequired, siRequired, "SI Required");

        String modeOfOperation = testData.path("mode_operation").asText();
        depositAccount.selectByText(depositAccount.modeOperation, modeOfOperation, "Mode Of Operation");

        String installmentAmount = testData.path("rd_expected_installment").asText();
        depositAccount.provideRDInstallment(installmentAmount);

        String termMonths = testData.path("term_months").asText();
        depositAccount.provideRDTermOfInstallment(termMonths);

//      Nominee Details

        depositAccount.navigateToTab(NOMINEE_DETAILS);
        String nomineeRegFlag = testData.path("nominee_reg_flag").asText();
        depositAccount.selectByText(depositAccount.nomineeRegFlag, nomineeRegFlag, "Nomination registration flag");
        TestDataGenerator dummydata = new TestDataGenerator();
        depositAccount.type(depositAccount.refusalReason, dummydata.getRefusalReason(), "Refusal Reason");
        depositAccount.submitTransmit();
        depositAccount.waitForLoaderComplete();

        String queue1 = depositAccount.retrieveQueueAfterCreation();
        new CBSHomePage().doLogOut();
////        *****************         Checker     ********************************* //
        new CBSLoginPage().doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
        new CBSHomePage().validateCBSHomeLoaded();
        this.waitForTimeout(10000);
        new CBSHomePage().ClickOnMaker();

        depositAccount.click(depositAccount.executeQueueSearch, EXECUTE);
        depositAccount.clickOnQueueNumber(depositAccount.grabQueueNumberFromAlertMsg(queue1));
        click(depositAccount.authorise, AUTHORISE);
        depositAccount.waitForLoaderComplete();

        String accountNumber = depositAccount.retrieveAccountNumberFromRDInfo();
        System.out.println(accountNumber);
        depositAccount.closePopUp();

//      ********************** Account Enquiry Validation **************** //
        getPage().locator(new CBSHomePage().homeButton).click();
        new CBSHomePage().validateCBSHomeLoaded();
        new CBSHomePage().clickOnCard(CUSTOMER_MANAGEMENT);

        new CBSHomePage().clickOnCard(ENQUIRIES, true);
        EnquiriesPage ep = new EnquiriesPage();
        ep.validateAccountNumberIsCreated(cifNumber, accountNumber);
        depositAccount.navigateToTab(LINKED_ACCOUNTS);
        assertThat(getPage().locator(ep.linkedAccounts).getByText(accountNumber)).isVisible();
        new CBSHomePage().doLogOut();
    }

}
