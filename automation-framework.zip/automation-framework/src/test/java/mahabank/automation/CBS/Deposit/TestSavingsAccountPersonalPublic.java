package mahabank.automation.CBS.Deposit;

import com.fasterxml.jackson.databind.JsonNode;
import mahabank.automation.CBS.BaseTest;
import mahabank.automation.data.dynamic.TestDataGenerator;
import mahabank.automation.e2e.CBS.CBSConstant;
import mahabank.automation.e2e.CBS.CBSHomePage;
import mahabank.automation.e2e.CBS.CBSLoginPage;
import mahabank.automation.e2e.CBS.DEPOSIT.DepositAccount;
import mahabank.automation.e2e.CBS.EnquiriesPage;
import mahabank.automation.utility.ReadDynamicJson;
import org.testng.annotations.Test;

public class TestSavingsAccountPersonalPublic extends BaseTest implements CBSConstant {


    public String testdataPath = "src/main/java/mahabank/automation/data/CBS/deposit_test_data.json";
    ReadDynamicJson rawdata = new ReadDynamicJson(testdataPath);

    @Test(groups = {REGRESSION, DEPOSIT_ACCOUNT_OPENING})
    public void testNewRegularSavingsAccountWithChequeSinglyOperatingNomineeAsDeclined() {
        JsonNode testData = rawdata.getObject(
                "TC01_NEW_REG_SAVINGS_ACCOUNT_WITH_CHEQUE_OPERATING_SINGLY_NOMI_NO");

        String testcaseName =
                "TC01 - Create New Regular Savings Account with Cheque Book, No Nominee, Single Operating Mode";

        String testDescription =
                "Objective:<br/>" +
                        "Verify successful creation and authorization of a Regular Savings Account with Cheque Book facility enabled, " +
                        "Operating Mode as Singly, and Nominee facility declined.<br/><br/>" +

                        "Pre-Requisites:<br/>" +
                        "1. Valid CIF exists in CBS.<br/>" +
                        "2. Maker and Checker users are available.<br/>" +
                        "3. User has account opening and authorization privileges.<br/><br/>" +

                        "Test Steps:<br/>" +
                        "1. Login to CBS using Maker credentials.<br/>" +
                        "2. Navigate to Deposit/CC -> Account Opening.<br/>" +
                        "3. Search and select the CIF specified in test data.<br/>" +
                        "4. Select Product Type as Regular Savings Account.<br/>" +
                        "5. Enter all mandatory details such as Customer Category, Currency, Scheme, Branch, etc.<br/>" +
                        "6. Select Operating Mode as 'Singly'.<br/>" +
                        "7. Enable Cheque Book facility.<br/>" +
                        "8. Select Nominee option as 'No'.<br/>" +
                        "9. Submit the account opening request.<br/>" +
                        "10. Capture the generated Queue Number.<br/>" +
                        "11. Logout from Maker session.<br/>" +
                        "12. Login to CBS using Checker credentials.<br/>" +
                        "13. Retrieve the Queue Number.<br/>" +
                        "14. Verify account details and authorize the request.<br/>" +
                        "15. Capture the generated Account Number.<br/>" +
                        "16. Navigate to Customer/Account Inquiry screen.<br/>" +
                        "17. Search using CIF or Account Number.<br/>" +
                        "18. Open the Linked Accounts tab.<br/>" +
                        "19. Verify newly created account is available under Linked Accounts.<br/><br/>";

        startTestCase(testcaseName, testDescription, DEPOSIT_ACCOUNT_OPENING, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());

        CBSHomePage homePage = new CBSHomePage();
        registerLogoutAction(homePage::doLogOutException);

        homePage.waitForLoaderComplete();
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(DEPOSIT_CC_OD_ACCOUNTS);

        homePage.clickOnCard("Create");
        DepositAccount depositAccount = new DepositAccount();
        String cifNumber = testData.path("cif").asText();
        depositAccount.setExtCifAccountNumber(cifNumber);
        depositAccount.clickFetchButton();
        depositAccount.handleDoNotProcessEmailCheckbox(depositAccount.doNotProcessEmailCheckbox);
        depositAccount.submitTransmit();

        depositAccount.waitForLoaderComplete();
        depositAccount.validateCustomerNumber(cifNumber);
//      Core Options
        String accountSegCode = testData.path("account_segment_code").asText();
        depositAccount.selectByText(depositAccount.accountSegCode, accountSegCode, "Account Seg Code");

        String productName = testData.path("product").asText();
        depositAccount.selectByText(depositAccount.product, productName, "Product");

        String productType = testData.path("product_type").asText();
        depositAccount.selectByText((depositAccount.productType), productType, "Product Type");

        String customerCat = testData.path("customer_cat").asText();
        depositAccount.selectByText((depositAccount.customerCat), customerCat, "Customer Category");

        String locationTerm = testData.path("location_term").asText();
        depositAccount.selectByText((depositAccount.locationTerm), locationTerm, "Location Term");

        String currency = testData.path("currency").asText();
        depositAccount.selectByText((depositAccount.currency), currency, "Currency");

        depositAccount.clickValidateEligibility();

//        Term A/C Options
        depositAccount.navigateToTab(TERM_AC_OPTIONS);
        String siRequired = testData.path("si_required").asText();
        depositAccount.selectByText(depositAccount.siRequired, siRequired, "SI Required");

        String modeOfOperation = testData.path("mode_operation").asText();
        depositAccount.selectByText(depositAccount.modeOperation, modeOfOperation, "Mode Of Operation");

//      Nominee Details
        depositAccount.navigateToTab(NOMINEE_DETAILS);
        depositAccount.ValidationOfNomineeRegistrationWhileNomineeFlagNo(
                testData.path("nominee_reg_flag").asText()
        );

        depositAccount.submitTransmit();
        depositAccount.waitForLoaderComplete();
        String queue1 = depositAccount.grabQueueNumberFromAlertMsg(depositAccount.retrieveQueueAfterCreation());

        homePage.doLogOut();

//        *****************         Checker     ********************************* //
        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.ClickOnMaker();

        String accountNumber = depositAccount.AuthoriseQueueAndGetAccountNumber(queue1);

//      ********************** Account Enquiry Validation **************** //
        click(homePage.homeButton, "Home button");
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        homePage.clickOnCard(ENQUIRIES, true);

        EnquiriesPage ep = new EnquiriesPage();
        ep.validateAccountNumberIsCreated(cifNumber, accountNumber);
        homePage.doLogOut();
    }

    @Test(groups = {REGRESSION, DEPOSIT_ACCOUNT_OPENING})
    public void testNewRegularSavingsAccountWithoutChequeSinglyOperatingNomineeAsYesTypeSuccessive() {

        JsonNode testData = rawdata.getObject(
                "TC02_NEW_REG_SAVINGS_ACCOUNT_WITHOUT_CHEQUE_OPERATING_SINGLY_NOMI_YES_SUCCESSIVE");

        String testcaseName =
                "TC02 - Create New Regular Savings Account without Cheque Book, With Nominee And nominee type as Successive, Single Operating Mode";

        String testDescription =
                "Objective:<br/>" +
                        "Verify successful creation and authorization of a Regular Savings Account without Cheque Book facility, " +
                        "with Nominee details captured and Operating Mode as Singly.<br/><br/>" +

                        "Pre-Requisites:<br/>" +
                        "1. Valid CIF exists in CBS.<br/>" +
                        "2. Maker and Checker users are available.<br/>" +
                        "3. User has account opening and authorization privileges.<br/>" +
                        "4. Valid nominee details are available in test data.<br/><br/>" +

                        "Test Steps:<br/>" +
                        "1. Login to CBS using Maker credentials.<br/>" +
                        "2. Navigate to Deposit/CC/OD -> Account Opening.<br/>" +
                        "3. Search and select the CIF specified in test data.<br/>" +
                        "4. Select Product Type as Regular Savings Account.<br/>" +
                        "5. Enter all mandatory details such as Customer Category, Currency, Scheme, Branch, etc.<br/>" +
                        "6. Select Operating Mode as 'Singly'.<br/>" +
                        "7. Select Cheque Book facility as 'No'.<br/>" +
                        "8. Select Nominee option as 'Yes'.<br/>" +
                        "9. Enter nominee details including nominee name, relationship, date of birth, address and guardian details (if applicable).<br/>" +
                        "10. Submit the account opening request.<br/>" +
                        "11. Capture the generated Queue Number.<br/>" +
                        "12. Logout from Maker session.<br/>" +
                        "13. Login to CBS using Checker credentials.<br/>" +
                        "14. Retrieve the Queue Number.<br/>" +
                        "15. Authorize the request.<br/>" +
                        "16. Capture the generated Account Number.<br/>" +
                        "17. Navigate to Customer/Account Inquiry screen.<br/>" +
                        "18. Search using CIF or Account Number.<br/>" +
                        "19. Open the Linked Accounts tab.<br/>" +
                        "20. Verify newly created account is available under Linked Accounts.<br/>";

        startTestCase(testcaseName, testDescription, DEPOSIT_ACCOUNT_OPENING, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());

        CBSHomePage homePage = new CBSHomePage();
        registerLogoutAction(homePage::doLogOutException);

        homePage.waitForLoaderComplete();
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(DEPOSIT_CC_OD_ACCOUNTS);

        homePage.clickOnCard("Create");
        DepositAccount depositAccount = new DepositAccount();
        String cifNumber = testData.path("cif").asText();

        depositAccount.setExtCifAccountNumber(cifNumber);
        depositAccount.clickFetchButton();
        depositAccount.handleDoNotProcessEmailCheckbox(depositAccount.doNotProcessEmailCheckbox);
        depositAccount.submitTransmit();

        depositAccount.waitForLoaderComplete();
        depositAccount.validateCustomerNumber(cifNumber);

//      Core Options
        String accountSegCode = testData.path("account_segment_code").asText();
        depositAccount.selectByText(depositAccount.accountSegCode, accountSegCode, "Account Seg Code");

        String productName = testData.path("product").asText();
        depositAccount.selectByText(depositAccount.product, productName, "Product");

        String productType = testData.path("product_type").asText();
        depositAccount.selectByText((depositAccount.productType), productType, "Product Type");

        String customerCat = testData.path("customer_cat").asText();
        depositAccount.selectByText((depositAccount.customerCat), customerCat, "Customer Category");

        String locationTerm = testData.path("location_term").asText();
        depositAccount.selectByText((depositAccount.locationTerm), locationTerm, "Location Term");

        String currency = testData.path("currency").asText();
        depositAccount.selectByText((depositAccount.currency), currency, "Currency");

        depositAccount.clickValidateEligibility();

//        Term A/C Options
        depositAccount.navigateToTab(TERM_AC_OPTIONS);
        String siRequired = testData.path("si_required").asText();
        depositAccount.selectByText(depositAccount.siRequired, siRequired, "SI Required");

        String modeOfOperation = testData.path("mode_operation").asText();
        depositAccount.selectByText(depositAccount.modeOperation, modeOfOperation, "Mode Of Operation");

//      Nominee Details
        depositAccount.navigateToTab(NOMINEE_DETAILS);

        depositAccount.ValidationOfNomineeRegistrationWhileNomineeFlagYes(testData.path("nominee_reg_flag").asText(), testData.path("type_of_nomination").asText(),
                testData.path("number_of_nominee").asInt(),testData.path("nominee_tile").asText(),new TestDataGenerator().getFullName(),
                testData.path("nominee_age").asText(), testData.path("nominee_relationship").asText(),
                testData.path("nominee_address").asText(), testData.path("nominee_telephone_number").asText(),
                null
                , null);
//        depositAccount.ValidationOfNomineeRegistrationWhileNomineeFlagYes(testData.path("nominee_reg_flag").asText(),
//                testData.path("nominee_tile").asText(), testData.path("nominee_name").asText(), testData.path("nominee_age").asText(),
//                testData.path("nominee_relationship").asText(), testData.path("nominee_address").asText(),
//                testData.path("nominee_telephone_number").asText(), testData.path("type_of_nomination").asText(),
//                testData.path("type_of_nomination").asText(), "");

        depositAccount.submitTransmit();
        depositAccount.waitForLoaderComplete();

        String queue1 = depositAccount.grabQueueNumberFromAlertMsg(depositAccount.retrieveQueueAfterCreation());
        homePage.doLogOut();

//        *****************         Checker     ********************************* //
        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.ClickOnMaker();

        String accountNumber = depositAccount.AuthoriseQueueAndGetAccountNumber(queue1);

//      ********************** Account Enquiry Validation **************** //
        click(homePage.homeButton, "Home button");
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        homePage.clickOnCard(ENQUIRIES, true);

        EnquiriesPage ep = new EnquiriesPage();
        ep.validateAccountNumberIsCreated(cifNumber, accountNumber);
        homePage.doLogOut();
    }


    @Test(groups = {REGRESSION, DEPOSIT_ACCOUNT_OPENING})
    public void testNewRegularSavingsAccountWithoutChequeSinglyOperatingNomineeAsYesModeSimultaneous() {

        JsonNode testData = rawdata.getObject(
                "TC03_NEW_REG_SAVINGS_ACCOUNT_WITHOUT_CHEQUE_OPERATING_SINGLY_NOMI_YES_SIMULTANEOUS");

        String testcaseName =
                "TC03 - Create New Regular Savings Account without Cheque Book, With Nominee and Nominee Type as Simultaneous, Single Operating Mode";

        String testDescription =
                "Objective:<br/>" +
                        "Verify successful creation and authorization of a Regular Savings Account without Cheque Book facility, " +
                        "with Nominee details captured and Operating Mode as Singly.<br/><br/>" +

                        "Pre-Requisites:<br/>" +
                        "1. Valid CIF exists in CBS.<br/>" +
                        "2. Maker and Checker users are available.<br/>" +
                        "3. User has account opening and authorization privileges.<br/>" +
                        "4. Valid nominee details are available in test data.<br/><br/>" +

                        "Test Steps:<br/>" +
                        "1. Login to CBS using Maker credentials.<br/>" +
                        "2. Navigate to Deposit/CC/OD -> Account Opening.<br/>" +
                        "3. Search and select the CIF specified in test data.<br/>" +
                        "4. Select Product Type as Regular Savings Account.<br/>" +
                        "5. Enter all mandatory details such as Customer Category, Currency, Scheme, Branch, etc.<br/>" +
                        "6. Select Operating Mode as 'Singly'.<br/>" +
                        "7. Select Cheque Book facility as 'No'.<br/>" +
                        "8. Select Nominee option as 'Yes'.<br/>" +
                        "9. Enter nominee details including nominee name, relationship, date of birth, address and guardian details (if applicable).<br/>" +
                        "10. Submit the account opening request.<br/>" +
                        "11. Capture the generated Queue Number.<br/>" +
                        "12. Logout from Maker session.<br/>" +
                        "13. Login to CBS using Checker credentials.<br/>" +
                        "14. Retrieve the Queue Number.<br/>" +
                        "15. Authorize the request.<br/>" +
                        "16. Capture the generated Account Number.<br/>" +
                        "17. Navigate to Customer/Account Inquiry screen.<br/>" +
                        "18. Search using CIF or Account Number.<br/>" +
                        "19. Open the Linked Accounts tab.<br/>" +
                        "20. Verify newly created account is available under Linked Accounts.<br/>";

        startTestCase(testcaseName, testDescription, DEPOSIT_ACCOUNT_OPENING, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(cbsConfig.appUserName(), cbsConfig.appPassword(), cbsConfig.appBranchName());

        CBSHomePage homePage = new CBSHomePage();
        registerLogoutAction(homePage::doLogOutException);

        homePage.waitForLoaderComplete();
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(DEPOSIT_CC_OD_ACCOUNTS);

        homePage.clickOnCard("Create");
        DepositAccount depositAccount = new DepositAccount();
        String cifNumber = testData.path("cif").asText();

        depositAccount.setExtCifAccountNumber(cifNumber);
        depositAccount.clickFetchButton();
        depositAccount.handleDoNotProcessEmailCheckbox(depositAccount.doNotProcessEmailCheckbox);
        depositAccount.submitTransmit();

        depositAccount.waitForLoaderComplete();
        depositAccount.validateCustomerNumber(cifNumber);

//      Core Options
        String accountSegCode = testData.path("account_segment_code").asText();
        depositAccount.selectByText(depositAccount.accountSegCode, accountSegCode, "Account Seg Code");

        String productName = testData.path("product").asText();
        depositAccount.selectByText(depositAccount.product, productName, "Product");

        String productType = testData.path("product_type").asText();
        depositAccount.selectByText((depositAccount.productType), productType, "Product Type");

        String customerCat = testData.path("customer_cat").asText();
        depositAccount.selectByText((depositAccount.customerCat), customerCat, "Customer Category");

        String locationTerm = testData.path("location_term").asText();
        depositAccount.selectByText((depositAccount.locationTerm), locationTerm, "Location Term");

        String currency = testData.path("currency").asText();
        depositAccount.selectByText((depositAccount.currency), currency, "Currency");

        depositAccount.clickValidateEligibility();
//        Term A/C Options
        depositAccount.navigateToTab(TERM_AC_OPTIONS);
        String siRequired = testData.path("si_required").asText();
        depositAccount.selectByText(depositAccount.siRequired, siRequired, "SI Required");

        String modeOfOperation = testData.path("mode_operation").asText();
        depositAccount.selectByText(depositAccount.modeOperation, modeOfOperation, "Mode Of Operation");

//      Nominee Details
        depositAccount.navigateToTab(NOMINEE_DETAILS);

        depositAccount.ValidationOfNomineeRegistrationWhileNomineeFlagYes(testData.path("nominee_reg_flag").asText(), testData.path("type_of_nomination").asText(),
                testData.path("number_of_nominee").asInt(),testData.path("nominee_tile").asText(),new TestDataGenerator().getFullName(),
                testData.path("nominee_age").asText(), testData.path("nominee_relationship").asText(),
                testData.path("nominee_address").asText(), testData.path("nominee_telephone_number").asText(),
                null
                , testData.path("percentage").asText());

        depositAccount.submitTransmit();
        depositAccount.waitForLoaderComplete();

        String queue1 = depositAccount.grabQueueNumberFromAlertMsg(depositAccount.retrieveQueueAfterCreation());
        homePage.doLogOut();

//        *****************         Checker     ********************************* //
        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.ClickOnMaker();

        String accountNumber = depositAccount.AuthoriseQueueAndGetAccountNumber(queue1);

//      ********************** Account Enquiry Validation **************** //
        click(homePage.homeButton, "Home button");
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        homePage.clickOnCard(ENQUIRIES, true);

        EnquiriesPage ep = new EnquiriesPage();
        ep.validateAccountNumberIsCreated(cifNumber, accountNumber);
        homePage.doLogOut();
    }
}
