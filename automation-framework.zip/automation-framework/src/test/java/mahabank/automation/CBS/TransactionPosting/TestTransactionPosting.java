package mahabank.automation.CBS.TransactionPosting;

import com.fasterxml.jackson.databind.JsonNode;
import mahabank.automation.CBS.BaseTest;
import mahabank.automation.e2e.CBS.CBSConstant;
import mahabank.automation.e2e.CBS.CBSHomePage;
import mahabank.automation.e2e.CBS.CBSLoginPage;
import mahabank.automation.e2e.CBS.EnquiriesPage;
import mahabank.automation.e2e.CBS.TransactionPosting.CashDeposit;
import mahabank.automation.e2e.CBS.TransactionPosting.TransferByVoucherToDepositOrLoan;
import mahabank.automation.utility.ReadDynamicJson;
import org.testng.annotations.Test;

public class TestTransactionPosting extends BaseTest implements CBSConstant {

    public String testdataPath = "src/main/java/mahabank/automation/data/CBS/transaction_posting.json";
    ReadDynamicJson rawdata = new ReadDynamicJson(testdataPath);

    @Test(groups = {REGRESSION, DEPOSIT_TRANSACTIONS})
    public void testCashDepositToRegularSavingsAccount() {
        JsonNode testData = rawdata.getObject(
                "TC01_CASH_DEPOSIT_MAKER_CHECKER_BALANCE_VALIDATION");

        String testcaseName =
                "TC01 - Cash Deposit Transaction with Maker-Checker Authorization and Balance Verification";

        String testDescription =
                "Objective:<br/>" +
                        "Verify that a cash deposit transaction can be successfully initiated by a Maker, authorized by a Checker, " +
                        "and the deposited amount is correctly reflected in the account balance after authorization.<br/><br/>" +

                        "Pre-Requisites:<br/>" +
                        "1. Valid customer account exists in CBS.<br/>" +
                        "2. Maker and Checker users are available with required transaction privileges.<br/>" +
                        "3. Account is active and eligible for cash deposit transactions.<br/>" +
                        "4. Customer enquiry and transaction posting menus are accessible.<br/><br/>" +

                        "Test Steps:<br/>" +
                        "1. Login to CBS using Maker credentials.<br/>" +
                        "2. Navigate to Customer Management -> Enquiries.<br/>" +
                        "3. Search the customer account and capture the existing total balance.<br/>" +
                        "4. Navigate back to the Home page.<br/>" +
                        "5. Navigate to Transaction Posting -> Deposit / CC / OD Accounts.<br/>" +
                        "6. Initiate a cash deposit transaction for the customer account.<br/>" +
                        "7. Enter the deposit amount and complete all mandatory transaction details.<br/>" +
                        "8. Submit the cash deposit transaction.<br/>" +
                        "9. Capture the generated Queue Number.<br/>" +
                        "10. Logout from Maker session.<br/>" +
                        "11. Login to CBS using Checker credentials.<br/>" +
                        "12. Navigate to Maker-Checker authorization menu.<br/>" +
                        "13. Retrieve the submitted Queue Number.<br/>" +
                        "14. Verify transaction details and authorize the cash deposit transaction.<br/>" +
                        "15. Confirm successful journal/transaction posting.<br/>" +
                        "16. Navigate to Customer Management -> Enquiries.<br/>" +
                        "17. Search the same customer account.<br/>" +
                        "18. Retrieve the updated total balance.<br/>" +
                        "19. Verify the updated balance reflects the deposited amount.<br/>" +
                        "20. Logout from CBS.<br/><br/>";

        startTestCase(testcaseName, testDescription, REGRESSION, DEPOSIT_TRANSACTIONS);

//        **************** Testcase Execution Started **************************** //

        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(testData.get("maker_login_id").asText(),
                cbsConfig.appPassword(),
                testData.get("maker_branch").asText());

        CBSHomePage homePage = new CBSHomePage();
        registerLogoutAction(homePage::doLogOutException);

        homePage.waitForLoaderComplete();
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();

        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        homePage.clickOnCard(ENQUIRIES, true);

        EnquiriesPage ep = new EnquiriesPage();
        ep.enterCIFOrAccount(testData.get("account_number").asText());
        ep.navigateToTab(LINKED_ACCOUNTS);
        String oldTotalBalance = ep.getAccountLevelTotalBalance(testData.get("account_number").asText());

        click(homePage.homeButton, "Home button");
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();

        homePage.clickOnCard(TRANSACTION_POSTING);
        homePage.clickOnCard("Deposit / CC / OD Accounts");

        CashDeposit cashDeposit = new CashDeposit();
        cashDeposit.performCashDeposit(testData.get("account_number").asText(),
                testData.get("amount_to_deposit").asText());

        cashDeposit.enterDenomIn(testData.get("cash_1").asText(), testData.get("denom_in_1").asText());
        cashDeposit.summeryTransactionAmountInDenomIn(testData.get("amount_to_deposit").asText());

        cashDeposit.submitTransmitInCashDrawer();
        String queue1 = cashDeposit.grabQueueNumberFromAlertMsg(cashDeposit.retrieveQueueAfterCreation());
        homePage.doLogOut();

//        *****************         Checker     ********************************* //
        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.ClickOnMaker();
        cashDeposit.validateJournalNumberGenerated(queue1);

//      ********************** Account Enquiry Validation **************** //
        click(homePage.homeButton, "Home button");
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        homePage.clickOnCard(ENQUIRIES, true);

        ep.enterCIFOrAccount(testData.get("account_number").asText());
        ep.navigateToTab(LINKED_ACCOUNTS);

        cashDeposit.validateNewTotalBalanceAfterDeposit(oldTotalBalance, testData.get("amount_to_deposit").asText(),
                ep.getAccountLevelTotalBalance(testData.get("account_number").asText()), testData.get("cash_handling_charge").asText());
        homePage.doLogOut();
    }

    @Test(groups = {REGRESSION, DEPOSIT_TRANSACTIONS})
    public void testTransferDepositBetweenAccounts() {
        JsonNode testData = rawdata.getObject(
                "TC02_TRANSFER_BY_VOUCHER_TO_DEPOSIT_ACCOUNT_MAKER_CHECKER");

        String testcaseName =
                "TC02 - Transfer Funds by Voucher to Deposit/Loan Account with Maker-Checker Authorization and Balance Verification";

        String testDescription =
                "Objective:<br/>" +
                        "Verify that funds can be successfully transferred from a source account to a Deposit/Loan account through Voucher Transfer, " +
                        "authorized through Maker-Checker workflow, and reflected correctly in the destination account balance.<br/><br/>" +

                        "Pre-Requisites:<br/>" +
                        "1. Valid source and destination accounts exist in CBS.<br/>" +
                        "2. Maker and Checker users are available with transaction authorization privileges.<br/>" +
                        "3. Destination account is active and eligible for credit transactions.<br/>" +
                        "4. Customer Enquiry and Transaction Posting menus are accessible.<br/>" +
                        "5. Sufficient balance is available in the source account for transfer processing.<br/><br/>" +

                        "Test Steps:<br/>" +
                        "1. Login to CBS using Maker credentials.<br/>" +
                        "2. Navigate to Customer Management -> Enquiries.<br/>" +
                        "3. Search the destination account and capture the existing total balance.<br/>" +
                        "4. Navigate back to the Home page.<br/>" +
                        "5. Navigate to Transaction Posting -> Deposit / CC / OD Accounts.<br/>" +
                        "6. Open Transfers -> By Voucher to Deposit/Loan menu.<br/>" +
                        "7. Select the source account for debit transaction.<br/>" +
                        "8. Select the destination Deposit/Loan account for credit transaction.<br/>" +
                        "9. Enter the transfer amount and complete all mandatory transaction details.<br/>" +
                        "10. Submit the voucher transfer transaction.<br/>" +
                        "11. Capture the generated Queue Number.<br/>" +
                        "12. Logout from Maker session.<br/>" +
                        "13. Login to CBS using Checker credentials.<br/>" +
                        "14. Navigate to Maker-Checker authorization menu.<br/>" +
                        "15. Retrieve the submitted Queue Number.<br/>" +
                        "16. Verify transfer details and authorize the transaction.<br/>" +
                        "17. Confirm successful journal generation and transaction posting.<br/>" +
                        "18. Navigate to Customer Management -> Enquiries.<br/>" +
                        "19. Search the destination account again.<br/>" +
                        "20. Retrieve the updated account balance.<br/>" +
                        "21. Verify the updated balance reflects the transferred amount.<br/>" +
                        "22. Logout from CBS.<br/><br/>";

        startTestCase(testcaseName, testDescription, REGRESSION, DEPOSIT_TRANSACTIONS);

//        **************** Testcase Execution Started **************************** //

        String toAccountNumber = null;
        String depositAmount = null;

        if (containsKeyGlobalData("CDR_ACCOUNT_ID_AUTO_CLOSURE") && getGlobalData("CDR_ACCOUNT_ID_AUTO_CLOSURE") != null){
            toAccountNumber = (String) getGlobalData("CDR_ACCOUNT_ID_AUTO_CLOSURE");
        }
        else {
            toAccountNumber = testData.get("to_account_number").asText();
        }
//        ----------------------------
        if (containsKeyGlobalData("CDR_DEPOSIT_AMOUNT") && getGlobalData("CDR_DEPOSIT_AMOUNT") != null){
            depositAmount = (String) getGlobalData("CDR_DEPOSIT_AMOUNT");
        }
        else {
            depositAmount = testData.get("amount_to_deposit").asText();
        }


        navigate(cbsConfig.baseUrl());
        new CBSLoginPage().doLogin(testData.get("maker_login_id").asText(),
                cbsConfig.appPassword(),
                testData.get("maker_branch").asText());

        CBSHomePage homePage = new CBSHomePage();
        registerLogoutAction(homePage::doLogOutException);

        homePage.waitForLoaderComplete();
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();

        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        homePage.clickOnCard(ENQUIRIES, true);

        EnquiriesPage ep = new EnquiriesPage();
        ep.enterCIFOrAccount(toAccountNumber);
        ep.navigateToTab(LINKED_ACCOUNTS);
        String oldTotalBalance = ep.getAccountLevelTotalBalance(toAccountNumber);

        click(homePage.homeButton, "Home button");
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();

        homePage.clickOnCard(TRANSACTION_POSTING);
        homePage.clickOnCard("Deposit / CC / OD Accounts");

        TransferByVoucherToDepositOrLoan transferByVoucherToDepositOrLoan = new TransferByVoucherToDepositOrLoan();
        transferByVoucherToDepositOrLoan.expandSideMenuOperations("Transfers");
        transferByVoucherToDepositOrLoan.clickMenuToOpenAndPerformActions("By Voucher to Deposit/ Loan");


        transferByVoucherToDepositOrLoan.Validate001045DepositTransferOfFunds(testData.get("from_account_number").asText(),
                    toAccountNumber,  depositAmount);

        String queue1 = transferByVoucherToDepositOrLoan.grabQueueNumberFromAlertMsg(
                transferByVoucherToDepositOrLoan.retrieveQueueAfterCreation());
        homePage.doLogOut();

//        *****************         Checker     ********************************* //
        homePage.doLogin(cbsConfig.appUserNameChecker(), cbsConfig.appPasswordChecker(), cbsConfig.appBranchNameChecker());
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.ClickOnMaker();
        transferByVoucherToDepositOrLoan.validateJournalNumberGenerated(queue1);

//      ********************** Account Enquiry Validation **************** //
        click(homePage.homeButton, "Home button");
        homePage.validateHomePageRenderedAndWorkOnAnyFalseError();
        homePage.clickOnCard(CUSTOMER_MANAGEMENT);
        homePage.clickOnCard(ENQUIRIES, true);

        ep.enterCIFOrAccount(toAccountNumber);
        ep.navigateToTab(LINKED_ACCOUNTS);
        transferByVoucherToDepositOrLoan.validateNewTotalBalanceAfterDeposit(oldTotalBalance, depositAmount,
                ep.getAccountLevelTotalBalance(toAccountNumber), "0");
        homePage.doLogOut();
    }

    @Test(enabled = false, groups = {REGRESSION, DEPOSIT_TRANSACTIONS})
    public void testWithDrawlByCashVoucher(){
        // Enable when this scenario has executable steps and outcome assertions.
    }
}
