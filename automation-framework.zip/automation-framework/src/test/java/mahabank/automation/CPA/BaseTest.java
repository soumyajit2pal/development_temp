package mahabank.automation.CPA;

import mahabank.automation.base.ProjectHooks;
import mahabank.automation.config.CPA.CPAConfig;
import mahabank.automation.config.ConfigurationManager;


public class BaseTest extends ProjectHooks {
    CPAConfig cpaConfig =
            ConfigurationManager.getOrCreate(CPAConfig.class);
}
