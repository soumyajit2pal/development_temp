package mahabank.automation.CPA;

import mahabank.automation.data.dynamic.TestDataGenerator;
import mahabank.automation.e2e.CPA.AddNewAccountPage;
import mahabank.automation.e2e.CPA.CPAHomePage;
import mahabank.automation.e2e.CPA.PrePendingAccountList;
import org.testng.annotations.Test;

public class TestCPA extends BaseTest {
    
    @Test(groups = {REGRESSION}, priority = 0)
    public void validateMakerSubmission() {

        String testcaseName = "TC01 - Validate Maker Submission Done Successfully";
        String testDescription = "Validating Maker Submission Done Successfully<br/>" +
                "Steps:<br/>" +
                "1. Login in to Credit Process Audit Application with Maker<br/>" +
                "2. Adding account with MAKER login<br/>" +
                "3. Validating Account inserted as expected<br/>" +
                "4. Search with above mentioned a/c number<br/>" +
                "5. Started editing above mentioned a/c number<br/>" +
                "6. Selecting Office & Authority under Sanction Authority section<br/>" +
                "7. Selecting required option (NA/NO/YES) from dropdown options under Application Section, <br/>" +
                "   Sanction Section, Compliance Section, Takeover Norms Compliance section<br/>" +
                "8. Uploading Mandatory Documents under Document Upload Section<br/>" +
                "9. Clicking on Submit button and getting message as 'Maker Submission done successfully'";

        startTestCase(testcaseName, testDescription, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(cpaConfig.baseUrl());
        CPAHomePage homePage = new CPAHomePage();
        homePage.doMakerLogin(cpaConfig.appMakerPf(), cpaConfig.appZoneCodeMaker(), cpaConfig.appBranchCodeMaker());
        homePage.loginAs("Maker");
        homePage.loginAccountType("Pending Loan Accounts");

        AddNewAccountPage addnewaccpage = new AddNewAccountPage();
        click(addnewaccpage.addNewAccBtn, "Add New Account");
        String _accountNumber = new TestDataGenerator().getBankAccountNumber(11);
        String _cifNumber = new TestDataGenerator().getBankAccountNumber(11);
        addnewaccpage.addAccountDetails(_accountNumber, _cifNumber, "Testing Name",
                "14/12/2025", new TestDataGenerator().getCity(), "200005");
        addnewaccpage.validateToastMessage("Account inserted");

        PrePendingAccountList prePendingAccList = new PrePendingAccountList();

        prePendingAccList.searchLoanAccountNo(_accountNumber);
        prePendingAccList.validateToastMessage("Account list found.");
        prePendingAccList.clickEditOptionButton();
//         ** prePendingAccList.searchLoanAccountNo("1234548479879");
        prePendingAccList.sanctionAuthoritySelection();

        prePendingAccList.applicationSection();
        prePendingAccList.sanctionSection();
        prePendingAccList.complianceSection();
        prePendingAccList.takeoverNormsCompliance();

        prePendingAccList.documentUploadSection("Sanction Letter (Mandatory)", "\\CPA\\Sanction Letter.pdf");
        prePendingAccList.validateDocumentUploadCompleted();


        prePendingAccList.documentUploadSection("Appraisal Note (Mandatory)", "\\CPA\\Appraisal Note.pdf");
        prePendingAccList.validateDocumentUploadCompleted();

        prePendingAccList.documentUploadSection("Compliance Certificate (Mandatory)", "\\CPA\\Compliance Certificate.pdf");
        prePendingAccList.validateDocumentUploadCompleted();


        prePendingAccList.validateDownloadFileOnUpload("Sanction Letter");
        prePendingAccList.validateDownloadFileOnUpload("Compliance Certificate");
        prePendingAccList.validateDownloadFileOnUpload("Appraisal Note");

        prePendingAccList.setSubmitBtn();

        //Below is for pause execution
//        getPage().pause();

    }

//    @Test(groups = {REGRESSION, SEVERITY_HIGH}, priority = 1)
//    public void validateWithDifferentBranchCode() {
//
//        String testcaseName = "TC02 - Validate Login With Different Branch Code User getting `No Account Pending`";
//        String testDescription = "Validating With Different Branch Code User getting `No Account Pending`<br/>" +
//                "Steps:<br/>" +
//                "1. Login in to Credit Process Audit Application with Maker<br/>" +
//                "2. Adding account with MAKER login<br/>" +
//                "3. Validating Account inserted as expected<br/>" +
//                "4. Login in to Credit Process Audit Application with Checker with Different Branch Code<br/>" +
//                "5. Search with above mentioned a/c number";
//
//        startTestCase(testcaseName, testDescription, REGRESSION, SEVERITY_HIGH);
//
////        **************** Testcase Execution Started **************************** //
//
//        navigate(cpaConfig.baseUrl());
//        CPAHomePage homePage = new CPAHomePage();
//        homePage.doMakerLogin(cpaConfig.appMakerPf(), cpaConfig.appZoneCodeMaker(), cpaConfig.appBranchCodeMaker());
//        homePage.loginAs("Maker");
//        homePage.loginAccountType("Pending Loan Accounts");
//
//        AddNewAccountPage addnewaccpage = new AddNewAccountPage();
//        click(addnewaccpage.addNewAccBtn, "Add New Account");
//        String _accountNumber = new TestDataGenerator().getBankAccountNumber(11);
//        String _cifNumber = new TestDataGenerator().getBankAccountNumber(11);
//        addnewaccpage.addAccountDetails(_accountNumber, _cifNumber, "Testing Name",
//                "14/12/2025", new TestDataGenerator().getCity(), "200005");
//        addnewaccpage.validateToastMessage("Account inserted");
//        PrePendingAccountList prePendingAccList = new PrePendingAccountList();
//        prePendingAccList.searchLoanAccountNo(_accountNumber);
//
//        // Login with Checker
//        reportStep("Validating with Checker", "info");
//        navigate(cpaConfig.baseUrl());
//        homePage.doCheckerLogin(cpaConfig.appCheckerPf(), cpaConfig.appZoneCodeChecker(), cpaConfig.appBranchCodeChecker());
//        homePage.loginAs("Checker");
//        homePage.loginAccountType("Pre Disbursement Pending Accounts");
//        prePendingAccList.searchLoanAccountNo(_accountNumber);
//        verifyExactText(prePendingAccList.noAccountPending, "No Account Pending.");
//    }
//
    @Test(groups = {SANITY}, priority = 2)
    public void validateSaveAndNextBtnFunctionalityWithoutSelectingDropdownOption() {

        String testcaseName = "TC03 - Validate Save & Next button Functionality Without Selecting any Dropdown Option";
        String testDescription = "Validating Save & Next button Functionality Without Selecting any Dropdown Option<br/>" +
                "Steps:<br/>" +
                "1. Login in to Credit Process Audit Application with Maker<br/>" +
                "2. Adding account with MAKER login<br/>" +
                "3. Validating Account inserted as expected<br/>" +
                "4. Search with above mentioned a/c number<br/>" +
                "5. Started editing above mentioned a/c number<br/>" +
                "6. Without selecting Office & Authority from dropdown under Sanction Authority section <br/>" +
                "clicking on Save & Next button, then getting error header as 'Sanction Authority Error' & error message as 'Please select both dropdown'";

        startTestCase(testcaseName, testDescription, SANITY);

//        **************** Testcase Execution Started **************************** //

        navigate(cpaConfig.baseUrl());
        CPAHomePage homePage = new CPAHomePage();
        homePage.doMakerLogin(cpaConfig.appMakerPf(), cpaConfig.appZoneCodeMaker(), cpaConfig.appBranchCodeMaker());
        homePage.loginAs("Maker");
        homePage.loginAccountType("Pending Loan Accounts");

        AddNewAccountPage addnewaccpage = new AddNewAccountPage();
        click(addnewaccpage.addNewAccBtn, "Add New Account");
        String _accountNumber = new TestDataGenerator().getBankAccountNumber(11);
        String _cifNumber = new TestDataGenerator().getBankAccountNumber(11);
        addnewaccpage.addAccountDetails(_accountNumber, _cifNumber, "Testing Name",
                "15/12/2025", new TestDataGenerator().getCity(), "432156");
        addnewaccpage.validateToastMessage("Account inserted");

        PrePendingAccountList prePendingAccList = new PrePendingAccountList();
        prePendingAccList.searchLoanAccountNo(_accountNumber);
        prePendingAccList.validateToastMessage("Account list found.");
        prePendingAccList.clickEditOptionButton();
        prePendingAccList.saveAndNextBtnAction();
        verifyExactText(prePendingAccList.sanctionAuthorityErrHeader,"Sanction Authority Error");
        verifyExactText(prePendingAccList.selectBothDropdownErrMsg, "Please select both dropdown");
    }
//
    @Test(groups = {SMOKE}, priority = 3)
    public void validateDocumentUploadSectionOtherThanPDF() {

        String testcaseName = "TC04 - Validate Other than PDF file UI Throwing Error Message";
        String testDescription = "Validate other than PDF file, UI is blocking user to upload document<br/>" +
                "Steps:<br/>" +
                "1. Login in to Credit Process Audit Application with Maker<br/>" +
                "2. Adding account with MAKER login<br/>" +
                "3. Validating Account inserted as expected<br/>" +
                "4. Search with above mentioned a/c number<br/>" +
                "5. Started editing above mentioned a/c number<br/>" +
                "6. Selecting Office & Authority under Sanction Authority section<br/>" +
                "7. Selecting required option (NA/NO/YES) from dropdown options under Application Section," +
                    " Sanction Section, Compliance Section, Takeover Norms Compliance section<br/>" +
                "8. Uploading Mandatory Documents other than PDF format under Document Upload Section <br/>" +
                "then getting error header as 'Document Upload Section Error' & error message as 'Document narration required.'<br/>";

        startTestCase(testcaseName, testDescription, SMOKE);

//        **************** Testcase Execution Started **************************** //

        navigate(cpaConfig.baseUrl());
        CPAHomePage homePage = new CPAHomePage();
        homePage.doMakerLogin(cpaConfig.appMakerPf(), cpaConfig.appZoneCodeMaker(), cpaConfig.appBranchCodeMaker());
        homePage.loginAs("Maker");
        homePage.loginAccountType("Pending Loan Accounts");

        AddNewAccountPage addnewaccpage = new AddNewAccountPage();
        click(addnewaccpage.addNewAccBtn, "Add New Account");
        String _accountNumber = new TestDataGenerator().getBankAccountNumber(11);
        String _cifNumber = new TestDataGenerator().getBankAccountNumber(11);
        addnewaccpage.addAccountDetails(_accountNumber, _cifNumber, "Testing Name",
                "14/12/2025", new TestDataGenerator().getCity(), "200005");
        addnewaccpage.validateToastMessage("Account inserted");

        PrePendingAccountList prePendingAccList = new PrePendingAccountList();

        prePendingAccList.searchLoanAccountNo(_accountNumber);
        prePendingAccList.validateToastMessage("Account list found.");
        prePendingAccList.clickEditOptionButton();
        prePendingAccList.sanctionAuthoritySelection();

        prePendingAccList.applicationSection();
        prePendingAccList.sanctionSection();
        prePendingAccList.complianceSection();
        prePendingAccList.takeoverNormsCompliance();

        prePendingAccList.documentUploadSection("Sanction Letter (Mandatory)", "\\test.jpeg");
        prePendingAccList.validateToastMessage("Something Went Wrong");

    }
}
