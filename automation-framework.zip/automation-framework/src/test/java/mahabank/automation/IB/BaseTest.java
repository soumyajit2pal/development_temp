package mahabank.automation.IB;

import mahabank.automation.base.ProjectHooks;
import mahabank.automation.config.IB.IBConfig;
import mahabank.automation.config.ConfigurationManager;


public class BaseTest extends ProjectHooks {
    IBConfig ibConfig =
            ConfigurationManager.getOrCreate(IBConfig.class);
}
