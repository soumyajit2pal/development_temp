package mahabank.automation.IB;

public interface IBConstant {

    String GLOBAL_EDGE_FUREVER_ACCOUNT = "Global Edge Furever Account";
    String OPEN_MAINTAIN_GLOBAL_EDGE_FOREVER_ACCOUNT = "Open/Maintain Global Edge Furever Account";
    String TERMS_AND_CONDITIONS_WARNING_MESSAGE = "Warning : Please read terms and conditions and click the checkbox to proceed..!!!";
    String NOMINATION_REQUIRED_MESSAGE = "Error : Nomination Required is Mandatory";
    String NOMINATION_NO_REASON = "Error : Refusal Reason is Mandatory";
    String PET_NAME_VALIDATION_ERROR = "Pet Name : Validation Error: Value is required.";
    String OPENING_REQUEST_CONFIRMATION = "Furever Account Opening Request Confirmation";
}
