package mahabank.automation.IB;

import com.microsoft.playwright.Locator;
import mahabank.automation.data.dynamic.TestDataGenerator;
import mahabank.automation.e2e.CPA.AddNewAccountPage;
import mahabank.automation.e2e.CPA.CPAHomePage;
import mahabank.automation.e2e.CPA.PrePendingAccountList;
import mahabank.automation.e2e.IB.IBFurEverAccount;
import mahabank.automation.e2e.IB.IBHomePage;
import mahabank.automation.e2e.IB.IBLoginPage;
import org.testng.annotations.Test;

public class TestIBFurever extends BaseTest implements IBConstant{
    
    @Test(groups = {REGRESSION})
    public void validateMandatoryFields() {

        String testcaseName = "TC01 - Ensure System Displays Warning When Terms & Conditions Are Not Accepted Before Submission";
        String testDescription = "<br/>" +
                "Steps:<br/>" +
                "1. Login in to IB<br/>" +
                "2. use CIF does not have furever a/c opened earlier <br/>" +
                "3. Click on `Open/Maintain Global Edge Furever Account`<br/>" +
                "4. click on `Submit Request` button without checked chekbox of T&C<br/>" +
                "Validation: 1. Warning message should be pop-up on the screen<br/>" +
                "           2. Validate warning message should be `Warning : Please read terms and conditions and click the checkbox to proceed..!!!`<br/>" +
                "5. Click on close icon to close pop-up window<br/>" +
                "6. Click on Logout button<br/>"+
                "7. Logout Should be completed successfully<br/>";

        startTestCase(testcaseName, testDescription, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(ibConfig.baseUrl());
        IBLoginPage loginPage = new IBLoginPage();
        loginPage.doLogin(ibConfig.appUserName(), ibConfig.appPassword());
//      Enter OTP and Submit
        loginPage.submitOtpVerification();

        IBHomePage homePage = new IBHomePage();

        homePage.validateLoginSuccesFull(ibConfig.appUserName());
        homePage.navigateToPage("Global Edge Furever Account");

        IBFurEverAccount furEverAccount = new IBFurEverAccount();

        furEverAccount.validateFurEverAccountLanded(GLOBAL_EDGE_FUREVER_ACCOUNT);
        furEverAccount.OpenFureverAccount(OPEN_MAINTAIN_GLOBAL_EDGE_FOREVER_ACCOUNT);
        furEverAccount.checkUncheckOfTermsAndConditionsValidation(false);
        furEverAccount.clickSubmitRequestForRequestPage();
        furEverAccount.validateWindowPopUp();
        furEverAccount.validateDialogPopupMessage(TERMS_AND_CONDITIONS_WARNING_MESSAGE);
        furEverAccount.closeWarningPoUp();

//        Logout Part
        homePage.verifyDisplayed(homePage.logOut, "Logout");
        homePage.doLogOut();
        loginPage.verifyDisplayed(loginPage.username, "Username");
    }

    @Test(groups = {REGRESSION})
    public void validateNominationSelections() {

        String testcaseName = "TC02 - Validate Nomination Selection Behavior and Mandatory Field Handling";
        String testDescription = "TC02A - Validate Mandatory Reason Field When Nomination Is Set to “No”<br/>" +
                "TC02B - Verify Nominee Details Fields Visibility When Nomination Is Set to “Yes”<br/>" +
                "Steps:<br/>" +
                "1. Login in to IB<br/>" +
                "2. use CIF does not have furever a/c opened earlier <br/>" +
                "3. Click on `Open/Maintain Global Edge Furever Account`<br/>" +
                "4. Select Nominee as `No` <br/>" +
                "Validation: 1. Reason textbox should be visible <br/>" +
                            "2. Validate error message should be pop-up on the screen, message should be `Error : Refusal Reason is Mandatory`<br/>" +
                "5. Select Nominee as `Yes`" +
                "Validation: Nominee Title, Nominee Name, Nominee Address, Nominee Relation, Nominee Age fields should be visible<br/>" +
                "6. Click on Logout button<br/>"+
                "7. Logout Should be completed successfully<br/>";

        startTestCase(testcaseName, testDescription, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(ibConfig.baseUrl());
        IBLoginPage loginPage = new IBLoginPage();
        loginPage.doLogin(ibConfig.appUserName(), ibConfig.appPassword());
//      Enter OTP and Submit
        loginPage.submitOtpVerification();

        IBHomePage homePage = new IBHomePage();

        homePage.validateLoginSuccesFull(ibConfig.appUserName());
        homePage.navigateToPage(GLOBAL_EDGE_FUREVER_ACCOUNT);

        IBFurEverAccount furEverAccount = new IBFurEverAccount();

        furEverAccount.validateFurEverAccountLanded(GLOBAL_EDGE_FUREVER_ACCOUNT);
        furEverAccount.OpenFureverAccount(OPEN_MAINTAIN_GLOBAL_EDGE_FOREVER_ACCOUNT);

//      Validate Without nominee selection it should block the flow
        furEverAccount.checkUncheckOfTermsAndConditions(true);
        furEverAccount.clickSubmitRequestForRequestPage();
        furEverAccount.validateWindowPopUp();
        furEverAccount.validateDialogPopupMessage(NOMINATION_REQUIRED_MESSAGE);
        furEverAccount.closeWarningPoUp();

//        Validate While nominee selection set as "No", mandatory reason should be given by the user
        furEverAccount.selectNomineeRequires("No");
        furEverAccount.verifyDisplayed(furEverAccount.nomineeSkipReason, "Reason textbox");

        furEverAccount.checkUncheckOfTermsAndConditions(true);
        furEverAccount.clickSubmitRequestForRequestPage();
        furEverAccount.validateWindowPopUp();
        furEverAccount.validateDialogPopupMessage(NOMINATION_NO_REASON);
        furEverAccount.closeWarningPoUp();

//        Validate While nominee selection set as "Yes",
        furEverAccount.selectNomineeRequires("Yes");
        furEverAccount.nomineeSectionLabelValidation();

//        Logout Part
        homePage.verifyDisplayed(homePage.logOut, "Logout");
        homePage.doLogOut();
        loginPage.verifyDisplayed(loginPage.username, "Username");
    }

    @Test(groups = {REGRESSION})
    public void validateWithOutPetNameOpeningShouldNotBeAllowed() {

        String testcaseName = "TC03 - Verify System Restricts Submission and Displays Error When Pet Name Field Is Blank";
        String testDescription = "Validating without pet name error messaging rendering on ui and blocking execution<br/>" +
                "Steps:<br/>" +
                "1. Login in to IB<br/>" +
                "2. use CIF does not have furever a/c opened earlier <br/>" +
                "3. Click on `Open/Maintain Global Edge Furever Account`<br/>" +
                "4. Select Nominee as `No` <br/>" +
                "5. provide mandatory reason in textbox<br/>" +
                "6. Accept Terms & Conditions <br/>" +
                "7. Keep blanks pet name <br/>" +
                "8. click on `Submit Request` button <br/>" +
                "Validation: Error message should be populated on ui, message should be `Pet Name : Validation Error: Value is required.`" +
                "9. Click on Logout button<br/>"+
                "10. Logout Should be completed successfully<br/>";

        startTestCase(testcaseName, testDescription, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(ibConfig.baseUrl());
        IBLoginPage loginPage = new IBLoginPage();
        loginPage.doLogin(ibConfig.appUserName(), ibConfig.appPassword());
//      Enter OTP and Submit
        loginPage.submitOtpVerification();

        IBHomePage homePage = new IBHomePage();

        homePage.validateLoginSuccesFull(ibConfig.appUserName());
        homePage.navigateToPage("Global Edge Furever Account");

        IBFurEverAccount furEverAccount = new IBFurEverAccount();

        furEverAccount.validateFurEverAccountLanded(GLOBAL_EDGE_FUREVER_ACCOUNT);
        furEverAccount.OpenFureverAccount(OPEN_MAINTAIN_GLOBAL_EDGE_FOREVER_ACCOUNT);

        furEverAccount.selectNomineeRequires("No");
        furEverAccount.enterReasonForNomineeSetAsNo("dummy reason");

        furEverAccount.checkUncheckOfTermsAndConditions(true);
        furEverAccount.clickSubmitRequestForRequestPage();
        furEverAccount.uiMessagevalidation(PET_NAME_VALIDATION_ERROR);


//        Logout Part
        homePage.verifyDisplayed(homePage.logOut, "Logout");
        homePage.doLogOut();
        loginPage.verifyDisplayed(loginPage.username, "Username");
    }

    @Test(groups = {SANITY})
    public void validationOfFurEverAccountOpening() {

        String testcaseName = "TC04 - Verify Opening Of FurEver Account";
        String testDescription = "Validating FurEver Account Opening<br/>" +
                "Steps:<br/>" +
                "1. Login in to IB<br/>" +
                "2. use CIF does not have furever a/c opened earlier <br/>" +
                "3. Click on `Open/Maintain Global Edge Furever Account`<br/>" +
                "4. Select Nominee as `No` <br/>" +
                "5. provide mandatory reason in textbox<br/>" +
                "6. Enter pet name<br/>" +
                "6. Accept Terms & Conditions <br/>" +
                "8. click on `Submit Request` button <br/>" +
                "Validation: Furever Account Opening Request page should be open`" +
                "9. Click on Logout button<br/>"+
                "10. Logout Should be completed successfully<br/>";

        startTestCase(testcaseName, testDescription, SANITY);

//        **************** Testcase Execution Started **************************** //

        navigate(ibConfig.baseUrl());
        IBLoginPage loginPage = new IBLoginPage();
        loginPage.doLogin(ibConfig.appUserName(), ibConfig.appPassword());
//      Enter OTP and Submit
        loginPage.submitOtpVerification();

        IBHomePage homePage = new IBHomePage();

        homePage.validateLoginSuccesFull(ibConfig.appUserName());
        homePage.navigateToPage("Global Edge Furever Account");

        IBFurEverAccount furEverAccount = new IBFurEverAccount();

        furEverAccount.validateFurEverAccountLanded(GLOBAL_EDGE_FUREVER_ACCOUNT);
        furEverAccount.OpenFureverAccount(OPEN_MAINTAIN_GLOBAL_EDGE_FOREVER_ACCOUNT);

        furEverAccount.selectNomineeRequires("No");
        furEverAccount.enterReasonForNomineeSetAsNo("dummy reason");

        furEverAccount.enterPetName("Kalu");

        furEverAccount.checkUncheckOfTermsAndConditions(true);
        furEverAccount.clickSubmitRequestForRequestPage();
        furEverAccount.verifyConfirmationWindow(OPENING_REQUEST_CONFIRMATION);
//        Logout Part
        homePage.verifyDisplayed(homePage.logOut, "Logout");
        homePage.doLogOut();
        loginPage.verifyDisplayed(loginPage.username, "Username");
    }
}
