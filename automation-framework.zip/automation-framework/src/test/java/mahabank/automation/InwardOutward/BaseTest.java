package mahabank.automation.InwardOutward;

import mahabank.automation.base.ProjectHooks;
import mahabank.automation.config.ConfigurationManager;
import mahabank.automation.config.InwardOutward.InwardOutwardConfig;

public class BaseTest extends ProjectHooks {
    InwardOutwardConfig inwardOutwardConfig = ConfigurationManager.getOrCreate(InwardOutwardConfig.class);
}
