package mahabank.automation.InwardOutward;
import mahabank.automation.e2e.InwardOutward.IOLoginPage;
import mahabank.automation.e2e.InwardOutward.LetterManagementDashboard;
import org.testng.annotations.Test;


public class TestInwardOutward extends BaseTest{
    @Test(groups = {REGRESSION})
    public void testInwardOutward() {
//        String testdataPath = "src/main/java/mahabank/automation/data/CBS/deposit_test_data.json";
//        ReadDynamicJson rawdata = new ReadDynamicJson(testdataPath);
//        JsonNode testData = rawdata.getObject("TC02_CREATE_NEW_FIXED_DEPOSIT");
        String testcaseName = "TC01 - Login Testcase Dispatch";
        String testDescription = "Inward Outward Functionality Check\n" +
                "Steps:\n" +
                "1. Login in to Mahadarpan\n" +
                "2. Click on `LIOS–IT Dept` link\n" +
                "3. Then Click on Outward Letter button\n";
        startTestCase(testcaseName, testDescription, REGRESSION);

//        **************** Testcase Execution Started **************************** //

        navigate(inwardOutwardConfig.baseUrl());
        IOLoginPage loginPage = new IOLoginPage();
        loginPage.doLogin(inwardOutwardConfig.appUserName(), inwardOutwardConfig.appPassword(), "");

        LetterManagementDashboard lm = new LetterManagementDashboard();
        lm.linkToOpenModule("LIOS–IT Dept");
        lm.validateLMLanded();
        lm.doNavigation("Outward Letter");
        selectByValue("//*[.=\"Select department\"]//..//select", "CORPORATE SERVICES", "Select Department");
//      Below is for pause execution
//      getPage().pause();
    }
}
