package mahabank.automation.OTAPI;

import com.microsoft.playwright.APIRequestContext;
import mahabank.automation.base.ProjectHooks;
import mahabank.automation.config.ConfigurationManager;
import mahabank.automation.config.InwardOutward.InwardOutwardConfig;
import mahabank.automation.config.OTAPI.OTAPIConfig;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

public class BaseTest extends mahabank.automation.base.api.ApiProjectHooks {
    OTAPIConfig otapiConfig = ConfigurationManager.getOrCreate(OTAPIConfig.class);

    @BeforeMethod
    public void createContext(){
        setRequestContext(otapiConfig.baseAPIUrl());
    }
}
