package mahabank.automation.OTAPI;

import mahabank.automation.e2e.OTAPI.API.OtapiCollenctions;
import org.testng.annotations.Test;

public class testOTAPI extends BaseTest{

    @Test(groups = {REGRESSION})
    public void validateMandatoryFields() {

        String testcaseName = "TC01 - DUMMY";
        String testDescription = "<br/>" +
                "Steps:<br/>" +
                "1.Dummy<br/>";

        startTestCase(testcaseName, testDescription, REGRESSION);
        OtapiCollenctions oc = new OtapiCollenctions();
        baseURI_API.set(otapiConfig.baseAPIUrl());
        oc.getcifLongEnquiry();

    }
}
