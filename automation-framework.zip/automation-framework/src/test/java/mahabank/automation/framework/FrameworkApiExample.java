package mahabank.automation.framework;

import com.sun.net.httpserver.HttpServer;
import mahabank.automation.base.api.ApiProjectHooks;
import mahabank.automation.base.api.ApiResponseChecks;
import org.testng.annotations.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import static org.testng.Assert.*;

/** Local API integration example; no browser binary or banking endpoint is required. */
public class FrameworkApiExample extends ApiProjectHooks {
    private HttpServer server;
    @BeforeMethod public void startLocalApi() throws Exception {
        server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        server.createContext("/health",exchange -> {
            byte[] body="{\"status\":\"UP\"}".getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type","application/json");
            exchange.sendResponseHeaders(200,body.length);
            try(var out=exchange.getResponseBody()) { out.write(body); }
        });
        server.createContext("/unauthorized", exchange -> {
            byte[] body="{\"error\":{\"code\":\"UNAUTHORIZED\"}}".getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type","application/problem+json");
            exchange.sendResponseHeaders(401,body.length);
            try(var out=exchange.getResponseBody()) { out.write(body); }
        });
        server.start(); setRequestContext("http://127.0.0.1:"+server.getAddress().getPort());
    }
    @Test(groups={SMOKE}) public void apiOnlySessionCanRequestJson() {
        assertNull(getDriver(),"API-only tests must not launch browsers");
        var response=get("/health");
        try { ApiResponseChecks.assertThat(response).hasStatus(200).hasJsonContentType().hasText("/status", "UP"); }
        finally { response.dispose(); }
    }
    @Test(groups={SMOKE}) public void unauthorizedResponseHasAnExplicitErrorContract() {
        var response=get("/unauthorized");
        try { ApiResponseChecks.assertThat(response).hasStatus(401).hasJsonContentType().hasText("/error/code", "UNAUTHORIZED"); }
        finally { response.dispose(); }
    }
    @AfterMethod(alwaysRun=true) public void stopLocalApi() { if(server!=null) server.stop(0); }
}
