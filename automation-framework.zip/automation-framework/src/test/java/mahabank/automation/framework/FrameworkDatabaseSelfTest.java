package mahabank.automation.framework;

import mahabank.automation.base.PlaywrightWrapper;
import mahabank.automation.database.DatabaseClient;
import org.testng.annotations.Test;

import javax.sql.rowset.CachedRowSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.testng.Assert.*;

/** Embedded JDBC checks exercise real SQL and resource cleanup without a banking service. */
public class FrameworkDatabaseSelfTest {
    @Test public void boundParametersRemainDataAndResultsAreDetached() throws Exception {
        try (TestDatabase database = new TestDatabase()) {
            DatabaseClient client = database.client;
            client.update("CREATE TABLE fixture (id INT PRIMARY KEY, name VARCHAR(200), note VARCHAR(50))");
            String unusualName = "O'Reilly'; DROP TABLE fixture; --";
            assertEquals(client.update("INSERT INTO fixture VALUES (?, ?, ?)", 1, unusualName, null), 1);
            List<String> names = client.query("SELECT name FROM fixture WHERE name = ?", row -> row.getString(1), unusualName);
            assertEquals(names, List.of(unusualName));
            assertEquals(client.query("SELECT COUNT(*) FROM fixture", row -> row.getInt(1)), List.of(1));
            assertEquals(client.query("SELECT id FROM fixture WHERE note IS NULL", row -> row.getInt(1)), List.of(1));
            expectThrows(UnsupportedOperationException.class, () -> names.add("another"));
            database.assertConnectionsClosed();
        }
    }

    @Test public void mappingFailuresCloseRowsStatementsAndConnections() throws Exception {
        try (TestDatabase database = new TestDatabase()) {
            ResultSet[] observedRows = new ResultSet[1];
            PreparedStatement[] observedStatements = new PreparedStatement[1];
            expectThrows(SQLException.class, () -> database.client.query("SELECT 1 AS id", row -> {
                observedRows[0] = row;
                observedStatements[0] = (PreparedStatement) row.getStatement();
                assertEquals(observedStatements[0].getQueryTimeout(), 5);
                throw new SQLException("simulated mapping failure");
            }));
            assertTrue(observedRows[0].isClosed());
            assertTrue(observedStatements[0].isClosed());
            database.assertConnectionsClosed();
        }
    }

    @Test public void sqlFailuresCloseConnectionsAndDoNotReturnAnEmptySuccess() throws Exception {
        try (TestDatabase database = new TestDatabase()) {
            expectThrows(SQLException.class, () -> database.client.query("SELECT * FROM absent_table", row -> row.getInt(1)));
            expectThrows(SQLException.class, () -> database.client.update("UPDATE absent_table SET id = ?", 1));
            database.assertConnectionsClosed();
        }
    }

    @Test public void cachedRowsOutliveTheirDatabaseConnection() throws Exception {
        CachedRowSet rows;
        try (TestDatabase database = new TestDatabase()) {
            rows = database.client.queryRows("SELECT ? AS account_id", "0012");
            database.assertConnectionsClosed();
        }
        try (rows) {
            assertTrue(rows.next());
            assertEquals(rows.getString("account_id"), "0012");
            assertFalse(rows.next());
        }
    }

    @Test public void legacyDatabaseAdapterReturnsDetachedRows() throws Exception {
        DatabaseProbe probe = new DatabaseProbe();
        try (TestDatabase database = new TestDatabase();
             var manager = probe.getDatabaseManager(database.url, "sa", "")) {
            ResultSet rows = manager.executeQuery("SELECT ? AS account_id", "0042");
            try (rows) {
                assertTrue(rows instanceof CachedRowSet);
                assertTrue(rows.next());
                assertEquals(rows.getString("account_id"), "0042");
            }
        } finally { probe.endResult(); }
    }

    @Test public void invalidDatabaseInputsFailBeforeOpeningAConnection() {
        DatabaseClient client = new DatabaseClient(() -> { throw new AssertionError("must not connect"); }, 5);
        expectThrows(IllegalArgumentException.class, () -> client.update(" "));
        expectThrows(IllegalArgumentException.class, () -> client.query(null, row -> row.getInt(1)));
        expectThrows(IllegalArgumentException.class, () -> new DatabaseClient(() -> null, 0));
        expectThrows(IllegalArgumentException.class, () -> new DatabaseClient("https://example.test", "user", "password"));
    }

    private static final class TestDatabase implements AutoCloseable {
        private final String url = "jdbc:h2:mem:" + UUID.randomUUID();
        private final Connection anchor;
        private final List<Connection> opened = new ArrayList<>();
        private final DatabaseClient client;

        TestDatabase() throws SQLException {
            anchor = DriverManager.getConnection(url, "sa", "");
            client = new DatabaseClient(() -> {
                Connection connection = DriverManager.getConnection(url, "sa", "");
                opened.add(connection);
                return connection;
            }, 5);
        }

        void assertConnectionsClosed() throws SQLException {
            assertFalse(opened.isEmpty());
            for (Connection connection : opened) assertTrue(connection.isClosed(), "Operation leaked a JDBC connection");
        }

        @Override public void close() throws SQLException {
            try { for (Connection connection : opened) connection.close(); }
            finally { anchor.close(); }
        }
    }

    private static final class DatabaseProbe extends PlaywrightWrapper {
        @Override public String takeSnap() { return null; }
    }
}
