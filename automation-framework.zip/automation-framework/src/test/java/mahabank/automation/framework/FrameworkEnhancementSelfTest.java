package mahabank.automation.framework;

import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Response;
import mahabank.automation.base.api.ApiFactory;
import mahabank.automation.base.api.ApiProjectHooks;
import mahabank.automation.base.api.ApiResponseChecks;
import mahabank.automation.base.ProjectHooks;
import mahabank.automation.config.ConfigurationManager;
import mahabank.automation.utility.Utils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.math.BigDecimal;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Map;

import static org.testng.Assert.*;

public class FrameworkEnhancementSelfTest {
    @DataProvider public Object[][] invalidSettings() {
        return new Object[][] {
                {"browser", "typo"}, {"session.scope", "suite"}, {"report.theme", "neon"},
                {"headless", "treu"}, {"enable.tracing", "1"},
                {"timeout", "0"}, {"timeout", "-1"}, {"timeout", "many"}, {"timeout", "2147483648"},
                {"timeout.assertion", "0"}, {"pause.low", "-1"}, {"max.retry", "-1"},
                {"action.delay", "-1"}, {"action.delay", "NaN"}, {"action.delay", "Infinity"}
        };
    }

    @Test(dataProvider = "invalidSettings")
    public void invalidSettingsIdentifyTheKeyAndAreNotCached(String key, String value) {
        String previous = System.getProperty(key);
        ConfigurationManager.clearCache();
        try {
            System.setProperty(key, value);
            IllegalArgumentException error = expectThrows(IllegalArgumentException.class, ConfigurationManager::configuration);
            assertTrue(error.getMessage().contains("'" + key + "'"), error.getMessage());
            // An invalid configuration must not poison subsequent reads.
            restoreProperty(key, previous);
            assertNotNull(ConfigurationManager.configuration());
        } finally {
            restoreProperty(key, previous);
            ConfigurationManager.clearCache();
        }
    }

    @DataProvider public Object[][] amounts() {
        return new Object[][] {
                {"9007199254740993.0100", "9,007,199,254,740,993.0100"},
                {"1234.123456789012345678", "1,234.123456789012345678"},
                {"-1234.50", "-1,234.50"}, {"1,234.00", "1,234.00"},
                {"1E+6", "1,000,000"}, {"1.00E-3", "0.00100"}
        };
    }

    @Test(dataProvider = "amounts")
    public void amountFormattingPreservesDecimalPrecision(String input, String expected) {
        assertEquals(Utils.formatAmountToString(input), expected);
    }

    @Test public void amountFormattingDoesNotDependOnMachineLocale() {
        Locale previous = Locale.getDefault();
        try {
            Locale.setDefault(Locale.GERMANY);
            assertEquals(Utils.formatAmountToString("1234.50"), "1,234.50");
        } finally { Locale.setDefault(previous); }
    }

    @Test public void amountValidationComparesValuesAndRejectsMissingInputs() {
        Utils.validateAmount("1,000.00", "1000.0");
        expectThrows(AssertionError.class, () -> Utils.validateAmount("1000.01", "1000"));
        expectThrows(IllegalArgumentException.class, () -> Utils.formatAmountToDecimal(null));
        expectThrows(IllegalArgumentException.class, () -> Utils.formatAmountToDecimal(" "));
        assertEquals(Utils.formatAmountToString(null), "0.00");
    }

    @Test public void apiContractsSupportNestedTypedFieldsAndExactDecimals() {
        APIResponse response = response(200, Map.of("CONTENT-TYPE", "Application/Json; charset=utf-8"),
                "{\"data\":{\"active\":true,\"accounts\":[{\"id\":\"0012\",\"amount\":9007199254740993.10}]},\"a/b\":{\"~value\":\"ok\"}}");
        ApiResponseChecks.assertThat(response).hasStatus(200).hasJsonContentType()
                .hasField("/data").hasBoolean("/data/active", true).hasArraySize("/data/accounts", 1)
                .hasText("/data/accounts/0/id", "0012")
                .hasNumber("/data/accounts/0/amount", new BigDecimal("9007199254740993.100"))
                .hasText("/a~1b/~0value", "ok");
    }

    @Test public void apiContractsRejectWrongStatusesTypesAndMissingFields() {
        var checks = ApiResponseChecks.assertThat(response(202, Map.of("Content-Type", "text/html"),
                "{\"count\":\"1\",\"active\":\"true\",\"id\":1,\"missing\":null}"));
        expectThrows(AssertionError.class, () -> checks.hasStatus(200));
        expectThrows(AssertionError.class, checks::hasJsonContentType);
        expectThrows(AssertionError.class, () -> checks.hasNumber("/count", BigDecimal.ONE));
        expectThrows(AssertionError.class, () -> checks.hasBoolean("/active", true));
        expectThrows(AssertionError.class, () -> checks.hasText("/id", "1"));
        expectThrows(AssertionError.class, () -> checks.hasField("/missing"));
        expectThrows(AssertionError.class, () -> checks.hasField("/absent"));
        expectThrows(IllegalArgumentException.class, () -> checks.hasField("data.id"));
    }

    @DataProvider public Object[][] invalidJson() {
        return new Object[][] {{""}, {"{broken"}, {"{\"id\":1} {\"id\":2}"}, {"{\"id\":1,\"id\":2}"}};
    }

    @Test(dataProvider = "invalidJson") public void apiContractsRejectAmbiguousOrMalformedJson(String body) {
        expectThrows(AssertionError.class, () -> ApiResponseChecks.assertThat(response(200, Map.of(), body)).hasField("/id"));
    }

    @Test public void browserResponsesUseTheSameContractChecks() {
        Response response = FrameworkSelfTest.mock(Response.class, (proxy, method, args) -> switch (method.getName()) {
            case "status" -> 401;
            case "headers" -> Map.of("Content-Type", "application/problem+json");
            case "text" -> "{\"error\":{\"code\":\"UNAUTHORIZED\"}}";
            default -> FrameworkSelfTest.defaultValue(method.getReturnType());
        });
        ApiResponseChecks.assertThat(response).hasStatus(401).hasJsonContentType().hasText("/error/code", "UNAUTHORIZED");
    }

    @Test public void apiCallsWithoutSetupFailWithAnActionableMessage() {
        ApiFactory api = new ApiFactory();
        var error = expectThrows(IllegalStateException.class, () -> api.get("/health"));
        assertTrue(error.getMessage().contains("setRequestContext"));
        expectThrows(IllegalStateException.class, () -> api.post("/health", "{}"));
        expectThrows(IllegalStateException.class, () -> api.put("/health", "{}"));
        expectThrows(IllegalStateException.class, () -> api.delete("/health"));
    }

    @Test public void apiSetupValidatesTheBaseUrlAndSession() {
        ApiProjectHooks api = new ApiProjectHooks();
        expectThrows(IllegalArgumentException.class, () -> api.setRequestContext("/relative"));
        expectThrows(IllegalArgumentException.class, () -> api.setRequestContext("file:///tmp/example"));
        expectThrows(IllegalStateException.class, () -> api.setRequestContext("https://example.test"));
    }

    @Test public void legacyUploadPathsResolveOnTheCurrentPlatform() {
        ProjectHooks hooks = new ProjectHooks();
        Path expected = Path.of(System.getProperty("user.dir"), "src/main/java/mahabank/automation/data/upload/CPA/Sanction Letter.pdf");
        assertEquals(hooks.resolveUploadDocument("\\CPA\\Sanction Letter.pdf"), expected);
        assertEquals(hooks.resolveUploadDocument("CPA/Sanction Letter.pdf"), expected);
        expectThrows(IllegalArgumentException.class, () -> hooks.resolveUploadDocument("missing.pdf"));
        expectThrows(IllegalArgumentException.class, () -> hooks.resolveUploadDocument("../outside.pdf"));
    }

    private static APIResponse response(int status, Map<String, String> headers, String body) {
        return FrameworkSelfTest.mock(APIResponse.class, (proxy, method, args) -> switch (method.getName()) {
            case "status" -> status;
            case "headers" -> headers;
            case "text" -> body;
            default -> FrameworkSelfTest.defaultValue(method.getReturnType());
        });
    }

    private static void restoreProperty(String key, String value) {
        if (value == null) System.clearProperty(key); else System.setProperty(key, value);
    }
}
