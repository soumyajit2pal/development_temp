package mahabank.automation.framework;
import mahabank.automation.base.ProjectHooks;
import org.testng.*;
import org.testng.annotations.Test;
import org.testng.xml.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import static org.testng.Assert.*;

public class FrameworkLifecycleSelfTest {
    @Test public void setupFailureSkipsBodyAndAttemptsCleanup() throws Exception { subprocess("setup"); }
    @Test public void successfulMethodRunsLogoutAndCleanup() throws Exception { subprocess("success"); }
    @Test public void cleanupErrorCannotPassTheSuite() throws Exception { subprocess("cleanup"); }
    @Test public void classSessionsRejectParallelMethods() throws Exception { subprocess("parallel"); }
    @Test public void dataProviderRowsExportDistinctStableReportIdentities() throws Exception { subprocess("parameters"); }
    static void subprocess(String mode) throws Exception {
        String javaCommand=java.nio.file.Path.of(System.getProperty("java.home"),"bin","java").toString();
        String classpath=System.getProperty("surefire.test.class.path",System.getProperty("java.class.path"));
        var outputFile=java.nio.file.Files.createTempFile("lifecycle-", ".log");
        Process process=null;
        try {
            process=new ProcessBuilder(javaCommand,"-cp",classpath,LifecycleProbe.class.getName(),mode)
                .redirectErrorStream(true).redirectOutput(outputFile.toFile()).start();
            if(!process.waitFor(30,java.util.concurrent.TimeUnit.SECONDS)) {
                process.destroyForcibly();
                process.waitFor(5,java.util.concurrent.TimeUnit.SECONDS);
                fail("Lifecycle probe timed out: "+mode+"\n"+java.nio.file.Files.readString(outputFile));
            }
            assertEquals(process.exitValue(),0,java.nio.file.Files.readString(outputFile));
        } finally {
            if(process!=null && process.isAlive()) process.destroyForcibly();
            java.nio.file.Files.deleteIfExists(outputFile);
        }
    }
}
