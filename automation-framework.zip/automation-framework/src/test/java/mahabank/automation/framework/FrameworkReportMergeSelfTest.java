package mahabank.automation.framework;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.JsonFormatter;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import mahabank.automation.utility.*;
import org.testng.annotations.Test;
import java.nio.file.*;
import java.util.*;
import static org.testng.Assert.*;

public class FrameworkReportMergeSelfTest {
    private static final ObjectMapper JSON = new ObjectMapper();

    @Test public void tenPlusFifteenExecutionsKeepLatestResultsAndFailureHistory() throws Exception {
        Path root = Path.of("target/report-merge-demo").toAbsolutePath();
        Path first = root.resolve("run-1"), second = root.resolve("run-2"), merged = root.resolve("merged");
        LinkedHashMap<String, Status> firstResults = new LinkedHashMap<>(), secondResults = new LinkedHashMap<>();
        for (int test = 1; test <= 10; test++) firstResults.put("TC" + test, test <= 2 ? Status.FAIL : Status.PASS);
        secondResults.put("TC1", Status.PASS); secondResults.put("TC2", Status.PASS);
        for (int test = 11; test <= 23; test++) secondResults.put("TC" + test, Status.PASS);
        archive(first, "run-1", firstResults, true);
        archive(second, "run-2", secondResults, false);
        byte[] originalArchive = Files.readAllBytes(first.resolve("ExtentResults.json"));
        var result = ReportMerger.merge(List.of(first, second), merged, ReportMerger.Mode.LATEST);
        assertEquals(result.executions(), 25);
        assertEquals(result.uniqueTests(), 23);
        JsonNode summary = JSON.readTree(merged.resolve("MergeSummary.json").toFile());
        assertEquals(summary.path("latestStatuses").path("PASS").asInt(), 23);
        assertEquals(summary.path("latestStatuses").path("FAIL").asInt(), 0);
        assertEquals(JSON.readTree(merged.resolve("ExecutionHistory.json").toFile()).size(), 25);
        assertEquals(JSON.readTree(merged.resolve("ExtentResults.json").toFile()).size(), 23);
        String html = Files.readString(result.report());
        assertTrue(html.contains("Execution history (2 attempts)"));
        assertTrue(html.contains("Attempt 1 — FAIL"));
        assertTrue(html.contains("Attempt 2 — PASS"));
        assertTrue(html.contains("Historical failure &lt;script&gt;bad&lt;/script&gt;"));
        assertTrue(Files.exists(merged.resolve("artifacts/source-001/artifacts/TC1/failure.png")));
        assertTrue(Files.exists(merged.resolve("artifacts/source-001/artifacts/TC1/trace.zip")));
        assertEquals(Files.readAllBytes(first.resolve("ExtentResults.json")), originalArchive);
        // The informational history must not make a recovered test fail in the rendered dashboard.
        assertTrue(html.contains("<b>23</b> tests passed"), "Latest dashboard should count 23 passes");
        assertTrue(html.contains("<b>0</b> tests failed"), "Historical failures must not affect the latest dashboard");
    }

    @Test public void allModePreservesEveryAttemptAndLatestFailuresWin() throws Exception {
        Path root = Files.createTempDirectory("merge-all-");
        try {
            Path first = root.resolve("first"), second = root.resolve("second");
            archive(first, "first", Map.of("TC1", Status.PASS), false);
            archive(second, "second", Map.of("TC1", Status.FAIL), false);
            Path latest = root.resolve("latest"), all = root.resolve("all");
            ReportMerger.merge(List.of(first, second), latest, ReportMerger.Mode.LATEST);
            assertEquals(JSON.readTree(latest.resolve("ExtentResults.json").toFile()).get(0).path("status").asText(), "FAIL");
            ReportMerger.merge(List.of(first, second), all, ReportMerger.Mode.ALL);
            assertEquals(JSON.readTree(all.resolve("ExtentResults.json").toFile()).size(), 2);
            String html = Files.readString(all.resolve("ExecutionReport.html"));
            assertTrue(html.contains("[execution 1]")); assertTrue(html.contains("[execution 2]"));
        } finally { deleteTemporary(root); }
    }

    @Test public void mergingAnExistingMergePreservesHistoryWithoutDoubleCounting() throws Exception {
        Path root = Files.createTempDirectory("merge-again-");
        try {
            Path first = root.resolve("first"), second = root.resolve("second"), third = root.resolve("third");
            archive(first, "first", Map.of("TC1", Status.FAIL), false);
            archive(second, "second", Map.of("TC1", Status.PASS), false);
            archive(third, "third", Map.of("TC2", Status.PASS), false);
            Path merged = root.resolve("merged"), combined = root.resolve("combined");
            ReportMerger.merge(List.of(first, second), merged, ReportMerger.Mode.LATEST);
            var result = ReportMerger.merge(List.of(first, merged, third), combined, ReportMerger.Mode.LATEST);
            assertEquals(result.executions(), 3); assertEquals(result.uniqueTests(), 2); assertEquals(result.sourceRuns(), 3);
            assertEquals(JSON.readTree(combined.resolve("ExecutionHistory.json").toFile()).size(), 3);
            assertTrue(Files.readString(result.report()).contains("Execution history (2 attempts)"));
        } finally { deleteTemporary(root); }
    }

    @Test public void invalidInputsDoNotOverwriteTheirSourceReports() throws Exception {
        Path root = Files.createTempDirectory("merge-invalid-");
        try {
            Path run = root.resolve("run"); archive(run, "run", Map.of("TC1", Status.PASS), false);
            expectThrows(IllegalArgumentException.class, () -> ReportMerger.merge(List.of(run), run, ReportMerger.Mode.LATEST));
            expectThrows(java.io.IOException.class, () -> ReportMerger.merge(List.of(root.resolve("html-only")), root.resolve("output"), ReportMerger.Mode.LATEST));
            Path malformed = root.resolve("invalid.json"); Files.writeString(malformed, "{\"tests\":[]}");
            expectThrows(java.io.IOException.class, () -> ReportMerger.merge(List.of(malformed), root.resolve("output"), ReportMerger.Mode.LATEST));
            assertFalse(Files.exists(root.resolve("output/ExecutionReport.html")));
        } finally { deleteTemporary(root); }
    }

    @Test public void absoluteScreenshotPathsRemainInsideTheMergedDirectory() throws Exception {
        Path root = Files.createTempDirectory("merge-media-");
        try {
            Path run = root.resolve("run"), output = root.resolve("merged");
            archive(run, "run", Map.of("TC1", Status.FAIL), true);
            Path file = run.resolve("ExtentResults.json");
            var data = JSON.readTree(file.toFile());
            ((com.fasterxml.jackson.databind.node.ObjectNode) data.get(0).path("children").get(0).path("media").get(0))
                    .put("path", run.resolve("artifacts/TC1/failure.png").toAbsolutePath().toString());
            JSON.writeValue(file.toFile(), data);
            ReportMerger.merge(List.of(run), output, ReportMerger.Mode.LATEST);
            var merged = JSON.readTree(output.resolve("ExtentResults.json").toFile());
            String media = merged.get(0).path("children").get(0).path("media").get(0).path("path").asText();
            assertFalse(media.contains(".."));
            Path screenshot = output.toRealPath().resolve(media).normalize();
            assertTrue(screenshot.startsWith(output.toRealPath())); assertTrue(Files.isRegularFile(screenshot));
        } finally { deleteTemporary(root); }
    }

    @Test public void frameworkExportsAnArchiveWithAnIdentityThatSurvivesRenaming() throws Exception {
        ReportProbe report = new ReportProbe();
        Path directory;
        try {
            report.startTestCase("automatic", "");
            report.setReportTestId("CBS.deposit.TC01");
            report.startTestCase("Friendly case name", "", "Smoke");
            report.reportStep("Completed", "pass");
            directory = HtmlReporter.reportDirectory();
        } finally { report.endResult(); }
        JsonNode test = JSON.readTree(directory.resolve("ExtentResults.json").toFile()).get(0);
        assertEquals(test.path("infoMap").path(ReportMerger.CASE_ID).asText(), "CBS.deposit.TC01");
        assertFalse(test.path("infoMap").path(ReportMerger.ATTEMPT_ID).asText().isBlank());
        assertEquals(test.path("name").asText(), "Friendly case name");
    }

    @Test public void parameterIdentitiesSeparateRowsWithoutRecordingTheirValues() throws Exception {
        var method = FrameworkReportMergeSelfTest.class.getMethod("caseWithData", String.class);
        String secret = "sample-password-never-log";
        String one = TestCaseIdentity.forMethod(method, new Object[]{secret, Map.of("b", 2, "a", 1)});
        String same = TestCaseIdentity.forMethod(method, new Object[]{secret, Map.of("a", 1, "b", 2)});
        String other = TestCaseIdentity.forMethod(method, new Object[]{"another-row", Map.of("a", 1, "b", 2)});
        assertEquals(one, same); assertNotEquals(one, other); assertFalse(one.contains(secret));
        assertNotEquals(TestCaseIdentity.forMethod(method, new Object[]{1}), TestCaseIdentity.forMethod(method, new Object[]{"1"}));
        assertNotEquals(TestCaseIdentity.forMethod(method, new Object[]{"a, b", "c"}), TestCaseIdentity.forMethod(method, new Object[]{"a", "b, c"}));
    }

    public void caseWithData(String ignored) {}

    private static void archive(Path directory, String run, Map<String, Status> results, boolean media) throws Exception {
        Files.createDirectories(directory);
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(new JsonFormatter(directory.resolve("ExtentResults.json").toString()));
        for (var entry : results.entrySet()) {
            var test = extent.createTest(entry.getKey());
            test.getModel().getInfoMap().put(ReportMerger.CASE_ID, entry.getKey());
            test.getModel().getInfoMap().put(ReportMerger.ATTEMPT_ID, UUID.randomUUID().toString());
            test.getModel().getInfoMap().put(ReportMerger.RUN_ID, run);
            var steps = test.createNode("Test Steps");
            steps.log(entry.getValue(), entry.getValue() == Status.FAIL ? "Historical failure <script>bad</script>" : "Completed");
            if (media && entry.getValue() == Status.FAIL) {
                Path artifacts = directory.resolve("artifacts").resolve(entry.getKey()); Files.createDirectories(artifacts);
                Files.write(artifacts.resolve("failure.png"), Base64.getDecoder().decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aN1cAAAAASUVORK5CYII="));
                Files.write(artifacts.resolve("trace.zip"), new byte[]{0x50, 0x4b, 0x05, 0x06});
                steps.addScreenCaptureFromPath("artifacts/" + entry.getKey() + "/failure.png");
            }
        }
        extent.flush();
    }

    private static void deleteTemporary(Path root) throws Exception {
        try (var paths = Files.walk(root)) { for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path); }
    }
    private static final class ReportProbe extends HtmlReporter { @Override public String takeSnap() { return null; } }
}
