package mahabank.automation.framework;

import com.microsoft.playwright.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import mahabank.automation.base.BrowserFactory;
import mahabank.automation.base.api.*;
import mahabank.automation.config.*;
import mahabank.automation.config.CBS.CBSConfig;
import mahabank.automation.utility.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;
import static org.testng.Assert.*;
import java.lang.reflect.Proxy;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class FrameworkSelfTest {
    @Test public void browserNamesAreValidated() {
        assertEquals(BrowserFactory.normalizeBrowser(" Firefox "), "firefox");
        assertEquals(BrowserFactory.normalizeBrowser("safari"), "webkit");
        assertEquals(BrowserFactory.normalizeBrowser("chromium"), "chromium");
        expectThrows(IllegalArgumentException.class,()->BrowserFactory.normalizeBrowser("typo"));
    }
    @Test public void jvmOverridesClasspathDefaults() {
        System.setProperty("headless","false"); ConfigurationManager.clearCache();
        try { assertFalse(ConfigurationManager.configuration().headless()); }
        finally { System.clearProperty("headless"); ConfigurationManager.clearCache(); }
    }
    @Test public void applicationOverridesDoNotCollide() {
        System.setProperty("CBS.app.password","dummy-secret"); ConfigurationManager.clearCache();
        try { assertEquals(ConfigurationManager.getOrCreate(CBSConfig.class).appPassword(),"dummy-secret"); }
        finally { System.clearProperty("CBS.app.password"); ConfigurationManager.clearCache(); }
    }
    @Test public void configCacheSupportsConcurrentReads() throws Exception {
        ConfigurationManager.clearCache();
        ExecutorService pool=Executors.newFixedThreadPool(4);
        try {
            List<Future<Configuration>> futures=new ArrayList<>();
            for(int i=0;i<16;i++) futures.add(pool.submit(ConfigurationManager::configuration));
            Configuration first=futures.get(0).get();
            for(Future<Configuration> future:futures) assertSame(future.get(),first);
        } finally { pool.shutdownNow(); }
    }
    @Test public void missingJsonCaseIsAnError() throws Exception {
        Path file=Files.createTempFile("fixture-", ".json");
        try {
            Files.writeString(file,"{\"TC01\":{\"name\":\"sample\"}}");
            ReadDynamicJson data=new ReadDynamicJson(file.toString());
            assertEquals(data.getObject("TC01").get("name").asText(),"sample");
            expectThrows(IllegalArgumentException.class,()->data.getObject("missing"));
        } finally { Files.delete(file); }
    }
    @Test public void malformedAndNonObjectJsonAreRejected() throws Exception {
        Path file=Files.createTempFile("fixture-", ".json");
        try {
            Files.writeString(file,"[]");
            expectThrows(IllegalArgumentException.class,()->new ReadDynamicJson(file.toString()));
            Files.writeString(file,"{broken");
            expectThrows(IllegalArgumentException.class,()->new ReadDynamicJson(file.toString()));
        } finally { Files.delete(file); }
    }
    @Test public void requiredFieldsRejectBlankValues() throws Exception {
        var data=new ObjectMapper().readTree("{\"name\":\"\"}");
        expectThrows(IllegalArgumentException.class,()->ReadDynamicJson.requireText(data,"name"));
        expectThrows(IllegalArgumentException.class,()->ReadDynamicJson.requireText(data,"absent"));
    }
    @Test public void globsTreatUrlPunctuationLiterally() {
        String regex=ApiCapture.globRegex("https://example.test/api/**?id=*");
        assertTrue("https://example.test/api/v1/item?id=123".matches(regex));
        assertFalse("https://exampleXtest/api/v1/itemXid=123".matches(regex));
        assertFalse("https://example.test/api/item?id=a/b".matches(regex));
    }
    @Test public void scenarioDataIsIsolatedByThread() throws Exception {
        BrowserFactory.setScenarioData("account","main");
        ExecutorService pool=Executors.newSingleThreadExecutor();
        try {
            assertNull(pool.submit(()->BrowserFactory.getScenarioData("account")).get());
            assertEquals(BrowserFactory.getScenarioData("account"),"main");
        } finally { pool.shutdownNow(); BrowserFactory.clearScenarioData(); }
        assertNull(BrowserFactory.getScenarioData("account")); BrowserFactory.clearScenarioData();
    }
    @Test public void suiteWorkflowDataCanBeReset() {
        BrowserFactory.setGlobalData("account","test");
        assertTrue(BrowserFactory.containsKeyGlobalData("account"));
        BrowserFactory.clearGlobalData(); assertNull(BrowserFactory.getGlobalData("account"));
    }
    @Test public void cleanupContinuesAfterCloseFailure() {
        AtomicInteger attempts=new AtomicInteger(); ResourceProbe probe=new ResourceProbe();
        probe.seed(attempts,true);
        expectThrows(IllegalStateException.class,probe::dispose);
        assertEquals(attempts.get(),4,"API, context, browser and Playwright must all be attempted");
        assertNull(probe.getContext()); assertNull(probe.getPage());
        assertNull(probe.getDriver()); assertNull(probe.getPlaywright()); assertNull(probe.getRequestContext());
        probe.dispose(); assertEquals(attempts.get(),4,"Cleanup must be idempotent");
    }
    @Test public void excelReadersDoNotSharePathsAndFormatCells() throws Exception {
        Path one=Files.createTempFile("one-", ".xlsx"),two=Files.createTempFile("two-", ".xlsx");
        try {
            workbook(one,12); workbook(two,42);
            ExcelUtil first=new ExcelUtil(one.toString(),"Data"), second=new ExcelUtil(two.toString(),"Data");
            assertEquals(first.readRow(1,"number","calculated").get("number"),"0012");
            assertEquals(first.readRow(1,"calculated").get("calculated"),"24");
            assertEquals(second.readRow(1,"number").get("number"),"0042");
            expectThrows(IllegalArgumentException.class,()->first.readRow(1,"unknown"));
        } finally { Files.delete(one); Files.delete(two); ExcelUtil.clearLegacyReader(); }
    }
    @Test public void reportingFailureThrowsAssertionAndEscapesMarkup() {
        ReportProbe report=new ReportProbe();
        try {
            report.startTestCase("Expected failure check", "");
            expectThrows(AssertionError.class,()->report.reportStep("<script>bad</script>","fail"));
            assertEquals(HtmlReporter.escapeHtml("<b>&"),"&lt;b&gt;&amp;");
        } finally { report.endResult(); }
    }
    @Test public void customCaseNameReusesAutomaticReportNode() {
        ReportProbe report=new ReportProbe();
        try {
            report.startTestCase("auto", ""); var original=report.getParentTest();
            report.startTestCase("friendly", "steps", "Smoke");
            assertSame(report.getParentTest(),original);
            assertEquals(original.getModel().getName(),"friendly");
        } finally { report.endResult(); }
    }
    private static void workbook(Path file,int value) throws Exception {
        try(var book=new XSSFWorkbook()) {
            var sheet=book.createSheet("Data"); var header=sheet.createRow(0);
            header.createCell(0).setCellValue("number");header.createCell(1).setCellValue("calculated");
            var row=sheet.createRow(1);var cell=row.createCell(0);cell.setCellValue(value);
            var style=book.createCellStyle();style.setDataFormat(book.createDataFormat().getFormat("0000"));cell.setCellStyle(style);
            row.createCell(1).setCellFormula("A2*2");
            try(var stream=Files.newOutputStream(file)) { book.write(stream); }
        }
    }
    static <T> T mock(Class<T> type,java.lang.reflect.InvocationHandler handler) {
        return type.cast(Proxy.newProxyInstance(type.getClassLoader(),new Class<?>[]{type},handler));
    }
    static Object defaultValue(Class<?> type) {
        if(type==boolean.class) return false;
        if(type==int.class) return 0;
        if(type==long.class) return 0L;
        if(type==double.class) return 0d;
        return null;
    }
    private static class ResourceProbe extends ApiFactory {
        void seed(AtomicInteger attempts,boolean fail) {
            java.lang.reflect.InvocationHandler handler=(obj,method,args)-> {
                if(method.getName().equals("close") || method.getName().equals("dispose")) {
                    attempts.incrementAndGet();
                    if(fail && (obj instanceof BrowserContext || obj instanceof APIRequestContext)) throw new IllegalStateException("simulated close failure");
                }
                return defaultValue(method.getReturnType());
            };
            context.set(mock(BrowserContext.class,handler)); driver.set(mock(Browser.class,handler));
            playwright.set(mock(Playwright.class,handler)); requestContext.set(mock(APIRequestContext.class,handler));
            page.set(mock(Page.class,handler));
        }
        void dispose() { disposeResources(); }
    }
    private static class ReportProbe extends HtmlReporter { public String takeSnap() { return null; } }
}
