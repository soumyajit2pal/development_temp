package mahabank.automation.framework;
import mahabank.automation.base.ProjectHooks;
import mahabank.automation.pages.BasePage;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;
import org.testng.annotations.Test;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import static org.testng.Assert.*;
import java.nio.file.Files;
import java.nio.file.Path;

/** Uses browser-local HTML, never connects to a banking application. */
public class FrameworkUiExample extends ProjectHooks {
    @Test(groups={SMOKE}) public void clickUpdatesStatus() {
        getPage().setContent("<button onclick=\"document.querySelector('#status').textContent='Saved'\">Save</button><p id='status' role='status'>Pending</p>");
        SavePage savePage = new SavePage(getPage());
        savePage.save();
        savePage.verifySaved();
    }
    @Test(groups={SMOKE}) public void contextStartsWithoutPreviousCookies() {
        org.testng.Assert.assertTrue(getContext().cookies().isEmpty());
    }

    @Test public void keyboardWrappersReplacePrefilledValuesAndTriggerKeys() {
        getPage().setContent("""
                <input id='enter' value='old' onkeydown="if(event.key==='Enter')document.querySelector('#entered').textContent=this.value">
                <p id='entered'></p><input id='tab' value='old' onblur="document.querySelector('#blurred').textContent=this.value">
                <p id='blurred'></p><button>Next</button>
                """);
        typeAndEnter("#enter", "new-enter", "Enter field");
        verifyExactText("#entered", "new-enter");
        typeAndTab("#tab", "new-tab", "Tab field");
        verifyExactText("#blurred", "new-tab");
        type("#enter", "replacement", "Enter field");
        verifyInputText("#enter", "replacement");
    }

    @Test public void dropdownIndexesSelectTheRequestedOptionIncludingFrames() {
        getPage().setContent("""
                <select id='select'><option value='same'>First</option>
                <optgroup label='Group'><option value='same'>Second</option></optgroup></select>
                <iframe id='frame' srcdoc="<input id='text' value='old'><select id='select'><option value='same'>First</option><option value='same'>Second</option></select>"></iframe>
                """);
        selectByIndex("#select", 1, "Dropdown");
        assertEquals(((Number) getPage().locator("#select").evaluate("element => element.selectedIndex")).intValue(), 1);
        setFrameLocator("#frame");
        selectByIndexInFrame("#select", 1, "Frame dropdown");
        assertEquals(((Number) getFrameLocator().locator("#select").evaluate("element => element.selectedIndex")).intValue(), 1);
        typeInFrame("#text", "new", "Frame input");
        assertThat(getFrameLocator().locator("#text")).hasValue("new");
    }

    @Test public void customDropdownSelectionMatchesTheExactOption() {
        getPage().setContent("""
                <button id='open' onclick="document.querySelector('#options').hidden=false">Open</button>
                <div id='options' hidden><button role='option' onclick="document.querySelector('#selected').textContent='Yes'">Yes</button>
                <button role='option' onclick="document.querySelector('#selected').textContent='Yes please'">Yes please</button></div>
                <p id='selected'></p>
                """);
        selectByClick("#open", "Yes", "Dropdown");
        verifyExactText("#selected", "Yes");
    }

    @Test public void checkboxesCanBeCheckedAndUncheckedThroughTheIbHelper() {
        getPage().setContent("<input type='checkbox' name='agreeBox'>");
        var account = new mahabank.automation.e2e.IB.IBFurEverAccount();
        account.checkUncheckOfTermsAndConditions(true);
        account.checkUncheckOfTermsAndConditionsValidation(true);
        account.checkUncheckOfTermsAndConditions(false);
        account.checkUncheckOfTermsAndConditionsValidation(false);
    }

    @Test public void nonEmptyAssertionsSupportTextAndInputs() {
        getPage().setContent("<p id='text'>Text value</p><input id='input' value='Input value'>");
        verifyNotEmpty(getPage().locator("#text"), "Text");
        verifyNotEmpty(getPage().locator("#input"), "Input");
    }

    @Test public void popupSwitchingIgnoresUnrelatedContextPages() {
        getPage().setContent("<button id='open' onclick=\"window.open('about:blank')\">Open popup</button>");
        Page original = getPage();
        Page[] unrelated = new Page[1];
        var pages = switchToOpenedPage(original, () -> {
            unrelated[0] = getContext().newPage(); original.locator("#open").click();
        });
        assertSame(pages.get("oldPage"), original);
        assertNotSame(pages.get("newPage"), unrelated[0]);
        assertSame(getPage(), pages.get("newPage"));
        pages.get("newPage").close(); unrelated[0].close(); setPage(original);
    }

    @Test public void repeatedDownloadsKeepBothFiles() throws Exception {
        String name = "wrapper-" + java.util.UUID.randomUUID();
        Path first = Path.of("download", name + ".txt");
        Path second = Path.of("download", name + " (1).txt");
        try {
            getPage().setContent("<a id='download' download='original.txt' href='data:text/plain,wrapper-download'>Download</a>");
            handleDownloadOnClick("#download", name); handleDownloadOnClick("#download", name);
            assertEquals(Files.readString(first), "wrapper-download");
            assertEquals(Files.readString(second), "wrapper-download");
        } finally { Files.deleteIfExists(first); Files.deleteIfExists(second); }
    }

    @Test public void passiveApiCapturePreservesMocksAndResetsBetweenCaptures() {
        getPage().route("https://example.test/", route -> route.fulfill(new com.microsoft.playwright.Route.FulfillOptions()
                .setContentType("text/html").setBody("<p>Local fixture</p>")));
        getPage().navigate("https://example.test/");
        var api = new mahabank.automation.base.api.ApiWrapper() {};
        api.mockApi("**/api/**", "{\"mock\":true}");
        api.initApiInterception(); api.initApiInterception(); api.interceptApi("**/api/**");
        getPage().evaluate("async () => (await fetch('/api/one')).json()");
        assertEquals(api.getApiResponse("**/api/one", 1).get("body"), "{\"mock\":true}");
        api.resetApiCapture(); api.interceptApi("**/api/**");
        getPage().evaluate("async () => (await fetch('/api/two')).json()");
        assertEquals(api.getApiResponse("**/api/two", 1).get("body"), "{\"mock\":true}");
        expectThrows(IllegalStateException.class, () -> api.getApiResponse("**/api/one", null));
    }

    @Test public void loginWaitsForDelayedControlsWithoutAnInteractivePause() {
        getPage().setContent("""
                <input id='userLogin:userName'><input id='userLogin:password' type='password'>
                <button id='userLogin:loginButton' style='display:none' onclick="document.querySelector('#result').textContent='Logged in'">Login</button>
                <p id='result'></p><script>setTimeout(() => document.getElementById('userLogin:loginButton').style.display='block',100)</script>
                """);
        new mahabank.automation.e2e.IB.IBLoginPage().doLogin("local-user", "local-password");
        verifyExactText("#result", "Logged in");
    }

    @Test public void failedTestsProduceReadableScreenshotsTracesAndJson() throws Exception {
        FrameworkLifecycleSelfTest.subprocess("browser-failure");
    }

    @Test public void repeatedDialogRegistrationAcceptsEachDialogOnce() {
        getPage().setContent("<p id='result'></p>");
        AcceptDialog(); AcceptDialog();
        getPage().evaluate("() => { alert('First dialog'); alert('Second dialog'); document.querySelector('#result').textContent='Accepted'; }");
        verifyExactText("#result", "Accepted");
    }

    /** Page objects receive their dependency; only the test inherits lifecycle hooks. */
    private static final class SavePage extends BasePage {
        private final Locator saveButton;
        private final Locator status;

        SavePage(Page page) {
            super(page);
            saveButton = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Save").setExact(true));
            status = page.getByRole(AriaRole.STATUS);
        }

        void save() { saveButton.click(); }
        void verifySaved() { assertThat(status).hasText("Saved"); }
    }
}
