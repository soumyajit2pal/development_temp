package mahabank.automation.framework;

import com.microsoft.playwright.*;
import mahabank.automation.base.PlaywrightWrapper;
import mahabank.automation.base.api.ApiCapture;
import mahabank.automation.base.api.ApiWrapper;
import mahabank.automation.e2e.CBS.CIF.PersonalCustomer.PersonalDetails;
import mahabank.automation.e2e.CBS.DEPOSIT.DepositAccount;
import mahabank.automation.e2e.CBS.EnquiriesPage;
import mahabank.automation.e2e.CBS.TransactionPosting.CashDeposit;
import mahabank.automation.utility.*;
import org.testng.annotations.Test;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import static org.testng.Assert.*;
import static mahabank.automation.framework.FrameworkSelfTest.mock;
import static mahabank.automation.framework.FrameworkSelfTest.defaultValue;

public class FrameworkWrapperSelfTest {
    @Test public void actionFailuresPreserveCausesAndAppearanceCannotSilentlyPass() {
        PlaywrightException cause = new PlaywrightException("simulated missing control");
        Locator locator = mock(Locator.class, (object, method, arguments) -> { throw cause; });
        WrapperProbe probe = new WrapperProbe();
        probe.setPage(mock(Page.class, (object, method, arguments) -> method.getName().equals("locator")
                ? locator : defaultValue(method.getReturnType())));
        try {
            assertSame(expectThrows(AssertionError.class, () -> probe.type("#missing", "value", "Field")).getCause(), cause);
            assertSame(expectThrows(AssertionError.class, () -> probe.waitForAppearance("#missing")).getCause(), cause);
        } finally { probe.close(); }
    }

    @Test public void invalidIndexesAndDownloadNamesFailBeforeBrowserActions() {
        WrapperProbe probe = new WrapperProbe();
        expectThrows(IllegalArgumentException.class, () -> probe.selectByIndex("select", -1, "Dropdown"));
        expectThrows(IllegalArgumentException.class, () -> probe.selectByIndexInFrame("select", -1, "Dropdown"));
        for (String name : Arrays.asList(null, "", " ", ".", "..", "../outside", "nested/file", "nested\\file"))
            expectThrows(IllegalArgumentException.class, () -> probe.handleDownloadOnClick("button", name));
    }

    @Test public void changingPagesClearsTheOldFrameSelection() {
        WrapperProbe probe = new WrapperProbe();
        FrameLocator frame = mock(FrameLocator.class, (object, method, arguments) -> null);
        Page first = mock(Page.class, (object, method, arguments) -> method.getName().equals("frameLocator")
                ? frame : defaultValue(method.getReturnType()));
        try {
            probe.setPage(first); probe.setFrameLocator("iframe"); assertSame(probe.getFrameLocator(), frame);
            probe.setPage(first); assertSame(probe.getFrameLocator(), frame);
            probe.setPage(mock(Page.class, (object, method, arguments) -> defaultValue(method.getReturnType())));
            expectThrows(IllegalStateException.class, probe::getFrameLocator);
        } finally { probe.close(); }
    }

    @Test public void captureIsIdempotentPassiveAndReturnsTheLatestArrival() {
        CaptureFixture fixture = new CaptureFixture();
        try {
            fixture.probe.initApiInterception(); fixture.probe.initApiInterception();
            fixture.probe.interceptApi("https://example.test/**");
            assertEquals(fixture.listeners.size(), 1); assertEquals(fixture.routes, 0);
            fixture.emit("https://example.test/one", "first");
            fixture.emit("https://example.test/one", "second");
            fixture.emit("https://example.test/two", "newest");
            assertEquals(fixture.probe.getApiResponse("https://example.test/**", null).get("body"), "newest");
            assertEquals(fixture.probe.getApiResponse("https://example.test/one", 1).get("body"), "first");
            expectThrows(IllegalArgumentException.class, () -> fixture.probe.getApiResponse("https://example.test/**", 1));
            expectThrows(UnsupportedOperationException.class, () -> fixture.probe.getApiResponse("https://example.test/one", 1).put("body", "changed"));
            fixture.probe.resetApiCapture();
            fixture.emit("https://example.test/one", "ignored");
            expectThrows(IllegalStateException.class, () -> fixture.probe.getApiResponse("https://example.test/**", null));
            fixture.probe.interceptApi("https://example.test/**"); fixture.emit("https://example.test/one", "fresh");
            assertEquals(fixture.probe.getApiResponse("https://example.test/one", 1).get("body"), "fresh");
        } finally { fixture.probe.close(); }
        assertTrue(fixture.listeners.isEmpty());
    }

    @Test public void captureIsIsolatedAcrossThreadsAndPageChanges() throws Exception {
        CaptureFixture main = new CaptureFixture();
        ExecutorService pool = Executors.newSingleThreadExecutor();
        try {
            main.probe.interceptApi("**"); main.emit("https://example.test/main", "main");
            assertEquals(pool.submit(() -> {
                CaptureFixture other = new CaptureFixture(main.probe);
                try {
                    expectThrows(IllegalStateException.class, () -> other.probe.getApiResponse("**", null));
                    other.probe.interceptApi("**"); other.emit("https://example.test/other", "other");
                    return other.probe.getApiResponse("**", null).get("body");
                } finally { other.probe.close(); }
            }).get(5, TimeUnit.SECONDS), "other");
            assertEquals(main.probe.getApiResponse("**", null).get("body"), "main");
            CaptureFixture next = new CaptureFixture(main.probe);
            next.probe.interceptApi("**");
            assertTrue(main.listeners.isEmpty());
            expectThrows(IllegalStateException.class, () -> next.probe.getApiResponse("**", null));
        } finally { pool.shutdownNow(); main.probe.close(); }
    }

    @Test public void unreadableCapturedBodiesAreNotReportedAsSuccessfulData() {
        CaptureFixture fixture = new CaptureFixture();
        PlaywrightException cause = new PlaywrightException("unavailable body");
        try {
            fixture.probe.interceptApi("**");
            fixture.listeners.get(0).accept(mock(Response.class, (object, method, arguments) -> switch (method.getName()) {
                case "url" -> "https://example.test/body";
                case "status" -> 200;
                case "text" -> throw cause;
                default -> defaultValue(method.getReturnType());
            }));
            assertSame(expectThrows(IllegalStateException.class, () -> fixture.probe.getApiResponse("**", null)).getCause(), cause);
        } finally { fixture.probe.close(); }
    }

    @Test public void fixturesRejectAmbiguousJsonAndWrongRequiredFieldTypes() throws Exception {
        Path fixture = Files.createTempFile("strict-fixture-", ".json");
        try {
            for (String content : List.of("{\"case\":{}} {}", "{\"case\":{},\"case\":{}}")) {
                Files.writeString(fixture, content);
                expectThrows(IllegalArgumentException.class, () -> new ReadDynamicJson(fixture.toString()));
            }
            var data = new com.fasterxml.jackson.databind.ObjectMapper().readTree("{\"text\":\"valid\",\"number\":42,\"flag\":true,\"object\":{},\"array\":[],\"null\":null}");
            assertEquals(ReadDynamicJson.requireText(data, "text"), "valid");
            for (String key : List.of("number", "flag", "object", "array", "null", "absent"))
                expectThrows(IllegalArgumentException.class, () -> ReadDynamicJson.requireText(data, key));
            expectThrows(IllegalArgumentException.class, () -> ReadDynamicJson.requireText(null, "text"));
        } finally { Files.deleteIfExists(fixture); }
    }

    @Test public void spreadsheetRowsCannotBeModifiedThroughTheirSourceMap() {
        Map<String, String> values = new HashMap<>(Map.of("account", "0007"));
        RowData row = new RowData(values); values.put("account", "other");
        assertEquals(row.get("account"), "0007");
        expectThrows(UnsupportedOperationException.class, () -> row.getAll().put("account", "other"));
    }

    @Test public void balanceAssertionsCompareValueInsteadOfDecimalScale() {
        var page = new mahabank.automation.e2e.CBS.BasePage() {
            @Override public void reportStep(String text, String status) {}
        };
        page.validateNewTotalBalanceAfterDeposit("10.0", "5.000", "15.00", "0");
        expectThrows(AssertionError.class, () -> page.validateNewTotalBalanceAfterDeposit("10", "5", "14.99", "0"));
    }

    @Test public void missingLinkedAccountsFailInsteadOfReturningAnEmptyBalance() {
        Locator accounts = mock(Locator.class, (object, method, arguments) -> defaultValue(method.getReturnType()));
        WrapperProbe resources = new WrapperProbe();
        resources.setPage(mock(Page.class, (object, method, arguments) -> method.getName().equals("locator")
                ? accounts : defaultValue(method.getReturnType())));
        EnquiriesPage enquiries = new EnquiriesPage() {
            @Override public void reportFailure(String text, Throwable cause) { throw new AssertionError(text, cause); }
        };
        try { expectThrows(AssertionError.class, () -> enquiries.getAccountLevelTotalBalance("missing")); }
        finally { resources.close(); }
    }

    @Test public void invalidBusinessInputsFailBeforeChangingThePage() {
        PersonalDetails personal = new PersonalDetails();
        for (String date : Arrays.asList(null, "31/2/2024", "12/13/2000", "malformed"))
            expectThrows(IllegalArgumentException.class, () -> personal.selectDOB(date));
        expectThrows(IllegalArgumentException.class, () -> new CashDeposit().enterDenomIn("unsupported", "1"));
        DepositAccount deposit = new DepositAccount();
        for (int count : List.of(0, 5)) expectThrows(IllegalArgumentException.class, () -> nominate(deposit, count, "100"));
        expectThrows(IllegalArgumentException.class, () -> nominate(deposit, 2, "110,-10"));
        expectThrows(IllegalArgumentException.class, () -> deposit.ValidationOfNomineeRegistrationWhileNomineeFlagYes(
                "Y", "2:Simultaneous", 1, "Mr", "Nominee", "10", "Other", "Address", "0000000000", "Y", "100"));
    }

    @Test public void missingMockFilesPreserveTheirIoCause() {
        CaptureProbe probe = new CaptureProbe();
        var error = expectThrows(AssertionError.class,
                () -> probe.mockApiFromFile("**/api/**", "target/missing-mock-" + UUID.randomUUID() + ".json"));
        assertTrue(error.getCause() instanceof java.nio.file.NoSuchFileException);
    }

    private static void nominate(DepositAccount deposit, int count, String percentages) {
        deposit.ValidationOfNomineeRegistrationWhileNomineeFlagYes("Y", "2:Simultaneous", count,
                "Mr", "Nominee", "30", "Other", "Address", "0000000000", "N", percentages);
    }
    private static class WrapperProbe extends PlaywrightWrapper {
        public String takeSnap() { return null; }
        @Override public void reportStep(String text, String status) {}
        @Override public void reportFailure(String text, Throwable cause) { throw new AssertionError(text, cause); }
        void close() { disposeResources(); }
    }
    private static class CaptureProbe extends ApiWrapper {
        @Override public void reportStep(String text, String status) {}
        @Override public void reportFailure(String text, Throwable cause) { throw new AssertionError(text, cause); }
        void close() { disposeResources(); }
    }
    private static class CaptureFixture {
        final CaptureProbe probe;
        final List<Consumer<Response>> listeners = new ArrayList<>();
        int routes;
        CaptureFixture() { this(new CaptureProbe()); }
        @SuppressWarnings("unchecked") CaptureFixture(CaptureProbe probe) {
            this.probe = probe;
            probe.setPage(mock(Page.class, (object, method, arguments) -> {
                switch (method.getName()) {
                    case "onResponse" -> listeners.add((Consumer<Response>) arguments[0]);
                    case "offResponse" -> listeners.remove(arguments[0]);
                    case "route" -> routes++;
                }
                return defaultValue(method.getReturnType());
            }));
        }
        void emit(String url, String body) {
            Response response = mock(Response.class, (object, method, arguments) -> switch (method.getName()) {
                case "url" -> url;
                case "status" -> 200;
                case "text" -> body;
                default -> defaultValue(method.getReturnType());
            });
            List.copyOf(listeners).forEach(listener -> listener.accept(response));
        }
    }
}
