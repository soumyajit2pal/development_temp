package mahabank.automation.framework;
import mahabank.automation.base.ProjectHooks;
import org.testng.*;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.xml.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import static org.testng.Assert.*;

public class LifecycleProbe {
    /** Probe runs in another JVM so expected TestNG failures can't contaminate the parent suite. */
    public static void main(String[] args) {
        switch(args[0]) {
            case "setup" -> {
                TestNG runner=run(SetupFailure.class);
                assertTrue(runner.hasFailure()); assertEquals(SetupFailure.body.get(),0);
                assertTrue(SetupFailure.closes.get()>=1);
            }
            case "success" -> {
                TestNG runner=run(Successful.class); assertFalse(runner.hasFailure());
                assertEquals(Successful.logout.get(),1);assertEquals(Successful.closes.get(),1);
            }
            case "cleanup" -> assertTrue(run(CleanupFailure.class).hasFailure());
            case "parallel" -> {
                XmlSuite suite=new XmlSuite();suite.setName("invalid session scope");
                suite.setParallel(XmlSuite.ParallelMode.METHODS);
                XmlTest test=new XmlTest(suite);test.setName("invalid");test.addParameter("sessionScope","CLASS");
                test.setXmlClasses(List.of(new XmlClass(Successful.class)));
                TestNG runner=new TestNG();runner.setUseDefaultListeners(false);runner.setVerbose(0);
                runner.setXmlSuites(List.of(suite));runner.run();assertTrue(runner.hasFailure());
            }
            case "parameters" -> {
                assertFalse(run(Parameterized.class).hasFailure());
                try {
                    var file = mahabank.automation.utility.HtmlReporter.reportDirectory().resolve("ExtentResults.json");
                    String archive = java.nio.file.Files.readString(file);
                    var cases = new com.fasterxml.jackson.databind.ObjectMapper().readTree(archive);
                    assertEquals(cases.size(), 2);
                    String key = mahabank.automation.utility.ReportMerger.CASE_ID;
                    assertNotEquals(cases.get(0).path("infoMap").path(key).asText(), cases.get(1).path("infoMap").path(key).asText());
                    assertEquals(cases.get(0).path("name").asText(), "Same friendly name");
                    assertEquals(cases.get(1).path("name").asText(), "Same friendly name");
                    assertFalse(archive.contains("data-row-alpha")); assertFalse(archive.contains("data-row-beta"));
                } catch (java.io.IOException e) { throw new IllegalStateException(e); }
            }
            case "browser-failure" -> {
                System.setProperty("enable.tracing", "true");
                mahabank.automation.config.ConfigurationManager.clearCache();
                assertTrue(run(BrowserFailure.class).hasFailure());
                var report = mahabank.automation.utility.HtmlReporter.reportDirectory();
                try (var files = java.nio.file.Files.walk(report.resolve("artifacts"))) {
                    var artifacts = files.filter(java.nio.file.Files::isRegularFile).toList();
                    var png = artifacts.stream().filter(file -> file.getFileName().toString().equals("failure.png")).findFirst().orElseThrow();
                    assertNotNull(javax.imageio.ImageIO.read(png.toFile()), "Screenshot must be a readable PNG");
                    var trace = artifacts.stream().filter(file -> file.getFileName().toString().equals("trace.zip")).findFirst().orElseThrow();
                    try (var zip = new java.util.zip.ZipFile(trace.toFile())) { assertTrue(zip.size() > 0); }
                    var archive = new com.fasterxml.jackson.databind.ObjectMapper().readTree(report.resolve("ExtentResults.json").toFile());
                    assertEquals(archive.size(), 1); assertEquals(archive.get(0).path("status").asText(), "FAIL");
                } catch (java.io.IOException e) { throw new IllegalStateException(e); }
            }
            default -> throw new IllegalArgumentException("Unknown probe");
        }
    }
    private static TestNG run(Class<?> type) {
        TestNG runner=new TestNG();runner.setUseDefaultListeners(false);runner.setVerbose(0);
        runner.setTestClasses(new Class<?>[]{type});runner.run();return runner;
    }
    public static class SetupFailure extends ProjectHooks {
        static final AtomicInteger body=new AtomicInteger(),closes=new AtomicInteger();
        @Override public void initializeBrowser(String browser) { throw new IllegalStateException("simulated launch failure"); }
        @Override protected void closeResources() { closes.incrementAndGet(); super.closeResources(); }
        @Test public void neverRuns() { body.incrementAndGet(); }
    }
    public static class Successful extends ProjectHooks {
        static final AtomicInteger logout=new AtomicInteger(),closes=new AtomicInteger();
        @Override public void initializeBrowser(String browser) {}
        @Override protected void setupContextAndPage() {}
        @Override protected void closeResources() { closes.incrementAndGet(); super.closeResources(); }
        @Test public void passes() { registerLogoutAction(logout::incrementAndGet); }
    }
    public static class CleanupFailure extends Successful {
        @Override protected void closeResources() { super.closeResources(); throw new IllegalStateException("simulated cleanup error"); }
    }
    public static class Parameterized extends ProjectHooks {
        @Override public void initializeBrowser(String browser) {}
        @Override protected void setupContextAndPage() {}
        @DataProvider public Object[][] rows() { return new Object[][] {{"data-row-alpha"}, {"data-row-beta"}}; }
        @Test(dataProvider="rows") public void caseWithRow(String row) {
            assertTrue(Set.of("data-row-alpha", "data-row-beta").contains(row));
            startTestCase("Same friendly name", ""); reportStep("Row completed", "pass");
        }
    }
    public static class BrowserFailure extends ProjectHooks {
        @Test public void expectedFailure() {
            getPage().setContent("<p>Local failure artifact probe</p>");
            throw new AssertionError("Expected failure for screenshot/trace validation");
        }
    }
}
