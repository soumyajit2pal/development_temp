"""Transactional email notifications for workflow activity.

SMTP is deliberately disabled unless SMTP_ENABLED=true. Once enabled,
workflow events are placed in a durable outbox, so a transient SMTP outage
never loses a notification.
"""
import asyncio
import datetime
import logging
import os
import smtplib
import ssl
import threading
import time
from dataclasses import dataclass
from email.message import EmailMessage
from html import escape
from urllib.parse import quote
from uuid import uuid4

from sqlalchemy import event, or_
from sqlalchemy.orm import Session as SASession, joinedload, selectinload

from . import models
from .constants import Role, format_role_labels
from .database import SessionLocal
from .resilience import CircuitOpenError, smtp_circuit

logger = logging.getLogger("qa_portal.email")
_listener_installed = False
_poller_started = False
_delivery_lock = threading.Lock()
_delivery_scheduler_lock = threading.Lock()
_delivery_worker_running = False
_delivery_rerun_requested = False
_last_sla_check: float | None = None
_MAX_ATTEMPTS = 5
_EMAIL_TEMPLATE_MARKER = "qa-portal-email-template:v1"


@dataclass(frozen=True)
class NotificationRoute:
    recipient_ids: set[int]
    recipient_label: str
    action_required: bool
    instruction: str
    requester_input_ids: frozenset[int] = frozenset()


def _enabled() -> bool:
    return os.getenv("SMTP_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}


def _smtp_settings() -> dict:
    from_name = os.getenv("SMTP_FROM_NAME", "QualityOps").strip() or "QualityOps"
    if from_name.casefold() in {"qa portal", "qa-portal"}:
        from_name = "QualityOps"
    return {
        "host": os.getenv("SMTP_HOST", "").strip(),
        "port": int(os.getenv("SMTP_PORT", "587")),
        "username": os.getenv("SMTP_USERNAME", "").strip(),
        "password": os.getenv("SMTP_PASSWORD", ""),
        "from_address": os.getenv("SMTP_FROM_ADDRESS", "").strip(),
        "from_name": from_name,
        "starttls": os.getenv("SMTP_STARTTLS", "true").strip().lower() in {"1", "true", "yes", "on"},
        "ssl": os.getenv("SMTP_SSL", "false").strip().lower() in {"1", "true", "yes", "on"},
        "timeout": int(os.getenv("SMTP_TIMEOUT_SECONDS", "15")),
    }


def smtp_readiness() -> tuple[bool, str | None]:
    if not _enabled():
        return False, "SMTP_ENABLED is false"
    settings = _smtp_settings()
    if not settings["host"] or not settings["from_address"]:
        return False, "SMTP_HOST and SMTP_FROM_ADDRESS are required"
    if settings["ssl"] and settings["starttls"]:
        return False, "SMTP_SSL and SMTP_STARTTLS cannot both be enabled"
    return True, None


# def _send_message(message: EmailMessage, settings: dict) -> None:
#     """Send one prepared message through the configured SMTP transport."""
#     tls_context = ssl.create_default_context(cafile=os.getenv("SMTP_CA_CERTS_FILE") or None)
#     tls_context.minimum_version = ssl.TLSVersion.TLSv1_2
#     tls_context.check_hostname = True
#     tls_context.verify_mode = ssl.CERT_REQUIRED
#     smtp_class = smtplib.SMTP_SSL if settings["ssl"] else smtplib.SMTP
#     try:
#         with smtp_class(settings["host"], settings["port"], timeout=settings["timeout"],
#                         **({"context": tls_context} if settings["ssl"] else {})) as client:
#             if settings["starttls"]:
#                 client.starttls(context=tls_context)
#             if settings["username"]:
#                 client.login(settings["username"], settings["password"])
#             client.send_message(message)
#     except Exception:
#         smtp_circuit.record_failure()
#         raise
#     smtp_circuit.record_success()

def _send_message(message: EmailMessage, settings: dict) -> None:
    """Send one prepared message through the configured SMTP transport."""
    smtp_class = smtplib.SMTP_SSL if settings["ssl"] else smtplib.SMTP
    try:
        with smtp_class(settings["host"], settings["port"], timeout=settings["timeout"]) as client:
            if settings["starttls"]:
                client.starttls()
            if settings["username"]:
                client.login(settings["username"], settings["password"])
            client.send_message(message)
    except Exception:
        smtp_circuit.record_failure()
        raise
    smtp_circuit.record_success()

def _html_email(title: str, subtitle: str, instruction: str, *,
                status: str | None, panel_title: str, panel_html: str,
                action_label: str, action_url: str,
                footer: str | None = None) -> str:
    """Render the one approved QualityOps mail design.

    This is deliberately the exact Test Case digest structure: teal header,
    title, instruction, status line, one pale detail panel and one teal
    action button.  Every notification calls this renderer; no email type is
    allowed to introduce a separate table/card/layout. ``panel_html`` is
    built from escaped values at each call site.
    """
    footer = footer or "This is an automated QualityOps workflow notification."
    status_html = ""
    if status:
        status_html = (
            '<p style="margin:0 0 10px;color:#627981;font-size:13px">Current status</p>'
            f'<p style="margin:0 0 18px;font-weight:600">{escape(status)}</p>'
        )
    # This is the only approved visual format.  Do not introduce a template
    # per notification type: every caller supplies content to these same six
    # areas (header, title, instruction, status, detail panel and CTA).
    return f"""<!doctype html><!-- {_EMAIL_TEMPLATE_MARKER} --><html><body style=\"margin:0;background:#f3f7f8;font-family:Arial,Helvetica,sans-serif;color:#19333b\">
<div style=\"max-width:704px;margin:16px auto;background:#ffffff;border:1px solid #d7e5e8;border-radius:12px;overflow:hidden\">
  <div style=\"padding:20px 30px;background:#116b7d;color:#ffffff\"><strong style=\"font-size:19px;letter-spacing:.1px\">QualityOps</strong><div style=\"margin-top:5px;font-size:12px;line-height:1.25\">{escape(subtitle)}</div></div>
  <div style=\"padding:28px 30px 26px\"><h1 style=\"margin:0 0 12px;font-size:24px;line-height:1.2;color:#193d49\">{escape(title)}</h1>
    <p style=\"margin:0 0 21px;font-size:16px;line-height:1.45;color:#203a43\">{escape(instruction)}</p>
    {status_html}
    <div style=\"margin:18px 0 20px;padding:12px 17px;background:#f4f7f8;border-left:3px solid #147d91;font-size:13px;line-height:1.5;color:#19333b\"><strong>{escape(panel_title)}</strong>{panel_html}</div>
    <a href=\"{escape(action_url, quote=True)}\" style=\"display:inline-block;padding:13px 18px;background:#116b7d;color:#ffffff;text-decoration:none;border-radius:8px;font-weight:700;font-size:16px\">{escape(action_label)}</a>
  </div>
  <div style=\"padding:14px 30px;background:#f7fafb;color:#71858c;font-size:12px;line-height:1.3\">{escape(footer)}</div>
</div></body></html>"""


def send_test_email(recipient: str, requested_by: str) -> None:
    """Synchronously verify SMTP configuration and delivery for an Admin."""
    ready, reason = smtp_readiness()
    if not ready:
        raise RuntimeError(reason or "SMTP configuration is incomplete")
    settings = _smtp_settings()
    smtp_circuit.check()
    portal_url = os.getenv("PORTAL_BASE_URL", "").rstrip("/") or "/"
    sent_at = models.now().strftime("%d %b %Y, %I:%M %p IST")
    message = EmailMessage()
    message["Subject"] = "[QualityOps] SMTP test email"
    message["From"] = f'{settings["from_name"]} <{settings["from_address"]}>'
    message["To"] = recipient.strip()
    message.set_content(
        "QualityOps SMTP test completed successfully.\n"
        f"Requested by: {requested_by}\nSent at: {sent_at}"
    )
    message.add_alternative(_html_email(
        "SMTP test successful",
        "Administration · Email delivery check",
        "This message confirms that QualityOps can connect to the configured SMTP service and deliver email.",
        status="Delivered",
        panel_title="Test details",
        panel_html=(
            f'<p style="margin:8px 0 0">Requested by: {escape(requested_by)}</p>'
            f'<p style="margin:4px 0 0">Sent at: {escape(sent_at)}</p>'
        ),
        action_label="Open QualityOps",
        action_url=portal_url,
        footer="This test was initiated manually from QualityOps Administration.",
    ), subtype="html")
    _send_message(message, settings)


def _legacy_html_email(notification: models.EmailNotification) -> str:
    """Bring pre-template outbox rows into the approved layout at send time.

    Queue records survive deployments.  Some rows already in Oracle can have
    no HTML body or an older visual design; retaining that stored HTML would
    make the notification system look inconsistent after the shared template
    is introduced.  Plain text remains the source of truth for those rows
    and is presented in the same single-panel QualityOps design.
    """
    body = (notification.body or "No additional details were recorded.").strip()
    action_url = ""
    detail_lines = []
    for line in body.splitlines():
        label, separator, value = line.partition(":")
        if separator and label.strip().lower() in {"open item", "open test repository", "review access"}:
            action_url = value.strip()
            continue
        detail_lines.append(line)
    portal_url = os.getenv("PORTAL_BASE_URL", "").rstrip("/")
    if action_url.startswith("/") and portal_url:
        action_url = f"{portal_url}{action_url}"
    if not action_url:
        action_url = portal_url or "/"
    detail_html = escape("\n".join(detail_lines)).replace("\n", "<br>")
    return _html_email(
        "QualityOps notification", "Workflow update",
        "Open the portal to review this notification and take any required action.",
        status=None, panel_title="Notification details",
        panel_html=f"<p style=\"margin:8px 0 0\">{detail_html}</p>",
        action_label="Open in QualityOps", action_url=action_url,
    )


def _recipient_key(action: models.ApprovalAction, recipient_email: str) -> tuple[str, str]:
    """Return a transaction-local key for the outbox's unique pair.

    An ``ApprovalAction`` normally has no database identity while the
    before-commit listener is assembling its notifications. An action-local
    token stays stable until flush. A Python memory address can be reused
    after a previous transaction, so it must not identify a new action.
    Once it has an ID, use that ID to recognise persisted outbox rows.
    """
    if action.id is not None:
        action_key = f"id:{action.id}"
    else:
        if not getattr(action, '_outbox_pending_key', None):
            action._outbox_pending_key = uuid4().hex
        action_key = f"pending:{action._outbox_pending_key}"
    return action_key, recipient_email.strip()


def _is_notification_already_queued(
    db: SASession, action: models.ApprovalAction, recipient_email: str, category: str,
) -> bool:
    """Protect the outbox's one-action/one-recipient invariant before flush.

    The unique constraint remains the final database safeguard.  This helper
    handles the expected duplicate paths *before* SQLAlchemy flushes: a
    repeated listener evaluation, duplicate users with the same mailbox, or
    an action which already has a durable outbox row after an earlier retry.
    It deliberately uses ``no_autoflush`` for the durable-row check, so the
    check itself cannot cause a pending duplicate to turn into a 500.
    """
    recipient_email = recipient_email.strip()
    key = _recipient_key(action, recipient_email)
    reserved = db.info.setdefault("email_notification_recipient_keys", set())
    if key in reserved:
        logger.info(
            "SMTP notification queue skipped category=%s recipient=%s approval_action_id=%s reason=duplicate_recipient",
            category, recipient_email, action.id,
        )
        return True

    # Include flushed rows remembered by the listener as well as current
    # pending rows.  The relationship comparison covers new parent actions;
    # the FK comparison covers already-flushed parent actions.
    candidates = list(db.info.get("email_notification_outbox", [])) + list(db.new)
    for notification in candidates:
        if not isinstance(notification, models.EmailNotification):
            continue
        same_parent = notification.approval_action is action
        if action.id is not None and notification.approval_action_id == action.id:
            same_parent = True
        if same_parent and (notification.recipient_email or "").strip() == recipient_email:
            reserved.add(key)
            logger.info(
                "SMTP notification queue skipped category=%s recipient=%s approval_action_id=%s reason=duplicate_recipient",
                category, recipient_email, action.id,
            )
            return True

    # A completed/retried request can encounter an action which already has
    # its notification stored.  Never enqueue that exact action-recipient
    # pair a second time.  This is also important after a rolling deployment
    # where an in-flight request may be evaluated by two application workers.
    if action.id is not None:
        with db.no_autoflush:
            existing = db.query(models.EmailNotification.id).filter(
                models.EmailNotification.approval_action_id == action.id,
                models.EmailNotification.recipient_email == recipient_email,
            ).first()
        if existing:
            reserved.add(key)
            logger.info(
                "SMTP notification queue skipped category=%s recipient=%s approval_action_id=%s reason=already_persisted",
                category, recipient_email, action.id,
            )
            return True

    reserved.add(key)
    return False


def _queue_email_notification(
    db: SASession, action: models.ApprovalAction, recipient_email: str, *,
    subject: str, body: str, html_body: str | None, category: str,
) -> bool:
    """Add an idempotent durable outbox row and report whether it was added."""
    recipient_email = recipient_email.strip()
    if not recipient_email or _is_notification_already_queued(db, action, recipient_email, category):
        return False
    db.add(models.EmailNotification(
        approval_action=action,
        recipient_email=recipient_email,
        subject=subject,
        body=body,
        html_body=html_body,
    ))
    return True


def queue_access_review_notifications(db: SASession, user: models.User, *, review_reason: str | None = None) -> int:
    """Queue one access-review email for each active Administrator.

    Account-access review is a real approval event but not a business-request
    workflow, so it deliberately uses its own `USER_ACCESS` action rather
    than pretending it belongs to a QA request.  The action also keeps the
    email outbox's mandatory foreign key and duplicate protection intact.
    Like workflow mail, this queues only when SMTP is enabled, preventing a
    surprise backlog from being sent weeks after a relay is configured.
    """
    if not _enabled():
        logger.info("SMTP access-review notification skipped user=%s reason=smtp_disabled", user.username)
        return 0
    admins = (
        db.query(models.User)
        .join(models.UserRole)
        .filter(
            models.User.is_active == True,  # noqa: E712
            models.UserRole.role == Role.ADMIN,
        )
        .all()
    )
    recipients = sorted({admin.email.strip().lower() for admin in admins if (admin.email or "").strip()})
    if not recipients:
        logger.warning("SMTP access-review notification skipped user=%s reason=no_active_admin_recipient", user.username)
        return 0

    department = user.primary_department or user.department or "Other"
    portal_url = os.getenv("PORTAL_BASE_URL", "").rstrip("/")
    path = "/admin"
    url = f"{portal_url}{path}" if portal_url else path
    subject = f"Access review required: {user.full_name} ({user.username})"
    reason_text = f"Reason: {review_reason}\n\n" if review_reason else ""
    reason_html = f"<p>Reason: {escape(review_reason)}</p>" if review_reason else ""
    body = (
        "QualityOps ACCESS REVIEW REQUIRED\n\n"
        "A newly provisioned LDAP account requires access review.\n\n"
        f"User: {user.full_name}\nUsername: {user.username}\n"
        f"Department: {department}\n"
        f"Current role(s): {format_role_labels(user.roles) or 'No portal role assigned'}\n\n"
        f"{reason_text}"
        "Review the account and assign the appropriate roles and workspace access.\n\n"
        f"Review access: {url}\n"
    )
    html_body = _html_email(
        "New LDAP access request", "Access review required",
        "Review this account and assign the appropriate roles and workspace access.",
        status="Access review pending", panel_title="Access request",
        panel_html=(
            f"<ul style=\"margin:8px 0 0;padding-left:20px\"><li>User: {escape(user.full_name)}</li>"
            f"<li>Username: {escape(user.username)}</li><li>Department: {escape(department)}</li>"
            f"<li>Current role(s): {escape(format_role_labels(user.roles) or 'No portal role assigned')}</li></ul>{reason_html}"
        ),
        action_label="Review in QualityOps", action_url=url,
        footer="This is an automated QualityOps access-management notification.",
    )
    action = models.ApprovalAction(
        entity_type="USER_ACCESS",
        entity_id=user.id,
        step_name="Access review",
        actor_id=user.id,
        actor_role=user.roles_csv,
        decision="Access review requested",
        comments=f"New LDAP account mapped to {department}." + (f" {review_reason}" if review_reason else ""),
    )
    db.add(action)
    queued_count = 0
    for email in recipients:
        if _queue_email_notification(
            db, action, email, subject=subject, body=body, html_body=html_body,
            category="access_review",
        ):
            queued_count += 1
            logger.info("SMTP notification queued category=access_review recipient=%s user=%s", email, user.username)
    return queued_count


def queue_department_access_review_notifications(db: SASession, user: models.User) -> int:
    """Notify department coordinators, or System Admins if none can receive mail.

    Workspace placement is chosen by the reviewer, so notify coordinators
    across that department's workspaces rather than the onboarding workspace.
    The caller commits these outbox entries with the department selection.
    """
    if not _enabled() or user.needs_department_selection or not user.needs_role_review:
        return 0
    department = user.primary_department or user.department
    assignments = (
        db.query(models.DepartmentCoordinatorAssignment)
        .join(models.DepartmentCoordinatorAssignment.department)
        .join(models.DepartmentCoordinatorAssignment.workspace)
        .join(models.DepartmentCoordinatorAssignment.user)
        .options(joinedload(models.DepartmentCoordinatorAssignment.user))
        .filter(
            models.Department.name == department,
            models.Department.is_active == True,
            models.QAWorkspace.is_active == True,
            models.DepartmentCoordinatorAssignment.is_active == True,
            models.User.is_active == True,
            models.User.id != user.id,
        ).all()
    )
    recipients: set[str] = set()
    for assignment in assignments:
        email = (assignment.user.email or '').strip().lower()
        if email:
            recipients.add(email)
    if not recipients:
        logger.info('SMTP department access-review escalated user=%s reason=no_active_coordinator_recipient', user.username)
        return queue_access_review_notifications(
            db, user,
            review_reason=(
                f'No active Department Coordinator with a notification email is available for {department or "the selected department"}. '
                'System Admin approval is required for this first-login access request.'
            ),
        )
    action = models.ApprovalAction(
        entity_type='USER_ACCESS', entity_id=user.id, step_name='Department access review',
        actor_id=user.id, actor_role=user.roles_csv, decision='Access review requested',
        comments=f'First-login portal and workspace access requested for {department}.',
    )
    db.add(action)
    url = os.getenv('PORTAL_BASE_URL', '').rstrip('/') + '/department-admin'
    name = user.full_name or user.username
    instruction = f'{name} ({user.username}) needs approval to access the QualityOps. Please review the request and provide the necessary access in the respective workspace.'
    count = 0
    for email in sorted(recipients):
        body = (
            f'QualityOps ACCESS APPROVAL REQUIRED\n\n{instruction}\n\n'
            f'Department: {department}\n'
            'Review Pending role reviews in Department Admin.\n'
            f'Review access: {url}\n'
        )
        html_body = _html_email(
            'Portal and workspace access approval', 'First-login access request', instruction,
            status='Access approval pending', panel_title='Access request',
            panel_html=(f'<p>User: {escape(name)} ({escape(user.username)})</p>'
                        f'<p>Department: {escape(department or "")}</p>'
                        '<p>Review Pending role reviews in Department Admin.</p>'),
            action_label='Review access request', action_url=url,
        )
        count += int(_queue_email_notification(
            db, action, email, subject=f'Access approval required: {name} ({user.username})',
            body=body, html_body=html_body, category='department_access_review',
        ))
    return count


def queue_test_cycle_assignment_notification(
    db: SASession,
    *,
    action: models.ApprovalAction,
    recipient: models.User,
    cycle: models.TestCycle,
    test_cases: list[models.TestCase],
) -> int:
    """Queue one actionable email for a runner's cycle assignment batch.

    Adding or assigning a batch of testcases must not create one mailbox item
    per testcase.  A single ApprovalAction anchors one durable outbox record
    per recipient, while the email lists the governed testcase IDs and opens
    the exact cycle.  The supplied action is marked as handled so the generic
    test-case workflow listener does not create a second, less useful digest
    for the same assignment.
    """
    references = list(dict.fromkeys(
        str(getattr(test_case, "test_case_key", None) or f"Testcase #{getattr(test_case, 'id', '—')}")
        for test_case in test_cases
    ))
    if not references:
        return 0
    if not _enabled():
        logger.info(
            "SMTP test-cycle assignment notification skipped cycle=%s recipient=%s reason=smtp_disabled",
            cycle.cycle_key, recipient.username,
        )
        return 0
    if not recipient.is_active:
        logger.warning(
            "SMTP test-cycle assignment notification skipped cycle=%s recipient=%s reason=inactive_user",
            cycle.cycle_key, recipient.username,
        )
        return 0
    if recipient.id == action.actor_id:
        logger.info(
            "SMTP test-cycle assignment notification skipped cycle=%s recipient=%s reason=actor_is_assignee",
            cycle.cycle_key, recipient.username,
        )
        return 0
    email = (recipient.email or "").strip()
    if not email:
        logger.warning(
            "SMTP test-cycle assignment notification skipped cycle=%s recipient=%s reason=missing_email",
            cycle.cycle_key, recipient.username,
        )
        return 0

    # The normal workflow listener sees these TEST_CASE audit actions in the
    # same commit. This dedicated assignment digest is the authoritative
    # notification for this action, so suppress its generic fallback.
    action._email_notifications_queued = True
    shown_references = references[:20]
    remaining = len(references) - len(shown_references)
    type_label = "Test Case" if len(references) == 1 else "Test Cases"
    portal_url = os.getenv("PORTAL_BASE_URL", "").rstrip("/")
    path = f"/test-execution?project={cycle.project_id}&cycle={cycle.id}"
    url = f"{portal_url}{path}" if portal_url else path
    subject = f"Action required: {len(references)} {type_label} assigned — {cycle.cycle_key}"
    item_lines = "\n".join(f"• {reference}" for reference in shown_references)
    if remaining:
        item_lines += f"\n• and {remaining} more"
    body = (
        "QualityOps ACTION REQUIRED\n\n"
        f"You have been assigned {len(references)} {type_label.lower()} in {cycle.cycle_key} — {cycle.name}. "
        "Open the test cycle to record execution results.\n\n"
        "Current status: Assigned to you\n\n"
        f"Test cases:\n{item_lines}\n\n"
        f"Open Test Cycle: {url}\n"
    )
    html_items = "".join(f"<li style=\"margin:4px 0\">{escape(reference)}</li>" for reference in shown_references)
    if remaining:
        html_items += f"<li style=\"margin:4px 0\">and {remaining} more</li>"
    html_body = _html_email(
        f"{len(references)} {type_label}",
        "Action required · Test cycle assignment",
        f"You have been assigned testcases in {cycle.cycle_key} — {cycle.name}. Open the cycle to record execution results.",
        status="Assigned to you",
        panel_title="Test cases",
        panel_html=f"<ul style=\"margin:8px 0 0;padding-left:20px\">{html_items}</ul>",
        action_label="Open Test Cycle",
        action_url=url,
    )
    if not _queue_email_notification(
        db, action, email, subject=subject, body=body, html_body=html_body,
        category="test_cycle_assignment",
    ):
        return 0
    logger.info(
        "SMTP notification queued category=test_cycle_assignment recipient=%s cycle=%s testcase_count=%s",
        email, cycle.cycle_key, len(references),
    )
    return 1


def _target(action: models.ApprovalAction, db: SASession):
    mapping = {
        "QA_REQUEST": models.QARequest, "FUNCTIONAL_REQUEST": models.FunctionalRequest,
        "SAST": models.SASTRequest, "DAST": models.DASTRequest,
        "PERFORMANCE": models.PerformanceRequest, "SUPPRESSION": models.SuppressionRequest,
        "SIGNOFF": models.QASignOff, "DEFECT": models.Defect,
        "TEST_PROJECT": models.TestProject, "TEST_CASE": models.TestCase, "TEST_CYCLE": models.TestCycle, "TEST_EXECUTION": models.TestExecution,
    }
    model = mapping.get(action.entity_type)
    return db.get(model, action.entity_id) if model else None


def _department(target) -> str | None:
    if not target:
        return None
    direct = getattr(target, "department", None)
    if direct:
        return direct
    project = getattr(target, "project", None)
    if project and project.department:
        return project.department
    for relationship in ("cycle", "test_case", "qa_request"):
        parent = getattr(target, relationship, None)
        if parent is not None:
            return _department(parent)
    return None


def _requester_user_ids(target) -> set[int]:
    """The person who must respond when work is returned or completed."""
    if not target:
        return set()
    ids = set()
    for field in (
        "requester_id", "created_by_id", "author_id", "submitted_by_id", "pending_requested_by_id",
    ):
        value = getattr(target, field, None)
        if value:
            ids.add(value)
    # A TestCase's requester is stored on its active draft version rather
    # than on the permanent testcase identity.
    draft = getattr(target, "current_draft_version", None)
    if draft:
        for field in ("author_id", "submitted_by_id"):
            value = getattr(draft, field, None)
            if value:
                ids.add(value)
    parent = getattr(target, "qa_request", None)
    if parent and parent.requester_id:
        ids.add(parent.requester_id)
    return ids


def _next_approver_roles(target) -> set[str]:
    status = str(getattr(target, "status", "") or "").upper()
    # Sign-off uses historical status names, but its first decision is a QA
    # Lead and its second is the QA Executive group—not the business SM/DH.
    if isinstance(target, models.QASignOff):
        if status == "SM_APPROVAL_PENDING":
            return {Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA}
        if status == "DEPT_HEAD_QA_APPROVAL_PENDING":
            return {Role.CHIEF_MANAGER_QA, Role.AGM_QA}
    if isinstance(target, models.TestCase):
        if status == "IN REVIEW":
            return {Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA}
        if status == "RECOMMENDATION PENDING":
            return {Role.QA_ENGINEER}
        if status in {"REVIEW COMPLETED", "QA LEAD APPROVAL PENDING"}:
            return {Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA}
    if isinstance(target, models.TestProject) and target.pending_is_active is not None:
        return {Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA}
    if isinstance(target, models.QARequest) and status not in {"DRAFT", "CANCELLED"}:
        application = getattr(target, "application_master", None)
        application_status = str(getattr(application, "status", "") or "").upper()
        if application_status == "PENDING_APP_OWNER":
            return {Role.APPLICATION_OWNER}
        if application_status == "PENDING_SM":
            return {Role.SM}
    if status == "SM_APPROVAL_PENDING":
        return {Role.SM}
    if status == "DEPARTMENT_HEAD_APPROVAL_PENDING":
        return {Role.DEPARTMENT_HEAD_CM, Role.DEPARTMENT_HEAD_AGM}
    if status in {
        "QA_LEAD_ASSIGNED", "READINESS_VERIFICATION", "QA_ACTIVITY_INITIATED",
        "PLANNING", "QA_COMPLETED", "QA_CHANGE_REVIEW", "QA_SIGNOFF_PENDING", "ENGINEER_ASSIGNED",
        "READINESS", "FEASIBILITY", "RESULT_ANALYSIS", "REPORT", "SIGNOFF_PENDING",
    }:
        return {Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA}
    if status in {"SECURITY_LEAD_ASSIGNED", "SECURITY_READINESS"}:
        return {Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA}
    if status in {
        "TESTER_ASSIGNED", "TEST_DESIGN", "EXECUTION_IN_PROGRESS", "RETESTING",
    }:
        return {Role.QA_ENGINEER}
    if status in {
        "CONFIGURATION", "SCANNING", "FINDING_VALIDATION", "REMEDIATION",
        "ASSIGNED_TO_LEAD", "RESCAN", "SECURITY_COMPLETE", "REPORT_READY",
        "SECURITY_TEAM_VERIFICATION",
    }:
        return {Role.SECURITY_ANALYST}
    if status in {"ENVIRONMENT_SETUP", "SCRIPT_DEVELOPMENT", "BASELINE", "LOAD_TEST_EXECUTION"}:
        return {Role.QA_ENGINEER}
    if status in {"QA_LEAD_APPROVAL_PENDING", "REVIEW_COMPLETED"}:
        return {Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA}
    return set()


def _role_user_ids(db: SASession, roles: set[str], department: str | None) -> set[int]:
    if not roles:
        return set()
    users = db.query(models.User).join(models.UserRole).options(
        joinedload(models.User.department_assignments)
    ).filter(models.User.is_active == True, models.UserRole.role.in_(roles)).all()  # noqa: E712
    return {user.id for user in users if not department or user.has_department(department)}


def _target_workspace_id(target) -> int | None:
    """Find the persisted Workspace for gateway, child and test entities."""
    origin = getattr(target, "origin_workspace_id", None)
    if origin:
        return origin
    cycle = getattr(target, "cycle", None)
    if cycle is not None:
        return _target_workspace_id(cycle)
    direct = getattr(target, "qa_workspace_id", None)
    if direct:
        return direct
    qa_request = getattr(target, "qa_request", None)
    if qa_request and getattr(qa_request, "qa_workspace_id", None):
        return qa_request.qa_workspace_id
    project = getattr(target, "project", None)
    if project and getattr(project, "qa_workspace_id", None):
        return project.qa_workspace_id
    for relationship in ("sast_request", "dast_request"):
        parent = getattr(target, relationship, None)
        if parent is not None:
            return _target_workspace_id(parent)
    test_case = getattr(target, "test_case", None)
    if test_case and getattr(test_case, "project", None):
        return _target_workspace_id(test_case)
    return None


def _workspace_role_user_ids(db: SASession, workspace_id: int, roles: set[str]) -> set[int]:
    """Users with a requested role who can act in this workspace.

    Eligibility is based on the same selectable-workspace resolver used by
    request authorization, rather than only a direct membership row. This is
    important for a Parent Workspace Admin: their parent grant deliberately
    does not create duplicate memberships for every child workspace.
    """
    from .workspace_service import selectable_workspace_ids

    users = db.query(models.User).join(
        models.UserRole, models.UserRole.user_id == models.User.id,
    ).options(
        selectinload(models.User.role_assignments),
        selectinload(models.User.qa_workspace_memberships).joinedload(
            models.QAWorkspaceMember.workspace,
        ),
        selectinload(models.User.department_coordinator_assignments).joinedload(
            models.DepartmentCoordinatorAssignment.workspace,
        ),
        selectinload(models.User.department_coordinator_assignments).joinedload(
            models.DepartmentCoordinatorAssignment.department,
        ),
    ).filter(
        models.User.is_active == True,  # noqa: E712
        models.UserRole.role.in_(roles),
    ).distinct().all()
    return {user.id for user in users if workspace_id in selectable_workspace_ids(db, user)}


def _user_ids(value) -> set[int]:
    """Return a safe, de-duplicated set from a persisted assignee field.

    Functional and Performance keep their tester assignment as a compact
    comma-separated value for compatibility with the existing schema.  Do
    not let a malformed legacy value prevent the rest of the group from being
    notified; only valid positive integer IDs are meaningful here.
    """
    if value is None:
        return set()
    if isinstance(value, str):
        values = value.split(",")
    elif isinstance(value, (tuple, list, set)):
        values = value
    else:
        values = [value]
    ids = set()
    for item in values:
        try:
            user_id = int(item)
        except (TypeError, ValueError):
            continue
        if user_id > 0:
            ids.add(user_id)
    return ids


def _assigned_user_route(target) -> NotificationRoute | None:
    """Return the named current owner when the workflow has one.

    A role group owns an item only while no person has been selected.  Once a
    QA Lead assigns an analyst/tester (or a reviewer/defect assignee is
    explicitly recorded), sending the next action-required email to the
    whole group is both noisy and ambiguous.  This resolver is intentionally
    stage-aware: a historical assignment does not override a later stage
    that is back with the requester or QA Lead group.
    """
    status = str(getattr(target, "status", "") or "").upper()

    if isinstance(target, models.TestExecution):
        if target.cycle and target.cycle.status == "In Progress" and status in {"NOT EXECUTED", "FAIL", "BLOCKED"}:
            return NotificationRoute(_user_ids(target.assigned_to_id), "Assigned QA Tester", True,
                "Review this outstanding testcase execution and its linked defects.")
        return None

    if isinstance(target, models.TestCase) and status == "IN REVIEW":
        reviewer = getattr(target, "assigned_reviewer_id", None)
        if reviewer:
            return NotificationRoute({reviewer}, "Assigned Reviewer", True,
                "Your testcase review is required. Open the testcase to record your decision.")

    if isinstance(target, models.FunctionalRequest) and status in {
        "TESTER_ASSIGNED", "TEST_DESIGN", "EXECUTION_IN_PROGRESS", "RETESTING",
        "QA_COMPLETED", "QA_CHANGE_REVIEW",
    }:
        recipients = _user_ids(target.assigned_tester_ids)
        if recipients:
            return NotificationRoute(
                recipients, "Assigned QA Tester", True,
                "You have been assigned QA work on this request. Open the record to continue the workflow.",
            )

    if isinstance(target, models.PerformanceRequest) and status in {
        "ENVIRONMENT_SETUP", "SCRIPT_DEVELOPMENT", "BASELINE",
        "LOAD_TEST_EXECUTION",
    }:
        recipients = _user_ids(target.assigned_tester_ids)
        if recipients:
            return NotificationRoute(
                recipients, "Assigned QA Tester", True,
                "You have been assigned performance-testing work. Open the record to continue the workflow.",
            )

    if isinstance(target, (models.SASTRequest, models.DASTRequest)) and status in {
        "CONFIGURATION", "SCANNING", "FINDING_VALIDATION", "REMEDIATION",
        "ASSIGNED_TO_LEAD", "RESCAN", "SECURITY_COMPLETE", "REPORT_READY",
    }:
        recipients = _user_ids(target.security_analyst_id)
        if recipients:
            return NotificationRoute(
                recipients, "Assigned Security Analyst", True,
                "You have been assigned security-testing work. Open the record to continue the workflow.",
            )

    return None


def _security_remediation_route(db: SASession, target) -> NotificationRoute | None:
    """Keep target remediation with its input owner while QA scans other scope."""
    if not isinstance(target, (models.SASTRequest, models.DASTRequest)) or not target.id:
        return None
    if target.status not in {
        "CONFIGURATION", "SCANNING", "FINDING_VALIDATION", "REMEDIATION",
        "ASSIGNED_TO_REQUESTER", "WAITING_FOR_FIX", "ASSIGNED_TO_LEAD", "RESCAN",
    }:
        return None
    from .security_scan_state import repository_states, target_states
    kind = "SAST" if isinstance(target, models.SASTRequest) else "DAST"
    resolve_states = repository_states if kind == "SAST" else target_states
    scans = db.query(models.SecurityScanResult).filter_by(request_type=kind, request_id=target.id).order_by(
        models.SecurityScanResult.imported_at.desc(), models.SecurityScanResult.id.desc()).all()
    states = {row["state"] for row in resolve_states(target, scans)}
    if not states & {"WAITING_FOR_FIX", "STALE"}:
        return None
    delegation = target.active_delegation
    input_ids = _user_ids(delegation.assigned_to_id if delegation else target.requester_id)
    input_label = "Assigned Input Owner" if delegation else "Requester"
    recipients = set(input_ids)
    if states & {"NOT_SCANNED", "AWAITING_VALIDATION", "READY_FOR_RESCAN", "STALE"}:
        analyst_ids = _user_ids(target.security_analyst_id)
        if not analyst_ids:
            workspace = _target_workspace_id(target)
            analyst_ids = (_workspace_role_user_ids(db, workspace, {Role.SECURITY_ANALYST}) if workspace
                           else _role_user_ids(db, {Role.SECURITY_ANALYST}, _department(target)))
        recipients.update(analyst_ids)
        return NotificationRoute(
            recipients, f"{input_label} / Security Analyst", True,
            "Submit fixes for targets awaiting remediation or continue scanning and reviewing the remaining targets.",
            frozenset(input_ids),
        )
    return NotificationRoute(
        recipients, input_label, True,
        "Submit the fix references for targets awaiting remediation so QA can rescan them.",
        frozenset(input_ids),
    )


_DEFECT_QA_ROUTING_STATUSES = {"NEW"}
_DEFECT_OWNER_STATUSES = {"TRIAGED", "ASSIGNED", "IN PROGRESS", "REOPENED"}
_DEFECT_RETEST_STATUSES = {"RESOLVED", "RETEST", "READY FOR QA", "QA TESTING", "NOT A DEFECT REVIEW"}
_DEFECT_PAUSED_STATUSES = {"DEFERRED"}
_DEFECT_OUTCOME_STATUSES = {"REJECTED", "DUPLICATE", "NOT A DEFECT", "CHANGE REQUEST RAISED", "CLOSED"}


def _defect_notification_route(db: SASession, target: models.Defect) -> NotificationRoute | None:
    """Route every governed Defect stage to its next responsible audience.

    Defect status labels do not consistently contain generic workflow verbs
    (for example ``Triaged``, ``In Progress`` and ``Retest``), so they need an
    explicit contract instead of the generic keyword-based routing used by
    the other request workflows. Newly raised defects notify their reporter
    and named assignee; selected CC users are queued separately. Outcome
    messages go to both the defect reporter and the linked QA Request's requester. Subsequent workflow
    messages exclude the actor; creation also confirms receipt to the reporter.
    """
    if getattr(target, 'record_type', None) == 'Observation':
        return NotificationRoute(_user_ids(target.reporter_id), 'Observation Reporter', False,
            'The observation was recorded or reviewed. Open the record for the review decision and discussion.')
    status = str(getattr(target, "status", "") or "").upper()
    if status in _DEFECT_QA_ROUTING_STATUSES:
        recipients = _user_ids(target.reporter_id) | _user_ids(target.assignee_id)
        if recipients:
            return NotificationRoute(
                recipients, "Defect Participants", False,
                "A defect has been raised. Open the record to view its details and assignment.",
            )
        return None
    if status in _DEFECT_OWNER_STATUSES:
        recipients = _user_ids(getattr(target, "assignee_id", None))
        if recipients:
            return NotificationRoute(
                recipients, "Assigned Defect Owner", True,
                "You own the next action for this defect. Open the record to continue the workflow.",
            )
        return None
    if status in _DEFECT_RETEST_STATUSES:
        recipients = _user_ids(getattr(target, "retest_tester_id", None))
        if not recipients:
            recipients.update(_user_ids(getattr(target, "execution_assignee_id", None)))
        if recipients:
            return NotificationRoute(
                recipients, "Assigned QA Tester", True,
                "This defect is ready for retest activity or a retest decision.",
            )
        return None
    if status in {"BUSINESS ACCEPTANCE", "READY FOR RELEASE", "PRODUCTION VERIFICATION"}:
        field = "business_owner_id" if status == "BUSINESS ACCEPTANCE" else "release_owner_id"
        return NotificationRoute(_user_ids(getattr(target, field, None)),
            "Business Owner" if field == "business_owner_id" else "Release Owner", True,
            "You own the next verification or release action. Open the defect to continue.")
    if status in _DEFECT_PAUSED_STATUSES:
        recipients = _user_ids(getattr(target, "assignee_id", None))
        recipients.update(_user_ids(getattr(target, "reporter_id", None)))
        parent = getattr(target, "qa_request", None)
        recipients.update(_user_ids(getattr(parent, "requester_id", None)))
        if recipients:
            return NotificationRoute(
                recipients, "Defect Stakeholder", False,
                "This defect has been deferred. Open the record for its target release and expected resolution date.",
            )
        return None
    if status in _DEFECT_OUTCOME_STATUSES:
        recipients = _user_ids(getattr(target, "reporter_id", None))
        parent = getattr(target, "qa_request", None)
        recipients.update(_user_ids(getattr(parent, "requester_id", None)))
        if recipients:
            return NotificationRoute(
                recipients, "Defect Stakeholder", False,
                "This defect has reached a workflow outcome. Open the record for the decision details.",
            )
    return None


def _role_label(roles: set[str]) -> str:
    labels = {
        Role.SM: "SM",
        Role.DEPARTMENT_HEAD_CM: "Department Head",
        Role.DEPARTMENT_HEAD_AGM: "Department Head",
        Role.APPLICATION_OWNER: "Application Owner",
        Role.QA_LEAD: "QA Lead",
        Role.CHIEF_MANAGER_QA: "QA Lead Group",
        Role.AGM_QA: "QA Lead Group",
        Role.SECURITY_ANALYST: "Security Team",
        Role.QA_ENGINEER: "QA Team",
    }
    for role in roles:
        if role in labels:
            return labels[role]
    return "QualityOps user"


def _workflow_departments(target) -> list[str]:
    """Departments whose role-holders own the current workflow action."""
    if (isinstance(target, models.SuppressionRequest)
            and str(target.status).upper() == "DEPARTMENT_HEAD_APPROVAL_PENDING"):
        pending = [row.department_name for row in target.department_approvals
                   if row.decision == "Pending" and row.department_name]
        return pending or ([target.department] if target.department else [])
    department = _department(target)
    return [department] if department else []


def _is_workflow_transition(action: models.ApprovalAction) -> bool:
    """Ignore audit-only actions such as document uploads while an item waits.

    Workflow routing is based on the target's final status at commit time.
    Without this guard, an evidence upload during SM approval would send a
    second, misleading SM reminder even though no workflow stage changed.
    """
    if action.step_name in {'Traceability', 'Defect Traceability', 'Test Cycle Preview', 'Request Preview'}:
        return False
    if str(action.step_name or "").startswith("Security obstacle #") and action.entity_type in {"SAST", "DAST"}:
        return True
    # Defects have an explicit state graph. Several legitimate stage names
    # contain none of the generic action keywords below, so use the recorded
    # state change as the authoritative signal. This covers creation and
    # reassignment too, while link/edit/evidence audit rows have no state
    # change and remain silent.
    if action.entity_type == "DEFECT" and action.new_state \
            and action.previous_state != action.new_state:
        return True
    if action.entity_type == "TEST_CYCLE" and action.decision == "Created":
        return True
    if action.entity_type == "TEST_CYCLE" and action.new_state and action.previous_state != action.new_state:
        return True
    decision = (action.decision or "").strip().lower()
    # SAST/DAST have several legitimate hand-off labels that contain none of
    # the generic verbs below (Finding Validation, Awaiting Fix, Rescanning,
    # Report Ready, and Started).  Treat the request module's explicit audit
    # decisions as workflow events so every resting stage is evaluated by the
    # mail router.  Audit-only document/evidence actions use different labels
    # and remain silent.
    if action.entity_type in {"SAST", "DAST"} and decision in {
        "submitted", "pending", "approved", "returned", "rejected",
        "resubmitted", "reopened", "started", "passed", "failed",
        "security analyst assigned", "security analyst reassigned",
        "ssc results imported / scanning started",
        "rescan imported / scanning started", "scan marked complete",
        "finding validation", "assigned to requester", "awaiting fix",
        "fix submitted", "rescanning", "report ready", "closed",
    }:
        return True
    return any(word in decision for word in (
        "submit", "pending", "resubmit", "reopen", "approv", "recommend",
        "return", "reject", "fail", "accept", "clear", "issue", "complete",
        "close", "cancel", "change", "request", "assign",
    ))


def _notification_route(db, action, target):
    route = _unfiltered_notification_route(db, action, target)
    if not route or not target:
        return route
    if getattr(target, "is_deleted", False):
        return None
    from .workspace_service import selectable_workspace_ids, inherited_workspace_access_mode
    from .workflow_authority import admin_department_allowed, is_system_admin
    workspace = _target_workspace_id(target)
    department = _department(target)
    workflow_departments = _workflow_departments(target)
    roles = _next_approver_roles(target)
    if str(action.step_name or "").startswith("Security obstacle #") and action.entity_type in {"SAST", "DAST"}:
        # Scoped routes already enforce each obstacle's independent owner.
        roles = set()
    application_name_review = roles == {Role.APPLICATION_OWNER}
    department_scoped = bool(roles & {Role.SM, Role.DEPARTMENT_HEAD_CM,
                                     Role.DEPARTMENT_HEAD_AGM})
    recipients = set()
    for uid in route.recipient_ids:
        user = db.get(models.User, uid)
        if not user or not user.is_active:
            continue
        if workspace and workspace not in selectable_workspace_ids(db, user):
            continue
        if route.action_required:
            if application_name_review:
                from .application_approval import can_review_application_in_workspace
                if not can_review_application_in_workspace(db, user, workspace):
                    continue
            # Organisation-wide read-only profiles may inspect workflow data,
            # but cannot perform its next action even when the same account
            # also holds the nominal approver role.
            if Role.VIEW_ONLY in user.roles or Role.SCALE_6_PLUS in user.roles:
                continue
            if workspace and inherited_workspace_access_mode(db, user, workspace) == 'PARENT_VIEWER':
                continue
            if isinstance(target, models.TestCycle):
                if not set(user.roles).intersection({
                    Role.QA_ENGINEER, Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA,
                }):
                    continue
            if isinstance(target, models.TestExecution) and Role.QA_ENGINEER not in user.roles:
                continue
            if roles and uid not in route.requester_input_ids and not set(user.roles).intersection(roles):
                continue
            # The SM who approved the first stage cannot receive (or perform)
            # the Department Head stage merely because that person also holds
            # a Department Head role. Keep mail routing identical to the
            # pending queue and decision endpoint maker-checker rule.
            if (
                isinstance(target, models.SuppressionRequest)
                and str(target.status or "").upper() == "DEPARTMENT_HEAD_APPROVAL_PENDING"
                and uid == target.sm_id
                and not is_system_admin(user)
            ):
                continue
            action_department = department
            if isinstance(target, models.Defect) and uid == target.assignee_id:
                action_department = target.assigned_team or department
            if isinstance(target, models.Defect) and workspace:
                from .defect_assignment import assignment_error
                status = target.status.upper()
                field = ('assignee_id' if status in _DEFECT_OWNER_STATUSES else
                         'retest_tester_id' if status in _DEFECT_RETEST_STATUSES else
                         'business_owner_id' if status == 'BUSINESS ACCEPTANCE' else
                         'release_owner_id' if status in {'READY FOR RELEASE', 'PRODUCTION VERIFICATION'} else None)
                if field and assignment_error(db, target, user, field, target.assigned_team):
                    continue
            if workflow_departments and roles & {Role.DEPARTMENT_HEAD_CM, Role.DEPARTMENT_HEAD_AGM}:
                action_department = next(
                    (item for item in workflow_departments if user.has_department(item)),
                    workflow_departments[0],
                )
            if not application_name_review and not admin_department_allowed(user, action_department):
                continue
            if department_scoped and (
                not workflow_departments
                or not any(user.has_department(item) for item in workflow_departments)
            ):
                continue
            application = getattr(target, 'application_master', None)
            if application_name_review and application and uid == application.requested_by_id:
                continue
            if department_scoped and uid in _requester_user_ids(target):
                continue
        recipients.add(uid)
    return NotificationRoute(recipients, route.recipient_label, route.action_required, route.instruction,
                             route.requester_input_ids)


def _unfiltered_notification_route(db: SASession, action: models.ApprovalAction, target) -> NotificationRoute | None:
    """Route each workflow transition to its *next* responsible party.

    This deliberately does not copy every stakeholder on every message.
    For example, after a requester raises a request only the SM receives the
    action-required mail; after the SM approves it only the Department Head
    receives the next one. Returned work goes to the requester. This mirrors
    the Pending Approvals queue and prevents duplicate/noisy notifications.
    """
    reference = _portal_reference(action, target)
    if not target:
        logger.warning(
            "SMTP workflow notification skipped reference=%s entity_type=%s entity_id=%s reason=target_not_found",
            reference, action.entity_type, action.entity_id,
        )
        return None
    if not _is_workflow_transition(action):
        logger.info(
            "SMTP workflow notification skipped reference=%s status=%s decision=%s reason=non_workflow_action",
            reference, getattr(target, "status", None), action.decision or "",
        )
        return None

    if (isinstance(target, models.QARequest) and target.status == "DRAFT"
            and target.application_master_status == "REJECTED"
            and action.step_name in {"Application Name (Application Owner)", "Application Name (SM)"}
            and action.decision == "Rejected"):
        return NotificationRoute(
            _requester_user_ids(target), "Requester", True,
            "The application name was rejected and this QA request is back in Draft. "
            "Choose an available application or explicitly resubmit the name with a reason for reconsideration.",
        )

    if isinstance(target, models.Defect):
        route = _defect_notification_route(db, target)
        if route:
            logger.info(
                "SMTP defect route evaluated reference=%s status=%s recipient=%s eligible_recipient_count=%s",
                reference, target.status, route.recipient_label, len(route.recipient_ids),
            )
            return route
        logger.warning(
            "SMTP defect notification skipped reference=%s status=%s reason=no_eligible_recipient",
            reference, target.status,
        )
        return None

    if isinstance(target, models.TestCycle):
        if target.status in {"Completed", "Cancelled"}:
            return NotificationRoute(_user_ids(target.owner_id) | _requester_user_ids(target),
                "Cycle Stakeholder", False, "The test cycle has reached an outcome. Review its results and history.")
        return NotificationRoute(_user_ids(target.owner_id), "Cycle Owner", True,
            "You own this test cycle. Review its current status and continue the lifecycle.")

    from .security_obstacles import notification_route as obstacle_notification_route
    assigned_route = obstacle_notification_route(db, action, target) or _security_remediation_route(db, target) or _assigned_user_route(target)
    if assigned_route:
        logger.info(
            "SMTP workflow route evaluated reference=%s status=%s owner=individual eligible_recipient_count=%s",
            reference, getattr(target, "status", None), len(assigned_route.recipient_ids),
        )
        return assigned_route

    roles = _next_approver_roles(target)
    if roles:
        department = _department(target)
        workflow_departments = _workflow_departments(target)
        # Resolve workspace membership first. The shared route filter then
        # applies department and workflow authority before anything is queued.
        workspace_id = _target_workspace_id(target)
        recipients = (
            _workspace_role_user_ids(db, workspace_id, roles)
            if workspace_id else _role_user_ids(db, roles, None)
        )
        from .workflow_authority import admin_department_allowed
        recipients = {recipient_id for recipient_id in recipients
                      if (recipient := db.get(models.User, recipient_id)) is not None
                      and (roles == {Role.APPLICATION_OWNER} or not workflow_departments or any(
                          admin_department_allowed(recipient, item) for item in workflow_departments
                      ))}
        logger.info(
            "SMTP workflow route evaluated reference=%s status=%s owner=group roles=%s request_department=%s eligible_recipient_count=%s",
            reference, getattr(target, "status", None), ",".join(sorted(roles)), department or "<any>", len(recipients),
        )
        if recipients:
            label = _role_label(roles)
            return NotificationRoute(
                recipients, label, True,
                f"Your {label} review is required before this workflow can continue.",
            )
        logger.warning(
            "SMTP workflow notification skipped reference=%s status=%s reason=no_active_recipient_for_role roles=%s department=%s",
            reference, getattr(target, "status", None), ",".join(sorted(roles)), department or "<any>",
        )

    status = str(getattr(target, "status", "") or "").upper()
    requester_ids = _requester_user_ids(target)
    if not requester_ids:
        logger.info(
            "SMTP workflow notification skipped reference=%s status=%s reason=no_recipient_route",
            reference, status,
        )
        return None
    if status.startswith("RETURNED") or status in {"SM_REJECTED", "ASSIGNED_TO_REQUESTER", "WAITING_FOR_FIX", "REQUESTER_VERIFICATION"}:
        return NotificationRoute(
            requester_ids, "Requester", True,
            "This item needs your review or update before the workflow can continue.",
        )
    if status in {"REJECTED", "DEPARTMENT_HEAD_REJECTED", "DONE", "ISSUED", "CLOSED", "CANCELLED"}:
        return NotificationRoute(
            requester_ids, "Requester", False,
            "The workflow has reached an outcome. Open the record for the full details.",
        )
    return None


def _route(action: models.ApprovalAction) -> str:
    routes = {
        "QA_REQUEST": "/qa-requests", "FUNCTIONAL_REQUEST": "/functional-requests",
        "SAST": "/sast", "DAST": "/dast", "PERFORMANCE": "/performance",
        "SUPPRESSION": "/suppression", "SIGNOFF": "/signoff", "DEFECT": "/defects",
        "TEST_PROJECT": "/test-projects", "TEST_CASE": "/test-repository", "TEST_CYCLE": "/test-execution", "TEST_EXECUTION": "/test-execution",
    }
    return routes.get(action.entity_type, "/approvals")


def _portal_reference(action: models.ApprovalAction, target) -> str:
    """Return the business ID users see in the portal, never a database key."""
    if target:
        for field in (
            "request_id", "suppression_id", "certificate_id", "defect_key",
            "project_key", "test_case_key", "cycle_key",
        ):
            value = getattr(target, field, None)
            if value:
                return str(value)
    # This fallback is intentionally descriptive rather than presenting the
    # internal primary key as a user-facing record identifier.
    return action.entity_type.replace("_", " ").title()


def _portal_link(action: models.ApprovalAction, reference: str) -> str:
    """Link to the exact portal record, including when its list is paginated."""
    route = _route(action)
    if route == "/approvals":
        return route
    if action.entity_type == "TEST_CYCLE":
        return f"{route}?cycle={action.entity_id}"
    if action.entity_type == "TEST_EXECUTION":
        return f"{route}?execution={action.entity_id}"
    return f"{route}?open={quote(reference, safe='')}&openId={action.entity_id}"


def queue_activity_mentions(db: SASession, action: models.ApprovalAction,
                            author: models.User, recipients: list[models.User]) -> int:
    """Queue alongside the immutable comment; the commit listener delivers it."""
    if not _enabled() or not recipients:
        return 0
    target = _target(action, db)
    reference = _portal_reference(action, target)
    link = os.getenv("PORTAL_BASE_URL", "").rstrip("/") + _portal_link(action, reference)
    actor = author.full_name or author.username
    subject = f"{actor} mentioned you in Activity: {reference}"
    body = f"{actor} mentioned you in a comment on {reference}.\n\n{action.comments or ''}\n\nOpen record: {link}"
    html_body = _html_email(
        "You were mentioned in Activity", reference,
        f"{actor} mentioned you in a comment. Open the record to view Activity and reply.",
        status=None, panel_title="Comment",
        panel_html='<div style="white-space:pre-wrap;overflow-wrap:anywhere">'
                   + escape(action.comments or "") + '</div>',
        action_label="Open record", action_url=link,
    )
    return sum(int(_queue_email_notification(
        db, action, email, subject=subject, body=body, html_body=html_body,
        category="activity_mention",
    )) for email in sorted({user.email.strip().lower() for user in recipients}))


def _status_label(value) -> str:
    """Make stored status codes readable without degrading acronyms (SM/QA)."""
    words = str(value or "—").replace("_", " ").split()
    acronyms = {"SM", "QA", "SAST", "DAST", "COE", "AGM"}
    return " ".join(word if word.upper() in acronyms else word.title() for word in words)


def _queue_for_action(db: SASession, action: models.ApprovalAction) -> int:
    if action.step_name in {'Test Cycle Preview', 'Request Preview'}:
        # Reviewing a request records traceability without a workflow handoff.
        return 0
    # Before SMTP is deliberately enabled, do not accumulate weeks of stale
    # workflow mail that would surprise users on the first activation.
    if not _enabled():
        logger.info(
            "SMTP workflow notification skipped entity_type=%s entity_id=%s reason=smtp_disabled",
            action.entity_type, action.entity_id,
        )
        return 0
    if getattr(action, "_email_notifications_queued", False):
        logger.info(
            "SMTP workflow notification skipped entity_type=%s entity_id=%s reason=already_evaluated",
            action.entity_type, action.entity_id,
        )
        return 0
    action._email_notifications_queued = True
    target = _target(action, db)
    logger.info(
        "SMTP workflow action evaluating entity_type=%s entity_id=%s step=%s decision=%s target_status=%s",
        action.entity_type, action.entity_id, action.step_name or "<none>", action.decision or "<none>",
        getattr(target, "status", None) if target else "<target_not_found>",
    )
    route = _notification_route(db, action, target)
    defect_creation = isinstance(target, models.Defect) and action.decision == 'Created'
    queued_count = _queue_notification_route(db, action, target, route, include_actor=defect_creation) if route else 0
    if isinstance(target, models.Defect) and (_is_workflow_transition(action) or action.decision in {'CC Updated', 'Updated', 'Commented'}):
        from .defect_cc import notification_ids
        record_label = 'observation' if getattr(target, 'record_type', None) == 'Observation' else 'defect'
        cc_route = NotificationRoute(notification_ids(db, target), 'CC', False,
                                     f'You are following this {record_label} in CC. This update is for your information.')
        queued_count += _queue_notification_route(db, action, target, cc_route, include_actor=defect_creation)
    return queued_count


def _queue_notification_route(db, action, target, route, *, include_actor=False):
    """Queue the working owner first, then passive CC; outbox deduplicates both."""
    reference = _portal_reference(action, target)
    # Raising a defect must also confirm receipt to its requester/reporter.
    # Other workflow notifications continue to exclude the acting user.
    recipient_ids = route.recipient_ids if include_actor else route.recipient_ids - {action.actor_id}
    if not recipient_ids:
        logger.info(
            "SMTP workflow notification skipped reference=%s reason=%s actor_id=%s",
            reference, "no_eligible_recipient" if include_actor else "no_eligible_recipient_other_than_actor", action.actor_id,
        )
        return 0
    users = db.query(models.User).filter(models.User.id.in_(recipient_ids), models.User.is_active == True).all()  # noqa: E712
    portal_url = os.getenv("PORTAL_BASE_URL", "").rstrip("/")
    path = _portal_link(action, reference)
    url = f"{portal_url}{path}" if portal_url else path
    status = _status_label(getattr(target, "status", None))
    type_label = action.entity_type.replace("_", " ").title()
    if getattr(target, 'record_type', None) == 'Observation':
        type_label = 'Observation'
    subject = f"{'Action required' if route.action_required else 'Workflow update'}: {reference} — {route.recipient_label}"
    body = (
        f"QualityOps {'ACTION REQUIRED' if route.action_required else 'WORKFLOW UPDATE'}\n\n"
        f"{route.instruction}\n\n"
        f"Record: {reference}\nType: {type_label}\nCurrent status: {status}\n"
        f"Latest action: {action.step_name or 'Workflow'} — {action.decision or 'Updated'}\n"
        f"Comments: {action.comments or 'No comments provided.'}\n\n"
        f"Open item: {url}\n"
    )
    html_body = _html_email(
        reference, 'Action required' if route.action_required else 'Workflow update', route.instruction,
        status=status, panel_title="Workflow details",
        panel_html=(
            f"<ul style=\"margin:8px 0 0;padding-left:20px\"><li>Type: {escape(type_label)}</li>"
            f"<li>Latest action: {escape(action.step_name or 'Workflow')} — {escape(action.decision or 'Updated')}</li>"
            f"<li>Comments: {escape(action.comments or 'No comments provided.').replace(chr(10), '<br>')}</li></ul>"
        ),
        action_label="Open in QualityOps", action_url=url,
    )
    queued_count = 0
    deliverable_recipient_count = 0
    missing_email_users = []
    for user in users:
        email = (user.email or "").strip()
        if email:
            deliverable_recipient_count += 1
            if _queue_email_notification(
                db, action, email, subject=subject, body=body, html_body=html_body,
                category="workflow",
            ):
                queued_count += 1
                logger.info("SMTP notification queued category=workflow recipient=%s reference=%s action=%s", email, reference, action.decision or "Updated")
        else:
            missing_email_users.append(user.username)
    if missing_email_users:
        logger.warning(
            "SMTP workflow notification recipient skipped reference=%s reason=missing_email users=%s",
            reference, ",".join(missing_email_users),
        )
    if not queued_count:
        if deliverable_recipient_count:
            logger.info(
                "SMTP workflow notification not queued reference=%s reason=all_deliverable_recipients_already_queued resolved_recipient_count=%s",
                reference, len(recipient_ids),
            )
        else:
            logger.warning(
                "SMTP workflow notification not queued reference=%s reason=no_deliverable_recipient resolved_recipient_count=%s",
                reference, len(recipient_ids),
            )
    return queued_count


def _queue_test_case_digests(db: SASession, actions: list[models.ApprovalAction]) -> int:
    """Create one summary email per recipient/stage for a test-case batch.

    Test cases are routinely submitted, recommended, or approved in bulk.
    Sending a separate email for every row turns a useful notification into
    mailbox noise, so all records from the same transaction and workflow
    checkpoint are presented as one actionable summary instead.
    """
    if actions and not _enabled():
        logger.info("SMTP test-case digest skipped action_count=%s reason=smtp_disabled", len(actions))
        return 0
    groups: dict[tuple[int, str, bool, str], list[tuple[models.ApprovalAction, object, NotificationRoute]]] = {}
    for action in actions:
        if getattr(action, "_email_notifications_queued", False):
            continue
        action._email_notifications_queued = True
        target = _target(action, db)
        route = _notification_route(db, action, target)
        if not route:
            continue
        status = _status_label(getattr(target, "status", None))
        for recipient_id in route.recipient_ids - {action.actor_id}:
            key = (recipient_id, route.recipient_label, route.action_required, status)
            groups.setdefault(key, []).append((action, target, route))

    portal_url = os.getenv("PORTAL_BASE_URL", "").rstrip("/")
    queued_count = 0
    for (recipient_id, label, action_required, status), entries in groups.items():
        user = db.get(models.User, recipient_id)
        email = (user.email or "").strip() if user else ""
        if not email:
            logger.warning(
                "SMTP test-case digest recipient skipped recipient_id=%s reason=missing_or_inactive_email",
                recipient_id,
            )
            continue
        first_action, _, route = entries[0]
        references = list(dict.fromkeys(_portal_reference(action, target) for action, target, _ in entries))
        shown_references = references[:20]
        remaining = len(references) - len(shown_references)
        type_label = "Test Case" if len(references) == 1 else "Test Cases"
        subject = f"{'Action required' if action_required else 'Workflow update'}: {len(references)} {type_label} — {label}"
        url_path = _route(first_action)
        url = f"{portal_url}{url_path}" if portal_url else url_path
        item_lines = "\n".join(f"• {reference}" for reference in shown_references)
        if remaining:
            item_lines += f"\n• and {remaining} more"
        body = (
            f"QualityOps {'ACTION REQUIRED' if action_required else 'WORKFLOW UPDATE'}\n\n"
            f"{route.instruction}\n\n"
            f"{len(references)} {type_label.lower()} are now at: {status}\n\n"
            f"Items:\n{item_lines}\n\n"
            f"Open Test Repository: {url}\n"
        )
        html_items = "".join(f"<li style=\"margin:4px 0\">{escape(reference)}</li>" for reference in shown_references)
        if remaining:
            html_items += f"<li style=\"margin:4px 0\">and {remaining} more</li>"
        html_body = _html_email(
            f"{len(references)} {type_label}",
            f"{'Action required' if action_required else 'Workflow update'} · Test case summary",
            route.instruction, status=status, panel_title="Test cases",
            panel_html=f"<ul style=\"margin:8px 0 0;padding-left:20px\">{html_items}</ul>",
            action_label="Open Test Repository", action_url=url,
        )
        if _queue_email_notification(
            db, first_action, email, subject=subject, body=body, html_body=html_body,
            category="test_case_digest",
        ):
            queued_count += 1
            logger.info("SMTP notification queued category=test_case_digest recipient=%s count=%s", email, len(references))
    return queued_count


def _before_flush(session: SASession, flush_context, instances) -> None:
    """Remember workflow actions that an endpoint flushes before commit.

    Several creation flows need generated child IDs and call ``db.flush()``
    before their final ``db.commit()``. SQLAlchemy removes flushed audit and
    outbox rows from ``session.new``; retaining both collections keeps
    routing, delivery triggering, and recipient-count logs accurate for the
    entire transaction. This notably covers child SM Approval Pending rows
    created while raising a QA Request.
    """
    tracked = session.info.setdefault("email_notification_actions", [])
    known = {id(action) for action in tracked}
    for action in session.new:
        if isinstance(action, models.ApprovalAction) and id(action) not in known:
            tracked.append(action)
            known.add(id(action))
    tracked_outbox = session.info.setdefault("email_notification_outbox", [])
    known_outbox = {id(notification) for notification in tracked_outbox}
    for notification in session.new:
        if isinstance(notification, models.EmailNotification) and id(notification) not in known_outbox:
            tracked_outbox.append(notification)
            known_outbox.add(id(notification))


def _before_commit(session: SASession) -> None:
    if session.info.get("email_notification_listener"):
        return
    actions = list(session.info.get("email_notification_actions", []))
    known = {id(action) for action in actions}
    for item in session.new:
        if isinstance(item, models.ApprovalAction) and id(item) not in known:
            actions.append(item)
            known.add(id(item))
    if not actions:
        return
    session.info["email_notification_listener"] = True
    try:
        tracked_outbox = list(session.info.get("email_notification_outbox", []))
        known_outbox = {id(notification) for notification in tracked_outbox}
        for item in session.new:
            if isinstance(item, models.EmailNotification) and id(item) not in known_outbox:
                tracked_outbox.append(item)
                known_outbox.add(id(item))
        preexisting_outbox_count = len(tracked_outbox)
        # A single endpoint can log several history rows while moving one
        # record through intermediate states (e.g. Submitted then SM
        # Approval Pending). Route only the final row for that record, based
        # on its final status, so the next approver receives one precise
        # notification instead of duplicates.
        final_actions = {}
        for action in actions:
            final_actions[(action.entity_type, action.entity_id)] = action
        logger.info(
            "SMTP workflow evaluation started approval_action_count=%s final_action_count=%s smtp_enabled=%s actions=%s",
            len(actions), len(final_actions), _enabled(),
            "; ".join(
                f"{action.entity_type}:{action.entity_id}:{action.step_name or '-'}:{action.decision or '-'}"
                for action in final_actions.values()
            ),
        )
        test_case_actions = [action for action in final_actions.values() if action.entity_type == "TEST_CASE"]
        routed_outbox_count = _queue_test_case_digests(session, test_case_actions)
        for action in final_actions.values():
            if action.entity_type == "TEST_CASE":
                continue
            routed_outbox_count += _queue_for_action(session, action)
        # The after-commit hook must run only for the transaction that
        # actually created workflow messages. Delivery itself commits status
        # changes too, and must never recursively spawn more delivery threads.
        tracked_outbox = list(session.info.get("email_notification_outbox", []))
        known_outbox = {id(notification) for notification in tracked_outbox}
        for item in session.new:
            if isinstance(item, models.EmailNotification) and id(item) not in known_outbox:
                tracked_outbox.append(item)
                known_outbox.add(id(item))
        outbox_count = len(tracked_outbox)
        if outbox_count:
            session.info["email_notifications_created"] = True
            logger.info(
                "SMTP workflow evaluation completed routed_outbox_count=%s direct_outbox_count=%s total_outbox_count=%s",
                routed_outbox_count, preexisting_outbox_count, outbox_count,
            )
        else:
            logger.warning(
                "SMTP workflow evaluation completed routed_outbox_count=0 total_outbox_count=0 reason=no_notification_created",
            )
    finally:
        session.info.pop("email_notification_listener", None)


def _after_commit(session: SASession) -> None:
    session.info.pop("email_notification_actions", None)
    session.info.pop("email_notification_outbox", None)
    session.info.pop("email_notification_recipient_keys", None)
    if not session.info.pop("email_notifications_created", False):
        return
    if _enabled():
        logger.info("SMTP outbox delivery trigger scheduled after workflow evaluation")
        deliver_pending_async()
    else:
        logger.info("SMTP outbox delivery trigger skipped reason=smtp_disabled")


def _queue_sla_breaches_if_due() -> None:
    """Queue SLA alerts at most once per hour for this application process.

    Both the commit-triggered worker and the periodic poller call this helper.
    Reserving the timestamp under the scheduler lock prevents concurrent
    workers from producing duplicate breach notifications. A failed check
    releases that reservation so the next delivery pass can retry it.
    """
    global _last_sla_check
    now = time.monotonic()
    with _delivery_scheduler_lock:
        if _last_sla_check is not None and now - _last_sla_check < 3600:
            return
        _last_sla_check = now
    try:
        from .sla_notifications import queue_breaches
        queue_breaches()
    except Exception:
        with _delivery_scheduler_lock:
            if _last_sla_check == now:
                _last_sla_check = None
        raise


def deliver_pending_async() -> None:
    """Wake one coalesced outbox worker without delaying the API request.

    A workflow-heavy import or bulk approval can commit many times in a few
    seconds. Starting one thread per commit used to let those workers contend
    for the same database pool (and SMTP relay). Keep at most one delivery
    worker per application process; work committed while it is active asks it
    to make one additional pass after its current batch. The durable outbox
    and periodic poller remain the cross-process reliability mechanism.
    """
    if notification_worker_mode() == 'dedicated':
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            wake_notification_worker()
        else:
            # A synchronous ORM commit can run inside an async upload/comment
            # handler. Keep this bounded Redis hint off that handler's loop.
            loop.run_in_executor(None, wake_notification_worker)
        return
    global _delivery_worker_running, _delivery_rerun_requested
    with _delivery_scheduler_lock:
        if _delivery_worker_running:
            _delivery_rerun_requested = True
            logger.info("SMTP outbox delivery trigger coalesced reason=worker_already_running")
            return
        _delivery_worker_running = True

    def _run_coalesced() -> None:
        global _delivery_worker_running, _delivery_rerun_requested
        while True:
            try:
                _queue_sla_breaches_if_due()
                deliver_pending()
            except Exception:
                logger.exception("SMTP outbox delivery worker failed")
            with _delivery_scheduler_lock:
                if _delivery_rerun_requested:
                    _delivery_rerun_requested = False
                    continue
                _delivery_worker_running = False
                return

    threading.Thread(target=_run_coalesced, name="email-outbox", daemon=True).start()


def start_outbox_poller() -> None:
    """Retry delayed outbox items even when no later workflow action occurs."""
    if notification_worker_mode() == 'dedicated':
        return
    global _poller_started
    if _poller_started:
        return
    _poller_started = True

    def _poll() -> None:
        while _enabled():
            try:
                _queue_sla_breaches_if_due()
                deliver_pending()
            except Exception:
                logger.exception("Email outbox retry poll failed")
            time.sleep(60)

    threading.Thread(target=_poll, name="email-outbox-poller", daemon=True).start()

    def _reminders() -> None:
        from .approval_reminders import queue_due_reminders
        while _enabled():
            try:
                queue_due_reminders()
            except Exception:
                logger.exception('Daily approval reminder scheduler failed; the next pass will retry')
            time.sleep(60)

    threading.Thread(target=_reminders, name="approval-reminder-scheduler", daemon=True).start()


def notification_worker_mode() -> str:
    from .config import settings
    mode = os.getenv('NOTIFICATION_WORKER_MODE', settings.notification_worker_mode).strip().lower()
    if mode not in {'embedded', 'dedicated'}:
        raise ValueError('NOTIFICATION_WORKER_MODE must be dedicated or embedded')
    return mode


def wake_notification_worker() -> None:
    """Best-effort wake hint; committed Oracle outbox rows remain recoverable."""
    try:
        from .redis_runtime import coordination_key, get_client
        get_client().set(coordination_key('notifications:wake'), '1', ex=120)
    except Exception:
        # Nothing after commit may turn an otherwise successful workflow
        # action into an API error. The dedicated worker polls Oracle too.
        logger.warning('Notification worker wake unavailable; committed messages remain queued')


def _after_rollback(session: SASession) -> None:
    session.info.pop("email_notification_actions", None)
    session.info.pop("email_notification_outbox", None)
    session.info.pop("email_notification_recipient_keys", None)
    session.info.pop("email_notifications_created", None)


def install_outbox_listener() -> None:
    global _listener_installed
    if _listener_installed:
        return
    event.listen(SASession, "before_flush", _before_flush)
    event.listen(SASession, "before_commit", _before_commit)
    event.listen(SASession, "after_commit", _after_commit)
    event.listen(SASession, "after_rollback", _after_rollback)
    _listener_installed = True


def _send(notification: models.EmailNotification) -> None:
    settings = _smtp_settings()
    try:
        smtp_circuit.check()
    except CircuitOpenError as exc:
        logger.warning(
            "SMTP notification deferred id=%s recipient=%s reason=circuit_open retry_after=%ss",
            notification.id, notification.recipient_email, exc.retry_after_seconds,
        )
        raise
    # Durable messages may have been queued before the product was renamed.
    # Replace display copy only; hyphenated URLs and template markers stay valid.
    def current_brand(value):
        return value.replace("QA Portal", "QualityOps").replace("QA PORTAL", "QualityOps")

    notification.subject = current_brand(notification.subject)
    notification.body = current_brand(notification.body)
    if notification.html_body:
        notification.html_body = current_brand(notification.html_body)
    logger.info("SMTP notification sending id=%s recipient=%s approval_action_id=%s subject=%s", notification.id, notification.recipient_email, notification.approval_action_id, notification.subject)
    message = EmailMessage()
    message["Subject"] = notification.subject
    message["From"] = f'{settings["from_name"]} <{settings["from_address"]}>'
    message["To"] = notification.recipient_email
    message.set_content(notification.body)
    html_body = notification.html_body
    if _EMAIL_TEMPLATE_MARKER not in (html_body or ""):
        html_body = _legacy_html_email(notification)
        # Persist the normalized template with the delivery outcome, so later
        # retry attempts do not need to render a legacy message again.
        notification.html_body = html_body
        logger.info(
            "SMTP notification template normalized id=%s recipient=%s approval_action_id=%s",
            notification.id, notification.recipient_email, notification.approval_action_id,
        )
    message.add_alternative(html_body, subtype="html")
    _send_message(message, settings)


def _candidate_notification_ids(now: datetime.datetime, limit: int) -> list[int]:
    """Read the batch once, then deliver every recipient in isolation."""
    db = SessionLocal()
    try:
        return [row.id for row in db.query(models.EmailNotification.id).filter(
            or_(
                models.EmailNotification.status == "PENDING",
                (models.EmailNotification.status == "RETRY") & (models.EmailNotification.next_attempt_at <= now),
                (models.EmailNotification.status == "SENDING") & (models.EmailNotification.last_attempt_at < now - datetime.timedelta(minutes=15)),
            )
        ).order_by(models.EmailNotification.created_at).limit(limit).all()]
    finally:
        db.close()


def _defect_creation_notification_allowed(db: SASession, notification: models.EmailNotification) -> bool:
    """Suppress old broadcast outbox rows and revoked recipients before SMTP.

    Only creation messages use this policy; later workflow ownership and
    explicit Activity mentions retain their existing routing rules.
    """
    action = notification.approval_action
    if not action or action.entity_type != 'DEFECT' or action.decision != 'Created':
        return True
    target = _target(action, db)
    if not isinstance(target, models.Defect):
        return False
    from .defect_cc import notification_ids
    from .workspace_service import selectable_workspace_ids
    recipient_ids = _user_ids(target.reporter_id) | _user_ids(target.assignee_id) | notification_ids(db, target)
    workspace = _target_workspace_id(target)
    recipient_email = notification.recipient_email.strip().casefold()
    for user in db.query(models.User).filter(models.User.id.in_(recipient_ids), models.User.is_active == True).all():  # noqa: E712
        if ((user.email or '').strip().casefold() == recipient_email
                and (not workspace or workspace in selectable_workspace_ids(db, user))):
            return True
    return False


def _deliver_one(notification_id: int, now: datetime.datetime) -> bool:
    """Deliver one outbox row in its own database session/transaction.

    SMTP rejections and even an unexpected persistence error for one recipient
    must not prevent the rest of a notification batch from being delivered.
    """
    db = SessionLocal()
    try:
        notification = db.get(models.EmailNotification, notification_id)
        if not notification:
            return False
        original_status = notification.status
        if original_status not in {"PENDING", "RETRY", "SENDING"}:
            return False

        # Claim atomically. Several Uvicorn workers can wake up for the same
        # outbox row, but only one may hand this recipient to the SMTP relay.
        claim = db.query(models.EmailNotification).filter(
            models.EmailNotification.id == notification_id,
            models.EmailNotification.status == original_status,
        )
        if original_status == "RETRY":
            claim = claim.filter(models.EmailNotification.next_attempt_at <= now)
        elif original_status == "SENDING":
            claim = claim.filter(models.EmailNotification.last_attempt_at < now - datetime.timedelta(minutes=15))
        claimed = claim.update({
            models.EmailNotification.status: "SENDING",
            models.EmailNotification.attempts: models.EmailNotification.attempts + 1,
            models.EmailNotification.last_attempt_at: now,
        }, synchronize_session=False)
        db.commit()
        if not claimed:
            return False

        notification = db.get(models.EmailNotification, notification_id)
        try:
            if not _defect_creation_notification_allowed(db, notification):
                notification.status = 'CANCELLED'
                notification.last_error = 'Defect creation email is limited to the requester, assigned user and selected CC users.'
                db.commit()
                logger.info('Defect creation email suppressed id=%s reason=recipient_not_selected', notification.id)
                return False
            from .approval_reminders import refresh_before_delivery
            if not refresh_before_delivery(db, notification):
                notification.status = 'CANCELLED'
                notification.last_error = 'Daily reminder no longer applies: resolved, stale or recipient no longer eligible.'
                db.commit()
                logger.info('Daily approval reminder suppressed id=%s', notification.id)
                return False
            _send(notification)
            notification.status = "SENT"
            notification.sent_at = models.now()
            notification.last_error = None
            db.commit()
            logger.info("SMTP notification sent id=%s recipient=%s approval_action_id=%s subject=%s", notification.id, notification.recipient_email, notification.approval_action_id, notification.subject)
            return True
        except Exception as exc:
            notification.last_error = str(exc)[:2000]
            if notification.attempts >= _MAX_ATTEMPTS:
                notification.status = "FAILED"
            else:
                notification.status = "RETRY"
                notification.next_attempt_at = models.now() + datetime.timedelta(minutes=2 ** notification.attempts)
            db.commit()
            logger.warning("SMTP notification failed id=%s recipient=%s approval_action_id=%s attempts=%s status=%s error=%s", notification_id, notification.recipient_email, notification.approval_action_id, notification.attempts, notification.status, exc)
            return False
    except Exception:
        db.rollback()
        logger.exception("Email delivery processing failed for outbox item %s", notification_id)
        return False
    finally:
        db.close()


def deliver_pending(limit: int = 20) -> int:
    """Deliver a bounded batch, with one local DB/SMTP worker at a time."""
    if not _delivery_lock.acquire(blocking=False):
        logger.info("SMTP outbox delivery skipped reason=delivery_already_running")
        return 0
    try:
        return _deliver_pending(limit)
    finally:
        _delivery_lock.release()


def _deliver_pending(limit: int = 20) -> int:
    ready, reason = smtp_readiness()
    if not ready:
        logger.warning("SMTP outbox delivery skipped reason=%s", reason)
        return 0
    now = models.now()
    # Do not let a bad mailbox, an SMTP refusal, or a transient DB error for
    # one recipient abort delivery for every other recipient in this batch.
    notification_ids = _candidate_notification_ids(now, limit)
    if not notification_ids:
        return 0
    logger.info("SMTP outbox delivery started batch_size=%s", len(notification_ids))
    delivered = sum(_deliver_one(notification_id, now) for notification_id in notification_ids)
    logger.info(
        "SMTP outbox delivery completed batch_size=%s delivered_count=%s unsuccessful_count=%s",
        len(notification_ids), delivered, len(notification_ids) - delivered,
    )
    return delivered
