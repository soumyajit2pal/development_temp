from ..functional_request_scope import visible_functional_requests
from ..request_scope import record_return_requirement, require_scope_satisfied
import os
from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from fastapi.responses import FileResponse, StreamingResponse
from sqlalchemy import and_, func, literal, or_
from sqlalchemy.orm import Session, joinedload
from sqlalchemy.exc import IntegrityError

from .. import models, pagination, schemas, certificate_summary, certificate_revisions
from ..database import get_db
from ..deps import (
    get_workflow_user as get_current_user, require_workflow_roles as require_roles, require_same_department, require_not_requester,
    dashboard_department_scope, require_department_visibility, active_qa_workspace_scope_ids,
    department_unit_visibility_condition, require_department_unit_visibility,
    require_department_unit_action_scope, has_department_unit_action_scope,
    require_can_execute_project, can_view_cycle_folder,
    require_can_view_cycle_folder,
)
from ..constants import Role, QAStatus, FUNCTIONAL_EDITABLE_STATUSES, TESTER_REASSIGNABLE_STATUSES, QA_REQUEST_STATUS_LABELS, QA_REQUEST_TERMINAL_STATUSES, QA_REQUEST_CREATOR_ROLES, format_role_labels, is_readiness_evidence_editable, validate_environment_promotion, validate_target_release_date, application_name_block_message
from ..pdf_export import build_request_detail_pdf
from .. import documents as doc_store
from .. import application_names as app_names
from .. import reassignment
from ..request_classification import business_defect_number
from ..workflow_authority import is_system_admin
from ..execution_cycles import (
    execution_cycle_choice,
    require_cycle_startable,
    require_cycle_unlinkable,
    require_cycles_completed,
)

router = APIRouter(prefix="/api/functional-requests", tags=["functional"])

# Linking is traceability, not an execution-result operation.  A test cycle
# may therefore be attached while it is still being prepared (Draft/Ready),
# as well as after its own execution has started.  Blocked and Completed
# cycles stay excluded: a blocked cycle must be explicitly resumed first and
# a completed cycle is terminal.  Keeping this list in one place prevents
# the picker endpoint and the save endpoint from drifting apart again.
_LINKABLE_TEST_CYCLE_STATUSES = ("Draft", "Ready", "In Progress")

# ---------------------------------------------------------------------------
# Functional Testing Request lifecycle -- covers whichever of Functional
# Testing/Sanity Testing/Regression Testing/UAT Support were selected on a QA
# Request (see routers/qa_requests.py::_sync_linked_child_requests), combined
# into a single request/workflow (models.FunctionalRequest). Carries the full
# lifecycle that used to live directly on the QA Request itself:
#
#   Draft -> Submit -> same-department SM Approval -> same-department
#   Department Head Approval -> workspace QA Lead group starts
#   Readiness Verification -> QA Activity (Planning -> Tester
#   Assignment -> Test Design -> Execution, with a Defect -> Waiting For Fix
#   -> Retesting -> Regression Testing cycle) -> QA Completed -> QA Clearance
#   -> Requester Verification -> Closed.
# ---------------------------------------------------------------------------


def _log(db: Session, entity_id: int, step: str, user: models.User, decision: str, comments: Optional[str] = None):
    db.add(models.ApprovalAction(
        entity_type="FUNCTIONAL_REQUEST", entity_id=entity_id, step_name=step,
        actor_id=user.id, actor_role=user.roles_csv, decision=decision, comments=comments,
    ))


def _require(obj, expected_statuses, action: str):
    if isinstance(expected_statuses, str):
        expected_statuses = [expected_statuses]
    if obj.status not in expected_statuses:
        raise HTTPException(
            400, f"'{action}' requires status in {expected_statuses} (currently '{obj.status}')"
        )


def _get_or_404(db: Session, req_id: int, lock: bool = False) -> "models.FunctionalRequest":
    query = db.query(models.FunctionalRequest).filter_by(id=req_id)
    if lock:
        query = query.populate_existing().with_for_update()
    # Primary-key lookup: avoid Oracle-incompatible FETCH FIRST with FOR UPDATE.
    obj = query.one_or_none()
    if not obj:
        raise HTTPException(404, "Functional Testing Request not found")
    return obj


def _clearance_certificate_for_request(
    db: Session,
    obj: "models.FunctionalRequest",
    signoff_id: int,
    *,
    current_user: Optional[models.User] = None,
    require_requester_ownership: bool = False,
    require_issued: bool = False,
    allow_denied: bool = False,
) -> "models.QASignOff":
    """Resolve a certificate without allowing cross-request/workspace reuse.

    ``confirm-signoff`` is retained only as a legacy recovery path for an
    issued certificate that was not auto-synchronised. It must never act as
    an alternative approval path for a Draft or pending certificate.
    """
    # Lock the certificate before checking whether another Functional Request
    # already owns the link. Without this row lock, two concurrent requests
    # could both observe no existing link and reuse the same certificate.
    # one_or_none() is intentional: Oracle cannot combine FOR UPDATE with the
    # FETCH FIRST shape that a convenience first()/limit() would generate.
    cert = (
        db.query(models.QASignOff)
        .filter_by(id=signoff_id)
        .populate_existing()
        .with_for_update()
        .one_or_none()
    )
    if not cert:
        raise HTTPException(400, "signoff_id does not reference an existing clearance certificate")

    workspace_id = obj.qa_request.qa_workspace_id if obj.qa_request else None
    if (
        workspace_id is None
        or cert.qa_workspace_id != workspace_id
        or cert.testing_request_id != obj.request_id
    ):
        raise HTTPException(
            400,
            "The clearance certificate must belong to this Functional Request and QA workspace",
        )
    if cert.certificate_type not in {
        "Full Clearance", "Conditional Clearance", "Clearance Denied",
    }:
        raise HTTPException(400, "The linked certificate has an unsupported certificate type")
    if cert.certificate_type == "Clearance Denied" and not allow_denied:
        raise HTTPException(400, "A Clearance Denied certificate cannot clear a Functional Request")

    other_link = (
        db.query(models.FunctionalRequest.id)
        .filter(
            models.FunctionalRequest.signoff_id == cert.id,
            models.FunctionalRequest.id != obj.id,
        )
        .first()
    )
    if other_link:
        raise HTTPException(409, "The clearance certificate is already linked to another Functional Request")

    if require_requester_ownership:
        if current_user is None:
            raise RuntimeError("current_user is required for certificate ownership validation")
        if cert.requester_id != current_user.id and not current_user.has_role(Role.ADMIN):
            raise HTTPException(403, "Only the certificate requester or an admin can link this certificate")
    if require_issued and cert.status != "ISSUED":
        raise HTTPException(409, "Requester verification requires an issued clearance certificate")
    return cert


def _is_active_delegate(obj: "models.FunctionalRequest", user: models.User) -> bool:
    delegation = obj.active_delegation
    return bool(delegation and delegation.assigned_to_id == user.id)


def _require_visible(db: Session, obj: "models.FunctionalRequest", user: models.User) -> None:
    delegated = _is_active_delegate(obj, user)
    require_department_visibility(
        user, obj.department, requester_id=obj.requester_id,
        delegated=delegated,
        entity_workspace_id=obj.qa_request.qa_workspace_id if obj.qa_request else None,
    )
    if obj.qa_request:
        require_department_unit_visibility(
            db, user, obj.department, obj.qa_request.department_unit_id,
            requester_id=obj.requester_id, delegated=delegated,
        )


def _require_distinct_department_head_approver(
    db: Session, obj: "models.FunctionalRequest", user: models.User,
) -> None:
    """Keep the SM and Department Head checkpoints independent.

    A multi-role user may legitimately be eligible for both stages, but may
    not approve both stages on the same request.  Use the append-only audit
    trail as the source of truth because FunctionalRequest has no dedicated
    ``sm_approved_by_id`` column.  Administrators retain the workflow's
    existing explicit oversight bypass.
    """
    # Workflow dependencies deliberately hide ADMIN from the actor's
    # effective roles.  The maker-checker exception is based on the stored
    # system-administrator assignment, so inspect that assignment directly.
    if is_system_admin(user):
        return
    sm_approval = (
        db.query(models.ApprovalAction)
        .filter_by(
            entity_type="FUNCTIONAL_REQUEST",
            entity_id=obj.id,
            step_name="SM Approval",
            decision="Approved",
            actor_id=user.id,
        )
        .first()
    )
    if sm_approval:
        raise HTTPException(
            403,
            "Department Head approval must be completed by a different approver; "
            "your SM approval is already recorded on this request.",
        )


def _it_qa_user(db: Session, user_id: Optional[int], role: str, label: str, workspace_id: int | None = None) -> models.User:
    user = db.get(models.User, user_id) if user_id else None
    if user and not user.show_in_user_dropdowns:
        raise HTTPException(400, "The selected user is hidden from assignment dropdowns")
    if not user or not user.is_active or not user.has_qa_workspace_role(role, workspace_id=workspace_id):
        raise HTTPException(400, f"{label} must hold {role.replace('_', ' ').title()} in this request's workspace")
    return user


def _require_assigned_qa_lead(obj: "models.FunctionalRequest", user: models.User) -> None:
    # Reported directly: "AGM QA / Chief Manager QA does not need to assign
    # QA lead separately as they [a]re the executive[s], ... they have super
    # power" -- CHIEF_MANAGER_QA/AGM_QA get a blanket Executive bypass on
    # every QA-Lead-gated action, same as has_role()'s own ADMIN bypass,
    # WITHOUT being listed as "QA Lead group" members anywhere in the UI
    # (see ORACLE_MIGRATION_2026-07.md section 59 -- that's a display-only
    # concern, kept to literal QA_LEAD; this is the separate action-
    # authorization check).
    if not user.has_role(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA):
        raise HTTPException(403, "Only a member of the QA Lead group can perform this action")


def _assigned_tester_ids(obj: "models.FunctionalRequest") -> set[int]:
    return {int(value) for value in (obj.assigned_tester_ids or "").split(",") if value}


FUNCTIONAL_REQUESTER_WORK_STATUSES = {
    QAStatus.DRAFT,
    QAStatus.RETURNED_BY_SM,
    QAStatus.SM_REJECTED,
    QAStatus.RETURNED_BY_DEPARTMENT_HEAD,
    QAStatus.RETURNED_BY_QA_LEAD,
    QAStatus.DEFECT_RAISED,
    QAStatus.WAITING_FOR_FIX,
    QAStatus.QA_SIGNED_OFF,
    QAStatus.REQUESTER_VERIFICATION,
}


def _functional_requester_work(user_id: int):
    """SQL predicate for work currently owned by the exact requester.

    Keep this status-gated: ``requester_id`` records who raised a request,
    not who owns every later workflow step.  In particular, adding a bare
    requester-id condition here would turn “My Assigned Work” into another
    “My Requests” view and expose SM/Department Head/QA-owned stages in the
    requester's active queue.  These values mirror the Functional workflow's
    existing ``Pending With = Requester`` mapping, including Draft as the
    requester's private work before submission.
    """
    return and_(
        models.FunctionalRequest.requester_id == user_id,
        models.FunctionalRequest.status.in_(FUNCTIONAL_REQUESTER_WORK_STATUSES),
    )


def _require_assigned_tester(obj: "models.FunctionalRequest", user: models.User) -> None:
    if not user.has_role(Role.ADMIN) and user.id not in _assigned_tester_ids(obj):
        raise HTTPException(403, "Only a QA tester assigned by the QA Lead can perform this action")


# 2026-08 -- reported directly, see TESTER_REASSIGNABLE_STATUSES' own
# comment on constants.py: reassigning is now open to the QA Lead group at
# any point (not just the very first PLANNING assignment), AND to whoever
# is currently assigned -- "the current assign[ed] people can reassign to
# another qa member" -- so an overloaded tester can hand their own slot off
# to a colleague without needing to go back to the QA Lead first. A user
# with no roles in common with either group (e.g. a QA Engineer who was
# never assigned to THIS request) is still blocked -- being a QA Engineer
# generally isn't enough, only actually being on this request's own
# assigned_tester_ids is.
def _require_assigned_qa_lead_or_current_tester(obj: "models.FunctionalRequest", user: models.User,
                                                 action: str = "reassign the tester(s) on this request") -> None:
    if user.has_role(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA):
        return
    if user.id in _assigned_tester_ids(obj):
        return
    raise HTTPException(403, f"Only the QA Lead group or a currently assigned tester can {action}")


def _create_reexecution_cycle(
    db: Session,
    obj: "models.FunctionalRequest",
    certificate: "models.QASignOff",
    payload: schemas.ClearanceChangeDecisionIn,
    current_user: models.User,
) -> "models.TestCycle":
    """Clone execution scope into a new Draft without rewriting signed evidence."""
    source = (
        db.query(models.TestCycle)
        .filter(models.TestCycle.id == payload.source_cycle_id)
        .populate_existing()
        .with_for_update()
        .one_or_none()
    )
    if not source:
        raise HTTPException(404, "The selected source Test Cycle was not found")
    link = source.child_request_link
    if not link or link.child_type != "Functional" or link.child_id != obj.id:
        raise HTTPException(
            400,
            "Select a completed Test Cycle linked to this Functional Request",
        )
    if source.status != "Completed":
        raise HTTPException(409, "Only a Completed Test Cycle can be used for re-execution")
    source_environment = (source.environment or "").strip().casefold()
    certificate_environment = (certificate.environment_tested or "").strip().casefold()
    if not certificate_environment or source_environment != certificate_environment:
        raise HTTPException(
            409,
            "Select a completed lineage-leaf Test Cycle from the certificate's "
            f"tested environment ({certificate.environment_tested or 'not recorded'})",
        )
    existing_successor = db.query(models.TestCycle).filter(
        models.TestCycle.reexecution_of_cycle_id == source.id,
    ).first()
    if existing_successor:
        raise HTTPException(
            409,
            f"{source.cycle_key} already continues as {existing_successor.cycle_key}; "
            "select the latest completed cycle in that re-execution lineage",
        )
    if not source.project or not source.project.is_active:
        raise HTTPException(409, "The source Test Cycle's project is inactive")
    require_can_execute_project(db, source.project_id, current_user)
    source_folder = None
    if source.folder_id is not None:
        source_folder = source.folder or db.get(models.TestCycleFolder, source.folder_id)
        if not source_folder or source_folder.project_id != source.project_id:
            raise HTTPException(409, "The source Test Cycle's folder is no longer valid")
        require_can_view_cycle_folder(source_folder, current_user)

    source_slots = list(source.executions)
    if not source_slots:
        raise HTTPException(409, "The source Test Cycle has no testcase scope to re-execute")
    invalid_cases: list[str] = []
    current_versions = {}
    for slot in source_slots:
        test_case = slot.test_case
        approved = test_case.current_approved_version if test_case else None
        case_label = (
            test_case.test_case_key
            if test_case and test_case.test_case_key
            else f"Testcase #{slot.test_case_id}"
        )
        # Keep the checks ordered by the remedy the user must take. A
        # rejected testcase in the Recycle Bin can legitimately retain an
        # Approved baseline, so checking the version pointer first would
        # hide the real blocker behind a misleading approval message.
        if not test_case:
            invalid_cases.append(
                f"{case_label}: source testcase identity is missing; "
                "ask an administrator to repair the stale cycle item"
            )
        elif test_case.is_deleted:
            invalid_cases.append(
                f"{case_label}: in the Recycle Bin; restore it before re-execution"
            )
        elif not approved:
            invalid_cases.append(
                f"{case_label}: no current Approved version; approve a version before re-execution"
            )
        elif approved.status == "Archived":
            invalid_cases.append(
                f"{case_label}: current version is Archived; restore it from Archive before re-execution"
            )
        elif approved.status != "Approved":
            version_status = (approved.status or "Unknown").strip() or "Unknown"
            invalid_cases.append(
                f"{case_label}: current Approved-version pointer targets status "
                f"'{version_status}'; correct or approve the version before re-execution"
            )
        else:
            current_versions[slot.test_case_id] = approved.id
    if invalid_cases:
        preview = "; ".join(invalid_cases[:8])
        remaining = len(invalid_cases) - 8
        suffix = f"; and {remaining} more" if remaining > 0 else ""
        raise HTTPException(
            409,
            detail={
                "code": "FUNCTIONAL_REEXECUTION_TESTCASE_INELIGIBLE",
                "cause": "Source testcase scope is not eligible for re-execution",
                "message": f"Re-execution cannot start. {preview}{suffix}",
                "guidance": (
                    "Restore any testcase in the Recycle Bin or Archive, and establish a current "
                    "Approved version for every remaining testcase. If an identity is missing, ask "
                    "an administrator to repair the stale cycle item. Then retry; no re-execution "
                    "cycle was created."
                ),
                "retryable": False,
            },
        )

    start_date = payload.retest_start_date or models.today_ist()
    end_date = payload.retest_end_date or start_date
    if start_date > end_date:
        raise HTTPException(400, "Retest start date cannot be after end date")
    generated_name = f"{source.name} - Re-execution"
    name = (payload.retest_cycle_name or generated_name).strip()[:150]
    build = payload.retest_build or source.build
    if not (build or "").strip():
        raise HTTPException(400, "A build is required for the re-execution cycle")

    successor = models.TestCycle(
        origin_workspace_id=source.origin_workspace_id,
        project_id=source.project_id,
        name=name,
        description=source.description,
        status="Draft",
        start_date=start_date,
        end_date=end_date,
        created_by_id=current_user.id,
        cycle_type=source.cycle_type,
        environment=source.environment,
        build=build.strip(),
        owner_id=source.owner_id,
        folder_id=source.folder_id,
        reexecution_of_cycle_id=source.id,
    )
    db.add(successor)
    db.flush()
    successor.child_request_link = models.TestCycleChildRequestLink(
        child_type="Functional",
        child_id=obj.id,
        child_key=obj.request_id,
    )

    # An assignment is operational authority, not merely copied display
    # metadata. Preserve it only when the old runner is still eligible under
    # the same rules as a fresh execution assignment: active/visible, an
    # explicit QA Engineer, and able to execute in this cycle's owning
    # workspace. Revoked roles or workspace access therefore produce an
    # unassigned slot instead of silently carrying obsolete authority into a
    # new execution round.
    candidate_ids = {
        slot.assigned_to_id for slot in source_slots if slot.assigned_to_id
    }
    eligible_assignee_ids: set[int] = set()
    if candidate_ids:
        from ..workspace_service import inherited_workspace_access_mode, selectable_workspace_ids
        from ..workflow_authority import admin_department_allowed

        workspace_id = source.origin_workspace_id or source.project.qa_workspace_id
        candidates = db.query(models.User).filter(
            models.User.id.in_(candidate_ids),
            models.User.is_active == True,  # noqa: E712 - Oracle boolean column
            models.User.show_in_user_dropdowns == True,  # noqa: E712
        ).all()
        for candidate in candidates:
            if Role.QA_ENGINEER not in candidate.roles or Role.VIEW_ONLY in candidate.roles:
                continue
            if workspace_id is None or workspace_id not in selectable_workspace_ids(db, candidate):
                continue
            if inherited_workspace_access_mode(db, candidate, workspace_id) == "PARENT_VIEWER":
                continue
            if not admin_department_allowed(candidate, source.project.department):
                continue
            if source_folder is not None and not can_view_cycle_folder(
                source_folder, candidate,
            ):
                continue
            eligible_assignee_ids.add(candidate.id)

    for slot in source_slots:
        assigned_to_id = (
            slot.assigned_to_id
            if slot.assigned_to_id in eligible_assignee_ids
            else None
        )
        db.add(models.TestExecution(
            cycle_id=successor.id,
            test_case_id=slot.test_case_id,
            pinned_version_id=current_versions[slot.test_case_id],
            status="Not Executed",
            assigned_to_id=assigned_to_id,
            assigned_by_id=slot.assigned_by_id if assigned_to_id else None,
            assigned_at=slot.assigned_at if assigned_to_id else None,
            added_by_id=slot.added_by_id or current_user.id,
            run_version=0,
        ))

    audit = (
        f"Created {successor.cycle_key} as a Draft re-execution of {source.cycle_key}; "
        f"copied {len(source_slots)} testcase slot(s) at their current Approved versions, "
        "with results, attempts, evidence and defect links reset. "
        f"Reason: {payload.comments}"
    )
    db.add_all([
        models.ApprovalAction(
            entity_type="TEST_CYCLE", entity_id=source.id, step_name="Re-execution",
            actor_id=current_user.id, actor_role=current_user.roles_csv,
            decision="Successor Created", comments=audit,
        ),
        models.ApprovalAction(
            entity_type="TEST_CYCLE", entity_id=successor.id, step_name="Re-execution",
            actor_id=current_user.id, actor_role=current_user.roles_csv,
            decision="Draft Created", comments=audit,
        ),
    ])
    return successor


def _require_held_clearance_retest_leaf_completed(
    obj: "models.FunctionalRequest",
) -> None:
    """Prevent a held certificate's mandated Retest from being bypassed.

    The original signed cycles stay linked and Completed. Without this
    explicit check, removing an empty successor could make those historical
    cycles sufficient for Complete QA even though QA selected Retest. A held
    certificate therefore requires a newly completed, linked lineage leaf
    that was not part of its frozen issued snapshot.
    """
    certificate = obj.signoff
    if not certificate or certificate.status != "ISSUED_UNDER_REVIEW":
        return
    linked_cycles = list(obj.linked_test_cycles)
    parent_ids = {
        cycle.reexecution_of_cycle_id
        for cycle in linked_cycles
        if cycle.reexecution_of_cycle_id is not None
    }
    leaf_cycles = [cycle for cycle in linked_cycles if cycle.id not in parent_ids]
    snapshot = certificate.certificate_summary or {}
    frozen_cycle_ids: set[int] = set()
    for field in ("cycle_ids", "defect_scope_cycle_ids"):
        for value in snapshot.get(field) or []:
            try:
                frozen_cycle_ids.add(int(value))
            except (TypeError, ValueError):
                # A malformed frozen snapshot cannot make an old cycle count
                # as successful new work; simply leave it outside the match.
                continue
    eligible = [
        cycle for cycle in leaf_cycles
        if cycle.reexecution_of_cycle_id is not None
        and cycle.id not in frozen_cycle_ids
        and cycle.status == "Completed"
        and (cycle.environment or "").strip().casefold()
            == (certificate.environment_tested or "").strip().casefold()
    ]
    if not eligible:
        raise HTTPException(
            409,
            "QA selected Retest for the held clearance. Complete the linked "
            "re-execution lineage leaf in the certificate's tested environment "
            "before completing QA.",
        )


# 2026-08 Reassignment CR, reported directly: "Reassignment shall be
# permitted to: the current assignee, the Department Head of the department
# to which the current assignee belongs, or Admin users." Deliberately
# narrower than _require_assigned_qa_lead_or_current_tester above (which
# still gates the FIRST assignment, unchanged) -- QA_LEAD on its own is not
# a Department Head per the CR's own clarification table (COE - Quality
# Assurance's Department Head is specifically AGM_QA/CHIEF_MANAGER_QA), so a
# QA Lead who isn't also currently assigned can no longer reassign someone
# else's slot once the first assignment has happened. See assign_tester's
# `is_initial_assignment` branch for where each gate applies.
def _require_can_reassign_tester(obj: "models.FunctionalRequest", user: models.User) -> None:
    if user.has_role(Role.ADMIN):
        return
    if user.id in _assigned_tester_ids(obj):
        return
    workspace_id = obj.qa_request.qa_workspace_id if obj.qa_request else None
    if user.has_qa_workspace_role(Role.CHIEF_MANAGER_QA, Role.AGM_QA, workspace_id=workspace_id):
        return
    # 2026-08 -- reported directly: QA_LEAD is required to keep reassignment
    # rights here too, not just CHIEF_MANAGER_QA/AGM_QA. The CR's own
    # eligibility list (current assignee / Department Head / Admin) would
    # otherwise narrow existing behavior -- a plain QA_LEAD could previously
    # reassign any tester on any request, same as the initial-assignment gate
    # (_require_assigned_qa_lead_or_current_tester) already allows.
    if user.has_role(Role.QA_LEAD):
        return
    raise HTTPException(
        403,
        "Only a currently assigned tester, a QA Lead, a QA Executive in the active workspace (Chief Manager QA / AGM QA), "
        "or an Administrator can reassign the tester(s) on this request",
    )


@router.get("", response_model=pagination.Page[schemas.FunctionalListOut])
def list_functional(params: pagination.PageParams = Depends(), requester_id: Optional[int] = None,
                     assigned_to_me: bool = False,
                     db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    # department/application_name/epic_number/application_master_status are
    # all delegated (read-only) properties resolved through the `qa_request`
    # relationship (see models.FunctionalRequest), not real columns -- every
    # filter that touches them needs the same join dashboard_department_scope
    # already required, and every row needs qa_request (+ its own
    # application_master) eager-loaded so FunctionalListOut's read of those
    # properties doesn't turn into a lazy-load-per-row N+1 (PAG-007/DBP-005).
    # isouter=True (not an inner join): qa_request_id is nullable (standalone
    # creation is disabled now, see create_functional above, but older rows
    # from before that -- if any -- would otherwise silently vanish from
    # every list view under an inner join).
    q = visible_functional_requests(db, current_user).options(
        joinedload(models.FunctionalRequest.qa_request).joinedload(models.QARequest.application_master),
    )
    delegated_to_user = models.QARequest.delegations.any(and_(
        models.QARequestDelegation.target_type == "FUNCTIONAL",
        models.QARequestDelegation.target_id == models.FunctionalRequest.id,
        models.QARequestDelegation.status == "ACTIVE",
        models.QARequestDelegation.assigned_to_id == current_user.id,
    ))
    # A delegation is exceptional, temporary input access. QA work is named
    # through the assigned lead/tester fields; requester work is added below
    # only for stages whose Pending With owner is the exact requester.
    named_assignee = or_(
        models.FunctionalRequest.qa_lead_id == current_user.id,
        func.instr(
            literal(",") + func.coalesce(models.FunctionalRequest.assigned_tester_ids, "") + literal(","),
            f",{current_user.id},",
        ) > 0,
    )
    requester_work = _functional_requester_work(current_user.id)
    if assigned_to_me:
        q = q.filter(or_(named_assignee, requester_work, delegated_to_user))
    q = pagination.apply_search(q, params, models.FunctionalRequest.request_id, models.QARequest.application_name, models.QARequest.module_name)
    q = pagination.apply_status_filter(q, params, models.FunctionalRequest.status)
    q = pagination.apply_department_filter(q, params, models.QARequest.department)
    q = pagination.apply_terminal_raised_date_filter(
        q, params, models.FunctionalRequest.status, models.FunctionalRequest.created_at, QA_REQUEST_TERMINAL_STATUSES,
    )
    # Module-specific, same reasoning/reported issue as qa_requests.py's own
    # requester_id addition -- lets Dashboard.tsx's "My Requests" tab filter
    # server-side instead of over a department-wide, page_size=100-capped
    # fetch that could silently omit a user's own older requests.
    if requester_id is not None:
        q = q.filter(models.FunctionalRequest.requester_id == requester_id)
    q = pagination.apply_sort(
        q, params,
        sortable={
            "created_at": models.FunctionalRequest.created_at,
            "updated_at": models.FunctionalRequest.updated_at,
            "status": models.FunctionalRequest.status,
            "application_name": models.QARequest.application_name,
            "module_name": models.QARequest.module_name,
        },
        default_column=models.FunctionalRequest.created_at, id_column=models.FunctionalRequest.id,
    )
    result = pagination.paginate(q, params)
    return pagination.to_page_response(result, params)


@router.get("/{req_id}", response_model=schemas.FunctionalOut)
def get_functional(req_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    obj = _get_or_404(db, req_id)
    _require_visible(db, obj, current_user)
    return obj


# Standalone creation is DISABLED -- a Functional Testing Request can only
# originate from a QA Request that includes Functional Testing/Sanity
# Testing/Regression Testing/UAT Support in its request types.
@router.post("", response_model=schemas.FunctionalOut)
def create_functional(payload: schemas.FunctionalCreate, db: Session = Depends(get_db),
                       current_user: models.User = Depends(get_current_user)):
    raise HTTPException(
        400,
        "Standalone Functional Testing Requests can no longer be raised directly -- include "
        "Functional Testing / Sanity Testing / Regression Testing / UAT Support in a QA Request's "
        "request types instead.",
    )


# Priority/risk_rating are real columns on FunctionalRequest itself; every
# other editable field is delegated (read-only property) from the parent QA
# Request, so it has to be written onto obj.qa_request instead of obj -- a
# plain setattr(obj, k, v) loop would raise AttributeError (no setter) for
# any of these. See schemas.FunctionalUpdate for the full field list/reasoning.
_FUNCTIONAL_OWN_FIELDS = {"priority", "risk_rating"}

# These identify *which* request this actually is -- changing them once the
# request exists (i.e. once it's been raised, since standalone creation is
# disabled) is an Admin-only action, same restriction as SAST/DAST/
# Performance's own Edit Details (see update_sast/update_dast/
# update_performance). A submitted value equal to the current one is let
# through for anyone -- that's not actually a change, just the form
# resubmitting a field it also displays.
_ADMIN_ONLY_FIELDS = {"application_name", "epic_number", "cr_number"}


@router.put("/{req_id}", response_model=schemas.FunctionalOut)
def update_functional(req_id: int, payload: schemas.FunctionalUpdate, db: Session = Depends(get_db),
                       current_user: models.User = Depends(get_current_user)):
    """Lets the requester (or SM/Department Head of the requester's own
    department) fix up a Functional Testing Request's details after it's
    been raised -- including the "Application & Change Details"/"Release &
    Environment" fields that are otherwise stuck once the QA Request gateway
    itself leaves DRAFT (see constants.GATEWAY_EDITABLE_STATUSES), since this
    request type has always shown them but, until now, had no way back in to
    correct one. QA (QA Lead/QA Engineer) deliberately has NO edit access
    here -- editing is a business-side (requester/SM/Department Head)
    concern, not QA's; QA's own recourse is to Return the request, which
    puts it back into an editable status for the requester. Same
    editable-status gate as the other modules' Edit Details endpoints
    (RETURNED_BY_QA_LEAD is still in FUNCTIONAL_EDITABLE_STATUSES -- that's
    "returned to requester", not "QA may edit"). Application Name/Epic
    Number/CR Number are further restricted to Admins only -- see
    _ADMIN_ONLY_FIELDS."""
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    # See _can_edit_details's own docstring below for the full permission
    # model (requester while it's theirs/returned to them; SM/Department
    # Head only while it's genuinely pending their own decision).
    if obj.status not in FUNCTIONAL_EDITABLE_STATUSES:
        raise HTTPException(400, f"Request cannot be edited while in status '{obj.status}'")
    if not _can_edit_details(db, obj, current_user):
        raise HTTPException(403, "You do not have permission to edit this request in its current status")
    data = payload.model_dump(exclude_unset=True)
    if not current_user.has_role(Role.ADMIN):
        for f in _ADMIN_ONLY_FIELDS:
            if f in data and data[f] != getattr(obj, f):
                raise HTTPException(403, f"Only an Administrator can change {f.replace('_', ' ').title()}")
    checked_items = data.pop("checked_items", None)
    if "change_type" in data or "business_defect_number" in data:
        data["business_defect_number"] = business_defect_number(
            data.get("business_defect_number", obj.business_defect_number),
            data.get("change_type", obj.change_type),
        )
    # Same Deployment/Target Promotion Environment ordering rule as
    # routers/qa_requests.py's create_request/edit_request -- environment/
    # target_promotion_environment are delegated (read-only) properties on
    # `obj` that resolve through obj.qa_request, so they can be read directly
    # here as the "not part of this particular edit" fallback the same way
    # edit_request falls back to its own obj's current values.
    if "environment" in data or "target_promotion_environment" in data:
        final_environment = data.get("environment", obj.environment)
        final_target = data.get("target_promotion_environment", obj.target_promotion_environment)
        try:
            validate_environment_promotion(final_environment, final_target)
        except ValueError as e:
            raise HTTPException(400, str(e))
    if "target_release_date" in data:
        try:
            validate_target_release_date(data["target_release_date"])
        except ValueError as e:
            raise HTTPException(400, str(e))
    # Reported directly ("Duplicate Application Name Validation Across All
    # Request Actions"): application_name used to fall straight into the
    # generic setattr(obj.qa_request, k, v) branch below -- a bare string
    # write with zero case/whitespace normalization and no dedup check
    # against models.ApplicationMaster, and obj.qa_request.application_master_id
    # was never updated to match, leaving the gateway's own approval-status
    # tracking stale. Popped out and routed through the same
    # resolve_application_name/cleanup_orphaned_application_master pair
    # routers/qa_requests.py::edit_request already uses for this exact field
    # on this exact same underlying QARequest row, so an Admin correcting a
    # typo here reuses an existing name (any case/spacing variant) instead of
    # silently creating a near-duplicate ApplicationMaster entry, same as
    # every other Application Name entry point in the app. Only re-resolved
    # when genuinely different from what's already saved (case/whitespace-
    # insensitive) -- same guard edit_request uses, so a plain re-save of an
    # unrelated field never re-touches it.
    application_name_in = data.pop("application_name", None)
    if application_name_in is not None and obj.qa_request:
        incoming_upper = (application_name_in or "").strip().upper()
        if incoming_upper != (obj.qa_request.application_name or "").strip().upper():
            old_master_id = obj.qa_request.application_master_id
            obj.qa_request.application_name, obj.qa_request.application_master_id = app_names.resolve_application_name(
                db, application_name_in, obj.qa_request.department, current_user.id, qa_request_id=obj.qa_request.id,
            )
            # Modules belong to the original application. Match the gateway
            # editor's behavior when this shared parent changes application.
            obj.qa_request.module_name = None
            app_names.cleanup_orphaned_application_master(db, old_master_id, obj.qa_request.id)
    for k, v in data.items():
        if k in _FUNCTIONAL_OWN_FIELDS:
            setattr(obj, k, v)
        elif obj.qa_request:
            # Standalone creation is disabled (see create_functional above),
            # so obj.qa_request should always be set for a real row -- this
            # guard just avoids a crash on the theoretical legacy row with
            # none, rather than silently pretending the edit succeeded.
            setattr(obj.qa_request, k, v)
    if checked_items is not None:
        # Lets the requester revisit their "Ready for Testing" readiness
        # checklist self-declaration from this same Edit Details modal --
        # previously the only place to tick these was the QA Request wizard
        # at intake time, with no way back in at all afterward (unlike
        # Performance/SAST/DAST, which already supported this).
        checked_set = set(checked_items)
        for item in obj.checklist_items:
            item.requester_checked = item.item in checked_set
    db.commit()
    db.refresh(obj)
    return obj


# ---- Requester: Draft -> Submitted -> SM Approval Pending ----
@router.post("/{req_id}/submit", response_model=schemas.FunctionalOut)
def submit_request(req_id: int, db: Session = Depends(get_db),
                    current_user: models.User = Depends(require_roles(*QA_REQUEST_CREATOR_ROLES))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    if obj.requester_id != current_user.id and not current_user.has_role(Role.ADMIN):
        raise HTTPException(403, "Only the requester or an admin can submit this request")
    _require(obj, QAStatus.DRAFT, "Submit")
    obj.status = QAStatus.SUBMITTED
    _log(db, obj.id, "Requester", current_user, "Submitted", None)
    if obj.application_master_status == "REJECTED":
        # The Application Name this request uses (delegated from its parent
        # QA Request) was already rejected by an SM -- see
        # routers/applications.py::_auto_reject_linked_requests, which
        # force-rejects any request that's already sitting at SM Approval
        # the moment the name is rejected. This covers the other case: a
        # sibling request (e.g. SAST/DAST) that only reaches Submit
        # *after* the name was already rejected shouldn't get a fresh shot at
        # SM Approval under a name that's already known-bad -- it lands
        # straight at Rejected instead.
        obj.status = QAStatus.SM_REJECTED
        _log(db, obj.id, "SM Approval", current_user, "Rejected",
             "Auto-rejected: this request's Application Name was rejected by SM")
    else:
        obj.status = QAStatus.SM_APPROVAL_PENDING
        _log(db, obj.id, "SM Approval", current_user, "Pending", "Awaiting SM decision")
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/{req_id}/resubmit", response_model=schemas.FunctionalOut)
def resubmit_request(req_id: int, db: Session = Depends(get_db),
                      current_user: models.User = Depends(require_roles(*QA_REQUEST_CREATOR_ROLES))):
    """Re-submits a request returned by SM, by the Department Head, or by the
    QA Lead -- or reopens one rejected by SM. Reported directly: a Rejected-
    by-SM request used to be a dead end (see QA_REQUEST_TERMINAL_STATUSES),
    with no way back in even if the requester fixed whatever caused the
    rejection. It's now reopenable the same way a Return is: edit details,
    then call this endpoint to send it straight back to SM_APPROVAL_PENDING
    for a fresh decision."""
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    if obj.requester_id != current_user.id and not current_user.has_role(Role.ADMIN):
        raise HTTPException(403, "Only the requester or an admin can resubmit this request")
    if obj.active_delegation:
        raise HTTPException(400, "The active delegation must be returned or recalled before resubmission")
    _require(obj, [QAStatus.RETURNED_BY_SM, QAStatus.SM_REJECTED,
                   QAStatus.RETURNED_BY_DEPARTMENT_HEAD, QAStatus.RETURNED_BY_QA_LEAD],
             "Resubmit")
    require_scope_satisfied(db, obj)
    doc_store.require_mandatory_checklist_evidence(
        db, "FUNCTIONAL_ITEM", obj.checklist_items,
    )
    if obj.status in (QAStatus.RETURNED_BY_SM, QAStatus.SM_REJECTED):
        reopening = obj.status == QAStatus.SM_REJECTED
        if obj.application_master_status == "REJECTED":
            obj.status = QAStatus.SM_REJECTED
            _log(db, obj.id, "SM Approval", current_user, "Rejected",
                 "Auto-rejected: this request's Application Name was rejected by SM")
        else:
            obj.status = QAStatus.SM_APPROVAL_PENDING
            _log(db, obj.id, "SM Approval", current_user,
                 "Reopened" if reopening else "Resubmitted",
                 "Rejected request reopened and re-submitted" if reopening else "Returned request re-submitted")
    elif obj.status == QAStatus.RETURNED_BY_DEPARTMENT_HEAD:
        # A genuine direct return from Department Head Approval itself.
        obj.status = QAStatus.DEPARTMENT_HEAD_APPROVAL_PENDING
        _log(db, obj.id, "Department Head Approval", current_user, "Resubmitted", "Returned request re-submitted")
    elif obj.status == QAStatus.RETURNED_BY_QA_LEAD and obj.needs_dept_head_reapproval:
        # QA Lead returned it but flagged that the fix needs a fresh
        # Department Head approval before Readiness Verification resumes.
        obj.status = QAStatus.DEPARTMENT_HEAD_APPROVAL_PENDING
        obj.needs_dept_head_reapproval = False
        _log(db, obj.id, "Department Head Approval", current_user, "Resubmitted",
             "Returned request re-submitted (Department Head re-approval required)")
    else:
        obj.status = QAStatus.READINESS_VERIFICATION
        obj.needs_dept_head_reapproval = False
        _log(db, obj.id, "Readiness Verification", current_user, "Resubmitted", "Returned request re-submitted")
    db.commit()
    db.refresh(obj)
    return obj


# ---- SM Approval: Approve (-> Department Head) / Return / Reject ----
@router.post("/{req_id}/sm-decision", response_model=schemas.FunctionalOut)
def sm_decision(req_id: int, payload: schemas.WorkflowDecision, db: Session = Depends(get_db),
                current_user: models.User = Depends(require_roles(Role.SM))):
    """Checkpoint between the requester's submission and Department Head
    approval. A Return goes back to the requester for correction; a Reject
    closes the request out (SM_REJECTED, terminal)."""
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    require_same_department(current_user, obj.department)
    require_department_unit_action_scope(
        db, current_user, obj.department,
        obj.qa_request.department_unit_id if obj.qa_request else None,
    )
    require_not_requester(current_user, obj.requester_id)
    _require(obj, QAStatus.SM_APPROVAL_PENDING, "SM decision")
    if payload.decision == "Approved" and obj.application_master_status not in (None, "APPROVED"):
        raise HTTPException(400, application_name_block_message(obj.application_master_status, "sm"))
    if payload.decision == "Approved":
        obj.status = QAStatus.DEPARTMENT_HEAD_APPROVAL_PENDING
    elif payload.decision == "Returned":
        obj.status = QAStatus.RETURNED_BY_SM
    elif payload.decision == "Rejected":
        obj.status = QAStatus.SM_REJECTED
    else:
        raise HTTPException(400, "decision must be one of: Approved, Returned, Rejected")
    record_return_requirement(db, obj, payload, current_user)
    _log(db, obj.id, "SM Approval", current_user, payload.decision, payload.comments)
    db.commit()
    db.refresh(obj)
    return obj


# ---- Department Head Approval: Approve / Return / Reject ----
@router.post("/{req_id}/department-head-decision", response_model=schemas.FunctionalOut)
def department_head_decision(req_id: int, payload: schemas.DepartmentHeadDecisionIn, db: Session = Depends(get_db),
                              current_user: models.User = Depends(require_roles(Role.DEPARTMENT_HEAD_CM, Role.DEPARTMENT_HEAD_AGM))):
    """Department Head approves the request for the workspace's QA Lead group."""
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    require_same_department(current_user, obj.department)
    require_department_unit_action_scope(
        db, current_user, obj.department,
        obj.qa_request.department_unit_id if obj.qa_request else None,
    )
    require_not_requester(current_user, obj.requester_id)
    _require(obj, QAStatus.DEPARTMENT_HEAD_APPROVAL_PENDING, "Department Head decision")
    _require_distinct_department_head_approver(db, obj, current_user)
    if payload.decision == "Approved" and obj.application_master_status not in (None, "APPROVED"):
        raise HTTPException(400, application_name_block_message(obj.application_master_status, "department_head"))
    obj.department_head_id = current_user.id

    if payload.decision == "Approved":
        obj.qa_lead_id = None
        obj.status = QAStatus.QA_LEAD_ASSIGNED
    elif payload.decision == "Returned":
        obj.status = QAStatus.RETURNED_BY_DEPARTMENT_HEAD
    elif payload.decision == "Rejected":
        obj.status = QAStatus.DEPARTMENT_HEAD_REJECTED
    else:
        raise HTTPException(400, "decision must be one of: Approved, Returned, Rejected")

    record_return_requirement(db, obj, payload, current_user)
    _log(db, obj.id, "Department Head Approval", current_user, payload.decision, payload.comments)
    db.commit()
    db.refresh(obj)
    return obj


# ---- QA Lead: Readiness Verification ----
@router.post("/{req_id}/start-readiness-verification", response_model=schemas.FunctionalOut)
def start_readiness_verification(req_id: int, db: Session = Depends(get_db),
                                  current_user: models.User = Depends(require_roles(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, QAStatus.QA_LEAD_ASSIGNED, "Start readiness verification")
    _require_assigned_qa_lead(obj, current_user)
    obj.qa_lead_id = current_user.id
    obj.status = QAStatus.READINESS_VERIFICATION
    _log(db, obj.id, "QA Readiness", current_user, "Started", "Readiness verification started by assigned QA Lead")
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/{req_id}/readiness-decision", response_model=schemas.FunctionalOut)
def readiness_decision(req_id: int, payload: schemas.ReadinessDecisionIn, db: Session = Depends(get_db),
                        current_user: models.User = Depends(require_roles(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, QAStatus.READINESS_VERIFICATION, "Readiness decision")
    _require_assigned_qa_lead(obj, current_user)
    if payload.decision == "Passed":
        # Every item the requester actually self-declared ready
        # (requester_checked) must be QA-verified (is_complete) before
        # Readiness Verification can Pass. Scoped to requester_checked rather
        # than every item on the list -- an item the requester never declared
        # ready in the first place can't be QA-verified anyway (see
        # update_checklist_item's own gate below), so requiring it here too
        # would permanently block Passed with no way forward; the requester
        # simply never claimed it, so it isn't part of what QA is confirming.
        # This checklist is Admin-configurable now (see checklist_config.py)
        # -- a mandatory item is already forced to be self-declared
        # (requester_checked) before the request can even be raised (see
        # routers/qa_requests.py::submit_request's pending_checklist_items
        # gate), so by the time a request reaches Readiness Verification at
        # all, every mandatory item is already inside the requester_checked
        # set checked below -- no separate mandatory-only check is needed
        # here on top of it.
        pending = [c.item for c in obj.checklist_items if c.requester_checked and not c.is_complete]
        if pending:
            raise HTTPException(400, f"Readiness checklist incomplete: {', '.join(pending)}")
        obj.status = QAStatus.QA_ACTIVITY_INITIATED
    elif payload.decision == "Failed":
        # The QA Lead acting here chooses whether this return needs
        # a fresh Department Head approval (routes back through
        # DEPARTMENT_HEAD_APPROVAL_PENDING on resubmit) or can go straight
        # back to them once the requester fixes it (the default -- same QA
        # Lead, no re-approval needed). Status is always RETURNED_BY_QA_LEAD --
        # the QA Lead is who actually returned it -- never
        # RETURNED_BY_DEPARTMENT_HEAD (misleading: that reads as though the
        # Department Head personally returned it, when they haven't even seen
        # it yet). The re-approval choice is tracked separately via
        # needs_dept_head_reapproval, which `resubmit` below reads to decide
        # routing, and which the frontend surfaces as a note next to the
        # (accurate) status badge.
        obj.status = QAStatus.RETURNED_BY_QA_LEAD
        obj.needs_dept_head_reapproval = payload.require_dept_head_reapproval
    else:
        raise HTTPException(400, "decision must be one of: Passed, Failed")
    # Group members may hand off readiness; retain the actual decision-maker
    # in the same transaction as the decision and its history entry.
    obj.qa_lead_id = current_user.id
    _log(db, obj.id, "Readiness Verification", current_user, payload.decision, payload.comments)
    db.commit()
    db.refresh(obj)
    return obj


# ---- QA Activity: Planning -> Tester Assignment -> Test Design -> Execution ----
@router.post("/{req_id}/begin-planning", response_model=schemas.FunctionalOut)
def begin_planning(req_id: int, db: Session = Depends(get_db),
                    current_user: models.User = Depends(require_roles(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, QAStatus.QA_ACTIVITY_INITIATED, "Begin planning")
    _require_assigned_qa_lead(obj, current_user)
    obj.status = QAStatus.PLANNING
    _log(db, obj.id, "QA Activity Initiated", current_user, "Planning Started", None)
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/{req_id}/assign-tester", response_model=schemas.FunctionalOut)
def assign_tester(req_id: int, payload: schemas.AssignTesterIn, db: Session = Depends(get_db),
                   current_user: models.User = Depends(require_roles(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA, Role.QA_ENGINEER))):
    """2026-08 -- reported directly: "once assigned there are no other
    option to reassign the tester or modify the tester." Previously only
    ever callable while status was exactly PLANNING (the very first
    assignment) by the QA Lead group -- see TESTER_REASSIGNABLE_STATUSES'
    own comment on constants.py. Now callable through the whole active-
    testing range, by either the QA Lead group OR any currently-assigned
    tester on this request (self-handoff to another QA member, see
    _require_assigned_qa_lead_or_current_tester above). Reassigning after
    the initial PLANNING->TESTER_ASSIGNED transition deliberately does NOT
    touch `status` -- a request already at, say, EXECUTION_IN_PROGRESS must
    stay there after a tester swap, not regress back to "Tester Assigned"
    and lose track of where the work actually is.

    2026-08 Reassignment CR -- once this is a genuine reassignment (status
    already past PLANNING), eligibility narrows to
    _require_can_reassign_tester (current tester / workspace QA Executive /
    Admin) and a reason becomes mandatory; the newly-added tester(s) are
    notified, and a dedicated "Reassigned" audit row (with previous/new
    names and the reason) is written alongside the existing history log
    entry below."""
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, TESTER_REASSIGNABLE_STATUSES, "Assign tester")
    is_initial_assignment = obj.status == QAStatus.PLANNING
    previous_ids = _assigned_tester_ids(obj)
    if is_initial_assignment:
        _require_assigned_qa_lead_or_current_tester(obj, current_user)
    else:
        _require_can_reassign_tester(obj, current_user)
        reassignment.require_reason(payload.reason)
    if not payload.tester_ids:
        raise HTTPException(400, "At least one tester_id is required")
    unique_ids = list(dict.fromkeys(payload.tester_ids))
    testers = [_it_qa_user(db, tester_id, Role.QA_ENGINEER, f"tester_id {tester_id}", obj.qa_request.qa_workspace_id if obj.qa_request else None) for tester_id in unique_ids]
    obj.assigned_tester_ids = ",".join(str(i) for i in unique_ids)
    if is_initial_assignment:
        obj.status = QAStatus.TESTER_ASSIGNED
    # Resolve to full names for the history log -- previously logged the raw
    # numeric ids (e.g. "Assigned tester user ids: [3]"), which meant nothing
    # to anyone reading the History tab. Falls back to "user #<id>" for any
    # id that doesn't resolve (e.g. a since-deleted account).
    name_by_id = {u.id: u.full_name for u in testers}
    tester_names = [name_by_id[i] for i in unique_ids]
    decision = "Tester Assigned" if is_initial_assignment else "Tester Reassigned"
    step = "Planning" if is_initial_assignment else QA_REQUEST_STATUS_LABELS.get(obj.status, obj.status)
    _log(db, obj.id, step, current_user, decision, f"Assigned tester(s): {', '.join(tester_names)}")
    if not is_initial_assignment:
        previous_users = db.query(models.User).filter(models.User.id.in_(previous_ids)).all() if previous_ids else []
        previous_label = ", ".join(u.full_name for u in previous_users) if previous_users else "Unassigned"
        reassignment.record_reassignment(
            db, "FUNCTIONAL_REQUEST", obj.id, current_user,
            previous_label, ", ".join(tester_names), payload.reason,
            assignment_role="QA_TESTER",
            previous_assignee_ids=previous_ids,
            new_assignee_ids=unique_ids,
        )
    else:
        reassignment.record_assignment_change(
            db, "FUNCTIONAL_REQUEST", obj.id, "QA_TESTER", current_user,
            previous_ids, unique_ids, payload.reason,
        )
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/{req_id}/start-test-design", response_model=schemas.FunctionalOut)
def start_test_design(req_id: int, db: Session = Depends(get_db),
                       current_user: models.User = Depends(require_roles( Role.QA_ENGINEER))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, QAStatus.TESTER_ASSIGNED, "Start test design")
    _require_assigned_tester(obj, current_user)
    obj.status = QAStatus.TEST_DESIGN
    _log(db, obj.id, "Tester Assigned", current_user, "Test Design Started", None)
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/{req_id}/start-execution", response_model=schemas.FunctionalOut)
def start_execution(req_id: int, payload: schemas.StartFunctionalExecutionIn,
                     db: Session = Depends(get_db),
                     current_user: models.User = Depends(require_roles(Role.QA_LEAD, Role.QA_ENGINEER))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, QAStatus.TEST_DESIGN, "Start execution")
    _require_assigned_tester(obj, current_user)
    # A link can be created from either side of the relationship. Resolve it
    # before evaluating this request so starting from Functional never asks
    # for (or creates) a second link when Test Lifecycle already linked one.
    discovered_link = (db.query(models.TestCycleChildRequestLink)
                       .filter_by(child_type="Functional", child_id=obj.id)
                       .order_by(models.TestCycleChildRequestLink.id.asc())
                       .first())
    discovered_cycle, should_create_link = execution_cycle_choice(
        discovered_link, payload.test_cycle_id,
    )
    cycle_id = (
        payload.test_cycle_id if should_create_link else discovered_cycle.id
    )
    # Global workflow lock order is Functional -> TestCycle -> link row. The
    # Functional row above prevents any compliant relink/unlink path from
    # changing an existing association; locking/reloading the selected cycle
    # and its unique association closes the standalone-cycle race with PATCH,
    # delete, and another request's Start Execution.
    cycle = (
        db.query(models.TestCycle)
        .filter(models.TestCycle.id == cycle_id)
        .populate_existing()
        .with_for_update()
        .one_or_none()
    )
    if cycle is None or not cycle.project or not cycle.project.is_active:
        raise HTTPException(
            400,
            "The selected test cycle is no longer eligible (only Draft, Ready, or In Progress cycles can be linked)",
        )
    locked_cycle_link = (
        db.query(models.TestCycleChildRequestLink)
        .filter(models.TestCycleChildRequestLink.cycle_id == cycle.id)
        .populate_existing()
        .with_for_update()
        .one_or_none()
    )
    if discovered_link is not None:
        if (
            locked_cycle_link is None
            or locked_cycle_link.id != discovered_link.id
            or locked_cycle_link.child_type != "Functional"
            or locked_cycle_link.child_id != obj.id
        ):
            raise HTTPException(
                409,
                "The Test Cycle request link changed concurrently; refresh before starting execution",
            )
    elif locked_cycle_link is not None:
        raise HTTPException(400, "This test cycle is already linked to another request")

    require_cycle_startable(cycle)
    if should_create_link:
        from .. import cycle_request_preview
        from ..deps import require_can_execute_project
        require_can_execute_project(db, cycle.project_id, current_user)
        cycle_request_preview.refresh_parent(db, obj, lock=True)
        application_master_id = obj.qa_request.application_master_id if obj.qa_request else None
        if (application_master_id and cycle.project.application_master_id is not None
                and cycle.project.application_master_id != application_master_id):
            raise HTTPException(400, "The selected test cycle is not relevant to this request's application")
        request_workspace_id = obj.qa_request.qa_workspace_id if obj.qa_request else None
        if (cycle.origin_workspace_id or cycle.project.qa_workspace_id) != request_workspace_id:
            raise HTTPException(400, "The Test Cycle and Functional QA Request must belong to the same workspace")
        review_id = cycle_request_preview.require_confirmed(
            db, payload.request_preview_token, current_user, cycle.project, obj, cycle.id,
        )
        db.add(models.TestCycleChildRequestLink(
            cycle_id=cycle.id, child_type="Functional", child_id=obj.id, child_key=obj.request_id,
        ))
        cycle_request_preview.applied(db, review_id, cycle, obj, current_user)
    obj.status = QAStatus.EXECUTION_IN_PROGRESS
    _log(
        db, obj.id, "Test Design", current_user, "Execution Started",
        f"Using test cycle {cycle.cycle_key} - {cycle.name}",
    )
    try:
        db.commit()
    except IntegrityError:
        # Reported directly (vague at first -- "sometimes getting key
        # issue" on an unnamed modal): the `cycle_link` pre-check above
        # (line ~649) gives a fast, friendly 400 in the common case, but
        # leaves a race window between two near-simultaneous "Start
        # Execution, link this cycle" calls for the SAME cycle from
        # different requests -- both pass the check, both insert into
        # qap_test_cycle_child_links (unique on cycle_id alone), and the
        # second commit trips that constraint. Same fix shape as
        # test_execution.py's create_cycle_folder_access.
        db.rollback()
        raise HTTPException(400, f"Test cycle {cycle.cycle_key} was just linked to another request -- refresh and try again")
    db.refresh(obj)
    return obj


@router.get("/{req_id}/eligible-test-cycles", response_model=List[schemas.EligibleTestCycleOut])
def eligible_test_cycles(req_id: int, db: Session = Depends(get_db),
                         current_user: models.User = Depends(require_roles(Role.QA_LEAD, Role.QA_ENGINEER))):
    obj = _get_or_404(db, req_id)
    _require(obj, QAStatus.TEST_DESIGN, "List eligible test cycles")
    _require_assigned_tester(obj, current_user)
    query = (db.query(models.TestCycle)
             .join(models.TestProject, models.TestCycle.project_id == models.TestProject.id)
             .outerjoin(models.TestCycleChildRequestLink, models.TestCycleChildRequestLink.cycle_id == models.TestCycle.id)
             .filter(models.TestProject.is_active == True,  # noqa: E712 - Oracle requires = 1, not IS 1
                     models.TestCycle.status.in_(_LINKABLE_TEST_CYCLE_STATUSES),
                     models.TestCycleChildRequestLink.id.is_(None)))
    application_master_id = obj.qa_request.application_master_id if obj.qa_request else None
    if application_master_id:
        query = query.filter(models.TestProject.application_master_id == application_master_id)
    else:
        # A Functional request without an approved Application mapping
        # cannot be paired safely with an application-bound Test Project.
        query = query.filter(False)
    request_workspace_id = obj.qa_request.qa_workspace_id if obj.qa_request else None
    query = query.filter(func.coalesce(models.TestCycle.origin_workspace_id, models.TestProject.qa_workspace_id) == request_workspace_id)
    cycles = query.order_by(models.TestCycle.created_at.desc()).all()
    return [{
        "id": cycle.id, "cycle_key": cycle.cycle_key, "project_id": cycle.project_id,
        "project_key": cycle.project.project_key, "project_name": cycle.project.name,
        "name": cycle.name, "status": cycle.status, "start_date": cycle.start_date,
        "end_date": cycle.end_date,
    } for cycle in cycles]


@router.delete("/{req_id}/test-cycles/{cycle_id}", response_model=schemas.FunctionalOut)
def unlink_test_cycle(req_id: int, cycle_id: int, db: Session = Depends(get_db),
                      current_user: models.User = Depends(require_roles(Role.QA_LEAD, Role.QA_ENGINEER))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    can_manage = (current_user.has_role(Role.ADMIN) or obj.qa_lead_id == current_user.id
                  or current_user.id in _assigned_tester_ids(obj))
    if not can_manage:
        raise HTTPException(403, "Only the assigned QA Lead or Tester can unlink this test cycle")
    link = db.query(models.TestCycleChildRequestLink).filter_by(
        cycle_id=cycle_id, child_type="Functional", child_id=obj.id,
    ).first()
    if not link:
        raise HTTPException(404, "This test cycle is not linked to the Functional Testing request")
    require_cycle_unlinkable(obj.status)
    db.delete(link)
    _log(
        db, obj.id, obj.status, current_user, "Test Cycle Unlinked",
        f"Removed test cycle {link.cycle.cycle_key}; it remains available as a standalone cycle.",
    )
    db.commit()
    db.refresh(obj)
    return obj


# ---- Defect -> Fix -> Retest -> Regression cycle ----
# Workflow change (reported directly: "raise defect, start retest currently
# not required as everything is linked with test cycle"): once a Test Cycle
# is linked to this request (mandatory in start_execution),
# defects are raised, tracked, and retested through Test Execution + the
# Defects module -- both scoped to that Test Cycle -- instead of this
# request's own manual Defect Raised -> Waiting For Fix -> Retesting states.
# The entry point is retired now that a Test Cycle is mandatory. The later
# waiting/retest endpoints remain only so historical records already in those
# states are not stranded.


@router.post("/{req_id}/raise-defect", response_model=schemas.FunctionalOut)
def raise_defect(req_id: int, payload: schemas.CommentIn, db: Session = Depends(get_db),
                  current_user: models.User = Depends(require_roles(Role.QA_ENGINEER))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, QAStatus.EXECUTION_IN_PROGRESS, "Raise defect")
    _require_assigned_tester(obj, current_user)
    raise HTTPException(
        400,
        "Raise defects from Test Execution / the Defects module against the linked Test Cycle.",
    )


@router.post("/{req_id}/mark-waiting-for-fix", response_model=schemas.FunctionalOut)
def mark_waiting_for_fix(req_id: int, payload: schemas.CommentIn, db: Session = Depends(get_db),
                          current_user: models.User = Depends(require_roles(Role.QA_ENGINEER))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, QAStatus.DEFECT_RAISED, "Mark waiting for fix")
    _require_assigned_tester(obj, current_user)
    obj.status = QAStatus.WAITING_FOR_FIX
    _log(db, obj.id, "Defect Raised", current_user, "Waiting For Fix", payload.comments)
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/{req_id}/start-retesting", response_model=schemas.FunctionalOut)
def start_retesting(req_id: int, payload: schemas.CommentIn, db: Session = Depends(get_db),
                     current_user: models.User = Depends(require_roles(Role.QA_LEAD, Role.QA_ENGINEER))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, QAStatus.WAITING_FOR_FIX, "Start retesting")
    _require_assigned_tester(obj, current_user)
    obj.status = QAStatus.RETESTING
    _log(db, obj.id, "Waiting For Fix", current_user, "Retesting Started", payload.comments)
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/{req_id}/complete-qa", response_model=schemas.FunctionalOut)
def complete_qa(req_id: int, payload: schemas.CommentIn, db: Session = Depends(get_db),
                 current_user: models.User = Depends(require_roles(Role.QA_ENGINEER))):
    """Marks QA activity complete -- reachable directly from execution (no issues found)
    or after the defect/retest cycle.

    Not gated on any SAST/DAST/Performance sibling raised alongside it on the
    same gateway QA Request -- every request type runs its own fully
    independent workflow end-to-end (see models.QARequest's own docstring:
    "QA request form is the gateway only"), so Functional completing has
    never depended on -- and now explicitly does not wait for -- a sibling
    request's own status."""
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, [QAStatus.EXECUTION_IN_PROGRESS, QAStatus.RETESTING], "Complete QA")
    _require_assigned_tester(obj, current_user)

    # Workflow change (reported directly): once execution is tracked through
    # a linked Test Cycle, that cycle's own lifecycle is the real record of
    # whether testing actually finished -- QA Complete can no longer jump
    # ahead of it. At least one linked cycle is required and every linked
    # cycle must reach "Completed" first. See raise_defect's matching comment for why
    # the Defect Raised/Waiting For Fix/Retesting states are no longer part
    # of this path once a cycle is linked.
    require_cycles_completed(obj.linked_test_cycles)
    _require_held_clearance_retest_leaf_completed(obj)

    obj.status = QAStatus.QA_COMPLETED
    _log(db, obj.id, "Execution", current_user, "QA Completed", payload.comments)
    db.commit()
    db.refresh(obj)
    return obj


# ---- QA Clearance -> Requester Verification -> Closed ----
@router.post("/{req_id}/request-signoff", response_model=schemas.FunctionalOut)
def request_signoff(req_id: int, payload: schemas.RequestSignoffIn = schemas.RequestSignoffIn(),
                     db: Session = Depends(get_db),
                     current_user: models.User = Depends(require_roles(
                         Role.QA_ENGINEER, Role.QA_LEAD,
                         Role.CHIEF_MANAGER_QA, Role.AGM_QA,
                     ))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, QAStatus.QA_COMPLETED, "Request clearance")
    # 2026-08 -- reported directly: "'Request Sign Off' button is not
    # enable[d] for QA lead ... if tester [is] no[t] available then at
    # least [o]n behalf of QA he can raise the request." Previously this
    # called _require_assigned_tester, which only ever let the literal
    # assigned tester (or Admin) through -- the route's own
    # require_roles(QA_LEAD, QA_ENGINEER) above never actually reached a
    # QA Lead in practice. Now the QA Lead group can always raise sign-off
    # on a request they own, same "QA Lead group OR current tester" shape
    # as tester reassignment.
    _require_assigned_qa_lead_or_current_tester(obj, current_user, "request sign-off on this request")
    certificate_summary.require_linked_security_resolved(db, obj)
    newly_linked = False
    # The frontend now creates the QA Clearance Certificate (POST /api/signoffs)
    # right before calling this, via SignOff.tsx's NewSignOffModal opened from
    # this request's own "Request Sign-off" button -- link it immediately
    # rather than leaving it to confirm-signoff, so the certificate is
    # associated with this request from the moment sign-off is requested.
    if payload.signoff_id is not None:
        if obj.signoff_id is not None and obj.signoff_id != payload.signoff_id:
            raise HTTPException(409, "This Functional Request is already linked to another clearance certificate")
        cert = _clearance_certificate_for_request(
            db,
            obj,
            payload.signoff_id,
            current_user=current_user,
            require_requester_ownership=True,
            allow_denied=True,
        )
        if obj.signoff_id is None:
            obj.signoff_id = cert.id
            newly_linked = True
    elif obj.signoff_id is not None:
        # A retry may omit the ID, but an existing link must still satisfy
        # the request/workspace/type constraints before the workflow moves.
        _clearance_certificate_for_request(
            db, obj, obj.signoff_id, allow_denied=True,
        )
    # Linking a Draft does not put work in the QA Lead bucket. The request
    # deliberately remains QA_COMPLETED (owned by the assigned QA team)
    # until the certificate requester submits the Draft; submit_signoff then
    # advances it atomically to QA_SIGNOFF_PENDING.
    if newly_linked:
        _log(
            db, obj.id, "QA Completed", current_user,
            "Clearance Draft Linked",
            f"Certificate {cert.certificate_id} linked to the Functional Request.",
        )
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/{req_id}/confirm-signoff", response_model=schemas.FunctionalOut)
def confirm_signoff(req_id: int, payload: schemas.ConfirmSignoffIn, db: Session = Depends(get_db),
                     current_user: models.User = Depends(require_roles(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA))):
    """Confirms the QA Clearance certificate (optionally linking a Module 8 QASignOff
    record created via /api/signoffs) and hands the request to the requester for
    final verification.

    Superseded for the normal case: routers/signoff.py::department_head_coe_decision
    now does this automatically the instant a certificate reaches ISSUED (see
    _sync_linked_functional_request there) -- a QA Lead no longer needs to
    remember a separate manual click, and the frontend's own "Confirm Sign-off"
    button has been removed (see Functional.tsx). Left in place, not deleted, as
    a manual fallback (e.g. a certificate issued before this change existed, with
    no linked FunctionalRequest.signoff_id yet to auto-sync against) -- reachable
    only while status is still QA_SIGNOFF_PENDING, which the auto-sync above
    already moves past for every certificate it successfully links."""
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    _require(obj, QAStatus.QA_SIGNOFF_PENDING, "Confirm clearance")
    if obj.signoff_id is not None and payload.signoff_id is not None and obj.signoff_id != payload.signoff_id:
        raise HTTPException(409, "This Functional Request is already linked to another clearance certificate")
    signoff_id = payload.signoff_id if payload.signoff_id is not None else obj.signoff_id
    if signoff_id is None:
        raise HTTPException(409, "Requester verification requires an issued clearance certificate")
    cert = _clearance_certificate_for_request(
        db, obj, signoff_id, require_issued=True, allow_denied=True,
    )
    obj.signoff_id = cert.id
    if cert.certificate_type == "Clearance Denied":
        _log(
            db, obj.id, "QA Clearance Decision", current_user,
            "Clearance Denied",
            payload.comments or (
                f"Certificate {cert.certificate_id} issued the QA denial decision; "
                "this is not a positive clearance."
            ),
        )
    else:
        obj.status = QAStatus.QA_SIGNED_OFF
        _log(db, obj.id, "QA Clearance", current_user, "Cleared", payload.comments)
    obj.status = QAStatus.REQUESTER_VERIFICATION
    _log(
        db, obj.id, "Requester Verification", current_user,
        "Denial Acknowledgement Pending" if cert.certificate_type == "Clearance Denied" else "Pending",
        (
            "Sent to the requester to acknowledge or return the denial decision for changes."
            if cert.certificate_type == "Clearance Denied"
            else "Sent for requester verification"
        ),
    )
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/{req_id}/requester-decision", response_model=schemas.FunctionalOut)
def requester_decision(req_id: int, payload: schemas.RequesterDecisionIn, db: Session = Depends(get_db),
                        current_user: models.User = Depends(require_roles(
                            *QA_REQUEST_CREATOR_ROLES, Role.APPLICATION_OWNER))):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    if obj.requester_id != current_user.id:
        raise HTTPException(403, "Only the Functional Request requester can record this decision")
    _require(obj, QAStatus.REQUESTER_VERIFICATION, "Requester decision")
    if obj.signoff_id is None:
        raise HTTPException(
            409,
            "Requester verification requires the currently linked issued certificate",
        )
    cert = _clearance_certificate_for_request(
        db,
        obj,
        obj.signoff_id,
        require_issued=True,
        allow_denied=True,
    )
    denial = cert.certificate_type == "Clearance Denied"
    if payload.decision == "Accepted":
        obj.status = QAStatus.CLOSED
        certificate_decision = "Denial Acknowledged" if denial else "Accepted by Requester"
        request_decision = "Denial Acknowledged" if denial else "Accepted"
        db.add(models.ApprovalAction(
            entity_type="SIGNOFF", entity_id=cert.id,
            step_name="Requester Verification", actor_id=current_user.id,
            actor_role=current_user.roles_csv, decision=certificate_decision,
            comments=payload.comments,
        ))
    elif payload.decision == "ChangesRequired":
        # Preserve the signed certificate and evidence exactly as issued.
        # QA first decides whether the feedback is clarification-only,
        # certificate revision, or genuine retesting; no successor Draft is
        # created merely because the requester asked for a discussion.
        if not (payload.comments or "").strip():
            raise HTTPException(400, "A reason is required when requesting changes")
        cert.status = "ISSUED_UNDER_REVIEW"
        obj.status = QAStatus.QA_CHANGE_REVIEW
        request_decision = "ChangesRequired"
        db.add(models.ApprovalAction(
            entity_type="SIGNOFF", entity_id=cert.id,
            step_name="Requester Verification", actor_id=current_user.id,
            actor_role=current_user.roles_csv,
            decision=(
                "Changes Required — Denial Review"
                if denial
                else "Changes Required — QA Review"
            ),
            comments=payload.comments.strip(),
        ))
    else:
        raise HTTPException(400, "decision must be one of: Accepted, ChangesRequired")
    _log(
        db, obj.id, "Requester Verification", current_user,
        request_decision, payload.comments,
    )
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/{req_id}/clearance-change-decision", response_model=schemas.FunctionalOut)
def clearance_change_decision(
    req_id: int,
    payload: schemas.ClearanceChangeDecisionIn,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles(
        Role.QA_ENGINEER, Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA,
    )),
):
    """Resolve a requester-returned issued clearance without mutating evidence."""
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    allowed_statuses = [QAStatus.QA_CHANGE_REVIEW]
    if payload.decision == "ReviseCertificate":
        allowed_statuses.append(QAStatus.QA_COMPLETED)
    _require(obj, allowed_statuses, "QA clearance change decision")
    if obj.signoff_id is None:
        raise HTTPException(409, "This Functional Request has no linked issued certificate")
    cert = _clearance_certificate_for_request(
        db, obj, obj.signoff_id, allow_denied=True,
    )
    allowed_certificate_statuses = {"ISSUED_UNDER_REVIEW"}
    if payload.decision == "ReviseCertificate" and obj.status == QAStatus.QA_COMPLETED:
        # Backward-compatible recovery for a retest completed before the
        # explicit hold state was deployed. New requester returns always use
        # ISSUED_UNDER_REVIEW.
        allowed_certificate_statuses.update({
            "ISSUED", "SM_REJECTED", "DEPT_HEAD_COE_REJECTED",
        })
    if cert.status not in allowed_certificate_statuses:
        raise HTTPException(
            409,
            f"Certificate {cert.certificate_id} in status '{cert.status}' cannot perform "
            f"{payload.decision} while the Functional Request is '{obj.status}'. "
            "Refresh and continue the certificate action available for its current workflow state.",
        )

    assigned_testers = _assigned_tester_ids(obj)
    can_decide = (
        current_user.has_role(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA)
        or current_user.id in assigned_testers
        or (not assigned_testers and cert.requester_id == current_user.id)
    )
    if not can_decide:
        raise HTTPException(
            403,
            "Only the QA Lead group or a currently assigned tester can decide the returned clearance; "
            "the original QA certificate requester is used only when this legacy request has no tester assignment",
        )

    previous_status = obj.status
    if payload.decision == "ResendIssued":
        if previous_status != QAStatus.QA_CHANGE_REVIEW:
            raise HTTPException(400, "Resend Issued is available only during QA Clearance Change Review")
        cert.status = "ISSUED"
        obj.status = QAStatus.REQUESTER_VERIFICATION
        certificate_decision = "Review completed — Issued certificate resent"
        request_decision = "Issued Clearance Resent"
        detail = f"Certificate {cert.certificate_id} was restored to Issued and returned for requester verification."
    elif payload.decision == "ReviseCertificate":
        predecessor_status = cert.status
        successor = certificate_revisions.create_certificate_revision(
            db, cert, current_user, payload.comments,
            successor_requester_id=current_user.id,
        )
        # create_certificate_revision deliberately returns the Functional
        # Request to QA_COMPLETED while the successor belongs to its QA
        # author. Submission, not Draft creation, enters QA Lead review.
        certificate_decision = "Revision Draft Created"
        request_decision = "Certificate Revision Required"
        if predecessor_status in {"SM_REJECTED", "DEPT_HEAD_COE_REJECTED"}:
            detail = (
                f"Certificate {cert.certificate_id} retained terminal status {predecessor_status} "
                f"and was continued by Draft {successor.certificate_id}; full QA Lead and "
                "Executive reapproval is required."
            )
        else:
            detail = (
                f"Certificate {cert.certificate_id} was superseded by Draft "
                f"{successor.certificate_id}; full QA Lead and Executive reapproval is required."
            )
    else:  # Retest
        if previous_status != QAStatus.QA_CHANGE_REVIEW:
            raise HTTPException(400, "Retest is available only during QA Clearance Change Review")
        try:
            successor_cycle = _create_reexecution_cycle(
                db, obj, cert, payload, current_user,
            )
            db.flush()
        except IntegrityError as exc:
            db.rollback()
            raise HTTPException(
                409,
                "A re-execution cycle was created concurrently; refresh and continue the latest cycle",
            ) from exc
        obj.status = QAStatus.EXECUTION_IN_PROGRESS
        certificate_decision = "Retesting required — release authority remains on hold"
        request_decision = "Retesting Required"
        detail = (
            f"Created Draft re-execution cycle {successor_cycle.cycle_key} from "
            f"cycle #{payload.source_cycle_id}; the issued certificate remains under review."
        )

    audit_comments = f"{detail} QA comments: {payload.comments}"
    db.add_all([
        models.ApprovalAction(
            entity_type="SIGNOFF", entity_id=cert.id,
            step_name="QA Change Review", actor_id=current_user.id,
            actor_role=current_user.roles_csv, decision=certificate_decision,
            comments=audit_comments,
        ),
        models.ApprovalAction(
            entity_type="FUNCTIONAL_REQUEST", entity_id=obj.id,
            step_name="QA Clearance Change Review", actor_id=current_user.id,
            actor_role=current_user.roles_csv, decision=request_decision,
            comments=audit_comments,
        ),
    ])
    try:
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        raise HTTPException(
            409,
            "The clearance review changed concurrently; refresh before deciding again",
        ) from exc
    db.refresh(obj)
    db.expire(obj, ["test_cycle_links"])
    return obj


# ---- Readiness checklist (Ready for Testing gate) ----
@router.get("/{req_id}/checklist", response_model=List[schemas.ChecklistItemOut])
def get_checklist(req_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    _require_visible(db, _get_or_404(db, req_id), current_user)
    return db.query(models.ReadinessChecklistItem).filter_by(functional_request_id=req_id).all()


@router.put("/{req_id}/checklist/{item_id}", response_model=schemas.ChecklistItemOut)
def update_checklist_item(req_id: int, item_id: int, payload: schemas.ChecklistItemUpdate,
                           db: Session = Depends(get_db),
                           current_user: models.User = Depends(require_roles(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA))):
    item = db.query(models.ReadinessChecklistItem).filter_by(id=item_id, functional_request_id=req_id).first()
    if not item:
        raise HTTPException(404, "Checklist item not found")
    parent = db.get(models.FunctionalRequest, req_id)
    if not parent or parent.status != QAStatus.READINESS_VERIFICATION:
        raise HTTPException(
            400,
            "Readiness checklist items can only be verified while the request is in "
            "Readiness Verification (i.e. by the QA Lead after Executive Approval) -- "
            "not while still in Draft or any other stage.",
        )
    _require_visible(db, parent, current_user)
    _require_assigned_qa_lead(parent, current_user)
    # The QA Lead verifies the requester's own self-declaration -- they can't
    # tick an item the requester never declared ready in the first place (see
    # the frontend's matching disabled-checkbox behavior in Functional.tsx).
    if payload.is_complete and not item.requester_checked:
        raise HTTPException(
            400,
            "Cannot verify this item -- the requester has not self-declared it ready. "
            "Ask the requester to tick it first (Edit Details), then verify it here.",
        )
    item.is_complete = payload.is_complete
    if payload.is_complete:
        item.approved_by_id = current_user.id
        item.approved_at = models.now()
    else:
        item.approved_by_id = None
        item.approved_at = None
    db.commit()
    db.refresh(item)
    return item


@router.get("/{req_id}/history", response_model=List[schemas.ApprovalActionOut])
def request_history(req_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    _require_visible(db, _get_or_404(db, req_id), current_user)
    return (db.query(models.ApprovalAction)
            .filter_by(entity_type="FUNCTIONAL_REQUEST", entity_id=req_id)
            .order_by(models.ApprovalAction.created_at).all())


@router.get("/{req_id}/export")
def export_functional(req_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    """Every field on this Functional QA request (including the ones
    delegated from its parent QA Request gateway), its readiness checklist,
    and its full approval/workflow history -- who submitted, approved,
    returned, signed off, etc., and when -- as one downloadable PDF."""
    obj = _get_or_404(db, req_id)
    _require_visible(db, obj, current_user)

    tester_names = []
    for uid in (obj.assigned_tester_ids or "").split(","):
        uid = uid.strip()
        if not uid:
            continue
        u = db.get(models.User, int(uid))
        if u:
            tester_names.append(u.full_name)

    sections = [
        ("Status", [
            ("Status", obj.status),
            ("Priority", obj.priority),
            ("Risk Rating", obj.risk_rating),
            ("Request Type(s)", obj.request_types),
        ]),
        ("Application & Change", [
            ("Application Name", obj.application_name),
            *([("Module Name", obj.module_name)] if obj.module_name else []),
            ("CR Number/EPIC Number", obj.cr_number or obj.epic_number),
            ("Change Type", obj.change_type),
            ("Previous Completed Request ID", obj.bug_fix_source_request_id if obj.change_type in {"Bug Fix", "Enhancement"} else None),
            ("Defect Number (Raised By Business)", obj.business_defect_number if obj.change_type == "Bug Fix" else None),
            ("Department", obj.department),
        ]),
        ("Environment & Release", [
            ("Deployment Environment", obj.environment),
            ("Target Promotion Environment", obj.target_promotion_environment),
            ("Release Version / Hash Value", obj.release_version),
            ("Build Number / Hash Value", obj.build_number),
            ("Target Release Date", obj.target_release_date),
        ]),
        ("People", [
            ("Requester", obj.requester.full_name if obj.requester else None),
            ("Department Head", db.get(models.User, obj.department_head_id).full_name if obj.department_head_id else None),
            ("Assigned QA Lead", db.get(models.User, obj.qa_lead_id).full_name if obj.qa_lead_id else None),
            ("Assigned Tester(s)", ", ".join(tester_names) if tester_names else None),
        ]),
        ("Readiness Checklist", [
            (c.item, f"Requester declared: {'Yes' if c.requester_checked else 'No'} | QA verified: {'Yes' if c.is_complete else 'No'}"
                      + (" (Mandatory)" if c.is_mandatory else ""))
            for c in obj.checklist_items
        ]),
    ]

    history_rows = (db.query(models.ApprovalAction)
                     .filter_by(entity_type="FUNCTIONAL_REQUEST", entity_id=req_id)
                     .order_by(models.ApprovalAction.created_at).all())
    history = []
    for h in history_rows:
        actor = db.get(models.User, h.actor_id) if h.actor_id else None
        history.append((h.step_name or "—", h.decision or "—", actor.full_name if actor else "—",
                         format_role_labels(h.actor_role) or "—", h.comments or "—",
                         h.created_at if h.created_at else "—"))

    buf = build_request_detail_pdf(
        title=f"{obj.request_id} — {obj.application_name}",
        subtitle="Functional QA Request — Full Detail Export",
        sections=sections, history=history,
        generated_by=current_user.full_name,
        generated_at=models.now().strftime("%Y-%m-%d %H:%M IST"),
        verification_context=(db, "FUNCTIONAL_REQUEST", req_id),
    )
    return StreamingResponse(
        buf, media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{obj.request_id}.pdf"'},
    )


# ---- Supporting documents (multiple files, uploaded any time after the
# request has been raised) -- see documents.py for the shared implementation. ----
def _can_upload_documents(db: Session, obj: "models.FunctionalRequest", user: models.User) -> bool:
    """Reported directly (Document and Evidence Access Control Based on
    Workflow Stage): access follows exactly 3 stages, then locks hard --
    (1) the requester, while the request is genuinely in their own hands
    (Draft/Submitted, Returned-by-*, Rejected, or back for their own final
    verification) may upload any number of files; (2) the SM, and only the
    SM, may upload while SM_APPROVAL_PENDING; (3) the Department Head, and
    only the Department Head, may upload while
    DEPARTMENT_HEAD_APPROVAL_PENDING. After Department Head approval, EVERY
    status is locked -- no QA Lead, tester, or anyone else may upload here
    -- until the request is returned to the requester (a RETURNED_BY_*
    status), which re-opens stage (1). This intentionally removes the prior
    QA-activity-status upload window (QA_LEAD_ASSIGNED through
    QA_SIGNOFF_PENDING) -- any evidence QA generates during actual execution
    belongs in Test Execution's own attempt-artifact system (TEST_EXEC_IMAGE
    in documents.py), not this readiness-facing Documents/Checklist
    Evidence store. Admin always bypasses, same convention as every other
    permission check in this file."""
    if user.has_role(Role.ADMIN):
        return True
    status = obj.status
    if status in (QAStatus.DRAFT, QAStatus.SUBMITTED, QAStatus.RETURNED_BY_SM, QAStatus.SM_REJECTED,
                  QAStatus.RETURNED_BY_DEPARTMENT_HEAD, QAStatus.RETURNED_BY_QA_LEAD,
                  QAStatus.REQUESTER_VERIFICATION):
        return (_is_active_delegate(obj, user)
                or (obj.requester_id == user.id and not obj.active_delegation))
    if status == QAStatus.SM_APPROVAL_PENDING:
        return (user.has_role(Role.SM) and user.has_department(obj.department)
                and has_department_unit_action_scope(
                    db, user, obj.department,
                    obj.qa_request.department_unit_id if obj.qa_request else None,
                ))
    if status == QAStatus.DEPARTMENT_HEAD_APPROVAL_PENDING:
        return (user.has_role(Role.DEPARTMENT_HEAD_CM, Role.DEPARTMENT_HEAD_AGM)
                and user.has_department(obj.department)
                and has_department_unit_action_scope(
                    db, user, obj.department,
                    obj.qa_request.department_unit_id if obj.qa_request else None,
                ))
    # Every QA-activity/post-approval/terminal status -- locked for everyone
    # but Admin until the request is returned to the requester above.
    return False


def _can_edit_details(db: Session, obj: "models.FunctionalRequest", user: models.User) -> bool:
    """Reported bug: an SM could still edit a request's own details after
    already returning it themselves (status RETURNED_BY_SM) -- a dead end,
    since only the requester/admin can ever call resubmit_request, so the SM
    ended up with edit access they could never actually push forward.
    Clarified: edit access for a reviewer (SM/Department Head) should exist
    only while the request is genuinely pending *their own* decision
    (SM_APPROVAL_PENDING / DEPARTMENT_HEAD_APPROVAL_PENDING) -- fix
    something, then Approve/Return/Reject -- and disappears the moment
    they've decided either way. Once returned to the requester
    (RETURNED_BY_SM/RETURNED_BY_DEPARTMENT_HEAD/RETURNED_BY_QA_LEAD), only
    the requester (or admin) may edit; reviewers are never involved again
    for a request already past their own checkpoint -- edit access for SM/
    Department Head stops at Department Head's own decision, never
    extending into QA's post-approval readiness/execution stages. Same
    department-scoping as those stages' own decision endpoints.

    SM_REJECTED is included alongside the RETURNED_BY_* statuses too --
    reported directly, a rejected request is now reopenable (edit + call
    resubmit_request), not a dead end, so the requester needs the same edit
    access here as they'd have after a Return."""
    if user.has_role(Role.ADMIN):
        return True
    status = obj.status
    if status in (QAStatus.DRAFT, QAStatus.RETURNED_BY_SM, QAStatus.SM_REJECTED,
                  QAStatus.RETURNED_BY_DEPARTMENT_HEAD, QAStatus.RETURNED_BY_QA_LEAD):
        return (_is_active_delegate(obj, user)
                or (obj.requester_id == user.id and not obj.active_delegation))
    if status == QAStatus.SM_APPROVAL_PENDING:
        return (user.has_role(Role.SM) and user.has_department(obj.department)
                and has_department_unit_action_scope(
                    db, user, obj.department,
                    obj.qa_request.department_unit_id if obj.qa_request else None,
                ))
    if status == QAStatus.DEPARTMENT_HEAD_APPROVAL_PENDING:
        return (user.has_role(Role.DEPARTMENT_HEAD_CM, Role.DEPARTMENT_HEAD_AGM)
                and user.has_department(obj.department)
                and has_department_unit_action_scope(
                    db, user, obj.department,
                    obj.qa_request.department_unit_id if obj.qa_request else None,
                ))
    return False


@router.get("/{req_id}/documents", response_model=List[schemas.RequestDocumentOut])
def list_functional_documents(req_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    _require_visible(db, _get_or_404(db, req_id), current_user)
    return doc_store.list_documents(db, "FUNCTIONAL", req_id)


@router.post("/{req_id}/documents", response_model=List[schemas.RequestDocumentOut])
def upload_functional_documents(req_id: int, files: List[UploadFile] = File(...), db: Session = Depends(get_db),
                                 current_user: models.User = Depends(get_current_user)):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    if not _can_upload_documents(db, obj, current_user):
        raise HTTPException(403, "Only the requester, central QA team, assigned tester, or the SM/Department Head currently reviewing the request can upload documents")
    return doc_store.save_documents(db, "FUNCTIONAL", req_id, obj.request_id, files, current_user.id,
                                    log_entity_type="FUNCTIONAL_REQUEST", log_entity_id=obj.id, log_actor=current_user)


@router.get("/{req_id}/documents/{doc_id}/download")
def download_functional_document(req_id: int, doc_id: int, db: Session = Depends(get_db),
                                  current_user: models.User = Depends(get_current_user)):
    _require_visible(db, _get_or_404(db, req_id), current_user)
    doc = doc_store.get_document_or_404(db, "FUNCTIONAL", req_id, doc_id)
    full_path = doc_store.full_path(doc)
    if not os.path.exists(full_path):
        raise HTTPException(404, "File is missing on disk")
    return FileResponse(full_path, filename=doc.file_name, media_type=doc.content_type or "application/octet-stream")


@router.delete("/{req_id}/documents/{doc_id}")
def delete_functional_document(req_id: int, doc_id: int, db: Session = Depends(get_db),
                                current_user: models.User = Depends(get_current_user)):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    doc = doc_store.get_document_or_404(db, "FUNCTIONAL", req_id, doc_id)
    if not doc_store.can_delete_document(doc, current_user, _can_upload_documents(db, obj, current_user)):
        raise HTTPException(403, "Only whoever uploaded this document, or an admin, can delete it -- and only while it's still your stage")
    doc_store.delete_document(db, doc, log_entity_type="FUNCTIONAL_REQUEST", log_entity_id=req_id, log_actor=current_user)
    return {"ok": True}


# ---- Evidence attached to one readiness-checklist row. Kept in the same
# shared document store under a distinct module key, so it remains separate
# from the request-level Documents tab and requires no schema migration. ----
def _functional_checklist_item_or_404(db: Session, req_id: int, item_id: int):
    item = db.query(models.ReadinessChecklistItem).filter_by(
        id=item_id, functional_request_id=req_id).first()
    if not item:
        raise HTTPException(404, "Checklist item not found")
    return item


@router.get("/{req_id}/checklist/documents", response_model=List[schemas.ChecklistItemDocumentOut])
def list_functional_checklist_documents_batch(req_id: int, db: Session = Depends(get_db),
                                               current_user: models.User = Depends(get_current_user)):
    """Batched counterpart to list_functional_checklist_documents below --
    see ChecklistItemDocumentOut for why this exists."""
    _require_visible(db, _get_or_404(db, req_id), current_user)
    item_ids = [row.id for row in db.query(models.ReadinessChecklistItem.id)
                .filter_by(functional_request_id=req_id).all()]
    docs = doc_store.list_documents_for_items(db, "FUNCTIONAL_ITEM", item_ids)
    return [schemas.ChecklistItemDocumentOut(
        id=d.id, file_name=d.file_name, content_type=d.content_type,
        file_size=d.file_size, uploaded_by_id=d.uploaded_by_id, uploaded_at=d.uploaded_at,
        item_id=d.request_id) for d in docs]


@router.get("/{req_id}/checklist/{item_id}/documents", response_model=List[schemas.RequestDocumentOut])
def list_functional_checklist_documents(req_id: int, item_id: int, db: Session = Depends(get_db),
                                         current_user: models.User = Depends(get_current_user)):
    _require_visible(db, _get_or_404(db, req_id), current_user)
    _functional_checklist_item_or_404(db, req_id, item_id)
    return doc_store.list_documents(db, "FUNCTIONAL_ITEM", item_id)


@router.post("/{req_id}/checklist/{item_id}/documents", response_model=List[schemas.RequestDocumentOut])
def upload_functional_checklist_documents(req_id: int, item_id: int, files: List[UploadFile] = File(...),
                                           db: Session = Depends(get_db),
                                           current_user: models.User = Depends(get_current_user)):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    item = _functional_checklist_item_or_404(db, req_id, item_id)
    if not is_readiness_evidence_editable(obj.status):
        raise HTTPException(400, "Checklist evidence is locked after Department Head approval unless the request is returned for correction")
    if not _can_upload_documents(db, obj, current_user):
        raise HTTPException(403, "Only the requester or this request's current stage owner can attach checklist evidence")
    return doc_store.save_documents(db, "FUNCTIONAL_ITEM", item_id,
                                    f"{obj.request_id}/checklist-{item_id}", files, current_user.id,
                                    log_entity_type="FUNCTIONAL_REQUEST", log_entity_id=obj.id, log_actor=current_user,
                                    log_label=f"checklist item '{item.item}'")


@router.get("/{req_id}/checklist/{item_id}/documents/{doc_id}/download")
def download_functional_checklist_document(req_id: int, item_id: int, doc_id: int,
                                            db: Session = Depends(get_db),
                                            current_user: models.User = Depends(get_current_user)):
    _require_visible(db, _get_or_404(db, req_id), current_user)
    _functional_checklist_item_or_404(db, req_id, item_id)
    doc = doc_store.get_document_or_404(db, "FUNCTIONAL_ITEM", item_id, doc_id)
    full_path = doc_store.full_path(doc)
    if not os.path.exists(full_path):
        raise HTTPException(404, "File is missing on disk")
    return FileResponse(full_path, filename=doc.file_name,
                        media_type=doc.content_type or "application/octet-stream")


@router.delete("/{req_id}/checklist/{item_id}/documents/{doc_id}")
def delete_functional_checklist_document(req_id: int, item_id: int, doc_id: int,
                                          db: Session = Depends(get_db),
                                          current_user: models.User = Depends(get_current_user)):
    obj = _get_or_404(db, req_id, lock=True)
    _require_visible(db, obj, current_user)
    item = _functional_checklist_item_or_404(db, req_id, item_id)
    if not is_readiness_evidence_editable(obj.status):
        raise HTTPException(400, "Checklist evidence is locked after Department Head approval unless the request is returned for correction")
    doc = doc_store.get_document_or_404(db, "FUNCTIONAL_ITEM", item_id, doc_id)
    if not doc_store.can_delete_document(doc, current_user, _can_upload_documents(db, obj, current_user)):
        raise HTTPException(403, "Only whoever uploaded this evidence, or an admin, can delete it -- and only while it's still your stage")
    doc_store.delete_document(db, doc, log_entity_type="FUNCTIONAL_REQUEST", log_entity_id=obj.id,
                              log_actor=current_user, log_label=f"checklist item '{item.item}'")
    return {"ok": True}
