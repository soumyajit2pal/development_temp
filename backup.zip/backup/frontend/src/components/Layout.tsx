import { useRequestNavigation } from '../hooks/useRequestNavigation'
import { clearGlobalSearchDestination, globalSearchDestination } from '../globalSearch'
import { api } from '../api'
import React, { useEffect, useState, useRef, ReactNode } from 'react'
import {NavLink, useLocation} from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { ROLE_LABELS, QA_REQUEST_CREATOR_ROLES, hasRole, hasWorkspaceRole, isViewOnly, uniqueWorkspaceAccess, WorkspaceAccessEntry } from '../constants'
import { QAWorkspaceOut, UserOut } from '../types'
import {
  IconGrid, IconEdit, IconFolder, IconShield, IconTarget, IconEyeOff,
  IconCertificate, IconApprove, IconChart, IconSearch, IconWorkflow,
  IconPlus, IconCheckCircle, IconLogout, IconUsers, IconApps, IconPlay, IconBell,
  IconHelp,
} from './Icons'
import GlobalSearchSpotlight from './GlobalSearchSpotlight'
import WorkspaceSwitcher from './WorkspaceSwitcher'
import { beginWorkspaceTransition, persistWorkspaceTransition, endWorkspaceTransition } from '../workspaceTransition'
import AppVersion from './AppVersion'
import { MaintenanceWindowBanner } from './MaintenanceWindowNotice'
import './BalancedHeader.css'
import './PortalActionButton.css'

interface NavItem {
  to: string
  label: string
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>
}

interface NavGroup {
  label: string
  items: NavItem[]
}

// Nav items are grouped into short, labeled sections (Workspace / Security /
// Governance / Administration) rather than one long flat list -- with 8+
// destinations a flat list stops reading as a hierarchy, so grouping gives
// the sidebar a clearer information architecture.
function canVerifySignatures(user: UserOut | null): boolean {
  return !!user?.roles.some((role) => !['DOCUMENT_PORTAL_VIEWER', 'DOCUMENT_PORTAL_CONTRIBUTOR', 'DOCUMENT_PORTAL_MANAGER'].includes(role))
}

function navGroups(user: UserOut | null, workspaceOptions: WorkspaceAccessEntry[]): NavGroup[] {
  const groups: NavGroup[] = [
    {
      label: 'Overview',
      items: [
        { to: '/', label: 'Dashboard', icon: IconGrid },
      ],
    },
    {
      label: 'Request Management',
      items: [
        { to: '/qa-requests', label: 'QA Requests', icon: IconEdit },
      ],
    },
    {
      label: 'Functional',
      items: [
        { to: '/functional-requests', label: 'Functional Requests', icon: IconFolder },
      ],
    },
    {
      label: 'Security',
      items: [
        { to: '/sast', label: 'SAST Requests', icon: IconShield },
        { to: '/dast', label: 'DAST Requests', icon: IconTarget },
        { to: '/suppression', label: 'Suppression / False Positive', icon: IconEyeOff },
      ],
    },
    {
      label: 'Specialized Testing',
      items: [
        { to: '/performance', label: 'Performance Testing', icon: IconWorkflow },
      ],
    },
    {
      label: 'Test Case Management',
      items: [
        { to: '/test-projects', label: 'Test Projects', icon: IconApps },
        { to: '/test-repository', label: 'Test Repository', icon: IconFolder },
        { to: '/test-execution', label: 'Test Execution', icon: IconPlay },
        // 2026-08 -- was role-gated for a while (QA team plus whoever could
        // raise a defect), then reported directly: "currently Defect
        // management is not available to everyone. make this visible to
        // everyone based on department filter." Nav item now shown
        // unconditionally, same as every other Test Management item above --
        // the backend's own department scoping (routers/defects.py's
        // _scoped_defects) is what actually restricts what a scoped user
        // sees once there, not this nav check.
        { to: '/defects', label: 'Defects & Observations', icon: IconTarget },
        // SRS EXE-002 "My Executions" -- the signed-in user's own actionable
        // items across every authorized project, one cross-project view
        // instead of hunting through each project's own Test Execution page.
        ...(!isViewOnly(user) && hasWorkspaceRole(user, 'QA_ENGINEER', 'QA_LEAD', 'CHIEF_MANAGER_QA', 'AGM_QA')
          ? [{ to: '/my-executions', label: 'My Executions', icon: IconCheckCircle }]
          : []),
        // SRS section 11 -- the 5 reporting views (repository health, cycle
        // progress, defect quality, version impact, project portfolio).
        { to: '/test-reports', label: 'Test Reports', icon: IconChart },
      ],
    },
    {
      label: 'Document Management',
      items: hasRole(user, 'DOCUMENT_PORTAL_VIEWER', 'DOCUMENT_PORTAL_CONTRIBUTOR', 'DOCUMENT_PORTAL_MANAGER')
        ? [{ to: '/document-portal', label: 'Document Portal', icon: IconFolder }]
        : [],
    },
    {
      label: 'Governance',
      items: [
        { to: '/signoff', label: 'QA Clearance', icon: IconCertificate },
        ...(canVerifySignatures(user) ? [{ to: '/verify-signature', label: 'Verify Signature', icon: IconShield }] : []),
        { to: '/pending-approvals', label: 'Pending Approvals', icon: IconBell },
        { to: '/approvals', label: 'Approval Workflow Log', icon: IconApprove },
        { to: '/reports', label: 'Reports & Export Centre', icon: IconChart },
        ...(hasRole(user, 'ADMIN', 'CHIEF_MANAGER_QA', 'AGM_QA')
          ? [{ to: '/audit-log', label: 'Audit Log', icon: IconSearch }]
          : []),
      ],
    },
    {
      label: 'Help & Support',
      items: [
        { to: '/help', label: 'Help & User Manual', icon: IconHelp },
      ],
    },
  ]
  // hasRole(user, 'DEPARTMENT_HEAD_CM', 'DEPARTMENT_HEAD_AGM') is also true for an Admin account (see
  // constants.ts::hasRole's own ADMIN short-circuit), so an Admin sees both
  // items below merged into the one Administration group rather than two
  // separately-labeled groups.
  const adminItems: NavItem[] = []
  if (!isViewOnly(user) && hasRole(user, 'ADMIN')) {
    adminItems.push({ to: '/admin', label: 'Users & Access', icon: IconUsers })
    adminItems.push({ to: '/checklist-config', label: 'Readiness Checklist Config', icon: IconCheckCircle })
    adminItems.push({ to: '/request-type-config', label: 'Request Type Config', icon: IconEdit })
  }
  if (!isViewOnly(user) && uniqueWorkspaceAccess(user).some((access) => access.role === 'PARENT_WORKSPACE_ADMIN')) {
    adminItems.push({ to: '/workspace-admin', label: 'Workspace Members', icon: IconUsers })
  }
  // Do not show the narrower Department Coordinator workspace merely because
  // `hasRole` grants Administrators its usual superuser shortcut. System
  // Admins belong in Users & Access, where every department and role is
  // available; this page is deliberately limited to a coordinator's own
  // department and was producing a misleading 403 for Admin accounts.
  const selectedWorkspaceId = Number(
    localStorage.getItem('active_workspace_id') || localStorage.getItem('qa_active_workspace_id'),
  ) || user?.preferred_workspace_id || user?.preferred_qa_workspace_id
  const selectedWorkspace = workspaceOptions.find((workspace) => workspace.workspace_id === selectedWorkspaceId)
  const isDepartmentCoordinator = (user?.department_coordinator_access || []).some(
    (assignment) => assignment.is_active && (
      assignment.workspace_id === selectedWorkspaceId
      || assignment.workspace_id === selectedWorkspace?.parent_workspace_id
    ),
  )
  if (!isViewOnly(user) && isDepartmentCoordinator) {
    adminItems.push({ to: '/department-admin', label: 'Department Coordinator', icon: IconUsers })
  }
  if (adminItems.length > 0) {
    groups.push({ label: 'Administration', items: adminItems })
  }
  return groups.filter((group) => group.items.length > 0)
}

function initials(name?: string | null): string {
  if (!name) return '?'
  const parts = name.trim().split(/\s+/)
  return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase()
}

export default function Layout({ children }: { children?: ReactNode }) {
  const { user, logout, refreshUser } = useAuth()
  const location = useLocation()
  const navigate = useRequestNavigation()
  const [search, setSearch] = useState('')
  const [searchOpen, setSearchOpen] = useState(false)
  const searchTriggerRef = useRef<HTMLButtonElement>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => localStorage.getItem('qa_nav_collapsed') === 'true')
  // Nav-group toggle buttons now default to closed -- the effect below still
  // auto-opens whichever group contains the current route, so the active
  // section is never hidden on load; only the OTHER groups start collapsed
  // instead of every group being expanded up front.
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('qa_nav_expanded_groups') || '[]')
      return new Set(Array.isArray(saved) ? saved : [])
    } catch {
      return new Set()
    }
  })
  const searchInputRef = useRef<HTMLInputElement>(null)
  // Topbar user menu -- clicking the signed-in name reveals Department +
  // Role(s) (mirrors the sidebar's own user-chip, but reachable from the
  // topbar too, which stays visible even with the sidebar collapsed/closed
  // on mobile).
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const userMenuRef = useRef<HTMLDivElement>(null)
  const [workspaceSwitching, setWorkspaceSwitching] = useState(false)
  const [workspaceSwitchError, setWorkspaceSwitchError] = useState('')
  const [workspaceDirectory, setWorkspaceDirectory] = useState<QAWorkspaceOut[]>([])
  const directWorkspaceAccess = uniqueWorkspaceAccess(user)
  const workspaceOptions: WorkspaceAccessEntry[] = workspaceDirectory.length
    ? workspaceDirectory.map((workspace) => {
        const direct = directWorkspaceAccess.find((access) => access.workspace_id === workspace.id)
        return {
          workspace_id: workspace.id,
          is_active: workspace.is_active,
          role: direct?.role || 'WORKSPACE_MEMBER',
          workspace_name: workspace.name,
          workspace_key: workspace.workspace_key,
          parent_workspace_id: workspace.parent_workspace_id,
          parent_workspace_name: workspace.parent_workspace_name,
          parent_workspace_key: workspace.parent_workspace_key,
        }
      })
    : directWorkspaceAccess

  useEffect(() => {
    if (!user) { setWorkspaceDirectory([]); return }
    void api.get<QAWorkspaceOut[]>('/api/workspaces')
      .then(setWorkspaceDirectory)
      .catch(() => setWorkspaceDirectory([]))
  }, [user?.id])

  useEffect(() => {
    if (user && !workspaceDirectory.length) return
    const memberships = workspaceOptions
    if (!memberships.length) {
      localStorage.removeItem('active_workspace_id')
      localStorage.removeItem('qa_active_workspace_id')
      return
    }
    const preferred = user?.preferred_workspace_id || user?.preferred_qa_workspace_id
    const current = Number(localStorage.getItem('active_workspace_id') || localStorage.getItem('qa_active_workspace_id'))
    const selected = memberships.some((row) => row.workspace_id === current)
      ? current
      : (memberships.some((row) => row.workspace_id === preferred) ? preferred : memberships[0].workspace_id)
    localStorage.setItem('active_workspace_id', String(selected))
    localStorage.removeItem('qa_active_workspace_id')
  }, [user?.id, user?.preferred_workspace_id, user?.preferred_qa_workspace_id, workspaceDirectory])

  async function selectWorkspace(workspaceId: number) {
    if (!workspaceId || workspaceSwitching) return
    const currentWorkspaceId = Number(localStorage.getItem('active_workspace_id') || localStorage.getItem('qa_active_workspace_id')) || user?.preferred_workspace_id || user?.preferred_qa_workspace_id
    if (workspaceId === currentWorkspaceId) return
    const destination = workspaceOptions.find(row => row.workspace_id === workspaceId)
    const destinationName = destination?.workspace_name || destination?.workspace_key || `Workspace ${workspaceId}`
    setWorkspaceSwitching(true)
    setWorkspaceSwitchError('')
    beginWorkspaceTransition(destinationName)
    try {
      // Persist permission first. If it fails, keep the current tenant header
      // intact so the rest of the page does not start issuing forbidden calls.
      await api.patch('/api/workspaces/preference/current', { workspace_id: workspaceId })
      localStorage.setItem('active_workspace_id', String(workspaceId))
      // Every mounted page may own independent cached queries. A full reload
      // makes the workspace change atomic: no old-workspace card can remain.
      persistWorkspaceTransition(destinationName)
      window.location.reload()
    } catch (error) {
      endWorkspaceTransition()
      setWorkspaceSwitchError(error instanceof Error ? error.message : 'Workspace could not be changed')
      setWorkspaceSwitching(false)
    }
  }

  const groups = navGroups(user, workspaceOptions)
  const isQARequestsPage = location.pathname === '/qa-requests'

  useEffect(() => { setSidebarOpen(false) }, [location.pathname])
  useEffect(() => { setUserMenuOpen(false) }, [location.pathname])
  useEffect(() => {
    // Keep Global Search consistent with the page it navigated to. Without
    // this, a CR traceability URL opened from a bookmark/refresh showed an
    // empty global box while the page displayed the CR in a second local
    // box, making it look as though two unrelated searches were active.
    const params = new URLSearchParams(location.search)
    setSearch(
      params.get('cr_number') ||
      params.get('search') ||
      params.get('open') ||
      params.get('openId') ||
      ''
    )
  }, [location.pathname, location.search])
  useEffect(() => {
    if (!userMenuOpen) return
    function onDocMouseDown(e: MouseEvent) {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) setUserMenuOpen(false)
    }
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') setUserMenuOpen(false)
    }
    document.addEventListener('mousedown', onDocMouseDown)
    document.addEventListener('keydown', onKeyDown)
    return () => {
      document.removeEventListener('mousedown', onDocMouseDown)
      document.removeEventListener('keydown', onKeyDown)
    }
  }, [userMenuOpen])
  useEffect(() => {
    localStorage.setItem('qa_nav_expanded_groups', JSON.stringify(Array.from(expandedGroups)))
  }, [expandedGroups])

  useEffect(() => {
    function focusGlobalSearch(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        setSearchOpen(true)
        searchInputRef.current?.focus()
        searchInputRef.current?.select()
      }
    }
    window.addEventListener('keydown', focusGlobalSearch)
    return () => window.removeEventListener('keydown', focusGlobalSearch)
  }, [])

  useEffect(() => {
    function focusRequestSearch() {
      setSearchOpen(true)
      searchInputRef.current?.focus()
      searchInputRef.current?.select()
    }
    window.addEventListener('request-search-focus', focusRequestSearch)
    return () => window.removeEventListener('request-search-focus', focusRequestSearch)
  }, [])

  function toggleSidebarSize() {
    setSidebarCollapsed((previous) => {
      const next = !previous
      localStorage.setItem('qa_nav_collapsed', String(next))
      return next
    })
  }

  function toggleGroup(label: string) {
    setExpandedGroups((previous) => {
      const next = new Set(previous)
      if (next.has(label)) next.delete(label)
      else next.add(label)
      return next
    })
  }

  function handleLogout() {
    logout()
  }

  function clearGlobalSearch() {
    setSearch('')
    const destination = clearGlobalSearchDestination(location.pathname, location.search)
    if (destination) navigate(destination, { replace: true })
  }

  function submitSearch(e: React.FormEvent) {
    e.preventDefault()
    const destination = globalSearchDestination(search)
    if (!destination) return
    setSearchOpen(false)
    navigate(destination)
  }

  return (
    <div className="app-shell redesigned-shell navigation-v2 navigation-v8">
      <button className={`sidebar-backdrop ${sidebarOpen ? 'visible' : ''}`} aria-label="Close navigation" onClick={() => setSidebarOpen(false)} />
      <aside className={`sidebar ${sidebarOpen ? 'sidebar-open' : ''} ${sidebarCollapsed ? 'sidebar-collapsed' : ''}`} aria-label="Primary navigation">
        <div className="brand">
          <img className="qualityops-app-logo" src="/qualityops-logo.png" alt="" aria-hidden="true" />
          <div className="brand-copy">
            <h1>Quality<span>Ops</span></h1>
            <img className="bank-wordmark sidebar-bank-wordmark" src="/bank-of-maharashtra-wordmark.png" alt="Bank of Maharashtra" />
          </div>
          <button className="sidebar-collapse-control" onClick={toggleSidebarSize} aria-label={sidebarCollapsed ? 'Expand navigation' : 'Collapse navigation'} title={sidebarCollapsed ? 'Expand navigation' : 'Collapse navigation'}>
            {sidebarCollapsed ? '›' : '‹'}
          </button>
          <button className="sidebar-mobile-close" onClick={() => setSidebarOpen(false)} aria-label="Close navigation">×</button>
        </div>

        <nav aria-label="Application modules">
          <div className="nav-workspace-label"><span>Quality operations</span><i /></div>
          {groups.map((group) => (
            <div className={`nav-group ${sidebarCollapsed || expandedGroups.has(group.label) ? 'group-open' : ''}`} key={group.label}>
              <button className="nav-group-toggle" onClick={() => toggleGroup(group.label)} aria-expanded={sidebarCollapsed || expandedGroups.has(group.label)}>
                <span>{group.label}</span><i>⌄</i>
              </button>
              <div className="nav-group-items">
                {group.items.map((item) => {
                  const Icon = item.icon
                  return (
                    <NavLink key={item.to} to={item.to} end={item.to === '/'} onClick={() => setSidebarOpen(false)}
                             title={sidebarCollapsed ? item.label : undefined}
                             className={({ isActive }) => (isActive ? 'active' : '')}>
                      <span className="nav-icon"><Icon /></span>
                      <span className="nav-label">{item.label}</span>
                    </NavLink>
                  )
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="audit-card shell-trust-card">
            <IconCheckCircle width={16} height={16} />
            <div>
              <div className="title">Governed workspace</div>
              <div className="desc">Actions and approvals are audit logged.</div>
            </div>
          </div>
          {user && (
            <div className="user-chip">
              <div className="avatar">{initials(user.full_name)}</div>
              <div className="who">
                <div className="name">{user.full_name}</div>
                <div className="role">
                  {(user.roles || []).map((r) => ROLE_LABELS[r] || r).join(' · ') || 'No role assigned'}
                </div>
                <div className="dept">{(user.departments && user.departments.length ? user.departments.join(', ') : user.department) || 'No department set'}</div>
              </div>
            </div>
          )}
        </div>
      </aside>

      <div className="main">
        <header className="topbar balanced-header" aria-label="Application header">
          <div className="balanced-header-chrome">
            <button type="button" className="mobile-nav-toggle" onClick={() => setSidebarOpen(true)} aria-label="Open navigation"><span /><span /><span /></button>
            <div className="balanced-header-brand">
              <img src="/qualityops-logo.png" alt="" aria-hidden="true" />
              <span>QualityOps</span>
            </div>
            {workspaceOptions.length > 0 && (
              <div className="qa-workspace-switcher">
                <WorkspaceSwitcher
                  value={Number(localStorage.getItem('active_workspace_id')) || user?.preferred_workspace_id || user?.preferred_qa_workspace_id || workspaceOptions[0]?.workspace_id}
                  onChange={(value) => void selectWorkspace(value)}
                  options={workspaceOptions}
                  disabled={workspaceSwitching}
                />
                {workspaceSwitchError && <small className="workspace-switch-error" role="alert">{workspaceSwitchError}</small>}
              </div>
            )}
            <div className="balanced-header-toolbar">
              <button type="button" ref={searchTriggerRef} className="search-box global-search-trigger" aria-label="Open global search" aria-haspopup="dialog" aria-expanded={searchOpen} aria-keyshortcuts="Control+k Meta+k" onClick={() => setSearchOpen(true)}>
                <IconSearch width={18} height={18} aria-hidden="true" />
                <span className="global-search-trigger-label">{search || 'Search all requests or IDs…'}</span>
                <kbd>⌘ K</kbd>
              </button>
              {canVerifySignatures(user) && <NavLink to="/verify-signature" className="btn portal-action-button balanced-header-verify" title="Verify a digital signature or PDF" aria-label="Verify Signature"><IconShield width={16} height={16} aria-hidden="true" /><span>Verify signature</span></NavLink>}
              {!isQARequestsPage && hasRole(user, ...QA_REQUEST_CREATOR_ROLES) && (
                <button type="button" className="btn portal-action-button balanced-header-create" onClick={() => navigate('/qa-requests', { state: { openNew: true } })}>
                  <IconPlus width={16} height={16} aria-hidden="true" /> New QA request
                </button>
              )}
            </div>
            {user && (
              <div className="topbar-user-menu" ref={userMenuRef}>
                <button
                  type="button"
                  className="topbar-user-context"
                  onClick={() => setUserMenuOpen((v) => !v)}
                  aria-label={`${user.full_name} account`}
                  aria-expanded={userMenuOpen}
                  aria-controls={userMenuOpen ? 'topbar-account-details' : undefined}
                >
                  <span className="topbar-avatar">{initials(user.full_name)}</span>
                  <span className="topbar-user-summary">
                    <strong className="topbar-user-name">{user.full_name}</strong>
                  </span>
                  <i className={`topbar-user-caret ${userMenuOpen ? 'open' : ''}`}>⌄</i>
                </button>
                {userMenuOpen && (
                  <div className="topbar-user-popover" id="topbar-account-details">
                    <div className="topbar-user-popover-name">{user.full_name}</div>
                    <div className="topbar-user-popover-email">{user.username}</div>
                    <div className="topbar-user-popover-row">
                      <span className="label">Email</span>
                      <span className="topbar-user-popover-email-address">{user.email?.trim() || 'Not provided'}</span>
                    </div>
                    <div className="topbar-user-popover-row">
                      <span className="label">Department</span>
                      <span>{(user.departments && user.departments.length ? user.departments.join(', ') : user.department) || 'No department set'}</span>
                    </div>
                    <div className="topbar-user-popover-row">
                      <span className="label">Role(s)</span>
                      <span>{(user.roles || []).map((r) => ROLE_LABELS[r] || r).join(', ') || 'No role assigned'}</span>
                    </div>
                    <button type="button" className="topbar-logout" onClick={handleLogout}>
                      <IconLogout width={15} height={15} />
                      <span>Log out</span>
                    </button>
                  </div>
                )}
              </div>
            )}
            {!user && <span className="topbar-user-context"><span className="status-dot" />Signed in</span>}
          </div>
        </header>
        <MaintenanceWindowBanner />
        <div className="content">{children}</div>
        {/* Moved out of the sidebar's own footer (previously .portal-credit,
            hidden entirely once the sidebar was collapsed -- see index.css)
            into a real page footer instead, so it's visible on every signed-
            in page (not just an expanded sidebar) regardless of collapse
            state. Lives here rather than inside .content so it stays pinned
            under the scrollable page area (same fixed-shell pattern as
            .topbar above it) instead of scrolling away with long page
            content. */}
        <div className="app-footer">
          <span>Developed by</span>
          <strong>Soumyajit Pal</strong>
          <span>·</span>
          <span>Quality Assurance Department - IT</span>
          <span>·</span>
          <span>© 2026 All rights reserved.</span>
          <AppVersion />
        </div>
      </div>
      {searchOpen && (
        <GlobalSearchSpotlight
          key={`${user?.id}:${user?.active_workspace_id}`}
          inputRef={searchInputRef}
          value={search}
          onChange={setSearch}
          onClear={clearGlobalSearch}
          onSubmit={submitSearch}
          onSelect={(suggestion) => {
            setSearch(suggestion.reference)
            setSearchOpen(false)
            navigate(suggestion.destination)
          }}
          onDismiss={() => {
            setSearchOpen(false)
          }}
        />
      )}
    </div>
  )
}
