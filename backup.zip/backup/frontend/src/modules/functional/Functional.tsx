import { WorkSession, useWorkState, useRetainedState, useListScrollRestoration } from '../../components/WorkViews'
import TestingScopeNotice, { additionalTestingOptions } from '../../components/TestingScopeNotice'
import { useUserOptions } from '../../hooks/useUserOptions'
import WorkflowStatusBadge from '../../components/WorkflowStatusBadge'
import { useRequestNavigation, useViewerManagedDeepLinks } from '../../hooks/useRequestNavigation'
import React, { useEffect, useState, useCallback, useRef } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { api } from "../../api";
import { createLatestRequestGate } from "../../latestRequest";
import { formatDateTimeIST, istToday } from "../../time";
import { useAuth } from "../../context/AuthContext";
import { Card, Table, Badge, Modal, Field, ErrorText, PageHeader, ApprovalDecisionButtons, DetailSection, DetailField, RequestDocuments, ChecklistEvidence, useChecklistDocuments, ReadinessPassError, EmptyState, WorkflowDecisionPanel, applicationNameAwareStatusLabel, WarningNotice } from "../../components/Common";
import MultiUserAssignSelect from "../../components/MultiUserAssignSelect";
import UserAssignSelect from "../../components/UserAssignSelect";
import ConfirmModal from "../../components/ConfirmModal";
import BusinessDefectNumberField from "../../components/BusinessDefectNumberField";
import CycleRequestPicker from "../../components/CycleRequestPicker";
import FunctionalTestingProgress from "../../components/FunctionalTestingProgress";
import JiraActivity from "../../components/JiraActivity";
import ClearableSearchInput from "../../components/ClearableSearchInput";
import RaisedHistoryFilter from "../../components/RaisedHistoryFilter";
import RoleGroupLink from "../../components/RoleGroupLink";
import RecordNumberLink from "../../components/RecordNumberLink";
import RequestDelegation from "../../components/RequestDelegation";
import {
  QA_STATUSES,
  QA_STATUS_LABELS,
  QA_PENDING_WITH,
  QA_EXECUTION_GROUP_ROLE,
  TESTER_REASSIGNABLE_STATUSES,
  PRIORITIES,
  RISK_RATINGS,
  DEPLOYMENT_ENVIRONMENTS,
  CHANGE_TYPES,
  hasWorkflowRole as hasRole,
  hasDepartment,
  hasWorkspaceRole,
  isViewOnly,
  validTargetPromotionOptions,
  validEnvironmentPromotion,
  canManageReadinessEvidence,
  SIGNOFF_STATUS_LABELS,
} from "../../constants";
import {
  FunctionalOut,
  FunctionalListOut,
  UserOption,
  ChecklistItemOut,
  ApprovalActionOut,
  SignOffOut,
  EligibleTestCycleOut,
  LinkedTestCycleRef,
  RequestDocumentOut,
} from "../../types";
import { usePaginatedList } from "../../hooks/usePaginatedList";
import {
  clearanceRetestLineageLeaves,
  eligibleClearanceRetestCycles,
  isLegacyCertificateRequesterFallback,
} from "../../clearanceRetest";
import {
  functionalClearanceCapabilities,
  functionalWorkflowActors,
} from "../../functionalWorkflowAuthority";
import { functionalPendingWithLabel } from "../../functionalPendingWith";
// Reused as-is from the Governance module -- the app is now a single
// consolidated Vite app (see README "Frontend architecture"), so importing
// across module folders is a plain relative import, no remote/federation
// boundary involved. Raising sign-off from a Functional Testing Request
// always means the certificate is FOR that request, so it's opened here
// with `presetRequest={req}` (locks the Testing Request ID picker instead
// of showing a search box -- see NewSignOffModal in SignOff.tsx).
import { NewSignOffModal } from "../governance/SignOff";

// Priority/Risk Rating are real columns on FunctionalRequest itself. Every
// other field here (Application Name, CR Number/EPIC Number, Change Type,
// Deployment Environment, Target Promotion Environment, Release Version,
// Build Number, Target Release Date) is otherwise delegated (read-only) from
// the parent QA Request -- update_functional (backend) writes those straight
// through to the linked QA Request instead, since the QA Request gateway
// itself can no longer be edited once it's left Draft (see
// GATEWAY_EDITABLE_STATUSES) -- this is the only place left to fix one of
// them after that point. Application Name/CR Number/EPIC Number identify
// *which* request this actually is, so -- once raised -- only an Admin can
// change them (backend-enforced too, see update_functional's
// _ADMIN_ONLY_FIELDS); everyone else sees them locked. Department stays
// read-only everywhere (fixed to the requester's own profile).
function FunctionalFormModal({
  onClose,
  onSaved,
  editing,
  documentsByItem,
  reloadEvidence,
}: {
  onClose: () => void;
  onSaved: (f: FunctionalOut) => void;
  editing: FunctionalOut;
  documentsByItem: Record<number, RequestDocumentOut[]>;
  reloadEvidence: () => Promise<void>;
}) {
  const { user } = useAuth();
  const isAdmin = hasRole(user, "ADMIN");
  const [form, setForm] = useWorkState('functional.edit.form', {
    priority: editing.priority || "Medium",
    risk_rating: editing.risk_rating || "Medium",
    application_name: editing.application_name || "",
    cr_number: editing.cr_number || editing.epic_number || "",
    change_type: editing.change_type || "New",
    business_defect_number: editing.business_defect_number || "",
    environment: editing.environment || "SIT",
    target_promotion_environment: editing.target_promotion_environment || "UAT",
    release_version: editing.release_version || "",
    build_number: editing.build_number || "",
    target_release_date: editing.target_release_date || "",
  });
  // Lets the requester revisit their "Ready for Testing" readiness checklist
  // self-declaration from here too -- previously the only place to tick
  // these was the QA Request wizard at intake time, with no way back in
  // even while this request was still sitting in the requester's own hands
  // (e.g. Draft or returned for changes). Same pattern as Performance.tsx's
  // PerformanceFormModal/SAST.tsx's SASTFormModal.
  const [checkedItems, setCheckedItems] = useWorkState<string[]>('functional.edit.checkedItems', 
    editing.checklist_items
      .filter((c) => c.requester_checked)
      .map((c) => c.item)
  );
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  // Mirrors the identity check the detail view computes for canEditDetails/
  // canSMDecide/canDepartmentHeadDecide -- this modal only ever opens via
  // that same canEditDetails gate, but the checklist evidence controls
  // inside it need their own explicit identity+status check (see
  // canManageReadinessEvidence's isOwner param) rather than assuming the
  // status alone means this particular viewer may attach/remove evidence.
  const viewOnlyModal = isViewOnly(user);
  const isActiveDelegateModal = !viewOnlyModal && editing.active_delegation?.status === "ACTIVE" && editing.active_delegation.assigned_to_id === user?.id;
  const isRequesterModal = isActiveDelegateModal || isAdmin || (
    !viewOnlyModal && editing.requester_id === user?.id && !editing.active_delegation
  );
  const sameDeptModal = hasDepartment(user, editing.department);
  const canSMDecideModal = hasRole(user, "SM") && editing.status === "SM_APPROVAL_PENDING" && sameDeptModal;
  const canDeptHeadDecideModal =
    hasRole(user, "DEPARTMENT_HEAD_CM", "DEPARTMENT_HEAD_AGM") &&
    editing.status === "DEPARTMENT_HEAD_APPROVAL_PENDING" && sameDeptModal;
  const canManageEvidenceModal =
    isAdmin ||
    (editing.status === "SM_APPROVAL_PENDING" ? canSMDecideModal :
    editing.status === "DEPARTMENT_HEAD_APPROVAL_PENDING" ? canDeptHeadDecideModal :
    isRequesterModal);
  function set<K extends keyof typeof form>(k: K, v: (typeof form)[K]) {
    setForm((f) => ({ ...f, [k]: v }));
  }
  function toggleChecked(item: string) {
    setCheckedItems((items) =>
      items.includes(item) ? items.filter((i) => i !== item) : [...items, item]
    );
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    // Same Deployment/Target Promotion Environment ordering rule as the QA
    // Request wizard's DetailsStep.tsx -- this modal's own dropdown already
    // only offers valid Target options and auto-corrects on Deployment
    // change (see the two selects below), so this should never actually
    // trip, but it's the last line of defense before the PUT goes out.
    if (!validEnvironmentPromotion(form.environment, form.target_promotion_environment)) {
      setError(
        new Error(
          `Target Promotion Environment ('${form.target_promotion_environment}') must be later than Deployment Environment ('${form.environment}') in the pipeline SIT -> UAT -> Pre-Production -> Production.`
        )
      );
      return;
    }
    setBusy(true);
    try {
      const saved = await api.put<FunctionalOut>(
        `/api/functional-requests/${editing.id}`,
        {
          ...form,
          target_release_date: form.target_release_date || null,
          checked_items: checkedItems,
        }
      );
      // Evidence is uploaded independently from the form PUT. Refresh the
      // shared detail cache before closing so the Checklist tab immediately
      // reflects everything attached in Edit Details.
      await reloadEvidence();
      onSaved(saved);
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal title={`Edit ${editing.request_id}`} onClose={onClose} closeDisabled={busy} workView wide>
      {editing?.qa_request && (
        <p className="muted small" style={{ marginTop: -8 }}>
          Auto-created from QA Request {editing.qa_request.request_id} --
          changes below (other than Priority/Risk Rating) are saved back onto
          that QA Request, since it can no longer be edited directly once
          raised.
        </p>
      )}
      {!isAdmin && (
        <p className="muted small" style={{ marginTop: -4 }}>
          Application Name and CR Number/EPIC Number are locked once
          this request has been raised -- only an Administrator can change them.
        </p>
      )}
      <form onSubmit={submit}>
        <div className="form-section">
          {/* <div className="form-section-title">
            Identity{!isAdmin ? " (Admin-only)" : ""}
          </div> */}
          <div className="form-row">
            <Field label="Application Name">
              <input
                disabled={!isAdmin}
                value={form.application_name}
                onChange={(e) => set("application_name", e.target.value)}
              />
            </Field>
            {editing.module_name && <Field label="Module Name"><input disabled value={editing.module_name} /></Field>}
            <Field label="CR Number/EPIC Number">
              <input
                disabled={!isAdmin}
                value={form.cr_number}
                onChange={(e) => set("cr_number", e.target.value)}
              />
            </Field>
          </div>
        </div>

        <div className="form-section">
          <div className="form-section-title">Classification</div>
          <div className="form-row">
            <Field label="Priority">
              <select
                value={form.priority}
                onChange={(e) => set("priority", e.target.value)}
              >
                {PRIORITIES.map((o) => (
                  <option key={o} value={o}>
                    {o}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Risk Rating">
              <select
                value={form.risk_rating}
                onChange={(e) => set("risk_rating", e.target.value)}
              >
                {RISK_RATINGS.map((o) => (
                  <option key={o} value={o}>
                    {o}
                  </option>
                ))}
              </select>
            </Field>
          </div>
        </div>

        <div className="form-section">
          <div className="form-section-title">Change &amp; Environment</div>
          <div className="form-row">
            <Field label="Change Type">
              <select
                value={form.change_type}
                onChange={(e) => {
                  const changeType = e.target.value;
                  set("change_type", changeType);
                  if (changeType !== "Bug Fix") set("business_defect_number", "");
                }}
              >
                {CHANGE_TYPES.map((o) => (
                  <option key={o} value={o}>
                    {o}
                  </option>
                ))}
              </select>
            </Field>
            <BusinessDefectNumberField changeType={form.change_type} value={form.business_defect_number}
              onChange={(value) => set("business_defect_number", value)} />
            <Field label="Deployment Environment">
              <select
                value={form.environment}
                onChange={(e) => {
                  const nextEnv = e.target.value;
                  set("environment", nextEnv);
                  // Target Promotion Environment must always stay strictly
                  // later than Deployment Environment in the SIT -> UAT ->
                  // Pre-Production -> Production pipeline -- snap it forward
                  // to the nearest valid stage if the already-picked target
                  // is no longer valid against the newly-picked deployment
                  // environment, same as DetailsStep.tsx.
                  const validTargets = validTargetPromotionOptions(nextEnv);
                  if (!validTargets.includes(form.target_promotion_environment)) {
                    set("target_promotion_environment", validTargets[0] || "");
                  }
                }}
              >
                {DEPLOYMENT_ENVIRONMENTS.map((o) => (
                  <option key={o} value={o}>
                    {o}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Target Promotion Environment">
              <select
                value={form.target_promotion_environment}
                onChange={(e) =>
                  set("target_promotion_environment", e.target.value)
                }
              >
                <option value="">Select Target Promotion Environment</option>
                {validTargetPromotionOptions(form.environment).map((o) => (
                  <option key={o} value={o}>
                    {o}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Release Version / Hash Value">
              <input
                value={form.release_version}
                onChange={(e) => set("release_version", e.target.value)}
              />
            </Field>
            <Field label="Build Number / Hash Value">
              <input
                value={form.build_number}
                onChange={(e) => set("build_number", e.target.value)}
              />
            </Field>
            <Field label="Target Release Date">
              <input
                type="date"
                min={istToday()}
                value={form.target_release_date}
                onChange={(e) => set("target_release_date", e.target.value)}
              />
            </Field>
          </div>
        </div>

        {editing.checklist_items.length > 0 && (
          <div className="form-section">
            <div className="form-section-title">
              Readiness Checklist — Self-Declaration
            </div>
            <p
              className="muted small"
              style={{ marginTop: -4, marginBottom: 8 }}
            >
              Update what's already in place. This is your own declaration for
              reference only -- QA independently verifies every mandatory item
              during Readiness Verification.
            </p>
            {/* Reported directly: "Attach Evidence is not uniform everywhere.
                On edit details it should be like while creating the
                request." -- reuses the exact same grid-table layout
                (security-checklist-table/-header/-row/-check/-criterion)
                as the QA Request wizard's ReadinessChecklistSection.tsx,
                instead of the ad-hoc flex row this used to be, so the
                Evidence column lines up identically here and at intake
                time. */}
            <div className="security-checklist-table" role="group" aria-label="Functional readiness checklist">
              <div className="security-checklist-header" aria-hidden="true">
                <span>Ready</span>
                <span>Readiness criterion</span>
                <span>Supporting evidence</span>
              </div>
              {editing.checklist_items.map((c) => {
                const checked = checkedItems.includes(c.item)
                const checkboxId = `functional-edit-checklist-${c.id}`
                return (
                  <div className={`security-checklist-row ${checked ? "is-checked" : ""}`} key={c.id}>
                    <div className="security-checklist-check">
                      <input
                        id={checkboxId}
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleChecked(c.item)}
                      />
                    </div>
                    <label className="security-checklist-criterion" htmlFor={checkboxId}>
                      <span>
                        <strong>{c.item}</strong>
                        {c.owner && <span className="muted small">({c.owner})</span>}
                        {c.is_mandatory && <span className="badge badge-gray">Mandatory</span>}
                        {c.is_complete && <span className="badge badge-green">QA verified</span>}
                      </span>
                    </label>
                    <ChecklistEvidence apiBase="/api/functional-requests" reqId={editing.id} itemId={c.id}
                      canManage={canManageReadinessEvidence(editing.status, canManageEvidenceModal)}
                      required={c.is_mandatory || c.requester_checked}
                      documents={documentsByItem[c.id] || []}
                      onReload={reloadEvidence}
                      checked={checked} />
                  </div>
                )
              })}
            </div>
          </div>
        )}

        <ErrorText error={error} />
        <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
          <button className="btn btn-primary" disabled={busy}>
            {busy ? "Saving..." : "Save Changes"}
          </button>
          <button type="button" className="btn" onClick={onClose}>
            Cancel
          </button>
        </div>
      </form>
    </Modal>
  );
}

// Compact "what happens after submit" preview -- mirrors the real lifecycle
// order (see backend app/constants.py QAStatus docstring): Draft -> SM ->
// Department Head -> QA -> Sign-off.
const LIFECYCLE_STAGES = [
  "Draft",
  "SM Approval",
  "Dept. Head Approval",
  "QA Activity",
  "Clearance",
  "Closed",
];

// Reported directly: "sm approval not completed but still QA Lead assigned"
// -- the "Assigned Group" field/column used to hardcode "QA Lead"
// unconditionally, regardless of the request's actual current status, so it
// showed "QA Lead" even while a request was still sitting at
// SM_APPROVAL_PENDING (or earlier). This maps the real backend status (see
// routers/functional.py's own status transitions -- SM_APPROVAL_PENDING is
// gated by Role.SM, DEPARTMENT_HEAD_APPROVAL_PENDING by
// Role.DEPARTMENT_HEAD_CM/AGM, everything from QA_LEAD_ASSIGNED through
// QA activity and post-execution review statuses to whichever group is genuinely holding the
// request right now. Returns null for every requester-owned/terminal/
// Sign-off-phase status (Draft, Submitted, any RETURNED_BY_*/*_REJECTED,
// QA Clearance phase, Requester Verification, Closed, Cancelled) -- those
// aren't sitting with a review group at all, so the field shows "—" instead
// of a misleading group.
// Derived from QA_PENDING_WITH (constants.ts) -- the same table that already
// drives the list's "Pending With" column and is itself kept in exact sync
// with dashboard.py's STAGE_TEAM/backend require_roles() gates -- rather
// than re-deriving its own status list, so this can never drift out of sync
// with "Pending With" or silently miss a status. Only labels that name an
// actual role-holding group get a RoleGroupLink; "Requester" (an individual,
// not a group) and "--" (terminal/dead-end) both resolve to null, which
// callers render as "--".
function assignedGroupFor(
  status: string,
  applicationMasterStatus?: string | null,
  department?: string | null,
): { role: string | string[]; label: string; department?: string | null } | null {
  // Reported directly: while the request's own status is still
  // SM_APPROVAL_PENDING but its Application Name is a brand-new entry
  // awaiting the Application Owner (see applicationNameAwareStatusLabel in
  // Common.tsx, which overrides the Status badge the same way), the actual
  // work is sitting with the Application Owner, not the SM yet -- checked
  // first, ahead of the normal QA_PENDING_WITH-derived mapping below, since
  // this is a sub-state of SM_APPROVAL_PENDING rather than its own status
  // value. `department` is passed through here (and nowhere else in this
  // function) because Application Owner is a department-scoped role
  // enforced server-side (require_same_department in
  // decide_app_owner_name) -- RoleGroupLink filters its member list to it
  // when provided.
  if (applicationNameAwareStatusLabel(status, applicationMasterStatus)) {
    return { role: "APPLICATION_OWNER", label: "Application Owner", department };
  }
  const pendingWith = QA_PENDING_WITH[status];
  // Reported directly: "SM mapping should be based on department level. but
  // SM group details showing those are from different department." SM and
  // Department Head are BOTH department-scoped roles enforced server-side
  // (require_same_department in sm_decision/department_head_decision,
  // functional.py) exactly like Application Owner above -- `department` was
  // missing here, so RoleGroupLink showed every SM/Department Head in the
  // system instead of just the ones who could actually act on this request.
  if (pendingWith === "SM") return { role: "SM", label: "SM", department };
  if (pendingWith === "Department Head") {
    return { role: ["DEPARTMENT_HEAD_CM", "DEPARTMENT_HEAD_AGM"], label: "Department Head", department };
  }
  // Reported directly: this "QA Lead group members" list should only show
  // literal QA_LEAD role holders -- Chief Manager - QA / AGM - QA act on
  // this work via their own separate Executive bypass (isAssignedQALead
  // below), not by being members of the QA Lead group, so they're
  // deliberately excluded from this roster even though they can still open
  // the request and act on it directly.
  if (pendingWith === "QA Lead") return { role: "QA_LEAD", label: "QA Lead" };
  // "QA" covers TESTER_ASSIGNED/TEST_DESIGN/EXECUTION_IN_PROGRESS/RETESTING --
  // limited to QA_ENGINEER only (reported directly) -- "Assigned Tester(s)"
  // elsewhere on the page names the specific individual, this names the
  // execution-team group accountable for the stage; QA_LEAD has its own
  // separate group above instead of also appearing here.
  if (pendingWith === "QA") return { role: QA_EXECUTION_GROUP_ROLE, label: "QA" };
  return null;
}

function StartExecutionModal({ req, busy, onCancel, onStart }: {
  req: FunctionalOut;
  busy: boolean;
  onCancel: () => void;
  onStart: (cycleId: number | null, previewToken?: string) => void;
}) {
  const [cycles, setCycles] = useState<EligibleTestCycleOut[]>([]);
  const [selectedCycleId, setSelectedCycleId] = useState<number | null>(null);
  const [requestPreviewToken, setRequestPreviewToken] = useState("");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<unknown>(null);
  // A returned clearance may have immutable Completed history plus a new
  // Draft re-execution clone. Start the active clone, never the first
  // historical cycle merely because it was linked earliest.
  const linkedCycle = req.linked_test_cycles?.find((cycle) => cycle.status !== "Completed")
    || (req.linked_test_cycles?.length === 1 ? req.linked_test_cycles[0] : undefined);

  useEffect(() => {
    if (linkedCycle) return;
    setLoading(true);
    setError(null);
    api.get<EligibleTestCycleOut[]>(`/api/functional-requests/${req.id}/eligible-test-cycles`)
      .then(setCycles).catch(setError).finally(() => setLoading(false));
  }, [linkedCycle, req.id]);

  const query = search.trim().toLowerCase();
  const visibleCycles = cycles.filter((cycle) => !query ||
    cycle.cycle_key.toLowerCase().includes(query) ||
    cycle.name.toLowerCase().includes(query) ||
    cycle.project_key.toLowerCase().includes(query) ||
    cycle.project_name.toLowerCase().includes(query));
  const selectedCycle = cycles.find((cycle) => cycle.id === selectedCycleId);

  return <Modal
    title="Start Functional Test Execution"
    onClose={onCancel}
    variant="dialog"
    preventBackdropClose
  >
    {linkedCycle ? <>
      <div className="execution-cycle-existing">
        <span className="execution-cycle-existing-icon">✓</span>
        <div>
          <strong>
            Test Cycle <Link to={`/test-execution?project=${linkedCycle.project_id}&cycle=${linkedCycle.id}`}>{linkedCycle.cycle_key}</Link> is already linked to this request.
          </strong>
          <p>Do you want to start execution?</p>
          <small>{linkedCycle.name} · {linkedCycle.status}</small>
        </div>
      </div>
      <div className="execution-cycle-actions">
        <button type="button" className="btn" disabled={busy} onClick={onCancel}>Cancel</button>
        <button type="button" className="btn btn-primary" disabled={busy} onClick={() => onStart(null)}>{busy ? "Starting…" : "Start Execution"}</button>
      </div>
    </> : <div className="execution-cycle-dialog">
      <div className="execution-cycle-hero">
        <span className="execution-cycle-hero-icon" aria-hidden="true">↗</span>
        <div>
          <span className="execution-cycle-kicker">Required before execution</span>
          <strong>Link a Test Cycle</strong>
          <p>Select the cycle that will hold the test cases, results, and defects for <b>{req.request_id}</b>.</p>
        </div>
      </div>

      <div className="execution-cycle-picker">
        <div className="execution-cycle-picker-heading">
          <div><strong>Eligible Test Cycles</strong><span>Draft, Ready, and In Progress cycles</span></div>
          {!loading && <span>{cycles.length} available</span>}
        </div>
        <ClearableSearchInput value={search} onChange={(event) => setSearch(event.target.value)} onClear={() => setSearch("")} placeholder="Search by cycle name, ID, or project" clearLabel="Clear test cycle search" />
        {loading && <div className="execution-cycle-loading"><span />Loading eligible Test Cycles…</div>}
        {!loading && cycles.length === 0 && !error && <div className="execution-cycle-empty"><span className="execution-cycle-empty-icon">○</span><strong>No eligible Test Cycles</strong><span>Create or make a Test Cycle available for this application, then return here to start execution.</span></div>}
        {!loading && cycles.length > 0 && visibleCycles.length === 0 && <div className="execution-cycle-empty compact"><strong>No matching Test Cycles</strong><span>Try a different cycle name, ID, or project.</span></div>}
        <div className="execution-cycle-list">
          {visibleCycles.map((cycle) => <button type="button" key={cycle.id} aria-pressed={selectedCycleId === cycle.id} className={selectedCycleId === cycle.id ? "selected" : ""} onClick={() => { setSelectedCycleId(cycle.id); setRequestPreviewToken('') }}>
            <span className="execution-cycle-radio" aria-hidden="true"><i /></span>
            <span className="execution-cycle-copy"><strong>{cycle.name}</strong><small><b>{cycle.cycle_key}</b><span>•</span>{cycle.project_key}<span>•</span>{cycle.project_name}</small></span>
            <Badge status={cycle.status} />
          </button>)}
        </div>
        <ErrorText error={error} />
      </div>

      {selectedCycle && <CycleRequestPicker projectId={selectedCycle.project_id} application={req.application_name || ''}
        cycleId={selectedCycle.id} value={`Functional:${req.id}`} options={[req]} disabled standalone={false}
        onChange={() => {}} onReviewed={setRequestPreviewToken} reviewRequired reviewed={!!requestPreviewToken} />}

      <div className="execution-cycle-footer">
        <div className={`execution-cycle-selection ${selectedCycle ? "ready" : ""}`}>
          <span aria-hidden="true">{selectedCycle ? "✓" : "1"}</span>
          <div>{selectedCycle ? <><strong>{selectedCycle.cycle_key} selected</strong><small>Ready to link and begin execution</small></> : <><strong>Select one Test Cycle</strong><small>The action becomes available after selection</small></>}</div>
        </div>
        <div className="execution-cycle-actions">
          <button type="button" className="btn" disabled={busy} onClick={onCancel}>Cancel</button>
          <button type="button" className="btn btn-primary" disabled={busy || selectedCycleId === null || !requestPreviewToken} onClick={() => onStart(selectedCycleId, requestPreviewToken)}>{busy ? "Starting…" : "Link & Start Execution"}</button>
        </div>
      </div>
    </div>}
  </Modal>;
}

// Reported directly: while an Application Name is still with the
// Application Owner -- the first of the two approval tiers a name goes
// through, see ApplicationNameBanner -- this request's own `status` is
// already SM_APPROVAL_PENDING under the hood (same reason
// applicationNameAwareStatusLabel in components/Common.tsx overrides the
// Status badge), so this stepper would otherwise highlight "SM Approval" as
// the current stage even though there's nothing for the SM to do yet.
// `applicationOwnerPending` inserts an extra "Application Owner" step ahead
// of "SM Approval" and highlights THAT one as current instead -- only while
// genuinely at that exact sub-step (SM Approval stage AND
// application_master_status is still PENDING_APP_OWNER); collapses back to
// the normal stage list the moment the name clears that tier (or was never
// gated by one at all, e.g. an older request with no ApplicationMaster row).
function LifecyclePreview({
  status,
  history,
  applicationOwnerPending,
}: {
  status?: string;
  history: ApprovalActionOut[];
  applicationOwnerPending?: boolean;
}) {
  let stages = [...LIFECYCLE_STAGES];
  let effectiveActiveIndex = lifecycleStageIndex(status);

  // A return is a branch back to the requester, not continued forward
  // progress at the reviewer who returned it. Keep the stages genuinely
  // reached before the decision, then show where the request is now.
  if (status === "RETURNED_BY_SM" || status === "SM_REJECTED") {
    stages = ["Draft", "SM Approval", "Requester Action", "Dept. Head Approval", "QA Activity", "Clearance", "Closed"];
    effectiveActiveIndex = 2;
  } else if (status === "RETURNED_BY_DEPARTMENT_HEAD") {
    stages = ["Draft", "SM Approval", "Dept. Head Approval", "Requester Action", "QA Activity", "Clearance", "Closed"];
    effectiveActiveIndex = 3;
  } else if (status === "RETURNED_BY_QA_LEAD") {
    stages = ["Draft", "SM Approval", "Dept. Head Approval", "QA Activity", "Requester Action", "Clearance", "Closed"];
    effectiveActiveIndex = 4;
  }

  const latestRejection = [...history].reverse().find((item) =>
    String(item.decision || "").toLowerCase() === "rejected"
  );
  const rejectionStep = latestRejection?.step_name || "";
  const terminalAfterRejection = status === "CLOSED" && !!latestRejection;

  // Rejection/early closure is a terminal branch. Do not paint QA Activity
  // and Sign-off as completed when the request never entered those stages.
  if (status === "DEPARTMENT_HEAD_REJECTED" || (terminalAfterRejection && rejectionStep.includes("Department Head"))) {
    stages = ["Draft", "SM Approval", "Dept. Head Approval", "Closed"];
    effectiveActiveIndex = 3;
  } else if (terminalAfterRejection && rejectionStep.includes("SM Approval")) {
    stages = ["Draft", "SM Approval", "Closed"];
    effectiveActiveIndex = 2;
  } else if (status === "CANCELLED") {
    stages = ["Draft", "Closed"];
    effectiveActiveIndex = 1;
  }

  const showAppOwnerStage = !!applicationOwnerPending && status === "SM_APPROVAL_PENDING";
  if (showAppOwnerStage) {
    stages = [LIFECYCLE_STAGES[0], "Application Owner", ...LIFECYCLE_STAGES.slice(1)];
    effectiveActiveIndex = 1;
  }
  return (
    <div className="stepper" style={{ margin: "4px 0 18px" }}>
      {stages.map((label, i) => (
        <React.Fragment key={label}>
          <div className={`step ${i <= effectiveActiveIndex ? "filled" : ""} ${i === effectiveActiveIndex ? "current" : ""}`}>
            <div className="circle">{i + 1}</div>
            <div className="step-label">{label}</div>
          </div>
          {i < stages.length - 1 && (
            <div className={`connector ${i < effectiveActiveIndex ? "filled" : ""}`} />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function lifecycleStageIndex(status?: string): number {
  if (!status || status === "DRAFT") return 0;
  if (["SUBMITTED", "SM_APPROVAL_PENDING", "RETURNED_BY_SM"].includes(status))
    return 1;
  if (
    [
      "DEPARTMENT_HEAD_APPROVAL_PENDING",
      "RETURNED_BY_DEPARTMENT_HEAD",
    ].includes(status)
  )
    return 2;
  if (
    [
      "QA_LEAD_ASSIGNED",
      "READINESS_VERIFICATION",
      "RETURNED_BY_QA_LEAD",
      "QA_ACTIVITY_INITIATED",
      "PLANNING",
      "TESTER_ASSIGNED",
      "TEST_DESIGN",
      "EXECUTION_IN_PROGRESS",
      "DEFECT_RAISED",
      "WAITING_FOR_FIX",
      "RETESTING",
      "QA_COMPLETED",
    ].includes(status)
  )
    return 3;
  if (
    ["QA_SIGNOFF_PENDING", "QA_SIGNED_OFF", "REQUESTER_VERIFICATION", "QA_CHANGE_REVIEW"].includes(
      status
    )
  )
    return 4;
  if (
    ["CLOSED", "CANCELLED", "SM_REJECTED", "DEPARTMENT_HEAD_REJECTED"].includes(
      status
    )
  )
    return 5;
  return 0;
}

function userName(users: UserOption[], id?: number | null): string | null {
  const u = users.find((x) => x.id === id);
  return u ? u.full_name : null;
}

interface FunctionalDetailProps {
  req: FunctionalOut;
  onClose: () => void;
  onChanged: (req: FunctionalOut) => void;
  users: UserOption[];
  preview?: { busy: boolean; onConfirm: () => void };
}

export function FunctionalDetail(props: FunctionalDetailProps) {
  return <WorkSession target={{ kind: 'functional', id: props.req.id }}><FunctionalDetailContent {...props} /></WorkSession>
}

function FunctionalDetailContent({
  req,
  onClose,
  onChanged,
  users,
  preview,
}: FunctionalDetailProps) {
  const { user } = useAuth();
  const navigate = useRequestNavigation();
  const [tab, setTab] = useWorkState('functional.detail.tab', "overview");
  const [checklist, setChecklist] = useState<ChecklistItemOut[]>([]);
  const [history, setHistory] = useState<ApprovalActionOut[]>([]);
  const [error, setError] = useState<unknown>(null);
  const [comments, setComments] = useWorkState('functional.detail.comments', "");
  // 2026-08 -- dedicated from the shared `comments` state above (which is
  // only ever populated by the unrelated "What was the behaviour earlier?"
  // Readiness Verification textarea, and was empty at this later stage) so
  // the Requester can actually give a reason for "Changes Required" -- see
  // the backend's own mandatory-reason check in
  // routers/functional.py::requester_decision.
  const [requesterComments, setRequesterComments] = useWorkState('functional.detail.requesterComments', "");
  // Requester-requested certificate changes are first reviewed by QA. No
  // successor certificate or mutable copy of an issued certificate is made
  // until QA explicitly chooses the appropriate path below.
  const [clearanceChangeComments, setClearanceChangeComments] = useWorkState('functional.detail.clearanceChangeComments', "");
  const [retestSourceCycleId, setRetestSourceCycleId] = useWorkState<number | null>('functional.detail.retestSourceCycleId', null);
  const [createdReexecutionCycle, setCreatedReexecutionCycle] = useState<LinkedTestCycleRef | null>(null);
  const [selectedQALead, setSelectedQALead] = useWorkState('functional.detail.selectedQALead', "");
  const [selectedTesters, setSelectedTesters] = useWorkState<string[]>('functional.detail.selectedTesters', (req.assigned_tester_ids || "").split(",").filter(Boolean));
  // 2026-08 Reassignment CR -- a reason is mandatory when this is a genuine
  // reassignment (not the very first tester assignment); the backend
  // enforces this too (reassignment.require_reason), this is just the UI
  // half. Reset whenever the request itself changes, same as selectedTesters.
  const [reassignReason, setReassignReason] = useWorkState('functional.detail.reassignReason', "");
  // Whether the "require Department Head re-approval on return" popup (see
  // canReadinessDecide below) is open -- reported directly: an always-visible
  // checkbox next to "Readiness Failed" was easy to miss/forget before
  // clicking, so this is now asked as a pop-up at the moment of failing
  // readiness instead.
  const [showReapprovalConfirm, setShowReapprovalConfirm] = useState(false);
  const [readinessPassError, setReadinessPassError] = useState<unknown>(null);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [editingDetails, setEditingDetails] = useWorkState('functional.detail.editingDetails', false);
  const [showSignoffModal, setShowSignoffModal] = useState(false);
  const [showStartExecution, setShowStartExecution] = useWorkState('functional.detail.showStartExecution', false);
  const [executionNotice, setExecutionNotice] = useState("");
  const { documentsByItem, reload: reloadEvidence } = useChecklistDocuments(
    "/api/functional-requests",
    req.id
  );

  const load = useCallback(async () => {
    try {
      const [cl, hist] = await Promise.all([
        api.get<ChecklistItemOut[]>(
          `/api/functional-requests/${req.id}/checklist`
        ),
        api.get<ApprovalActionOut[]>(
          `/api/functional-requests/${req.id}/history`
        ),
      ]);
      setChecklist(cl);
      setHistory(hist);
    } catch (err) {
      setError(err);
    }
  }, [req.id]);

  useEffect(() => {
    load();
  }, [load]);

  const previousRequest = useRef(req.id);
  useEffect(() => {
    if (previousRequest.current === req.id) return;
    previousRequest.current = req.id;
    setCreatedReexecutionCycle(null);
    setRetestSourceCycleId(null);
    setClearanceChangeComments("");
  }, [req.id]);

  async function act(action: string, extra?: Record<string, unknown>) {
    setError(null);
    const isReadinessPass = action === "readiness-decision" && extra?.decision === "Passed";
    if (isReadinessPass) setReadinessPassError(null);
    setBusyAction(action);
    try {
      const updated = await api.post<FunctionalOut>(
        `/api/functional-requests/${req.id}/${action}`,
        extra || {}
      );
      onChanged(updated);
      setComments("");
      setRequesterComments("");
      setClearanceChangeComments("");
      await load();
    } catch (err) {
      if (isReadinessPass) setReadinessPassError(err);
      else setError(err);
    } finally {
      setBusyAction(null);
    }
  }

  async function decideClearanceChange(
    decision: "ResendIssued" | "ReviseCertificate" | "Retest",
    sourceCycleId?: number | null,
  ) {
    const reason = clearanceChangeComments.trim();
    if (reason.length < 3) {
      setError(new Error("Enter QA review comments of at least 3 characters before choosing an action."));
      return;
    }
    if (decision === "Retest" && !sourceCycleId) {
      setError(new Error("Select the completed Test Cycle to use as the re-execution baseline."));
      return;
    }

    setError(null);
    setBusyAction("clearance-change-decision");
    try {
      const existingCycleIds = new Set((req.linked_test_cycles || []).map((cycle) => cycle.id));
      const updated = await api.post<FunctionalOut>(
        `/api/functional-requests/${req.id}/clearance-change-decision`,
        {
          decision,
          comments: reason,
          ...(decision === "Retest" ? { source_cycle_id: sourceCycleId } : {}),
        },
      );
      const newReexecution = decision === "Retest"
        ? (updated.linked_test_cycles || []).find((cycle) => !existingCycleIds.has(cycle.id)) || null
        : null;
      setCreatedReexecutionCycle(newReexecution);
      setClearanceChangeComments("");
      setRetestSourceCycleId(null);
      onChanged(updated);
      await load();
    } catch (err) {
      setError(err);
    } finally {
      setBusyAction(null);
    }
  }

  // Called once the QA Clearance Certificate modal has successfully created
  // its Draft certificate (POST /api/signoffs) -- immediately links it to
  // this request while the work remains with its QA author. The request only
  // moves to QA_SIGNOFF_PENDING when that Draft is submitted for QA Lead
  // approval (see routers/signoff.py::submit_signoff).
  async function requestSignoffWithCertificate(cert: SignOffOut) {
    setShowSignoffModal(false);
    await act("request-signoff", { signoff_id: cert.id });
  }

  async function startExecution(cycleId: number | null, previewToken?: string) {
    setError(null);
    setBusyAction("start-execution");
    try {
      const updated = await api.post<FunctionalOut>(
        `/api/functional-requests/${req.id}/start-execution`,
        { test_cycle_id: cycleId, ...(previewToken ? { request_preview_token: previewToken } : {}) }
      );
      onChanged(updated);
      setShowStartExecution(false);
      setExecutionNotice(cycleId !== null
        ? "Test cycle linked successfully. Test execution has started."
        : `Test Cycle ${req.linked_test_cycles?.find((cycle) => cycle.status !== "Completed")?.cycle_key || req.linked_test_cycles?.[0]?.cycle_key || ""} was already linked. Test execution has started.`);
      await load();
    } catch (err) {
      setError(err);
    } finally {
      setBusyAction(null);
    }
  }

  async function toggleChecklistItem(item: ChecklistItemOut) {
    setError(null);
    try {
      await api.put(`/api/functional-requests/${req.id}/checklist/${item.id}`, {
        is_complete: !item.is_complete,
      });
      load();
    } catch (err) {
      setError(err);
    }
  }

  const qaLeads = useUserOptions('qa_lead')
  const testers = useUserOptions('tester')

  const viewOnly = !!preview || isViewOnly(user);
  const workflowActors = functionalWorkflowActors({
    userId: user?.id,
    requesterId: req.requester_id,
    assignedTesterIds: req.assigned_tester_ids,
    viewOnly,
    isQaLeadGroup: hasWorkspaceRole(user, "QA_LEAD", "CHIEF_MANAGER_QA", "AGM_QA"),
    isQaEngineer: hasWorkspaceRole(user, "QA_ENGINEER"),
  });
  const isRequester = workflowActors.isRequester;
  const isActiveDelegate = !viewOnly && req.active_delegation?.status === "ACTIVE" && req.active_delegation.assigned_to_id === user?.id;
  const requesterInputEditor = isActiveDelegate || (isRequester && !req.active_delegation);

  const status = req.status;
  const sameDept = hasDepartment(user, req.department);
  // Executive bypass: CHIEF_MANAGER_QA/AGM_QA can act on every QA-Lead-
  // gated action, same as Admin, without being listed as "QA Lead group"
  // members anywhere (display-only concern, kept to literal QA_LEAD --
  // see assignedGroupFor below). ORACLE_MIGRATION_2026-07.md section 59.
  const isQALead = workflowActors.isQaLeadGroup;
  const isAssignedQALead = isQALead;
  const assignedTesterNames = (req.assigned_tester_ids || "")
    .split(",").map((id) => id.trim()).filter(Boolean)
    .map((id) => userName(users, Number(id)) || `User #${id}`).join(", ");
  const isAssignedTester = workflowActors.isAssignedTester;

  const canVerifyChecklist =
    isAssignedQALead &&
    status === "READINESS_VERIFICATION";

  const canSubmit = isRequester && status === "DRAFT";
  // SM_REJECTED included alongside the RETURNED_BY_* statuses -- reported
  // directly, a rejected request is now reopenable via the same resubmit
  // action instead of being a dead end (see resubmitLabel below for the
  // button's own wording).
  const canResubmit =
    isRequester && !req.active_delegation &&
    [
      "RETURNED_BY_SM",
      "SM_REJECTED",
      "RETURNED_BY_DEPARTMENT_HEAD",
      "RETURNED_BY_QA_LEAD",
    ].includes(status);
  const resubmitLabel = status === "SM_REJECTED" ? "Reopen Request" : "Re-submit";
  // SM and Department Head approvals remain requester-department scoped.
  // QA is a central vertical, so QA Lead actions below are intentionally not
  // bound to the requester's department.
  // Blocks Sign/Approve on both the SM and Department Head decision panels
  // below while this request's Application Name is still PENDING/REJECTED
  // (not yet APPROVED) -- see ApplicationNameBanner. An unset status (no
  // ApplicationMaster row at all, e.g. an older request) doesn't block.
  const applicationNameBlocking =
    !!req.application_master_status &&
    req.application_master_status !== "APPROVED";
  // Reported directly: canEditDetails above lets the SM/Department Head
  // themselves open Edit Details while the request is sitting at their own
  // decision -- if they untick a mandatory Readiness checklist item there
  // (fix something, then decide), Sign/Approve must be blocked the exact
  // same way the QA Request wizard already blocks Submit/Raise for the same
  // reason (see QARequests/RequestDetail.tsx's own pendingMandatory), not
  // silently let through just because this is post-raise now.
  const pendingSelfDeclare = checklist
    .filter((c) => c.is_mandatory && !c.requester_checked)
    .map((c) => c.item);
  const pendingMandatoryEvidence = checklist
    .filter((c) => c.is_mandatory && (documentsByItem[c.id] || []).length === 0)
    .map((c) => c.item);
  // Reported directly: the SM's own block message used to always say "your
  // decision above" even while the name was still sitting with the
  // Application Owner (i.e. not the SM's turn at all yet) -- misleading.
  // Tier-aware instead: names the actual holdup and who owns it. Updated
  // again when the decision banner itself moved off this page entirely (see
  // RequestDetail.tsx's own ApplicationNameBanner) -- "above" no longer
  // means anything here, so the PENDING_SM case now points to where the
  // decision actually happens.
  const smApplicationNameBlockedMessage =
    req.application_master_status === "PENDING_APP_OWNER"
      ? "This request's Application Name is still pending Application Owner approval -- it needs to be decided there before you can approve this request."
      : req.application_master_status === "REJECTED"
      ? "This request's Application Name was rejected -- the requester needs to pick a different name before this request can be approved."
      : "Application Name is still pending your decision -- decide it from this request's QA Request page before approving this request.";
  // Reported directly: a person who raised this request but also separately
  // holds SM/Department Head for the same department must not be able to
  // approve their own request just because they wear both hats -- someone
  // else holding that role has to decide it instead. System administration
  // is not operational workflow authority.
  const isSelfApproval = req.requester_id === user?.id;
  const canSMDecide =
    hasRole(user, "SM") &&
    status === "SM_APPROVAL_PENDING" &&
    sameDept &&
    !isSelfApproval;
  const canDepartmentHeadDecide =
    hasRole(user, "DEPARTMENT_HEAD_CM", "DEPARTMENT_HEAD_AGM") &&
    status === "DEPARTMENT_HEAD_APPROVAL_PENDING" &&
    sameDept &&
    !isSelfApproval;
  // Reported directly: "only the assigned person can update" -- once the
  // request has moved past the requester (e.g. to SM_APPROVAL_PENDING), the
  // requester is no longer the current assignee, so evidence control passes
  // exclusively to whoever it's actually sitting with now, matching the
  // backend's own (now-exclusive) _can_upload_documents exactly. Combined
  // with canManageReadinessEvidence's own status gate below, this only ever
  // matters for the pre-QA-lead-assignment statuses it covers.
  const evidenceOwner =
    (status === "SM_APPROVAL_PENDING" ? canSMDecide :
    status === "DEPARTMENT_HEAD_APPROVAL_PENDING" ? canDepartmentHeadDecide :
    requesterInputEditor);
  // Document and Evidence Access Control Based on Workflow Stage: exactly 3
  // upload stages, then a hard lock -- (1) the requester while it's Draft/
  // Submitted/Returned-by-*/Rejected/back for final verification, (2) the
  // SM only while SM_APPROVAL_PENDING, (3) the Department Head only while
  // DEPARTMENT_HEAD_APPROVAL_PENDING. Every QA-activity status after
  // Department Head approval is locked for everyone but Admin -- mirrors
  // the backend's own (now-simplified) _can_upload_documents exactly. Used
  // for the general Documents tab; evidenceOwner above covers the same 3
  // stages for checklist evidence.
  const canManageDocuments =
    (["DRAFT", "SUBMITTED", "RETURNED_BY_SM", "SM_REJECTED", "RETURNED_BY_DEPARTMENT_HEAD",
      "RETURNED_BY_QA_LEAD", "REQUESTER_VERIFICATION"].includes(status)
      ? requesterInputEditor
      : status === "SM_APPROVAL_PENDING"
      ? canSMDecide
      : status === "DEPARTMENT_HEAD_APPROVAL_PENDING"
      ? canDepartmentHeadDecide
      : false);
  const canStartReadiness =
    isAssignedQALead && status === "QA_LEAD_ASSIGNED";
  const canReadinessDecide =
    isAssignedQALead && status === "READINESS_VERIFICATION";
  const canBeginPlanning =
    isAssignedQALead && status === "QA_ACTIVITY_INITIATED";
  // 2026-08 -- reported directly: "once assigned there are no other option
  // to reassign the tester or modify the tester. give qa lead to reassign as
  // well as the current assign people can reasign to another qa member."
  // Widened from "QA Lead group only, only while status === PLANNING" to:
  // the QA Lead group OR any currently-assigned tester, at any point across
  // TESTER_REASSIGNABLE_STATUSES (Planning through Retesting). The backend
  // (functional.py's assign_tester) enforces the exact same window/authors
  // -- this only decides whether the button renders.
  const isInitialTesterAssignment = status === "PLANNING";
  // 2026-08 Reassignment CR, reported directly: "Reassignment shall be
  // permitted to: the current assignee, the Department Head of the
  // department to which the current assignee belongs, or Admin users." --
  // then, reported directly again: QA_LEAD is required to keep reassignment
  // rights too, restoring parity with isAssignedQALead (which already gates
  // the first assignment). Mirrors functional.py's
  // _require_can_reassign_tester exactly.
  const isQADepartmentHead = hasWorkspaceRole(user, "CHIEF_MANAGER_QA", "AGM_QA");
  const canReassignTester = isAssignedTester || isQADepartmentHead || hasRole(user, "QA_LEAD");
  const canAssignTester =
    (isInitialTesterAssignment ? isAssignedQALead || isAssignedTester : canReassignTester) &&
    TESTER_REASSIGNABLE_STATUSES.includes(status);
  const currentTesterIds = (req.assigned_tester_ids || "").split(",").filter(Boolean).map(Number).sort((a, b) => a - b);
  const nextTesterIds = selectedTesters.map(Number).sort((a, b) => a - b);
  const testerAssignmentChanged = currentTesterIds.length !== nextTesterIds.length || currentTesterIds.some((id, index) => id !== nextTesterIds[index]);
  // Pre-fill the picker with the currently-assigned tester(s) when this is a
  // reassignment (not the first-ever assignment) -- so reassigning defaults
  // to "hand off from the current roster" rather than starting blank. Only
  // runs once per loaded request (keyed on id + the assignment string
  // itself), so it won't stomp on in-progress edits to the picker.
  const previousAssignment = useRef(`${req.id}:${req.assigned_tester_ids}`);
  useEffect(() => {
    const assignmentKey = `${req.id}:${req.assigned_tester_ids}`;
    if (previousAssignment.current === assignmentKey) return;
    previousAssignment.current = assignmentKey;
    if (canAssignTester && !isInitialTesterAssignment) {
      setSelectedTesters((req.assigned_tester_ids || "").split(",").filter(Boolean));
    }
    // req.assigned_tester_ids only actually changes once a reassignment has
    // saved and reloaded, so clearing the reason field here (rather than
    // optimistically after the act() call, which resolves the same whether
    // the request succeeded or failed) only clears it on genuine success.
    setReassignReason("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [req.id, req.assigned_tester_ids, isInitialTesterAssignment]);
  const canStartTestDesign =
    isAssignedTester && status === "TESTER_ASSIGNED";
  const canStartExecution =
    isAssignedTester && status === "TEST_DESIGN";
  // Functional execution requires a linked Test Cycle. Defects are raised
  // and retested from that cycle. The old
  // Functional Raise Defect entry point is retired; the remaining legacy
  // status actions only let records already in those states finish.
  const hasLinkedCycle = (req.linked_test_cycles?.length ?? 0) > 0;
  const openLinkedCycles = (req.linked_test_cycles || []).filter(
    (cycle) => cycle.status !== "Completed"
  );
  // Resolve lineage heads across every linked cycle before applying the
  // signed certificate's environment. Otherwise an older UAT parent could
  // incorrectly reappear merely because its SIT successor was filtered out.
  const completedCycleLineageLeaves = clearanceRetestLineageLeaves(req.linked_test_cycles || []);
  const eligibleRetestSourceCycles = eligibleClearanceRetestCycles(
    req.linked_test_cycles || [],
    req.signoff_certificate_environment,
  );
  const effectiveRetestSourceCycleId = eligibleRetestSourceCycles.some((cycle) => cycle.id === retestSourceCycleId)
    ? retestSourceCycleId
    : eligibleRetestSourceCycles.length === 1
      ? eligibleRetestSourceCycles[0].id
      : null;
  const canRaiseDefect = false;
  const canMarkWaitingForFix =
    isAssignedTester && status === "DEFECT_RAISED";
  const canStartRetest =
    isAssignedTester && status === "WAITING_FOR_FIX";
  // Mark QA Complete requires a linked Test Cycle and that cycle must have
  // reached Completed -- see functional.py::complete_qa's matching gate.
  const completeQAMissingCycle =
    isAssignedTester &&
    ["EXECUTION_IN_PROGRESS", "RETESTING"].includes(status) &&
    !hasLinkedCycle;
  const completeQABlockedByCycle =
    isAssignedTester &&
    ["EXECUTION_IN_PROGRESS", "RETESTING"].includes(status) &&
    openLinkedCycles.length > 0;
  // 2026-08 -- reported directly: "'Request Sign Off' button is not
  // enable[d] for QA lead ... if tester [is] no[t] available then at least
  // [o]n behalf of QA he can raise the request." Previously this only
  // checked isAssignedTester, so a QA Lead (not also the assigned tester)
  // never saw the button even though whoever ran QA through to completion
  // should be able to raise the certificate -- widened to match the
  // backend's now-fixed "QA Lead group OR current tester" gate on both
  // POST /{id}/request-signoff (functional.py) and POST /api/signoffs
  // (signoff.py), so the QA Lead can raise it themselves when a tester
  // isn't available to.
  const canManageClearance =
    (isAssignedTester || isAssignedQALead) &&
    hasWorkspaceRole(user, "QA_ENGINEER", "QA_LEAD", "CHIEF_MANAGER_QA", "AGM_QA");
  const isCertificateRequesterFallback = isLegacyCertificateRequesterFallback({
    assignedTesterIds: req.assigned_tester_ids,
    certificateRequesterId: req.signoff_certificate_requester_id,
    userId: user?.id,
  }) && hasWorkspaceRole(user, "QA_ENGINEER", "QA_LEAD", "CHIEF_MANAGER_QA", "AGM_QA");
  const canDecideClearanceChange = canManageClearance || isCertificateRequesterFallback;
  const linkedCertificateStatus = req.signoff_certificate_status || null;
  const isClearanceDeniedOutcome = req.signoff_certificate_type === "Clearance Denied";
  const hasLinkedEditableCertificate = [
    "DRAFT",
    "RETURNED_BY_SM",
    "RETURNED_BY_DEPT_HEAD_COE",
    "RETURNED_BY_REQUESTER",
  ].includes(linkedCertificateStatus || "");
  const hasLinkedRevisionableCertificate = [
    "ISSUED",
    "ISSUED_UNDER_REVIEW",
    "SM_REJECTED",
    "DEPT_HEAD_COE_REJECTED",
  ].includes(linkedCertificateStatus || "");
  const canCreatePostRetestRevision = canDecideClearanceChange && status === "QA_COMPLETED" && hasLinkedRevisionableCertificate;
  const canContinueDraftClearance = canDecideClearanceChange && status === "QA_COMPLETED" && hasLinkedEditableCertificate && !!req.signoff_certificate_id;
  const clearanceCapabilities = functionalClearanceCapabilities({
    ...workflowActors,
    status,
    hasLinkedCycle,
    hasOpenLinkedCycle: openLinkedCycles.length > 0,
    hasLinkedCertificate: !!req.signoff_id,
    certificateRequesterFallback: isCertificateRequesterFallback,
  });
  const {
    canCompleteQA,
    canRequestSignoff,
    canReviewClearanceChanges,
    canRequesterDecide,
  } = clearanceCapabilities;
  const revisionPrompt = linkedCertificateStatus === "SM_REJECTED" || linkedCertificateStatus === "DEPT_HEAD_COE_REJECTED"
    ? "The previous certificate was rejected. Its terminal decision remains immutable; create one governed Draft successor and run the full approval chain again."
    : isClearanceDeniedOutcome
      ? "The issued denial decision remains immutable. Create one governed Draft successor from the latest evidence; QA Lead and Executive approval will run again before a revised decision returns to the requester."
    : linkedCertificateStatus === "ISSUED_UNDER_REVIEW"
      ? "Re-testing is complete. The issued certificate remains immutable and under review. Create its governed Draft successor from the latest execution evidence; QA Lead and Executive approval will run again."
      : "The linked issued certificate remains immutable. Create its governed Draft successor from the latest eligible evidence; QA Lead and Executive approval will run again.";
  // "Confirm Sign-off" (a manual QA Lead click) removed -- the linked
  // certificate reaching ISSUED now auto-advances this request straight to
  // Requester Verification (see routers/signoff.py::
  // _sync_linked_functional_request), so there's nothing left to manually
  // confirm here. While a certificate is still working through its own
  // Tester -> SM -> Department Head COE chain, this request just sits at
  // "QA Clearance Pending" with no action available on this side -- correct,
  // since it's genuinely waiting on someone else's decision, not on QA.
  const latestRequesterChange = [...history].reverse().find((item) => (
    String(item.decision || "").toLowerCase().replace(/[^a-z]/g, "").startsWith("changesrequired")
  ));
  // Mirrors backend FUNCTIONAL_EDITABLE_STATUSES/_can_edit_details exactly:
  // the requester (or admin) may edit while it's Draft or sitting with them
  // after a return (RETURNED_BY_SM/RETURNED_BY_DEPARTMENT_HEAD/
  // RETURNED_BY_QA_LEAD) -- returning a request hands it back to the
  // requester to fix and resubmit, so the reviewer who returned it doesn't
  // also keep edit access. Separately, the SM/Department Head may edit
  // while the request is genuinely pending *their own* decision
  // (SM_APPROVAL_PENDING/DEPARTMENT_HEAD_APPROVAL_PENDING) -- fix
  // something, then decide -- but that access disappears the moment
  // they've approved/returned/rejected; it never extends past Department
  // Head's own decision into QA's post-approval readiness/execution
  // stages.
  const canEditDetails =
    (requesterInputEditor &&
      [
        "DRAFT",
        "RETURNED_BY_SM",
        "SM_REJECTED",
        "RETURNED_BY_DEPARTMENT_HEAD",
        "RETURNED_BY_QA_LEAD",
      ].includes(status)) ||
    (hasRole(user, "SM") && status === "SM_APPROVAL_PENDING" && sameDept) ||
    (hasRole(user, "DEPARTMENT_HEAD_CM", "DEPARTMENT_HEAD_AGM") &&
      status === "DEPARTMENT_HEAD_APPROVAL_PENDING" &&
      sameDept);

  return (
    <Modal
      title={`${req.request_id} — ${req.application_name || ""}`}
      workView={!preview}
      closeDisabled={!!busyAction}
      onClose={onClose}
      wide
    >
      <div className="tabs">
        {["overview", "checklist", "documents", "history"].map(
          (t) => (
            <button
              key={t}
              className={tab === t ? "active" : ""}
              onClick={() => setTab(t)}
            >
              {t === "history" ? "Activity" : t[0].toUpperCase() + t.slice(1)}
            </button>
          )
        )}
      </div>
      <ErrorText error={error} />

      <TestingScopeNotice missing={req.missing_testing_types} parentId={req.qa_request_id} />
      {tab === "overview" && (
        <div>
          <LifecyclePreview
            status={req.status}
            history={history}
            applicationOwnerPending={req.application_master_status === "PENDING_APP_OWNER"}
          />

          <DetailSection title="Status">
            <DetailField label="Status">
              <WorkflowStatusBadge record={req} status={req.status} label={applicationNameAwareStatusLabel(req.status, req.application_master_status) || QA_STATUS_LABELS[req.status] || req.status} />
              {req.needs_dept_head_reapproval && (
                <span className="badge badge-yellow" style={{ marginLeft: 8 }}>
                  Department Head re-approval required after changes
                </span>
              )}
            </DetailField>
            <DetailField label="Priority / Risk">
              {req.priority || "—"} / {req.risk_rating || "—"}
            </DetailField>
            <DetailField label="Request Type(s)">
              {req.request_types || "—"}
            </DetailField>
            <DetailField label="Created">
              {formatDateTimeIST(req.created_at)}
            </DetailField>
            <DetailField label="Last Updated">
              {formatDateTimeIST(req.updated_at)}
            </DetailField>
          </DetailSection>

          <DetailSection title="Application & Change">
            <DetailField label="Application Name">
              {req.application_name || "—"}
              {req.application_master_status === "PENDING_APP_OWNER" && (
                <span className="badge badge-yellow" style={{ marginLeft: 8 }}>
                  Application Owner Approval Pending
                </span>
              )}
              {req.application_master_status === "PENDING_SM" && (
                <span className="badge badge-yellow" style={{ marginLeft: 8 }}>
                  Pending SM Approval
                </span>
              )}
              {req.application_master_status === "REJECTED" && (
                <span className="badge badge-red" style={{ marginLeft: 8 }}>
                  Rejected — pick a different name
                </span>
              )}
            </DetailField>
            {req.module_name && <DetailField label="Module Name">{req.module_name}</DetailField>}
            <DetailField label="CR Number/EPIC Number">
              {req.cr_number || req.epic_number || "—"}
            </DetailField>
            <DetailField label="Change Description">
              {req.change_description || "—"}
            </DetailField>
            <DetailField label="Change Type">
              {req.change_type || "—"}
            </DetailField>
            {req.change_type === "Bug Fix" && (
              <DetailField label="Defect Number (Raised By Business)">
                {req.business_defect_number || "—"}
              </DetailField>
            )}
            {["Bug Fix", "Enhancement"].includes(req.change_type || '') && (
              <DetailField label="Previous Completed Request ID">
                {req.bug_fix_source_request_id || "—"}
              </DetailField>
            )}
            <DetailField label="Department">
              {req.department || "—"}
            </DetailField>
            <DetailField label="Application Owner">
              {req.application_owner || "—"}
            </DetailField>
          </DetailSection>

          <DetailSection title="Environment & Release">
            <DetailField label="Deployment Environment">
              {req.environment || "—"}
            </DetailField>
            <DetailField label="Target Promotion Environment">
              {req.target_promotion_environment || "—"}
            </DetailField>
            <DetailField label="Release Version / Hash Value">
              {req.release_version || "—"}
            </DetailField>
            <DetailField label="Build Number / Hash Value">
              {req.build_number || "—"}
            </DetailField>
            <DetailField label="Target Release Date">
              {req.target_release_date || "—"}
            </DetailField>
          </DetailSection>

          <DetailSection title="People">
            <DetailField label="Requester">
              {userName(users, req.requester_id) || "—"}
            </DetailField>
            <DetailField label="Department Head">
              {userName(users, req.department_head_id) || "—"}
            </DetailField>
            <DetailField label="Assigned Group">
              {(() => {
                const assigned = assignedGroupFor(req.status, req.application_master_status, req.department);
                return assigned ? <RoleGroupLink role={assigned.role} label={assigned.label} department={assigned.department} /> : "—";
              })()}
            </DetailField>
            <DetailField label="Assigned Tester(s)">
              {assignedTesterNames || "—"}
            </DetailField>
          </DetailSection>

          {req.linked_test_cycles?.length > 0 && (
            <DetailSection title="Linked Test Cycle">
              {req.linked_test_cycles.map((cycle) => (
                <DetailField key={cycle.id} label={cycle.cycle_key}>
                  <Link className="linked-cycle-link" to={`/test-execution?project=${cycle.project_id}&cycle=${cycle.id}`}><strong>{cycle.name}</strong></Link> · {cycle.status}
                  {cycle.environment && <span className="muted small"> · {cycle.environment}</span>}
                  {cycle.reexecution_of_cycle_key && <span className="muted small"> · Re-execution of {cycle.reexecution_of_cycle_key}</span>}
                  {(cycle.start_date || cycle.end_date) && <span className="muted small"> · {cycle.start_date || "—"} to {cycle.end_date || "—"}</span>}
                </DetailField>
              ))}
            </DetailSection>
          )}

          {req.signoff_certificate_id && (
            // 2026-08 -- reported directly: "LINK THE CERTIFICATE ONCE
            // GENERATED" -- this request previously had no visible link to
            // its own QA Clearance certificate. Mirrors the "Linked Test
            // Cycle" section above; deep-links via SignOff.tsx's existing
            // `?open=<certificate_id>` pattern.
            <DetailSection title="Linked Clearance Certificate">
              <DetailField label={req.signoff_certificate_id}>
                <Link className="linked-cycle-link" to={`/signoff?open=${req.signoff_certificate_id}`}>
                  <strong>{req.signoff_certificate_id}</strong>
                </Link>{" "}
                · <WorkflowStatusBadge record={req} workflow="signoff" status={req.signoff_certificate_status} label={(req.signoff_certificate_status && SIGNOFF_STATUS_LABELS[req.signoff_certificate_status]) || req.signoff_certificate_status} />
                {req.signoff_certificate_environment && <span className="muted small"> · Tested in {req.signoff_certificate_environment}</span>}
              </DetailField>
            </DetailSection>
          )}

          {req.qa_request && (
            <p className="muted small">
              Raised alongside QA Request{" "}
              <strong>{req.qa_request.request_id}</strong> — see that request
              for supporting documents and any other linked
              SAST/DAST/Performance requests.
            </p>
          )}

          {(canSMDecide || canDepartmentHeadDecide) &&
            pendingSelfDeclare.length > 0 && (
              <WarningNotice
                style={{ marginTop: 8, marginBottom: 8 }}
              >
                <strong>Cannot Sign/Approve yet</strong> — the following
                mandatory Readiness checklist item(s) must be self-declared
                ready first (Edit Details):
                <ul style={{ margin: "6px 0 0", paddingLeft: 20 }}>
                  {pendingSelfDeclare.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </WarningNotice>
            )}

          {!preview && <>
          <div className="section-title">Workflow Actions</div>
          <FunctionalTestingProgress status={status} testerNames={assignedTesterNames} isAssignedTester={isAssignedTester} />
          {executionNotice && <div className={`execution-start-notice ${executionNotice.includes("was unlinked") ? "unlinked" : "linked"}`} role="status"><strong>{executionNotice.includes("was unlinked") ? "Test cycle unlinked" : "Execution started"}</strong><span>{executionNotice}</span></div>}
          {createdReexecutionCycle && (
            <div className="execution-start-notice linked" role="status">
              <strong>Re-execution cycle created</strong>
              <span>
                <Link to={`/test-execution?project=${createdReexecutionCycle.project_id}&cycle=${createdReexecutionCycle.id}`}>
                  {createdReexecutionCycle.cycle_key} — {createdReexecutionCycle.name}
                </Link>{" "}
                is linked to this request. Testcase membership was copied; execution results and defects were not.
              </span>
            </div>
          )}
          {completeQAMissingCycle && (
            <WarningNotice className="execution-cycle-required-warning" role="alert">
              <strong>Mark QA Complete is locked</strong>
              <span>This request has no linked Test Cycle. Relink it from Test Lifecycle before continuing.</span>
            </WarningNotice>
          )}
          {completeQABlockedByCycle && (
            <WarningNotice
              style={{ marginTop: 8, marginBottom: 8 }}
            >
              <strong>Mark QA Complete is locked</strong> — every linked Test
              Cycle must reach Completed first. Still open:{" "}
              {openLinkedCycles
                .map((cycle) => `${cycle.cycle_key} (${cycle.status})`)
                .join(", ")}
              . Raise and retest defects from Test Execution / the Defects
              module against the linked cycle.
            </WarningNotice>
          )}
          <div className="actions-panel">
            <div
              style={{
                display: "flex",
                gap: 8,
                flexWrap: "wrap",
                alignItems: "center",
              }}
            >
              <button
                className="btn btn-sm"
                onClick={() =>
                  api.downloadFile(
                    `/api/functional-requests/${req.id}/export`,
                    `${req.request_id}.pdf`
                  )
                }
              >
                Export PDF
              </button>
              <button className="btn btn-sm" onClick={() => navigate(`/defects?functional_request_id=${req.id}`)}>
                View linked defects
              </button>
              {canEditDetails && (
                <button
                  className="btn btn-sm"
                  disabled={!!busyAction}
                  onClick={() => setEditingDetails(true)}
                >
                  Edit Details
                </button>
              )}
              <RequestDelegation
                targetType="FUNCTIONAL"
                request={req}
                users={users}
                disabled={!!busyAction}
                onChanged={async (updated) => {
                  onChanged(updated);
                  await load();
                }}
              />
              {canSubmit && (
                <button
                  className="btn btn-primary btn-sm"
                  disabled={!!busyAction}
                  onClick={() => act("submit")}
                >
                  Submit for SM Approval
                </button>
              )}
              {canResubmit && (
                <button
                  className="btn btn-primary btn-sm"
                  disabled={!!busyAction || pendingMandatoryEvidence.length > 0 || !!req.missing_testing_types?.length}
                  onClick={() => act("resubmit")}
                >
                  {resubmitLabel}
                </button>
              )}
              {canResubmit && pendingMandatoryEvidence.length > 0 && (
                <p className="muted small" style={{ color: "var(--danger, #c0392b)", width: "100%" }}>
                  {pendingMandatoryEvidence.length} mandatory Readiness checklist item(s) have no attached evidence — see Edit Details.
                </p>
              )}

              {canSMDecide && (
                <ApprovalDecisionButtons
                  additionalTestingOptions={additionalTestingOptions(req.request_types, req.qa_request_id)}
                  userName={user?.full_name}
                  comments={comments}
                  busy={!!busyAction}
                  signBlocked={applicationNameBlocking || pendingSelfDeclare.length > 0}
                  signBlockedMessage={
                    applicationNameBlocking
                      ? smApplicationNameBlockedMessage
                      : pendingSelfDeclare.length > 0
                      ? "Mandatory Readiness checklist item(s) are not self-declared ready -- see the notice above."
                      : undefined
                  }
                  onApprove={(signed) =>
                    act("sm-decision", {
                      decision: "Approved",
                      comments: signed,
                    })
                  }
                  onReturn={(actionNote, requiredTestingTypes) =>
                    act("sm-decision", { decision: "Returned", comments: actionNote, required_testing_types: requiredTestingTypes })
                  }
                  onReject={(actionNote) =>
                    act("sm-decision", { decision: "Rejected", comments: actionNote })
                  }
                />
              )}

              {canDepartmentHeadDecide && (
                <ApprovalDecisionButtons
                  additionalTestingOptions={additionalTestingOptions(req.request_types, req.qa_request_id)}
                  userName={user?.full_name}
                  comments={comments}
                  busy={!!busyAction}
                  signBlocked={applicationNameBlocking || pendingSelfDeclare.length > 0}
                  signBlockedMessage={
                    applicationNameBlocking
                      ? "This request's Application Name is not yet approved by SM."
                      : pendingSelfDeclare.length > 0
                      ? "Mandatory Readiness checklist item(s) are not self-declared ready -- see the notice above."
                      : undefined
                  }
                  extraControlLabel="Assign to group"
                  extraControl={<RoleGroupLink role="QA_LEAD" label="QA Lead" />}
                  extraReady
                  onApprove={(signed) =>
                    act("department-head-decision", {
                      decision: "Approved",
                      comments: signed,
                    })
                  }
                  onReturn={(actionNote, requiredTestingTypes) =>
                    act("department-head-decision", {
                      decision: "Returned",
                      comments: actionNote,
                      required_testing_types: requiredTestingTypes,
                    })
                  }
                  onReject={(actionNote) =>
                    act("department-head-decision", {
                      decision: "Rejected",
                      comments: actionNote,
                    })
                  }
                />
              )}

              {canStartReadiness && (
                <button
                  className="btn btn-primary btn-sm"
                  disabled={!!busyAction}
                  onClick={() => act("start-readiness-verification")}
                >
                  Start Readiness Verification
                </button>
              )}
              {canReadinessDecide && (
                <>
                  <div className="form-field" style={{ width: "100%" }}>
                    <label htmlFor="readiness-earlier-behaviour">
                      What was the behaviour earlier? <small className="muted">(optional)</small>
                    </label>
                    <textarea
                      id="readiness-earlier-behaviour"
                      rows={3}
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      placeholder="Describe what the application's behaviour was before this QA cycle, for the tester's reference…"
                      disabled={!!busyAction}
                    />
                  </div>
                  <button
                    className="btn btn-success btn-sm"
                    disabled={!!busyAction}
                    onClick={() =>
                      act("readiness-decision", {
                        decision: "Passed",
                        comments,
                      })
                    }
                  >
                    Readiness Passed
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    disabled={!!busyAction}
                    onClick={() => setShowReapprovalConfirm(true)}
                  >
                    Readiness Failed
                  </button>
                </>
              )}
              {showReapprovalConfirm && (
                <ConfirmModal
                  title="Readiness Failed"
                  message="Require Department Head re-approval when this request is returned to the requester?"
                  confirmLabel="Yes, require re-approval"
                  cancelLabel="No, skip re-approval"
                  busy={!!busyAction}
                  onConfirm={() => {
                    setShowReapprovalConfirm(false);
                    act("readiness-decision", {
                      decision: "Failed",
                      comments,
                      require_dept_head_reapproval: true,
                    });
                  }}
                  onCancel={() => {
                    setShowReapprovalConfirm(false);
                    act("readiness-decision", {
                      decision: "Failed",
                      comments,
                      require_dept_head_reapproval: false,
                    });
                  }}
                  onDismiss={() => setShowReapprovalConfirm(false)}
                />
              )}

              {canBeginPlanning && (
                <button
                  className="btn btn-primary btn-sm"
                  disabled={!!busyAction}
                  onClick={() => act("begin-planning")}
                >
                  Begin Planning
                </button>
              )}
              {canAssignTester && (
                <>
                  <MultiUserAssignSelect
                    value={selectedTesters}
                    onChange={setSelectedTesters}
                    users={testers}
                    placeholder={
                      isInitialTesterAssignment
                        ? "Assign Tester(s)..."
                        : "Reassign Tester(s)..."
                    }
                    disabled={!!busyAction}
                    style={{ minWidth: 260 }}
                  />
                  {!isInitialTesterAssignment && (
                    <input
                      className="reassign-reason-input"
                      style={{ minWidth: 220 }}
                      placeholder="Reason for reassignment *"
                      value={reassignReason}
                      onChange={(e) => setReassignReason(e.target.value)}
                      disabled={!!busyAction}
                    />
                  )}
                  <button
                    className="btn btn-primary btn-sm"
                    disabled={
                      selectedTesters.length === 0 ||
                      !!busyAction ||
                      (!isInitialTesterAssignment && (!testerAssignmentChanged || !reassignReason.trim()))
                    }
                    onClick={() =>
                      act("assign-tester", {
                        tester_ids: selectedTesters.map(Number),
                        ...(isInitialTesterAssignment ? {} : { reason: reassignReason.trim() }),
                      })
                    }
                  >
                    {isInitialTesterAssignment
                      ? "Assign Tester(s)"
                      : "Reassign Tester(s)"}
                  </button>
                </>
              )}
              {canStartTestDesign && (
                <button
                  className="btn btn-primary btn-sm"
                  disabled={!!busyAction}
                  onClick={() => act("start-test-design")}
                >
                  Start Test Design
                </button>
              )}
              {canStartExecution && (
                <button
                  className="btn btn-primary btn-sm"
                  disabled={!!busyAction}
                  onClick={() => { setExecutionNotice(""); setShowStartExecution(true); }}
                >
                  Start Execution
                </button>
              )}

              {canRaiseDefect && (
                <button
                  className="btn btn-danger btn-sm"
                  disabled={!!busyAction}
                  onClick={() => act("raise-defect", { comments })}
                >
                  Raise Defect
                </button>
              )}
              {canMarkWaitingForFix && (
                <button
                  className="btn btn-sm"
                  disabled={!!busyAction}
                  onClick={() => act("mark-waiting-for-fix", { comments })}
                >
                  Mark Waiting For Fix
                </button>
              )}
              {canStartRetest && (
                <button
                  className="btn btn-primary btn-sm"
                  disabled={!!busyAction}
                  onClick={() => act("start-retesting", { comments })}
                >
                  Start Retesting
                </button>
              )}
              {canCompleteQA && (
                <button
                  className="btn btn-success btn-sm"
                  disabled={!!busyAction}
                  onClick={() => act("complete-qa", { comments })}
                >
                  Mark QA Completed
                </button>
              )}

              {canRequestSignoff && (
                <button
                  className="btn btn-primary btn-sm"
                  disabled={!!busyAction}
                  onClick={() => setShowSignoffModal(true)}
                >
                  Request Clearance
                </button>
              )}

              {canCreatePostRetestRevision && (
                <div style={{ width: "100%" }}>
                  <div className="info-banner">
                    <strong>Revised clearance required.</strong>{" "}
                    {revisionPrompt}
                  </div>
                  <div className="form-field">
                    <label htmlFor="post-retest-revision-reason">Revision reason *</label>
                    <textarea
                      id="post-retest-revision-reason"
                      rows={3}
                      maxLength={2000}
                      value={clearanceChangeComments}
                      onChange={(event) => setClearanceChangeComments(event.target.value)}
                      placeholder="Summarize the re-test outcome and why the clearance must be revised…"
                      disabled={!!busyAction}
                    />
                  </div>
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    disabled={!!busyAction || clearanceChangeComments.trim().length < 3}
                    onClick={() => void decideClearanceChange("ReviseCertificate")}
                  >
                    {busyAction === "clearance-change-decision" ? "Creating…" : "Create Revised Clearance"}
                  </button>
                </div>
              )}

              {canContinueDraftClearance && req.signoff_certificate_id && (
                <div className="info-banner" style={{ width: "100%" }}>
                  <strong>A linked clearance already needs QA action.</strong>{" "}
                  Continue that Draft or returned certificate instead of creating another one.{" "}
                  <Link className="btn btn-primary btn-sm" to={`/signoff?open=${req.signoff_certificate_id}`}>
                    Continue Clearance
                  </Link>
                </div>
              )}

              {canReviewClearanceChanges && (
                <div style={{ width: "100%" }}>
                  <div className="info-banner">
                    <strong>Requester changes need QA review.</strong>{" "}
                    The signed certificate is preserved as immutable evidence and no Draft replacement has been created automatically.
                    <span style={{ display: "block", marginTop: 6 }}>
                      <b>Held certificate environment:</b> {req.signoff_certificate_environment || "Not recorded"}
                    </span>
                    {isCertificateRequesterFallback && (
                      <span style={{ display: "block", marginTop: 6 }}>
                        <b>Recovery access:</b> No tester remains assigned, so the original QA certificate requester may resolve this legacy review.
                      </span>
                    )}
                    {latestRequesterChange?.comments && (
                      <span style={{ display: "block", marginTop: 6 }}>
                        <b>Requester comment:</b> {latestRequesterChange.comments}
                      </span>
                    )}
                  </div>
                  <div className="form-field">
                    <label htmlFor="clearance-change-review-comments">QA review comments *</label>
                    <textarea
                      id="clearance-change-review-comments"
                      rows={3}
                      maxLength={2000}
                      value={clearanceChangeComments}
                      onChange={(event) => setClearanceChangeComments(event.target.value)}
                      placeholder="Record why QA is resending, revising, or requiring re-testing…"
                      disabled={!!busyAction}
                    />
                  </div>
                  {eligibleRetestSourceCycles.length > 1 && (
                    <div className="form-field">
                      <label htmlFor="retest-source-cycle">Re-execution baseline *</label>
                      <select
                        id="retest-source-cycle"
                        value={effectiveRetestSourceCycleId || ""}
                        onChange={(event) => setRetestSourceCycleId(event.target.value ? Number(event.target.value) : null)}
                        disabled={!!busyAction}
                      >
                        <option value="">Select the latest completed cycle…</option>
                        {eligibleRetestSourceCycles.map((cycle) => (
                          <option key={cycle.id} value={cycle.id}>{cycle.cycle_key} — {cycle.name} · {cycle.environment}</option>
                        ))}
                      </select>
                      <small className="muted">Only completed lineage heads matching the held certificate environment are eligible; an older round that already has a successor cannot be cloned again.</small>
                    </div>
                  )}
                  {eligibleRetestSourceCycles.length === 1 && (
                    <p className="muted small">
                      Re-test baseline: <strong>{eligibleRetestSourceCycles[0].cycle_key} — {eligibleRetestSourceCycles[0].name} · {eligibleRetestSourceCycles[0].environment}</strong>. Testcase membership will be cloned into a new Draft cycle; results and defects will not be copied.
                    </p>
                  )}
                  {eligibleRetestSourceCycles.length === 0 && (
                    <WarningNotice className="execution-cycle-required-warning" role="alert">
                      <strong>Re-test is unavailable</strong>
                      <span>{!req.signoff_certificate_environment
                        ? "The held certificate does not have a tested environment, so a safe re-execution baseline cannot be selected."
                        : completedCycleLineageLeaves.length
                          ? `No latest completed linked Test Cycle matches the held certificate environment ${req.signoff_certificate_environment}. Latest cycle environment(s): ${completedCycleLineageLeaves.map((cycle) => `${cycle.cycle_key} (${cycle.environment || "not recorded"})`).join(", ")}.`
                          : "No eligible completed linked Test Cycle exists to use as the re-execution baseline."}</span>
                    </WarningNotice>
                  )}
                  <WorkflowDecisionPanel
                    busy={!!busyAction}
                    title="QA clearance change decision"
                    description="Choose one governed outcome. Every action records your mandatory QA comment."
                    options={[
                      {
                        key: "resend-issued",
                        label: isClearanceDeniedOutcome ? "Resend Denial Decision" : "Resend Issued Certificate",
                        description: isClearanceDeniedOutcome
                          ? "Return the same unchanged issued denial decision to requester verification."
                          : "Return the same unchanged issued certificate to requester verification.",
                        tone: "approve",
                        disabled: clearanceChangeComments.trim().length < 3,
                        onClick: () => void decideClearanceChange("ResendIssued"),
                      },
                      {
                        key: "revise-certificate",
                        label: isClearanceDeniedOutcome ? "Create Revised Denial Certificate" : "Create Revised Clearance",
                        description: isClearanceDeniedOutcome
                          ? "Supersede the issued denial and create one governed Draft successor for a fresh decision and approval."
                          : "Supersede the issued certificate and create one governed Draft successor for fresh approval.",
                        tone: "return",
                        disabled: clearanceChangeComments.trim().length < 3,
                        onClick: () => void decideClearanceChange("ReviseCertificate"),
                      },
                      {
                        key: "retest",
                        label: "Re-testing Required",
                        description: "Preserve completed evidence and create a linked Draft re-execution cycle from the selected baseline.",
                        tone: "reject",
                        disabled: clearanceChangeComments.trim().length < 3 || !effectiveRetestSourceCycleId,
                        onClick: () => void decideClearanceChange("Retest", effectiveRetestSourceCycleId),
                      },
                    ]}
                  />
                  <p className="muted small">
                    Re-testing never unlocks or rewrites a Completed cycle. QA works in the new linked cycle in Test Lifecycle, where testcases may be added and new results, evidence, and defects recorded.
                  </p>
                </div>
              )}

              {canRequesterDecide && (
                <>
                  <div className="form-field" style={{ width: "100%" }}>
                    <label htmlFor="requester-decision-comments">
                      Comments{" "}
                      <small className="muted">
                        (required for Changes Required)
                      </small>
                    </label>
                    <textarea
                      id="requester-decision-comments"
                      rows={3}
                      value={requesterComments}
                      onChange={(e) => setRequesterComments(e.target.value)}
                      placeholder={isClearanceDeniedOutcome
                        ? "Optional for acknowledgement; required when requesting changes to the denial…"
                        : "If requesting changes, describe what still needs to be fixed…"}
                      disabled={!!busyAction}
                    />
                  </div>
                  {isClearanceDeniedOutcome ? (
                    <div className="info-banner" style={{ width: "100%" }}>
                      <strong>QA issued a Clearance Denied decision.</strong>{" "}
                      Acknowledge the decision to close this request, or return it to QA Change Review with a required reason. The issued denial and its approval history remain immutable; returning it does not create a Draft or turn it into a positive clearance automatically.
                    </div>
                  ) : (
                    <div className="info-banner" style={{ width: "100%" }}>
                      <strong>Changes Required sends this request to QA Change Review.</strong>{" "}
                      It places the issued certificate under review but does not create or supersede a certificate automatically. QA will decide whether to resend it unchanged, create a revision, or perform re-testing.
                    </div>
                  )}
                  <button
                    className="btn btn-success btn-sm"
                    disabled={!!busyAction}
                    onClick={() =>
                      act("requester-decision", {
                        decision: "Accepted",
                        comments: requesterComments,
                      })
                    }
                  >
                    {isClearanceDeniedOutcome ? "Acknowledge Denial & Close" : "Accept & Close"}
                  </button>
                  <button
                    className="btn btn-danger btn-sm"
                    disabled={!!busyAction || !requesterComments.trim()}
                    title={
                      !requesterComments.trim()
                        ? "Describe what needs to change before submitting"
                        : undefined
                    }
                    onClick={() =>
                      act("requester-decision", {
                        decision: "ChangesRequired",
                        comments: requesterComments,
                      })
                    }
                  >
                    {isClearanceDeniedOutcome ? "Request Changes to Denial" : "Changes Required"}
                  </button>
                </>
              )}

              {!canEditDetails &&
                !canSubmit &&
                !canResubmit &&
                !canSMDecide &&
                !canDepartmentHeadDecide &&
                !canStartReadiness &&
                !canReadinessDecide &&
                !canBeginPlanning &&
                !canAssignTester &&
                !canStartTestDesign &&
                !canStartExecution &&
                !canRaiseDefect &&
                !canMarkWaitingForFix &&
                !canStartRetest &&
                !canCompleteQA &&
                !canRequestSignoff &&
                !canCreatePostRetestRevision &&
                !canContinueDraftClearance &&
                !canReviewClearanceChanges &&
                !canRequesterDecide && (
                  <span className="muted small">
                    No actions available for your role at this stage.
                  </span>
                )}
            </div>
          </div>

          {editingDetails && (
            <FunctionalFormModal
              editing={req}
              documentsByItem={documentsByItem}
              reloadEvidence={reloadEvidence}
              onClose={() => setEditingDetails(false)}
              onSaved={(saved) => {
                setEditingDetails(false);
                onChanged(saved);
                // Keep the Checklist tab's own state in sync immediately --
                // it's otherwise only fetched once, in `load()` above.
                setChecklist(saved.checklist_items || []);
              }}
            />
          )}

          {showSignoffModal && (
            <NewSignOffModal
              presetRequest={req}
              onClose={() => setShowSignoffModal(false)}
              onCreated={requestSignoffWithCertificate}
            />
          )}
          </>}
        </div>
      )}

      {tab === "checklist" && (
        <div>
          <p className="muted small">
            "Ready for Testing" gate — all mandatory items must be complete
            before Testing Initiation.
          </p>
          <p className="muted small">
            <strong>Requester declared</strong> is the requester's own
            self-declaration at raise-time (reference only).{" "}
            <strong>QA Lead verified</strong> is the binding, independent
            verification — ticking a requester-declared item does NOT
            auto-approve it here.
          </p>
          {status !== "READINESS_VERIFICATION" && (
            <p className="muted small">
              QA Lead verification is locked outside the Readiness Verification
              stage (current status: {QA_STATUS_LABELS[status] || status}).
            </p>
          )}
          <div
            style={{
              display: "flex",
              gap: 8,
              alignItems: "center",
              padding: "6px 0",
              fontWeight: 600,
              fontSize: 12,
              color: "var(--muted)",
            }}
          >
            <span style={{ flex: 1 }}>Item</span>
            <span style={{ width: 130, textAlign: "center" }}>
              Requester declared
            </span>
            <span style={{ width: 130, textAlign: "center" }}>
              QA Lead verified
            </span>
            <span style={{ width: 230, textAlign: "center" }}>Evidence</span>
          </div>
          {checklist.length === 0 && (
            <EmptyState compact title="No checklist items available" description="Checklist items will appear here when they are configured for Functional testing." />
          )}
          {checklist.map((c) => (
            <div
              key={c.id}
              style={{
                display: "flex",
                gap: 8,
                alignItems: "center",
                padding: "6px 0",
                borderBottom: "1px solid var(--border)",
              }}
            >
              <span style={{ flex: 1 }}>
                {c.item} <span className="muted small">({c.owner})</span>{" "}
                {c.is_mandatory && (
                  <span className="badge badge-gray">Mandatory</span>
                )}
              </span>
              <span style={{ width: 130, textAlign: "center" }}>
                {c.requester_checked ? (
                  <span className="badge badge-blue">Declared</span>
                ) : (
                  <span className="muted small">Not ticked</span>
                )}
              </span>
              <span style={{ width: 130, textAlign: "center" }}>
                <input
                  type="checkbox"
                  checked={c.is_complete}
                  disabled={
                    !canVerifyChecklist ||
                    (!c.requester_checked && !c.is_complete)
                  }
                  title={
                    !canVerifyChecklist
                      ? "Only verifiable by QA Lead / QA Engineer / Business Analyst during Readiness Verification"
                      : !c.requester_checked && !c.is_complete
                      ? "The requester has not self-declared this item ready yet -- cannot verify it until they tick it"
                      : ""
                  }
                  onChange={() => toggleChecklistItem(c)}
                />
              </span>
              <ChecklistEvidence apiBase="/api/functional-requests" reqId={req.id} itemId={c.id}
                canManage={!preview && canManageReadinessEvidence(req.status, evidenceOwner)}
                required={c.is_mandatory || c.requester_checked}
                documents={documentsByItem[c.id] || []}
                onReload={reloadEvidence}
                checked={c.requester_checked} />
            </div>
          ))}
        </div>
      )}

      {tab === "history" && (
        <JiraActivity readOnly={!!preview} ownerWorkspaceId={req.qa_workspace_id} entityType="FUNCTIONAL_REQUEST" entityId={req.id} items={history} onPosted={(item) => setHistory((prev) => [...prev, item])} />
      )}

      {tab === "documents" && (
        <RequestDocuments apiBase="/api/functional-requests" reqId={req.id} canManage={!preview && canManageDocuments} />
      )}

      <ReadinessPassError error={readinessPassError} />
      {preview && <div className="cycle-request-preview-confirm">
        <p>Review the application, CR / EPIC, business defect reference and requested change before linking this request.</p>
        <button type="button" className="btn btn-primary" disabled={preview.busy || !!error} onClick={preview.onConfirm}>
          {preview.busy ? 'Confirming…' : 'Use this request'}
        </button>
      </div>}
      {showStartExecution && <StartExecutionModal req={req} busy={busyAction === "start-execution"} onCancel={() => setShowStartExecution(false)} onStart={startExecution} />}
    </Modal>
  );
}

export default function Functional() {
  const viewerManagedDeepLinks = useViewerManagedDeepLinks();
  const [users, setUsers] = useState<UserOption[]>([]);
  const [statusFilter, setStatusFilter] = useRetainedState('functional.list.statusFilter', "");
  const [assignedOnly, setAssignedOnly] = useRetainedState('functional.list.assignedOnly', false);
  const [raisedHistory, setRaisedHistory] = useRetainedState('functional.list.raisedHistory', { from: "", to: "" });
  // SRS 7.2 PAG-006 -- the list only ever holds the lightweight
  // FunctionalListOut shape; opening a request fetches the full
  // FunctionalOut record fresh via GET /api/functional-requests/{id} before
  // FunctionalDetail (which needs every field) is shown.
  const [selected, setSelected] = useState<FunctionalOut | null>(null);
  const [openingId, setOpeningId] = useState<number | null>(null);
  const detailRequests = useRef(createLatestRequestGate()).current;
  const [error, setError] = useState<unknown>(null);
  const [searchParams, setSearchParams] = useSearchParams();

  const {
    items: requests, page, pageSize, total, totalPages, hasNext, hasPrevious,
    loading, setPage, setPageSize, reload,
  } = usePaginatedList<FunctionalListOut>("/api/functional-requests", {
    status: statusFilter ? [statusFilter] : undefined,
    extra: { assigned_to_me: assignedOnly ? "true" : undefined, raised_from: raisedHistory.from || undefined, raised_to: raisedHistory.to || undefined },
  }, { retainKey: "functional.list" });
  useListScrollRestoration(loading);

  useEffect(() => {
    api.get<UserOption[]>("/api/auth/user-options").then(setUsers).catch(setError);
  }, []);

  const openRequest = useCallback(async (idOrRow: number | FunctionalListOut) => {
    const id = typeof idOrRow === "number" ? idOrRow : idOrRow.id;
    const generation = detailRequests.begin();
    setOpeningId(id);
    try {
      const full = await api.get<FunctionalOut>(`/api/functional-requests/${id}`);
      if (detailRequests.isCurrent(generation)) setSelected(full);
    } catch (err) {
      if (detailRequests.isCurrent(generation)) setError(err);
    } finally {
      if (detailRequests.isCurrent(generation)) setOpeningId(null);
    }
  }, [detailRequests]);

  // Pending Approvals includes openId so this fetches the exact record even
  // when it is not on the module list's currently loaded page.  `open` is
  // retained as a backward-compatible fallback for older deep links.
  useEffect(() => {
    if (viewerManagedDeepLinks) return;
    const recordId = Number(searchParams.get("openId"));
    const openId = searchParams.get("open");
    if (Number.isInteger(recordId) && recordId > 0) {
      openRequest(recordId);
    } else if (openId) {
      const match = requests.find((r) => r.request_id === openId);
      if (!match) return;
      openRequest(match.id);
    } else {
      return;
    }
    setSearchParams(
      (p) => {
        p.delete("open");
        p.delete("openId");
        return p;
      },
      { replace: true }
    );
  }, [requests, searchParams, setSearchParams, openRequest, viewerManagedDeepLinks]);

  return (
    <div>
      <ErrorText error={error} />
      <PageHeader
        title="Functional QA Requests"
        count={total}
        subtitle="Functional, Regression, Sanity Testing and UAT Support are raised through a QA Request and tracked here from approval to clearance."
      />
      <div className="toolbar module-assignment-toolbar">
        <div className="tabs" style={{ margin: 0 }}>
          <button type="button" className={!assignedOnly ? "active" : ""} onClick={() => setAssignedOnly(false)}>All Requests</button>
          <button type="button" className={assignedOnly ? "active" : ""} onClick={() => setAssignedOnly(true)}>My Assigned Work</button>
        </div>
        <RaisedHistoryFilter value={raisedHistory} onChange={setRaisedHistory} />
      </div>
      {/* <div className="toolbar">
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="">All statuses</option>
          {QA_STATUSES.map((s) => (
            <option key={s} value={s}>
              {QA_STATUS_LABELS[s] || s}
            </option>
          ))}
        </select>
      </div> */}

      <Card>
        <Table
          rowKey="id"
          onRowClick={(r) => openRequest(r)}
          server={{
            page, pageSize, total, totalPages, hasNext, hasPrevious,
            onPageChange: setPage, onPageSizeChange: setPageSize, loading,
          }}
          columns={[
            {
              key: "request_id",
              header: "Request ID",
              render: (r) => <RecordNumberLink kind="functional" id={r.id} recordKey={r.request_id} loading={openingId === r.id} onOpen={() => openRequest(r)} />,
            },
            {
              key: "application_name",
              header: "Application",
              render: (r) => r.application_name || "—",
            },
            { key: "module_name", header: "Module", render: (r) => r.module_name || "—" },
            {
              key: "department",
              header: "Department Scope",
              render: (r) => r.department || "—",
              filterValue: (r) => r.department || "",
            },
            {
              key: "cr_number",
              header: "CR Number/EPIC Number",
              render: (r) => r.cr_number || r.epic_number || "—",
            },
            {
              key: "change_type",
              header: "Change Type",
              render: (r) => r.change_type || "—",
              filterValue: (r) => r.change_type || "",
            },
            {
              key: "change_description",
              header: "Change Description",
              render: (r) => (
                <span className="truncate-cell" title={r.change_description || ""}>
                  {r.change_description || "—"}
                </span>
              ),
              filterValue: (r) => r.change_description || "",
            },
            {
              key: "requester_id",
              header: "Requester",
              render: (r) => userName(users, r.requester_id) || "—",
              filterValue: (r) => userName(users, r.requester_id) || "",
            },
            {
              key: "qa_lead_id",
              header: "Assigned Group",
              render: (r) => assignedGroupFor(r.status, r.application_master_status)?.label || "—",
              filterValue: (r) => assignedGroupFor(r.status, r.application_master_status)?.label || "",
            },
            {
              key: "priority",
              header: "Priority",
              render: (r) => r.priority || "—",
            },
            {
              key: "status",
              header: "Status",
              render: (r) => <WorkflowStatusBadge record={r} status={r.status} label={applicationNameAwareStatusLabel(r.status, r.application_master_status) || QA_STATUS_LABELS[r.status] || r.status} />,
            },
            {
              key: "pending_with",
              header: "Pending With",
              render: (r) => functionalPendingWithLabel(
                r,
                applicationNameAwareStatusLabel(r.status, r.application_master_status)
                  ? "Application Owner"
                  : QA_PENDING_WITH[r.status],
                users,
              ),
              filterValue: (r) => functionalPendingWithLabel(
                r,
                applicationNameAwareStatusLabel(r.status, r.application_master_status)
                  ? "Application Owner"
                  : QA_PENDING_WITH[r.status],
                users,
              ),
            },
            {
              key: "qa_request",
              header: "QA Request",
              render: (r) => (r.qa_request ? r.qa_request.request_id : "—"),
              filterValue: (r) => (r.qa_request ? r.qa_request.request_id : ""),
            },
            {
              key: "created_at",
              header: "Created",
              render: (r) => formatDateTimeIST(r.created_at),
            },
            {
              key: "updated_at",
              header: "Updated",
              render: (r) => formatDateTimeIST(r.updated_at),
            },
          ]}
          retainStateKey="functional.list.table" rows={requests}
        />
      </Card>

      {selected && (
        <FunctionalDetail
          req={selected}
          users={users}
          onClose={() => setSelected(null)}
          onChanged={(updated) => {
            setSelected(updated);
            reload();
          }}
        />
      )}
    </div>
  );
}
