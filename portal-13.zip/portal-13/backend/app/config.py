"""Spring-style environment profiles for the QualityOps backend.

Configuration precedence, from highest to lowest, is:

1. Variables already present in the process environment.
2. The file named by ``APP_ENV_FILE``, when explicitly selected. Compose both
   injects its values and mounts it read-only at a stable container path.
3. Legacy implicit profile discovery (only when ``APP_ENV_FILE`` is unset):
   ``backend/.env.<APP_ENV>`` / repository-root ``.env.<APP_ENV>``, then
   ``backend/.env``.
4. Typed defaults declared by :class:`Settings`.

Docker Compose supplies the selected environment as real process variables,
so the same settings object works for containers and direct Uvicorn/Alembic
runs without environment-specific application code.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Literal, MutableMapping
from urllib.parse import urlsplit

from dotenv import dotenv_values
from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


BACKEND_DIR = Path(__file__).resolve().parents[1]
DEFAULT_PROFILE = "dev"
_PROFILE_PATTERN = re.compile(r"^[A-Za-z0-9_-]+$")


def _validated_profile(value: str | None) -> str:
    profile = (value or DEFAULT_PROFILE).strip().lower()
    if not _PROFILE_PATTERN.fullmatch(profile):
        raise RuntimeError(
            "APP_ENV may contain only letters, numbers, underscores, and hyphens."
        )
    return profile


def load_environment(
    *,
    backend_dir: Path = BACKEND_DIR,
    environ: MutableMapping[str, str] = os.environ,
) -> tuple[str, tuple[Path, ...]]:
    """Load the selected dotenv file without overriding process variables.

    The optional parameters keep the loader straightforward to test. Returned
    paths are the files that actually existed and were considered.
    """
    process_keys = set(environ)
    explicit_file = (environ.get("APP_ENV_FILE") or "").strip()
    if explicit_file:
        if "\x00" in explicit_file:
            raise RuntimeError("APP_ENV_FILE contains an invalid null byte.")
        selected_path = Path(explicit_file).expanduser()
        if not selected_path.is_absolute():
            # Repository-root relative paths match Compose's `.env.uat` style.
            # Tests or standalone layouts that pass a directory other than a
            # conventional `backend/` resolve relative to that directory.
            project_dir = backend_dir.parent if backend_dir.name == "backend" else backend_dir
            selected_path = project_dir / selected_path
        if not selected_path.is_file():
            raise RuntimeError("APP_ENV_FILE must identify a readable regular file.")
        try:
            selected_values = dotenv_values(selected_path)
        except (OSError, UnicodeError) as exc:
            raise RuntimeError("APP_ENV_FILE could not be read as a UTF-8 environment file.") from exc
        profile = _validated_profile(
            environ.get("APP_ENV") or selected_values.get("APP_ENV")
        )
        merged = {**selected_values, "APP_ENV": profile, "APP_ENV_FILE": explicit_file}
        for key, value in merged.items():
            if key not in process_keys and value is not None:
                environ[key] = value
        return profile, (selected_path,)

    base_file = backend_dir / ".env"
    base_values = dotenv_values(base_file) if base_file.is_file() else {}
    # Compose reads the repository-root .env itself and exports every value to
    # its containers. A direct host process must not inherit container paths
    # such as LOG_DIR=/app/logs from that same file. It may, however, use the
    # root APP_ENV value to select the complete host-compatible profile file.
    root_selector_file = backend_dir.parent / ".env"
    root_selector_values = (
        dotenv_values(root_selector_file)
        if not base_file.is_file() and root_selector_file.is_file()
        else {}
    )
    profile = _validated_profile(
        environ.get("APP_ENV")
        or base_values.get("APP_ENV")
        or root_selector_values.get("APP_ENV")
    )
    backend_profile_file = backend_dir / f".env.{profile}"
    root_profile_file = backend_dir.parent / f".env.{profile}"
    profile_file = (
        backend_profile_file
        if backend_profile_file.is_file() or not root_profile_file.is_file()
        else root_profile_file
    )
    profile_values = dotenv_values(profile_file) if profile_file.is_file() else {}

    # Capture genuine process variables before loading either file. This lets
    # profile values override the base file while preserving deployment-level
    # environment overrides.
    merged = {**base_values, **profile_values, "APP_ENV": profile}
    for key, value in merged.items():
        if key not in process_keys and value is not None:
            environ[key] = value

    loaded = tuple(path for path in (base_file, profile_file) if path.is_file())
    return profile, loaded


ACTIVE_PROFILE, LOADED_ENV_FILES = load_environment()


class Settings(BaseSettings):
    """Typed settings shared by the main API and Document Portal service."""

    model_config = SettingsConfigDict(case_sensitive=False, extra="ignore")

    app_env: str = DEFAULT_PROFILE
    app_env_file: str = ""
    database_url: str | None = None
    secret_key: str = ""
    signature_integrity_key: str = ""
    login_encryption_private_key_file: str | None = None
    access_token_expire_minutes: int = 30
    session_max_minutes: int = 480
    session_idle_minutes: int = 30
    session_cookie_secure: bool | None = None
    jwt_issuer: str = "qualityops-api"
    jwt_audience: str = "qualityops-web"
    upload_storage_root: str | None = None
    document_portal_storage_host_path: str | None = None
    document_portal_embedded: bool = True
    document_portal_minimum_free_bytes: int = 100 * 1024 * 1024
    document_portal_upload_chunk_size: int = 1024 * 1024
    document_portal_allowed_extensions: str = ""
    document_portal_blocked_extensions: str = ".exe,.bat,.cmd,.sh,.ps1,.dll,.com,.msi,.scr"
    redis_url: str | None = None
    cache_enabled: bool = True
    cache_socket_connect_timeout_seconds: float = Field(default=0.25, gt=0)
    cache_socket_timeout_seconds: float = Field(default=0.25, gt=0)
    cache_max_connections: int = Field(default=32, ge=1)
    cache_fill_lock_ttl_seconds: int = Field(default=15, ge=1)
    cache_fill_wait_seconds: float = Field(default=0.15, ge=0)
    cache_init_retry_seconds: float = Field(default=15, gt=0)
    dashboard_cache_ttl_seconds: int = Field(default=30, ge=1, le=300)
    redis_coordination_url: str | None = None
    redis_coordination_max_connections: int = Field(default=24, ge=1)
    redis_coordination_connect_timeout_seconds: float = Field(default=0.5, gt=0)
    redis_coordination_socket_timeout_seconds: float = Field(default=1, gt=0)
    job_queue_backend: Literal["local", "redis"] = "local"
    background_job_workers: int = Field(default=2, ge=1, le=16)
    background_job_global_concurrency: int = Field(default=2, ge=1, le=64)
    background_job_lease_seconds: int = Field(default=120, ge=15)
    background_job_poll_seconds: float = Field(default=2, gt=0, le=30)
    background_job_max_attempts: int = Field(default=3, ge=1, le=20)
    background_job_retention_seconds: int = Field(default=7 * 86400, ge=60)
    notification_worker_mode: Literal["embedded", "dedicated"] = "embedded"
    approval_reminders_enabled: bool = True
    approval_reminder_time: str = Field(default="09:00", pattern=r"^(?:[01]\d|2[0-3]):[0-5]\d$")
    login_rate_limit_backend: Literal["database", "redis"] = "database"
    cors_allowed_origins: str = ""
    trusted_hosts: str = "localhost,127.0.0.1,backend,document_portal"
    domain_name: str = ""
    ldap_mock_enabled: bool = False
    ldap_mock_password: str = ""
    ldap_mock_username_prefix: str = "bmock"

    @field_validator("app_env")
    @classmethod
    def validate_app_env(cls, value: str) -> str:
        return _validated_profile(value)

    @model_validator(mode="after")
    def validate_security_configuration(self):
        if self.access_token_expire_minutes <= 0 or self.session_max_minutes <= 0 or self.session_idle_minutes <= 0:
            raise ValueError("Token and session durations must be positive")
        if self.session_idle_minutes > self.session_max_minutes:
            raise ValueError("SESSION_IDLE_MINUTES cannot exceed SESSION_MAX_MINUTES")
        if len(self.secret_key) < 32:
            raise ValueError("SECRET_KEY must be a deployment secret of at least 32 characters")
        if self.signature_integrity_key and len(self.signature_integrity_key) < 32:
            raise ValueError("SIGNATURE_INTEGRITY_KEY must contain at least 32 characters")
        if self.app_env in {"uat", "prod", "production"}:
            if not self.database_url:
                raise ValueError("DATABASE_URL is required outside development")
            if self.session_cookie_secure is False:
                raise ValueError("SESSION_COOKIE_SECURE cannot be disabled in UAT or production")
            if "*" in self.cors_origins:
                raise ValueError("Credentialed CORS must use explicit origins in UAT or production")
            if "*" in self.allowed_hosts:
                raise ValueError("TRUSTED_HOSTS cannot allow every host in UAT or production")
            for origin in self.cors_origins:
                parsed = urlsplit(origin)
                if (
                    parsed.scheme != "https"
                    or not parsed.netloc
                    or parsed.username is not None
                    or parsed.password is not None
                    or parsed.path not in {"", "/"}
                    or parsed.query
                    or parsed.fragment
                ):
                    raise ValueError(
                        "CORS_ALLOWED_ORIGINS must contain only explicit HTTPS origins "
                        "without credentials, paths, queries, or fragments in UAT or production"
                    )
        for name, value in (("REDIS_URL", self.redis_url), ("REDIS_COORDINATION_URL", self.redis_coordination_url)):
            if value:
                parsed_redis_url = urlsplit(value)
                if parsed_redis_url.scheme.lower() not in {"redis", "rediss"} or not parsed_redis_url.hostname:
                    raise ValueError(f"{name} must be a valid redis:// or rediss:// URL")
        if self.job_queue_backend == "redis" or self.login_rate_limit_backend == "redis" or self.notification_worker_mode == "dedicated":
            if not self.redis_coordination_url:
                raise ValueError("REDIS_COORDINATION_URL is required for Redis jobs, login throttling or dedicated notifications")
            if self.cache_enabled and self.redis_url:
                cache_endpoint = urlsplit(self.redis_url)
                control_endpoint = urlsplit(self.redis_coordination_url)
                if (cache_endpoint.hostname, cache_endpoint.port or 6379) == (control_endpoint.hostname, control_endpoint.port or 6379):
                    raise ValueError("Cache and durable coordination must use separate Redis instances, not different database numbers")
        if self.app_env in {"prod", "production"} and self.ldap_mock_enabled:
            raise ValueError("LDAP mock authentication cannot be enabled in production")
        if self.ldap_mock_enabled:
            if len(self.ldap_mock_password) < 12:
                raise ValueError("LDAP_MOCK_PASSWORD must contain at least 12 characters")
            if not self.ldap_mock_username_prefix.strip():
                raise ValueError("LDAP_MOCK_USERNAME_PREFIX is required when LDAP mock authentication is enabled")
        return self

    @property
    def cors_origins(self) -> list[str]:
        return [item.strip().rstrip("/") for item in self.cors_allowed_origins.split(",") if item.strip()]

    @property
    def allowed_hosts(self) -> list[str]:
        hosts = [item.strip() for item in self.trusted_hosts.split(",") if item.strip()]
        if self.domain_name.strip():
            hosts.append(self.domain_name.strip())
        return list(dict.fromkeys(hosts))

    @property
    def secure_session_cookie(self) -> bool:
        if self.session_cookie_secure is not None:
            return self.session_cookie_secure
        return self.app_env in {"uat", "prod", "production"}


settings = Settings()
