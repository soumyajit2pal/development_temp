"""Shared helpers for the app-wide "Reassignment" requirement (2026-08 CR),
reported directly:

    Everywhere the system provides an Assign option -- Assign Tester, Assign
    Defect, Assign QA Lead, Assign Analyst -- it must also provide a
    Reassign option. Reassignment shall be permitted to: the current
    assignee, the Department Head of the department the current assignee
    belongs to, or an Administrator. During reassignment: only eligible
    users for that activity shall be displayed; a reassignment reason shall
    be mandatory; the
    previous assignee shall lose action permission after reassignment; the
    record's status/history shall remain unchanged; previous assignee, new
    assignee, reassigned by, date/time, and reason shall be captured in the
    audit history.

Scope note (confirmed directly before implementing): this covers the real,
already-populated assignee fields -- Functional/Performance tester(s), SAST/
DAST Security Analyst, Test Execution runner, Test Cycle owner, and Defect
assignee. FunctionalRequest.qa_lead_id / SAST&DASTRequest.security_lead_id /
PerformanceRequest.engineer_id are vestigial (never actually set to a real
person anywhere in this codebase). Test-case Reviewer and QA Lead routing is
managed by its dedicated project/test-case workflow endpoints.

Business assignees are governed by the Department Heads of their own
organisational department. QA assignees are governed by the QA Executive
roles inside the record's workspace. No department name implies QA access.

"The previous assignee shall lose action permission after reassignment" is
satisfied structurally, not by a separate flag: every eligibility check in
this app re-reads the assignee column fresh on each request (no caching),
so overwriting it to the new assignee is sufficient -- there is nothing
further for this module to enforce.
"""
import datetime
from typing import Iterable, List, Optional

from fastapi import HTTPException
from sqlalchemy.orm import Session

from . import models
from .constants import Role


def department_head_roles(department: Optional[str]) -> tuple:
    """Organisational Department Head roles for a business department."""
    return (Role.DEPARTMENT_HEAD_CM, Role.DEPARTMENT_HEAD_AGM)


def department_head_user_ids(db: Session, department: Optional[str]) -> List[int]:
    """Every active user who is a Department Head of `department` -- role
    AND department both matching (see module docstring).

    2026-08 "one user can be on multiple departments" CR -- a Department
    Head who now belongs to several departments still qualifies here as long
    as `department` is ONE of theirs, not necessarily their primary one --
    uses the department_assignments join table via has_department(), same as
    every other membership check in this module."""
    if not department:
        return []
    roles = set(department_head_roles(department))
    candidates = db.query(models.User).filter(
        models.User.department_assignments.any(models.UserDepartment.department == department),
        models.User.is_active == True,  # noqa: E712
    ).all()
    return [u.id for u in candidates if set(u.roles) & roles]


def require_can_reassign(current_user: models.User, current_assignee_id: Optional[int],
                          department, qa_workspace_id: Optional[int] = None) -> None:
    """403s unless `current_user` is the current assignee, a Department Head
    of `department`, or an Administrator (has_role's own Admin bypass covers
    the last one). `department` is the CURRENT ASSIGNEE's department -- the
    person being reassigned FROM, not the department the record itself
    lives in, per "the Department Head of the department to which the
    current assignee belongs."

    2026-08 "one user can be on multiple departments" CR -- `department` may
    now be a single string (legacy callers) OR a list (a previous
    assignee's full `.departments`, the normal case now). `current_user`
    qualifies as Department Head if they belong to (has_department) AND
    hold the Department Head role for ANY ONE of the given departments --
    not necessarily the previous assignee's primary one."""
    if current_user.has_role(Role.ADMIN):
        return
    if current_assignee_id and current_user.id == current_assignee_id:
        return
    if qa_workspace_id is not None and current_user.has_qa_workspace_role(
        Role.CHIEF_MANAGER_QA, Role.AGM_QA, workspace_id=qa_workspace_id,
    ):
        return
    departments = [department] if isinstance(department, str) else list(department or [])
    for dept in departments:
        if dept and current_user.has_department(dept) \
                and set(current_user.roles) & set(department_head_roles(dept)):
            return
    raise HTTPException(
        403,
        "Only the current assignee, the Department Head of their department, "
        "or an Administrator can reassign this",
    )


def require_reason(reason: Optional[str]) -> str:
    """A reassignment reason is mandatory -- same 400-on-blank convention as
    every other required free-text field in this app (see routers'
    `_required` helpers)."""
    if not reason or not reason.strip():
        raise HTTPException(400, "A reassignment reason is required")
    return reason.strip()


def record_assignment_change(
    db: Session,
    entity_type: str,
    entity_id: int,
    assignment_role: str,
    actor: models.User,
    previous_assignee_ids: Iterable[Optional[int]],
    new_assignee_ids: Iterable[Optional[int]],
    reason: Optional[str] = None,
    previous_assigned_at: Optional[datetime.datetime] = None,
) -> None:
    """Synchronize normalized assignment tenures for one entity/role.

    Rows active before the change are closed, retained assignees keep their
    original start time, and newly assigned users receive a fresh active row.
    When an assignment predates this table, ``previous_assignee_ids`` lazily
    creates the missing historical tenure before closing/retaining it.  This
    avoids inventing a bulk backfill that cannot reliably reconstruct the
    original actor or timestamp from free-text ApprovalAction rows.
    """
    previous_ids = {int(value) for value in previous_assignee_ids if value is not None}
    new_ids = {int(value) for value in new_assignee_ids if value is not None}
    changed_at = models.now()
    normalized_reason = reason.strip() if reason and reason.strip() else None

    active_rows = db.query(models.AssignmentHistory).filter(
        models.AssignmentHistory.entity_type == entity_type,
        models.AssignmentHistory.entity_id == entity_id,
        models.AssignmentHistory.assignment_role == assignment_role,
        models.AssignmentHistory.unassigned_at.is_(None),
    ).with_for_update().all()
    active_by_user = {row.assignee_id: row for row in active_rows}

    # Adopt legacy current assignments that existed before this normalized
    # table.  The source row's assigned_at is used when one exists; actor is
    # intentionally NULL because the original assigning actor is unknowable.
    for assignee_id in previous_ids - set(active_by_user):
        row = models.AssignmentHistory(
            entity_type=entity_type,
            entity_id=entity_id,
            assignment_role=assignment_role,
            assignee_id=assignee_id,
            assigned_by_id=None,
            assigned_at=previous_assigned_at or changed_at,
        )
        db.add(row)
        active_by_user[assignee_id] = row

    for assignee_id, row in active_by_user.items():
        if assignee_id not in new_ids:
            row.unassigned_by_id = actor.id
            row.unassigned_at = changed_at
            row.unassignment_reason = normalized_reason

    for assignee_id in new_ids - set(active_by_user):
        db.add(models.AssignmentHistory(
            entity_type=entity_type,
            entity_id=entity_id,
            assignment_role=assignment_role,
            assignee_id=assignee_id,
            assigned_by_id=actor.id,
            assigned_at=changed_at,
            assignment_reason=normalized_reason,
        ))


def record_reassignment(db: Session, entity_type: str, entity_id: int, actor: models.User,
                         previous_label: str, new_label: str,
                         reason: str, step_name: str = "Reassignment", *,
                         assignment_role: str,
                         previous_assignee_ids: Iterable[Optional[int]],
                         new_assignee_ids: Iterable[Optional[int]],
                         previous_assigned_at: Optional[datetime.datetime] = None,
                         assignment_entity_type: Optional[str] = None,
                         assignment_entity_id: Optional[int] = None) -> None:
    """Write both the human-readable event and normalized assignee tenures.

    ApprovalAction remains the business activity feed, while
    AssignmentHistory is the queryable source for exact assignee intervals,
    actors, roles and reasons.

    `previous_label`/`new_label` are plain display strings (a name, a
    comma-joined list of names, or "Unassigned") rather than User objects --
    some of the flows this covers (Functional/Performance testers) assign a
    LIST of people, not a single one, so the caller is better placed to
    format that than this shared helper would be."""
    db.add(models.ApprovalAction(
        entity_type=entity_type, entity_id=entity_id, step_name=step_name,
        actor_id=actor.id, actor_role=actor.roles_csv, decision="Reassigned",
        comments=reason, previous_state=previous_label, new_state=new_label,
    ))
    record_assignment_change(
        db, assignment_entity_type or entity_type,
        assignment_entity_id if assignment_entity_id is not None else entity_id,
        assignment_role, actor,
        previous_assignee_ids, new_assignee_ids, reason, previous_assigned_at,
    )
