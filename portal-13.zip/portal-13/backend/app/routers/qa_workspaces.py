from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload, selectinload

from .. import models, schemas
from ..document_portal_storage import DOCUMENT_ROOT, OWNER_FILE, rename_workspace_root, workspace_folder_name, workspace_root
from ..storage_lock import exclusive_file_lock
from ..database import get_db
from ..deps import get_current_user, require_roles
from ..constants import Role, REQUEST_TYPES
from ..workspace_service import (
    WORKSPACE_BOUNDARY_ROLES,
    PARENT_WORKSPACE_ROLES,
    can_configure_workspace,
    can_create_child_workspace,
    can_manage_workspace_members,
    ensure_administrator_workspace_memberships,
    remove_default_membership_after_assignment,
    selectable_workspace_ids,
)

router = APIRouter(tags=["Workspaces"])


def _workspace(db: Session, workspace_id: int) -> models.QAWorkspace:
    row = db.query(models.QAWorkspace).options(
        joinedload(models.QAWorkspace.parent_workspace),
        joinedload(models.QAWorkspace.members).joinedload(models.QAWorkspaceMember.user)
            .selectinload(models.User.department_assignments),
        joinedload(models.QAWorkspace.members).joinedload(models.QAWorkspaceMember.user)
            .selectinload(models.User.role_assignments),
        joinedload(models.QAWorkspace.department_coordinators).joinedload(models.DepartmentCoordinatorAssignment.user),
        joinedload(models.QAWorkspace.department_coordinators).joinedload(models.DepartmentCoordinatorAssignment.department),
        joinedload(models.QAWorkspace.department_coordinators).joinedload(models.DepartmentCoordinatorAssignment.department_unit),
        joinedload(models.QAWorkspace.coverage_rules).joinedload(models.QAWorkspaceCoverage.department),
        joinedload(models.QAWorkspace.coverage_rules).joinedload(models.QAWorkspaceCoverage.department_unit),
        joinedload(models.QAWorkspace.coverage_rules).joinedload(models.QAWorkspaceCoverage.application_master),
    ).filter(models.QAWorkspace.id == workspace_id).first()
    if not row:
        raise HTTPException(404, "Workspace not found")
    return row


def _check_family_quota(db: Session, *, parent: models.QAWorkspace | None,
                        quota_bytes: int, workspace_id: int | None = None) -> None:
    if parent is not None:
        if parent.document_portal_quota_bytes is None:
            raise HTTPException(409, 'Set the parent workspace storage limit before adding a child workspace')
        if quota_bytes > parent.document_portal_quota_bytes:
            raise HTTPException(400, 'A child workspace storage limit cannot exceed its parent workspace limit')
    elif workspace_id is not None:
        children = db.query(models.QAWorkspace).filter(
            models.QAWorkspace.parent_workspace_id == workspace_id).all()
        if any(child.document_portal_quota_bytes and child.document_portal_quota_bytes > quota_bytes for child in children):
            raise HTTPException(400, 'The parent workspace limit cannot be lower than a child workspace limit')


def _ensure_workspace_fallback(db: Session, user: models.User, excluded_workspace_id: int) -> int:
    """Keep an active user in a workspace after an administrator removes access."""
    existing = db.query(models.QAWorkspaceMember).join(models.QAWorkspace).filter(
        models.QAWorkspaceMember.user_id == user.id,
        models.QAWorkspaceMember.workspace_id != excluded_workspace_id,
        models.QAWorkspaceMember.is_active == True,  # noqa: E712
        models.QAWorkspace.is_active == True,  # noqa: E712
    ).order_by(models.QAWorkspace.is_default, models.QAWorkspace.id).first()
    if existing is not None:
        return existing.workspace_id

    excluded = db.get(models.QAWorkspace, excluded_workspace_id)
    if excluded is not None and excluded.is_default:
        raise HTTPException(
            409,
            "Assign this user to another workspace before removing their Default Workspace membership",
        )

    # Only the organisation default is an automatic fallback. Assigning an
    # unrelated workspace here would grant access the administrator did not
    # request when removing the user's last membership.
    fallback = db.query(models.QAWorkspace).filter(
        models.QAWorkspace.id != excluded_workspace_id,
        models.QAWorkspace.is_active == True,  # noqa: E712
        models.QAWorkspace.is_default == True,  # noqa: E712
    ).order_by(models.QAWorkspace.id).first()
    if fallback is None:
        raise HTTPException(
            409,
            "Restore the active Default Workspace before removing this user's only workspace membership",
        )

    membership = db.query(models.QAWorkspaceMember).filter_by(
        workspace_id=fallback.id, user_id=user.id, role="WORKSPACE_MEMBER",
    ).first()
    if membership is None:
        db.add(models.QAWorkspaceMember(
            workspace_id=fallback.id, user_id=user.id,
            role="WORKSPACE_MEMBER", is_active=True,
        ))
    else:
        membership.is_active = True
    return fallback.id


@router.get("/api/workspaces", response_model=list[schemas.QAWorkspaceOut])
def list_workspaces(db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    query = db.query(models.QAWorkspace).options(
        joinedload(models.QAWorkspace.parent_workspace),
        joinedload(models.QAWorkspace.members).joinedload(models.QAWorkspaceMember.user)
            .selectinload(models.User.department_assignments),
        joinedload(models.QAWorkspace.members).joinedload(models.QAWorkspaceMember.user)
            .selectinload(models.User.role_assignments),
        joinedload(models.QAWorkspace.department_coordinators).joinedload(models.DepartmentCoordinatorAssignment.user),
        joinedload(models.QAWorkspace.department_coordinators).joinedload(models.DepartmentCoordinatorAssignment.department),
        joinedload(models.QAWorkspace.department_coordinators).joinedload(models.DepartmentCoordinatorAssignment.department_unit),
        joinedload(models.QAWorkspace.coverage_rules).joinedload(models.QAWorkspaceCoverage.department),
        joinedload(models.QAWorkspace.coverage_rules).joinedload(models.QAWorkspaceCoverage.department_unit),
        joinedload(models.QAWorkspace.coverage_rules).joinedload(models.QAWorkspaceCoverage.application_master),
    ).order_by(models.QAWorkspace.name)
    if not current_user.has_role(Role.ADMIN):
        ids = selectable_workspace_ids(db, current_user)
        query = query.filter(models.QAWorkspace.id.in_(ids or [-1]), models.QAWorkspace.is_active == True)  # noqa: E712
    return query.all()


@router.post("/api/workspaces", response_model=schemas.QAWorkspaceOut)
def create_workspace(payload: schemas.QAWorkspaceCreate, db: Session = Depends(get_db),
                     current_user: models.User = Depends(get_current_user)):
    key = payload.workspace_key.strip().upper().replace(" ", "-")
    name = payload.name.strip()
    if not key or not name:
        raise HTTPException(400, "Workspace key and name are required")
    try:
        workspace_folder_name(name)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    if db.query(models.QAWorkspace).filter(
        (models.QAWorkspace.workspace_key == key) | (models.QAWorkspace.name == name)
    ).first():
        raise HTTPException(409, "A workspace with this key or name already exists")
    if key == "DEFAULT":
        raise HTTPException(409, "DEFAULT is reserved for the seeded Default Workspace")
    parent = None
    if payload.parent_workspace_id is not None:
        parent = db.get(models.QAWorkspace, payload.parent_workspace_id)
        if not parent or not parent.is_active:
            raise HTTPException(400, "Select an active parent workspace")
        if parent.parent_workspace_id is not None:
            raise HTTPException(400, "A child workspace cannot contain another workspace")
    if not can_create_child_workspace(current_user, parent):
        raise HTTPException(403, "Only a System Administrator can create a workspace")
    _check_family_quota(db, parent=parent, quota_bytes=payload.document_portal_quota_bytes)
    row = models.QAWorkspace(
        **payload.model_dump(exclude={"workspace_key", "name", "is_default", "parent_workspace_id"}),
        workspace_key=key, name=name, is_default=False,
        parent_workspace_id=parent.id if parent else None,
        created_by_id=current_user.id,
    )
    db.add(row)
    db.flush()
    created_root = None
    root_was_present = (DOCUMENT_ROOT / name).exists()
    try:
        created_root = workspace_root(row, create=True)
        ensure_administrator_workspace_memberships(db, workspace=row)
        db.commit()
    except FileExistsError as exc:
        db.rollback()
        raise HTTPException(409, str(exc)) from exc
    except Exception:
        db.rollback()
        if not root_was_present and created_root and created_root.is_dir() and set(item.name for item in created_root.iterdir()) == {OWNER_FILE}:
            (created_root / OWNER_FILE).unlink()
            created_root.rmdir()
        raise
    return _workspace(db, row.id)


@router.patch("/api/workspaces/{workspace_id:int}", response_model=schemas.QAWorkspaceOut)
def update_workspace(workspace_id: int, payload: schemas.QAWorkspaceUpdate,
                     db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    row = _workspace(db, workspace_id)
    if not can_configure_workspace(current_user, row):
        raise HTTPException(403, "You do not have administrative access to this workspace")
    data = payload.model_dump(exclude_unset=True)
    if data.get('document_portal_quota_bytes') is None and 'document_portal_quota_bytes' in data:
        raise HTTPException(400, 'Document Portal storage limit must be at least 1 byte')
    if not current_user.has_role(Role.ADMIN) and "parent_workspace_id" in data:
        if data["parent_workspace_id"] != row.parent_workspace_id:
            raise HTTPException(403, "Only a System Administrator can change workspace hierarchy")
    if "is_default" in data:
        raise HTTPException(400, "The seeded DEFAULT workspace is the fixed first-login workspace")
    if row.workspace_key == "DEFAULT":
        if data.get("is_active") is False:
            raise HTTPException(400, "The Default Workspace cannot be deactivated")
        if "name" in data and data["name"].strip() != "Default Workspace":
            raise HTTPException(400, "The Default Workspace name is fixed")
    if "parent_workspace_id" in data:
        parent_id = data["parent_workspace_id"]
        if row.is_default and parent_id is not None:
            raise HTTPException(400, "The Default Workspace must remain top-level")
        if parent_id == row.id:
            raise HTTPException(400, "A workspace cannot be its own parent")
        if parent_id is not None:
            parent = db.get(models.QAWorkspace, parent_id)
            if not parent or not parent.is_active:
                raise HTTPException(400, "Select an active parent workspace")
            if parent.parent_workspace_id is not None:
                raise HTTPException(400, "A child workspace cannot contain another workspace")
            if row.child_workspaces:
                raise HTTPException(400, "A parent workspace cannot be moved below another workspace")
    effective_parent_id = data.get('parent_workspace_id', row.parent_workspace_id)
    effective_parent = db.get(models.QAWorkspace, effective_parent_id) if effective_parent_id else None
    effective_quota = data.get('document_portal_quota_bytes', row.document_portal_quota_bytes)
    if effective_quota is not None:
        _check_family_quota(db, parent=effective_parent, quota_bytes=effective_quota,
                            workspace_id=row.id if effective_parent is None else None)
    if data.get("is_active") is False and row.is_active:
        member_user_ids = {member.user_id for member in row.members if member.is_active}
        for user_id in member_user_ids:
            member_user = db.get(models.User, user_id)
            if member_user:
                fallback_id = _ensure_workspace_fallback(db, member_user, row.id)
                if member_user.preferred_qa_workspace_id == row.id:
                    member_user.preferred_qa_workspace_id = fallback_id
    family_id = effective_parent.id if effective_parent else row.id
    lock_path = DOCUMENT_ROOT / f'.workspace-{family_id}.quota.lock'
    with exclusive_file_lock(lock_path) as acquired:
        if not acquired:
            raise HTTPException(409, 'Another storage operation is active in this workspace family')
        renamed_root = None
        if 'name' in data and data['name'].strip() != row.name:
            try:
                renamed_root = rename_workspace_root(row, data['name'].strip())
            except ValueError as exc:
                raise HTTPException(400, str(exc)) from exc
            except FileExistsError as exc:
                raise HTTPException(409, str(exc)) from exc
        for key, value in data.items():
            setattr(row, key, value.strip() if isinstance(value, str) else value)
        try:
            db.commit()
        except Exception:
            db.rollback()
            if renamed_root and renamed_root[0] != renamed_root[1]:
                renamed_root[1].rename(renamed_root[0])
            raise
    return _workspace(db, row.id)


@router.put("/api/workspaces/{workspace_id:int}/members", response_model=schemas.QAWorkspaceOut)
def replace_members(workspace_id: int, payload: schemas.QAWorkspaceMembersReplace,
                    db: Session = Depends(get_db), _: models.User = Depends(get_current_user)):
    workspace = _workspace(db, workspace_id)
    current_user = _
    if not can_manage_workspace_members(current_user, workspace):
        raise HTTPException(403, "You do not have permission to manage membership in this workspace")
    # Parent-level Viewer/Admin grants define inherited access and may be
    # assigned or changed only by a System Administrator. A Parent Workspace
    # Admin may manage ordinary direct members on the parent, but must
    # preserve every existing parent permission exactly.
    protected_parent_access = {
        row.user_id: row.role
        for row in db.query(models.QAWorkspaceMember).filter(
            models.QAWorkspaceMember.workspace_id == workspace_id,
            models.QAWorkspaceMember.role.in_(PARENT_WORKSPACE_ROLES),
            models.QAWorkspaceMember.is_active == True,  # noqa: E712
        )
    } if not current_user.has_role(Role.ADMIN) else {}
    desired: set[tuple[int, str]] = set()
    for member in payload.members:
        user = db.get(models.User, member.user_id)
        if not user or (not user.is_active and not user.has_role(Role.ADMIN)):
            raise HTTPException(400, f"Active user {member.user_id} was not found")
        roles = member.roles or ["WORKSPACE_MEMBER"]
        invalid_roles = sorted(set(roles) - WORKSPACE_BOUNDARY_ROLES)
        if invalid_roles:
            raise HTTPException(
                400,
                f"{', '.join(invalid_roles)} is not a workspace boundary role. "
                "Operational permissions must be assigned through the System Administrator permission profile.",
            )
        access_roles = set(roles)
        if len(access_roles) > 1:
            raise HTTPException(400, "Select exactly one workspace access level for each user")
        access_role = next(iter(access_roles), "WORKSPACE_MEMBER")
        if access_role in PARENT_WORKSPACE_ROLES and (
            workspace.parent_workspace_id is not None or workspace.is_default
        ):
            raise HTTPException(400, "Parent Viewer/Admin can be assigned only on a non-default top-level workspace")
        if not current_user.has_role(Role.ADMIN) and (
            access_role in PARENT_WORKSPACE_ROLES or member.user_id in protected_parent_access
        ) and protected_parent_access.get(member.user_id) != access_role:
            raise HTTPException(
                403,
                "Parent Workspace Viewer/Admin permissions are managed by a System Administrator",
            )
        # This endpoint owns workspace boundaries only. Global operational
        # permissions are managed by the System Administrator user-access API;
        # accepting them here would let a Parent Workspace Administrator turn
        # an ordinary membership update into a global role grant.
        desired.add((member.user_id, "WORKSPACE_MEMBER" if user.has_role(Role.ADMIN) else access_role))
    if protected_parent_access and any(
        (user_id, role) not in desired for user_id, role in protected_parent_access.items()
    ):
        raise HTTPException(
            409,
            "Parent Workspace Viewer/Admin permissions are managed by a System Administrator",
        )
    current_user_ids = {
        row.user_id for row in db.query(models.QAWorkspaceMember).filter(
            models.QAWorkspaceMember.workspace_id == workspace_id,
            models.QAWorkspaceMember.is_active == True,  # noqa: E712
        )
    }
    desired_user_ids = {user_id for user_id, _ in desired}
    inherited_parent_user_ids: set[int] = set()
    if workspace.parent_workspace_id is not None:
        inherited_parent_user_ids = {
            user_id for (user_id,) in db.query(models.QAWorkspaceMember.user_id).filter(
                models.QAWorkspaceMember.workspace_id == workspace.parent_workspace_id,
                models.QAWorkspaceMember.role.in_(PARENT_WORKSPACE_ROLES),
                models.QAWorkspaceMember.is_active == True,  # noqa: E712
            ).distinct()
        }
    removed_protected_ids = (current_user_ids - desired_user_ids) & inherited_parent_user_ids
    if removed_protected_ids:
        raise HTTPException(
            409,
            "Parent Workspace Viewer/Admin access is inherited and cannot be removed from a child workspace",
        )
    administrator_ids = {
        user_id for (user_id,) in db.query(models.UserRole.user_id).filter(
            models.UserRole.role == Role.ADMIN,
        ).distinct()
    }
    missing_administrator_ids = administrator_ids - desired_user_ids
    if missing_administrator_ids:
        raise HTTPException(
            409,
            "System Administrators are required members of every workspace and cannot be removed",
        )
    if workspace is not None and not workspace.is_default:
        for user_id in desired_user_ids - administrator_ids:
            user = db.get(models.User, user_id)
            if user is not None:
                remove_default_membership_after_assignment(db, user, workspace_id)
    for user_id in current_user_ids - desired_user_ids:
        user = db.get(models.User, user_id)
        if user:
            fallback_id = _ensure_workspace_fallback(db, user, workspace_id)
            if user.preferred_qa_workspace_id == workspace_id:
                user.preferred_qa_workspace_id = fallback_id
    db.query(models.DepartmentCoordinatorAssignment).filter(
        models.DepartmentCoordinatorAssignment.workspace_id == workspace_id,
        models.DepartmentCoordinatorAssignment.user_id.in_(current_user_ids - desired_user_ids),
    ).delete(synchronize_session=False)
    db.query(models.QAWorkspaceMember).filter(models.QAWorkspaceMember.workspace_id == workspace_id).delete()
    db.add_all([models.QAWorkspaceMember(workspace_id=workspace_id, user_id=user_id, role=role)
                for user_id, role in sorted(desired)])
    db.commit()
    return _workspace(db, workspace_id)


@router.get(
    "/api/workspaces/{workspace_id:int}/member-candidates",
    response_model=list[schemas.LocalAdminWorkspaceCandidateOut],
)
def list_workspace_member_candidates(
    workspace_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Full active directory for an authorized workspace-membership administrator."""
    workspace = _workspace(db, workspace_id)
    if not can_manage_workspace_members(current_user, workspace):
        raise HTTPException(403, "You do not have permission to manage membership in this workspace")
    direct_member_ids = select(models.QAWorkspaceMember.user_id).where(
        models.QAWorkspaceMember.workspace_id == workspace.id,
        models.QAWorkspaceMember.is_active == True,  # noqa: E712
    )
    inherited_member_ids = select(models.QAWorkspaceMember.user_id).where(
        models.QAWorkspaceMember.workspace_id == workspace.parent_workspace_id,
        models.QAWorkspaceMember.role.in_(PARENT_WORKSPACE_ROLES),
        models.QAWorkspaceMember.is_active == True,  # noqa: E712
    )
    return db.query(models.User).options(
        selectinload(models.User.department_assignments),
        selectinload(models.User.role_assignments),
    ).filter(
        models.User.is_active == True,  # noqa: E712
        models.User.show_in_user_dropdowns == True,  # noqa: E712
        ~models.User.id.in_(direct_member_ids),
        ~models.User.id.in_(inherited_member_ids),
    ).order_by(models.User.full_name).all()


@router.post(
    "/api/workspaces/{workspace_id:int}/department-coordinators",
    response_model=schemas.DepartmentCoordinatorOut,
)
def add_department_coordinator(
    workspace_id: int,
    payload: schemas.DepartmentCoordinatorCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    workspace = _workspace(db, workspace_id)
    if not can_configure_workspace(current_user, workspace):
        raise HTTPException(403, "You do not have administrative access to this workspace")
    if not workspace.is_active:
        raise HTTPException(400, "Select an active workspace")
    user = db.get(models.User, payload.user_id)
    if not user or not user.is_active:
        raise HTTPException(400, "Select an active user")
    if not user.show_in_user_dropdowns:
        raise HTTPException(400, "The selected user is hidden from assignment dropdowns")
    department = db.get(models.Department, payload.department_id)
    if not department or not department.is_active:
        raise HTTPException(400, "Select an active department")
    if payload.department_unit_id is not None:
        raise HTTPException(400, "Team scope is represented by a child workspace. Select the department only.")

    row = db.query(models.DepartmentCoordinatorAssignment).filter_by(
        workspace_id=workspace_id,
        user_id=user.id,
        department_id=department.id,
        department_unit_id=None,
    ).first()
    if row is None:
        row = models.DepartmentCoordinatorAssignment(
            workspace_id=workspace_id,
            user_id=user.id,
            department_id=department.id,
            department_unit_id=None,
            is_active=True,
            created_by_id=current_user.id,
        )
        db.add(row)
    else:
        row.is_active = True
        row.created_by_id = current_user.id

    # Coordinator assignment needs workspace access, but must not add a
    # second access level when the user already has Viewer/Admin access.
    # That duplicate previously made the member editor submit two mutually
    # exclusive levels and blocked unrelated additions to the workspace.
    active_access = db.query(models.QAWorkspaceMember).filter(
        models.QAWorkspaceMember.workspace_id == workspace_id,
        models.QAWorkspaceMember.user_id == user.id,
        models.QAWorkspaceMember.role.in_({
            "WORKSPACE_MEMBER", "WORKSPACE_VIEWER", *PARENT_WORKSPACE_ROLES,
        }),
        models.QAWorkspaceMember.is_active == True,  # noqa: E712
    ).first()
    if active_access is None:
        membership = db.query(models.QAWorkspaceMember).filter_by(
            workspace_id=workspace_id,
            user_id=user.id,
            role="WORKSPACE_MEMBER",
        ).first()
        if membership is None:
            db.add(models.QAWorkspaceMember(
                workspace_id=workspace_id, user_id=user.id,
                role="WORKSPACE_MEMBER", is_active=True,
            ))
        else:
            membership.is_active = True
    remove_default_membership_after_assignment(db, user, workspace_id)
    if user.preferred_qa_workspace_id is None:
        user.preferred_qa_workspace_id = workspace_id
    db.commit()
    return db.query(models.DepartmentCoordinatorAssignment).options(
        joinedload(models.DepartmentCoordinatorAssignment.user),
        joinedload(models.DepartmentCoordinatorAssignment.department),
        joinedload(models.DepartmentCoordinatorAssignment.workspace),
    ).filter(models.DepartmentCoordinatorAssignment.id == row.id).one()


@router.delete(
    "/api/workspaces/{workspace_id:int}/department-coordinators/{assignment_id:int}",
    status_code=204,
)
def delete_department_coordinator(
    workspace_id: int,
    assignment_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    if not can_configure_workspace(current_user, _workspace(db, workspace_id)):
        raise HTTPException(403, "You do not have administrative access to this workspace")
    row = db.query(models.DepartmentCoordinatorAssignment).filter(
        models.DepartmentCoordinatorAssignment.id == assignment_id,
        models.DepartmentCoordinatorAssignment.workspace_id == workspace_id,
    ).first()
    if row is None:
        raise HTTPException(404, "Department coordinator assignment not found")
    db.delete(row)
    db.commit()


@router.post("/api/workspaces/{workspace_id:int}/coverage", response_model=schemas.QAWorkspaceCoverageOut)
def add_coverage(workspace_id: int, payload: schemas.QAWorkspaceCoverageCreate,
                 db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    workspace = _workspace(db, workspace_id)
    if not can_configure_workspace(current_user, workspace):
        raise HTTPException(403, "You do not have administrative access to this workspace")
    if payload.department_id and not db.get(models.Department, payload.department_id):
        raise HTTPException(400, "Department not found")
    if payload.department_unit_id:
        raise HTTPException(400, "Unit routing has been replaced by child workspaces")
    if payload.application_master_id and not db.get(models.ApplicationMaster, payload.application_master_id):
        raise HTTPException(400, "Application not found")
    request_type = payload.request_type.strip() if payload.request_type else None
    if request_type and request_type not in REQUEST_TYPES:
        raise HTTPException(400, "Select a configured QA request type")
    duplicate = db.query(models.QAWorkspaceCoverage).filter_by(
        workspace_id=workspace_id,
        department_id=payload.department_id,
        department_unit_id=payload.department_unit_id,
        application_master_id=payload.application_master_id,
        request_type=request_type,
    ).first()
    if duplicate:
        raise HTTPException(409, "This workspace already has the same coverage rule")
    data = payload.model_dump(exclude={"request_type"})
    row = models.QAWorkspaceCoverage(workspace_id=workspace_id, request_type=request_type, **data)
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.delete("/api/workspaces/{workspace_id:int}/coverage/{coverage_id:int}", status_code=204)
def delete_coverage(workspace_id: int, coverage_id: int, db: Session = Depends(get_db),
                    current_user: models.User = Depends(get_current_user)):
    if not can_configure_workspace(current_user, _workspace(db, workspace_id)):
        raise HTTPException(403, "You do not have administrative access to this workspace")
    row = db.query(models.QAWorkspaceCoverage).filter(
        models.QAWorkspaceCoverage.id == coverage_id,
        models.QAWorkspaceCoverage.workspace_id == workspace_id,
    ).first()
    if not row:
        raise HTTPException(404, "Coverage rule not found")
    db.delete(row)
    db.commit()


@router.patch("/api/workspaces/preference/current", response_model=schemas.UserOut)
def set_preference(payload: schemas.QAWorkspacePreference, db: Session = Depends(get_db),
                   current_user: models.User = Depends(get_current_user)):
    workspace = db.get(models.QAWorkspace, payload.workspace_id)
    if not workspace or not workspace.is_active or workspace.id not in selectable_workspace_ids(db, current_user):
        raise HTTPException(403, "You do not have access to this workspace")
    current_user.preferred_qa_workspace_id = workspace.id
    db.commit()
    db.refresh(current_user)
    return current_user


@router.patch("/api/workspaces/requests/{request_id:int}/route", response_model=schemas.QARequestOut)
def manually_route_request(request_id: int, payload: schemas.QAWorkspaceRouteRequest,
                           db: Session = Depends(get_db), _: models.User = Depends(require_roles(Role.ADMIN))):
    request = db.get(models.QARequest, request_id)
    workspace = db.get(models.QAWorkspace, payload.workspace_id)
    if not request:
        raise HTTPException(404, "QA Request not found")
    if not workspace or not workspace.is_active:
        raise HTTPException(400, "Select an active workspace")
    request.qa_workspace_id = workspace.id
    request.workspace_routing_status = "MANUALLY_ROUTED"
    db.commit()
    db.refresh(request)
    return request


from ..defect_workflow import WorkflowPolicy


@router.get('/api/workspaces/{workspace_id:int}/defect-workflow/history', response_model=list[WorkflowPolicy])
def defect_workflow_history(workspace_id: int, db: Session = Depends(get_db),
                            current_user: models.User = Depends(get_current_user)):
    import json
    from ..defect_workflow import policy
    row = _workspace(db, workspace_id)
    if not can_configure_workspace(current_user, row):
        raise HTTPException(403, 'Only a workspace configuration administrator can view workflow history')
    versions = {}
    for entry in json.loads(row.defect_workflow_history_json or '[]'):
        for key in ('previous', 'published'):
            snapshot = WorkflowPolicy.model_validate(entry[key]).model_dump()
            versions[snapshot['version']] = snapshot
    current = policy(row.defect_workflow_json)
    versions[current['version']] = current
    return [versions[number] for number in sorted(versions, reverse=True)]


@router.put('/api/workspaces/{workspace_id:int}/defect-workflow', response_model=schemas.QAWorkspaceOut)
def publish_defect_workflow(workspace_id: int, payload: WorkflowPolicy,
                            db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    import json
    from ..defect_workflow import policy
    row = _workspace(db, workspace_id)
    if not can_configure_workspace(current_user, row):
        raise HTTPException(403, 'Only a workspace configuration administrator can publish a workflow')
    db.query(models.QAWorkspace).filter_by(id=row.id).with_for_update().populate_existing().one()
    current = policy(row.defect_workflow_json)
    if payload.version != current['version']:
        raise HTTPException(409, 'Workflow changed. Refresh before publishing.')
    updated = payload.model_dump()
    updated['version'] = current['version'] + 1
    history = json.loads(row.defect_workflow_history_json or '[]')
    history.append({'previous': current, 'published': updated, 'user_id': current_user.id,
                    'at': models.now().isoformat()})
    row.defect_workflow_json = json.dumps(updated)
    row.defect_workflow_history_json = json.dumps(history)
    db.commit()
    return _workspace(db, row.id)
