import os
from typing import List, Literal, Optional
from urllib.parse import urlparse
from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from sqlalchemy import and_, exists, func, or_
from sqlalchemy.orm import Session, joinedload, selectinload
from sqlalchemy.exc import IntegrityError

from .. import models, schemas, pagination, email_notifications
from ..execution_cycles import (
    CYCLE_LINKABLE_FUNCTIONAL_STATUSES,
    cycle_unlink_allowed,
    require_cycle_request_linkable,
    require_request_cycle_completable,
    require_cycle_unlinkable,
)
from ..database import get_db
from ..deps import (
    get_workflow_user as get_current_user, require_workflow_roles as require_roles, viewable_project_ids,
    require_can_execute_project, require_can_manage_execution_governance,
    can_view_cycle_folder, require_can_view_cycle_folder,
    get_project_or_404 as _get_project_or_404,
    require_project_visibility,
)
from ..constants import (
    Role,
    QAStatus,
    TEST_CYCLE_LOCKED_STATUSES,
    format_role_labels,
)
from ..workspace_service import (
    current_workspace_id, selectable_workspace_ids,
)
from .. import documents as doc_store
from .. import reassignment
from . import jobs
from ..job_tasks import make_spec
from ..xlsx_export import add_summary_sheet, add_table_sheet, new_workbook, workbook_response
from ..upload_limits import validate_document_uploads

# PAG-005-adjacent -- list_executions below keeps the full TestExecutionOut
# shape (unlike Functional/SAST/DAST/Test Cases, no separate lightweight
# ListOut was introduced here; a cycle's execution count is naturally
# bounded by how many test cases were assigned to it, not an
# unbounded-growth list like a whole project's request/case history), but it
# had NO eager-loading at all before this pagination pass -- every row was a
# fresh set of lazy queries for test_case/assigned_to/assigned_by/
# executed_by/runs/linked_defects. This is a partial mitigation (the direct,
# most-used relationships), not a complete N+1 elimination -- test_case's
# OWN nested relations (folder/created_by/checked_out_by/current_draft_version
# chain, tags) still lazy-load per row, same as before this change.
_LIST_EXECUTION_EAGER_LOADS = [
    joinedload(models.TestExecution.test_case),
    joinedload(models.TestExecution.assigned_to),
    joinedload(models.TestExecution.assigned_by),
    joinedload(models.TestExecution.executed_by),
    # Perf tuning (2026-08) -- added_by was missing from this list even
    # though TestExecutionOut.added_by_name reads it exactly like
    # assigned_by_name/executed_by_name do; every row was still a lazy
    # extra SELECT for this one relationship. Found while chasing the
    # "3500 testcases, add to cycle, timeout" report below.
    joinedload(models.TestExecution.added_by),
    selectinload(models.TestExecution.runs).selectinload(models.TestExecutionRun.defects),
    selectinload(models.TestExecution.primary_linked_defects),
    selectinload(models.TestExecution.additional_linked_defects),
]

router = APIRouter(prefix="/api/test-execution", tags=["test-management"])

# Same access as the Test Repository (test_repository.py): the QA Group and
# QA Lead Group (including CM QA and AGM QA) can manage execution work.
# Admin always bypasses via require_roles.
_EXEC_ROLES = (Role.QA_ENGINEER, Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA)
_RESULT_IMAGE_MODULE = "TEST_EXEC_IMAGE"  # <= qap_module_documents.module VARCHAR2(20)
_RESULT_IMAGE_TYPES = {"image/png", "image/jpeg", "image/gif", "image/webp"}
_RESULT_IMAGE_LIMIT = 8
_RESULT_IMAGE_MAX_BYTES = 10 * 1024 * 1024
# Oracle raises ORA-01795 when one IN expression contains more than 1,000
# values. Leave headroom rather than relying on the exact boundary so bulk
# selection remains portable across Oracle versions and SQLAlchemy drivers.
_ORACLE_IN_BATCH_SIZE = 900

# The QA Lead Group override exists to recover an execution workflow from an
# incorrect Functional Request association. It must not rewrite the evidence
# boundary after clearance has become authoritative. Rejected certificates
# are intentionally absent: they are terminal history, but correcting the
# underlying association before creating a revised certificate is legitimate.
_QA_LEAD_UNLINK_PROTECTED_REQUEST_STATUSES = {
    QAStatus.QA_SIGNED_OFF,
    QAStatus.REQUESTER_VERIFICATION,
    QAStatus.CLOSED,
    QAStatus.CANCELLED,
}
_QA_LEAD_UNLINK_PROTECTED_CERTIFICATE_STATUSES = {
    "ISSUED", "ISSUED_UNDER_REVIEW", "SUPERSEDED",
}


def _in_batches(values: List[int], size: int = _ORACLE_IN_BATCH_SIZE):
    """Yield Oracle-safe slices while preserving the caller's order."""
    for start in range(0, len(values), size):
        yield values[start:start + size]


def _cycle_candidate_query(db: Session, cycle: models.TestCycle,
                           search: Optional[str] = None, priority: Optional[str] = None,
                           test_type: Optional[str] = None,
                           created_by_id: Optional[int] = None):
    """Approved project testcases not already present in ``cycle``.

    The correlated NOT EXISTS is intentionally resolved by Oracle. It
    replaces the former pair of unrestricted client downloads (every
    project testcase plus every cycle testcase id).
    """
    already_in_cycle = exists().where(and_(
        models.TestExecution.cycle_id == cycle.id,
        models.TestExecution.test_case_id == models.TestCase.id,
    ))
    query = (
        db.query(models.TestCase)
        .join(
            models.TestCaseVersion,
            models.TestCaseVersion.id == models.TestCase.current_approved_version_id,
        )
        .filter(
            models.TestCase.project_id == cycle.project_id,
            models.TestCase.is_deleted == False,  # noqa: E712
            models.TestCaseVersion.status == "Approved",
            ~already_in_cycle,
        )
    )
    if search and search.strip():
        like = f"%{search.strip()}%"
        query = query.filter(or_(
            models.TestCase.test_case_key.ilike(like),
            models.TestCaseVersion.test_scenario.ilike(like),
            models.TestCaseVersion.module_name.ilike(like),
            models.TestCaseVersion.test_type.ilike(like),
        ))
    if priority and priority.strip():
        query = query.filter(models.TestCaseVersion.priority == priority.strip())
    if test_type and test_type.strip():
        query = query.filter(models.TestCaseVersion.test_type == test_type.strip())
    if created_by_id is not None:
        query = query.filter(models.TestCase.created_by_id == created_by_id)
    return query


def _get_cycle_or_404(db: Session, cycle_id: int) -> models.TestCycle:
    obj = db.get(models.TestCycle, cycle_id)
    if not obj:
        raise HTTPException(404, "Test Cycle not found")
    return obj


def _cycle_request_link_identity(link) -> tuple[str | None, int | None]:
    if link is None:
        return None, None
    return link.child_type, link.child_id


def _lock_cycle_update_scope(
    db: Session,
    cycle_id: int,
    *,
    proposed_functional_request_id: int | None = None,
) -> tuple[models.TestCycle, dict[int, models.FunctionalRequest]]:
    """Lock a cycle update in Functional-parent-before-cycle order.

    Retest and governed unlink already use ``FunctionalRequest -> TestCycle``
    as their global lock order. A generic PATCH must use the same order while
    also protecting the old association row; otherwise it can read an old
    link, wait behind Start Execution, and then detach/repoint that now-active
    request from a stale snapshot.

    The initial link read is only discovery. After all discovered Functional
    parents are locked in stable ID order, the cycle and its association row
    are locked and the identity is revalidated. A concurrent relink therefore
    fails with a refresh-required conflict instead of mutating the wrong
    request.
    """
    preview = _get_cycle_or_404(db, cycle_id)
    preview_link = db.query(models.TestCycleChildRequestLink).filter_by(
        cycle_id=cycle_id,
    ).one_or_none()
    observed_identity = _cycle_request_link_identity(preview_link)

    request_ids: set[int] = set()
    if observed_identity[0] == "Functional" and observed_identity[1] is not None:
        request_ids.add(observed_identity[1])
    if proposed_functional_request_id is not None:
        request_ids.add(proposed_functional_request_id)

    locked_requests: dict[int, models.FunctionalRequest] = {}
    if request_ids:
        rows = (
            db.query(models.FunctionalRequest)
            .filter(models.FunctionalRequest.id.in_(sorted(request_ids)))
            .order_by(models.FunctionalRequest.id)
            .populate_existing()
            .with_for_update()
            .all()
        )
        locked_requests = {row.id: row for row in rows}

    cycle = (
        db.query(models.TestCycle)
        .filter(models.TestCycle.id == cycle_id)
        .populate_existing()
        .with_for_update()
        .one_or_none()
    )
    if cycle is None:
        raise HTTPException(404, "Test Cycle not found")
    locked_link = (
        db.query(models.TestCycleChildRequestLink)
        .filter(models.TestCycleChildRequestLink.cycle_id == cycle_id)
        .populate_existing()
        .with_for_update()
        .one_or_none()
    )
    if _cycle_request_link_identity(locked_link) != observed_identity:
        raise HTTPException(
            409,
            "The Test Cycle request link changed concurrently; refresh before saving",
        )

    # The preview and locked query resolve to the same identity-mapped object.
    # Expire the relationship explicitly so every later guard observes the
    # association row that was just locked/revalidated, not a cached preview.
    db.expire(cycle, ["child_request_link"])
    cycle.child_request_link  # reload while the association lock is held
    return cycle, locked_requests


def _require_cycle_visibility(
    db: Session, cycle: models.TestCycle, current_user: models.User,
) -> None:
    """Apply both project and optional folder visibility to every cycle route.

    Cycle-folder grants are restrictive, so checking only the project leaves
    every child URL (executions, exports, runs, and evidence) as a direct-ID
    bypass.  Keep the two checks together so new cycle child routes have one
    canonical guard to call.
    """
    require_project_visibility(db, cycle.project_id, current_user)
    folder_id = getattr(cycle, "folder_id", None)
    if folder_id:
        folder = getattr(cycle, "folder", None) or _get_cycle_folder_or_404(db, folder_id)
        require_can_view_cycle_folder(folder, current_user)


def _require_execution_visibility(
    db: Session, execution: models.TestExecution, current_user: models.User,
) -> models.TestCycle:
    cycle = getattr(execution, "cycle", None) or _get_cycle_or_404(db, execution.cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    return cycle


def _require_cycle_request_link_change_allowed(
    db: Session,
    link,
    *,
    locked_functional_request: models.FunctionalRequest | None = None,
) -> None:
    """Protect a Functional execution link regardless of which UI changes it."""
    if not link or link.child_type != "Functional":
        return
    functional_request = locked_functional_request or db.get(
        models.FunctionalRequest, link.child_id,
    )
    if locked_functional_request is not None and locked_functional_request.id != link.child_id:
        raise HTTPException(
            409,
            "The Test Cycle request link changed concurrently; refresh before saving",
        )
    if functional_request:
        require_cycle_unlinkable(functional_request.status)


def _is_qa_lead_group_member(current_user: models.User) -> bool:
    """Apply the QA Lead Group hierarchy without a generic Admin bypass.

    Chief Manager QA and AGM QA inherit QA Lead authority, matching the
    established QA Lead Group used throughout Test Management.
    """
    return bool({Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA} & set(current_user.roles))


def _signed_certificate_cycle_ids(
    certificate: models.QASignOff,
) -> Optional[set[int]]:
    """Return the signed cycle boundary, or ``None`` when it is unknowable."""
    snapshot = certificate.certificate_summary
    if not isinstance(snapshot, dict) or not snapshot:
        return None
    protected_ids: set[int] = set()
    has_cycle_boundary = False
    for field in ("cycle_ids", "defect_scope_cycle_ids"):
        values = snapshot.get(field)
        if values is None:
            continue
        if not isinstance(values, list):
            return None
        has_cycle_boundary = True
        for value in values:
            try:
                protected_ids.add(int(value))
            except (TypeError, ValueError):
                return None
    if not has_cycle_boundary or not protected_ids:
        return None
    return protected_ids


def _certificate_protects_cycle(
    certificate: models.QASignOff,
    cycle_id: int,
) -> bool:
    """Whether signed immutable evidence names (or may name) this cycle.

    Draft/pending/returned certificates are deliberately never passed here:
    their snapshots will be refreshed and reapproved after a governed unlink.
    A signed legacy row without a usable snapshot fails closed because the
    affected evidence boundary cannot be proven safely.
    """
    protected_ids = _signed_certificate_cycle_ids(certificate)
    return protected_ids is None or cycle_id in protected_ids


def _is_governed_hold_retest(
    functional_request: models.FunctionalRequest,
    certificate: models.QASignOff,
    cycle: models.TestCycle,
) -> bool:
    """Identify the post-hold child that cannot be part of the frozen snapshot."""
    return bool(
        cycle.reexecution_of_cycle_id is not None
        and functional_request.status in {
            QAStatus.EXECUTION_IN_PROGRESS,
            QAStatus.DEFECT_RAISED,
            QAStatus.WAITING_FOR_FIX,
            QAStatus.RETESTING,
        }
        and functional_request.signoff_id == certificate.id
        and certificate.status == "ISSUED_UNDER_REVIEW"
    )


def _signed_certificate_blocks_unlink(
    functional_request: models.FunctionalRequest,
    certificate: models.QASignOff,
    cycle: models.TestCycle,
) -> bool:
    protected_ids = _signed_certificate_cycle_ids(certificate)
    if protected_ids is None and _is_governed_hold_retest(
        functional_request, certificate, cycle,
    ):
        return False
    return protected_ids is None or cycle.id in protected_ids


def _qa_lead_unlink_blocker(
    db: Session,
    functional_request: models.FunctionalRequest,
    cycle: models.TestCycle,
) -> Optional[str]:
    """Return the governance boundary that makes break-glass unlink unsafe."""
    if functional_request.status in _QA_LEAD_UNLINK_PROTECTED_REQUEST_STATUSES:
        return (
            f"Functional Request {functional_request.request_id} is already in "
            f"{functional_request.status}. Its execution trace cannot be detached after QA sign-off."
        )
    certificates = (
        db.query(models.QASignOff)
        .filter(
            models.QASignOff.testing_request_id == functional_request.request_id,
            models.QASignOff.status.in_(_QA_LEAD_UNLINK_PROTECTED_CERTIFICATE_STATUSES),
        )
        .order_by(models.QASignOff.id.desc())
        .all()
    )
    for certificate in certificates:
        # A Retest child was created only after this certificate entered its
        # immutable hold, so an old snapshot with no cycle-boundary fields
        # cannot contain that child. This narrow exception permits correcting
        # the newly selected child while legacy baseline cycles still fail
        # closed. Explicit inclusion always remains protected.
        if _signed_certificate_blocks_unlink(functional_request, certificate, cycle):
            return (
                f"QA Clearance Certificate {certificate.certificate_id} is {certificate.status} "
                "and its immutable signed evidence includes this Test Cycle. "
                "Create or continue a governed re-execution lineage instead of detaching it."
            )
    return None


def _reexecution_cycles_with_recorded_work(
    db: Session,
    cycle_ids: list[int],
) -> set[int]:
    """Batch-resolve re-execution children that contain any evidence."""
    result: set[int] = set()
    for batch in _in_batches(list(dict.fromkeys(cycle_ids))):
        result.update(cycle_id for (cycle_id,) in db.query(
            models.TestExecution.cycle_id,
        ).filter(
            models.TestExecution.cycle_id.in_(batch),
            or_(
                models.TestExecution.status.is_(None),
                models.TestExecution.status != "Not Executed",
                models.TestExecution.run_version.is_(None),
                models.TestExecution.run_version != 0,
                models.TestExecution.actual_result.isnot(None),
                models.TestExecution.test_run_artifacts.isnot(None),
                models.TestExecution.defect_id.isnot(None),
                models.TestExecution.executed_by_id.isnot(None),
                models.TestExecution.executed_at.isnot(None),
            ),
        ).distinct().all())
        result.update(cycle_id for (cycle_id,) in db.query(
            models.TestExecution.cycle_id,
        ).join(
            models.TestExecutionRun,
            models.TestExecutionRun.execution_id == models.TestExecution.id,
        ).filter(models.TestExecution.cycle_id.in_(batch)).distinct().all())
        # Defensive fail-closed boundary: normal UI flows cannot attach a
        # defect to an untouched slot, but imported/legacy data can. Cover
        # direct cycle ownership, primary execution ownership, and the
        # many-to-many additional-execution link.
        result.update(cycle_id for (cycle_id,) in db.query(
            models.Defect.cycle_id,
        ).filter(models.Defect.cycle_id.in_(batch)).distinct().all() if cycle_id is not None)
        result.update(cycle_id for (cycle_id,) in db.query(
            models.TestExecution.cycle_id,
        ).join(
            models.Defect,
            models.Defect.execution_id == models.TestExecution.id,
        ).filter(models.TestExecution.cycle_id.in_(batch)).distinct().all())
        result.update(cycle_id for (cycle_id,) in db.query(
            models.TestExecution.cycle_id,
        ).join(
            models.DefectExecutionLink,
            models.DefectExecutionLink.execution_id == models.TestExecution.id,
        ).filter(models.TestExecution.cycle_id.in_(batch)).distinct().all())
    return result


def _reexecution_cycle_has_recorded_work(db: Session, cycle_id: int) -> bool:
    return cycle_id in _reexecution_cycles_with_recorded_work(db, [cycle_id])


def _attach_request_link_permissions(
    db: Session, cycles, current_user: models.User,
) -> None:
    """Expose normal and executive link permissions without per-cycle queries."""
    functional_ids = {
        cycle.child_request_link.child_id
        for cycle in cycles
        if cycle.child_request_link and cycle.child_request_link.child_type == "Functional"
    }
    requests = {
        row.id: row
        for row in db.query(models.FunctionalRequest)
        .filter(models.FunctionalRequest.id.in_(functional_ids))
        .all()
    } if functional_ids else {}
    signed_certificates_by_request: dict[str, list[models.QASignOff]] = {}
    reexecution_work_cycle_ids = _reexecution_cycles_with_recorded_work(
        db,
        [cycle.id for cycle in cycles if cycle.reexecution_of_cycle_id is not None],
    )
    if requests and _is_qa_lead_group_member(current_user):
        request_keys = [request.request_id for request in requests.values() if request.request_id]
        signed_certificates = db.query(models.QASignOff).filter(
                models.QASignOff.testing_request_id.in_(request_keys),
                models.QASignOff.status.in_(_QA_LEAD_UNLINK_PROTECTED_CERTIFICATE_STATUSES),
            ).all() if request_keys else []
        for certificate in signed_certificates:
            signed_certificates_by_request.setdefault(
                certificate.testing_request_id, [],
            ).append(certificate)
    for cycle in cycles:
        link = cycle.child_request_link
        if not link:
            allowed = False
        elif link.child_type != "Functional" or link.child_id not in requests:
            allowed = True
        else:
            allowed = cycle_unlink_allowed(requests[link.child_id].status)
        cycle.linked_request_change_allowed = allowed
        request = requests.get(link.child_id) if link and link.child_type == "Functional" else None
        cycle.linked_request_status = request.status if request else None
        signed_cycle_protected = bool(request and any(
            _signed_certificate_blocks_unlink(request, certificate, cycle)
            for certificate in signed_certificates_by_request.get(request.request_id, [])
        ))
        cycle.linked_request_qa_lead_unlink_allowed = bool(
            request
            and not allowed
            and _is_qa_lead_group_member(current_user)
            and request.status not in _QA_LEAD_UNLINK_PROTECTED_REQUEST_STATUSES
            and not signed_cycle_protected
            and cycle.id not in reexecution_work_cycle_ids
        )


def _get_cycle_folder_or_404(db: Session, folder_id: int) -> models.TestCycleFolder:
    obj = db.get(models.TestCycleFolder, folder_id)
    if not obj:
        raise HTTPException(404, "Test Cycle Folder not found")
    return obj


def _require_active_project(db: Session, project_id: int) -> None:
    project = _get_project_or_404(db, project_id)
    if not project.is_active:
        raise HTTPException(400, "This Test Project is inactive. Reactivate it before changing test execution data")


def _require_open_cycle(cycle: models.TestCycle) -> None:
    """Blocked freezes operations; Completed permanently freezes the cycle."""
    if cycle.status in TEST_CYCLE_LOCKED_STATUSES:
        detail = (
            "This Test Cycle is Blocked. Resume Execution before making any changes."
            if cycle.status == "Blocked"
            else "This Test Cycle is Completed and read-only. No further changes are allowed."
        )
        raise HTTPException(
            400,
            detail,
        )


_ALLOWED_CYCLE_TRANSITIONS = {
    "Draft": {"Ready"},
    "Ready": {"In Progress"},
    "In Progress": {"Blocked", "Completed"},
    "Blocked": {"In Progress"},
    "Completed": set(),
}
_CYCLE_TRANSITION_ACTIONS = {
    ("Draft", "Ready"): "Mark as Ready",
    ("Ready", "In Progress"): "Start Execution",
    ("In Progress", "Blocked"): "Block Execution",
    ("Blocked", "In Progress"): "Resume Execution",
    ("In Progress", "Completed"): "Complete Execution",
}


def _sync_linked_functional_request_status(db: Session, cycle: "models.TestCycle",
                                             transition_action: str,
                                             current_user: "models.User") -> None:
    """2026-08 -- reported directly: "If test lifecycle is Blocked, then
    automatically mark linked QA request WAITING_FOR_FIX" and "again
    lifecycle marked as In Progress then linked qa request again marked as
    EXECUTION_IN_PROGRESS." Only wired for a Functional child link -- SAST/
    DAST/Performance don't share this status vocabulary (Performance's own
    lifecycle has no Blocked-equivalent Execution/Waiting-For-Fix pair --
    see PERFORMANCE_STATUSES, which lumps that concern into a single
    DEFECT_FIX_RETEST status -- so it's deliberately left untouched pending
    its own design decision if this is ever extended there).

    Guarded so this only ever restores execution from WAITING_FOR_FIX or the
    legacy RETESTING recovery state -- it will never clobber a manually-
    reached state like QA_COMPLETED, or a DEFECT_RAISED still awaiting a
    human decision on the (unlinked-cycle) manual defect flow.

    A Functional request may have several linked Test Cycles at once (see
    FunctionalRequest.linked_test_cycles / complete_qa's own "every linked
    cycle must be Completed" gate) -- Resume Execution only restores
    EXECUTION_IN_PROGRESS once none of the request's OTHER linked cycles are
    still Blocked, so one cycle resuming doesn't prematurely unblock a
    request that's still genuinely stuck on a different cycle."""
    link = cycle.child_request_link
    if not link or link.child_type != "Functional":
        return
    freq = db.get(models.FunctionalRequest, link.child_id)
    if not freq:
        return
    if transition_action == "Block Execution":
        if freq.status == QAStatus.EXECUTION_IN_PROGRESS:
            freq.status = QAStatus.WAITING_FOR_FIX
            db.add(models.ApprovalAction(
                entity_type="FUNCTIONAL_REQUEST", entity_id=freq.id, step_name="Execution In Progress",
                actor_id=current_user.id, actor_role=current_user.roles_csv,
                decision="Waiting For Fix (Test Cycle Blocked)",
                comments=f"Auto-set: linked Test Cycle {cycle.cycle_key} - {cycle.name} was marked Blocked.",
            ))
    elif transition_action == "Resume Execution":
        if freq.status in (QAStatus.WAITING_FOR_FIX, QAStatus.RETESTING):
            still_blocked = any(
                other.status == "Blocked" for other in freq.linked_test_cycles if other.id != cycle.id
            )
            if not still_blocked:
                previous_request_status = freq.status
                freq.status = QAStatus.EXECUTION_IN_PROGRESS
                previous_step = (
                    "Waiting For Fix"
                    if previous_request_status == QAStatus.WAITING_FOR_FIX
                    else "Retesting"
                )
                db.add(models.ApprovalAction(
                    entity_type="FUNCTIONAL_REQUEST", entity_id=freq.id, step_name=previous_step,
                    actor_id=current_user.id, actor_role=current_user.roles_csv,
                    decision="Execution In Progress (Test Cycle Resumed)",
                    comments=(
                        f"Auto-set from {previous_step}: linked Test Cycle {cycle.cycle_key} - "
                        f"{cycle.name} resumed to In Progress."
                    ),
                ))


def _validate_cycle_transition(current_status: str, requested_status: str,
                               blocking_reason: str) -> str:
    if requested_status not in _ALLOWED_CYCLE_TRANSITIONS.get(current_status, set()):
        raise HTTPException(
            400,
            "Invalid status transition. The Test Cycle cannot be changed from "
            f"{current_status} to {requested_status}.",
        )
    if requested_status == "Blocked" and not blocking_reason:
        raise HTTPException(400, "A blocking reason is required before blocking this Test Cycle")
    return _CYCLE_TRANSITION_ACTIONS[(current_status, requested_status)]


def _require_completion_link_status(
    cycle: models.TestCycle,
    locked_functional_requests: dict[int, models.FunctionalRequest],
) -> None:
    """Validate the cycle's locked request association for completion.

    The persisted data model permits at most one request per cycle because
    ``TestCycleChildRequestLink.cycle_id`` is unique. Combined link mutations
    and completion are rejected by ``update_cycle`` before this helper, so
    the one existing association is the complete authoritative scope.
    """
    link = cycle.child_request_link
    if link is None:
        return
    if link.child_type != "Functional":
        raise HTTPException(
            400,
            "Cannot complete this Test Cycle while it has an unsupported QA Request link. "
            "Replace or remove the invalid link first.",
        )
    request = locked_functional_requests.get(link.child_id)
    if request is None:
        raise HTTPException(
            409,
            "The linked Functional QA Request no longer exists. Refresh and correct the "
            "Test Cycle link before completing it.",
        )
    require_request_cycle_completable(request)


def _require_cycle_in_progress(cycle: models.TestCycle) -> None:
    if cycle.status != "In Progress":
        raise HTTPException(
            400,
            f"Test execution is unavailable while the Test Cycle is {cycle.status}. "
            "Use the permitted lifecycle action to move it to In Progress first.",
        )


_CYCLE_ITEM_NOT_READY_STATUSES = ("Draft", "In Review", "Review Completed", "Returned", "Rejected", "Archived")


def _require_execution_context(environment, build):
    if not (environment or '').strip() or not (build or '').strip():
        raise HTTPException(400, "Set the Test Cycle environment and build in Edit Cycle before starting or recording execution. Enter the actual tested build; blank does not mean NA.")


def _validate_cycle_ready(db: Session, cycle: models.TestCycle, start_date, end_date) -> None:
    """Validate that a cycle has a usable execution scope before it becomes
    Ready. Tester assignment is intentionally not a readiness prerequisite:
    assignments can be completed while the cycle is Ready, but each testcase
    still needs an eligible runner before an execution result can be recorded.
    Called only on a transition INTO "Ready" (see update_cycle below), not on
    every save, so a cycle can otherwise be edited freely while still being
    assembled. Item statuses are re-checked against each execution's PINNED
    version specifically (not just "was Approved when added") --
    add-to-cycle already only accepts an Approved version (CYC-003/004),
    but archiving a testcase after it was pinned retroactively changes that
    exact version's own status to Archived (see archive_test_case), so this
    is a genuine, not-redundant safety net at Ready time."""
    executions = cycle.executions
    if not executions:
        raise HTTPException(400, "A cycle needs at least one test case before it can become Ready")
    if not start_date or not end_date:
        raise HTTPException(400, "Both a start date and an end date are required before the cycle can become Ready")
    if start_date > end_date:
        raise HTTPException(400, "Start date cannot be after end date")
    link = cycle.child_request_link
    if link:
        if link.child_type != "Functional":
            raise HTTPException(400, "Only Functional QA Requests can be linked to Test Cycles")
        linked_request = db.get(models.FunctionalRequest, link.child_id)
        if not linked_request or not linked_request.request_id:
            raise HTTPException(400, "This cycle's Functional QA Request is no longer valid. Replace or remove the link before continuing")
        request_workspace_id = linked_request.qa_request.qa_workspace_id if linked_request.qa_request else None
        if (cycle.origin_workspace_id or cycle.project.qa_workspace_id) != request_workspace_id:
            raise HTTPException(
                400,
                "The Test Cycle and Functional QA Request must belong to the same workspace",
            )
    not_ready_items = [
        e.test_case.test_case_key for e in executions
        if e.pinned_version and e.pinned_version.status in _CYCLE_ITEM_NOT_READY_STATUSES and e.test_case
    ]
    if not_ready_items:
        preview = ", ".join(not_ready_items[:5])
        suffix = "…" if len(not_ready_items) > 5 else ""
        raise HTTPException(
            400,
            f"{len(not_ready_items)} test case(s) in this cycle are no longer Approved/Active "
            f"(likely archived since being added) and must be removed or replaced first: {preview}{suffix}",
        )


_SCOPE_EXPANSION_REASON_MIN_LENGTH = 10


def _cycle_has_recorded_attempts(db: Session, cycle_id: int) -> bool:
    """Whether the cycle has authoritative, retained execution history.

    TestExecutionRun is the immutable attempt ledger. The helper also gives
    legacy/inconsistent data a fail-closed fallback when a run exists before
    the lifecycle status was corrected to In Progress.
    """
    return db.query(models.TestExecutionRun.id).join(
        models.TestExecution, models.TestExecutionRun.execution_id == models.TestExecution.id,
    ).filter(models.TestExecution.cycle_id == cycle_id).first() is not None


def _scope_expansion_reason(db: Session, cycle: models.TestCycle, reason: Optional[str]) -> Optional[str]:
    """Require and normalize the audit reason for a post-start addition.

    Adding a new approved testcase does not alter any existing attempt, so
    every QA execution role that can already contribute to the project may
    expand an open cycle. Once execution has started, however, the expansion
    must be explicit and explainable in the cycle audit trail. Removal keeps
    its separate, stricter evidence-protection rules below.
    """
    # "In Progress" is the governed start boundary, even before the first
    # runner saves a result. Using the lifecycle boundary and locking the
    # cycle in add_test_cases_to_cycle closes the race where Start Execution
    # and the first scope expansion could otherwise cross in flight.
    if cycle.status != "In Progress" and not _cycle_has_recorded_attempts(db, cycle.id):
        return None
    normalized = (reason or "").strip()
    if len(normalized) < _SCOPE_EXPANSION_REASON_MIN_LENGTH:
        raise HTTPException(
            400,
            "Execution has already started. Provide a scope expansion reason of at least "
            f"{_SCOPE_EXPANSION_REASON_MIN_LENGTH} characters before adding more testcases.",
        )
    return normalized


# 2026-08 -- reported directly: "'Remove from cycle' should be available
# only for QA lead, also once execution history created then remove from
# cycle should not be enable for everyone. Same for Test Cycle, once
# execution history created then remove option should not be there for QA
# lead. Administration can supersede everything." Refined with Scenario 1
# (also reported directly): "tester add testcase in lifecycle, but not
# executed it, just added ... might be by mistake ... now system should
# allow to remove from lifecycle as there are no test execution history."
# Resolution (confirmed directly): whoever ADDED a testcase to a cycle may
# remove their OWN addition themselves, but only while it still has zero
# execution history -- self-correcting a same-person, zero-consequence
# mistake, without needing a QA Lead. Full rule, in priority order:
#   1. Admin always may (has_role's standing ADMIN short-circuit).
#   2. Any recorded attempt on THIS slot -- QA Lead Group and the original
#      adder both lose the ability; Admin only. Deliberately per-execution,
#      not cycle-wide like _require_scope_change_permission above, since
#      removal targets one slot at a time and other still-untouched slots in
#      the same cycle should stay removable.
#   3. No recorded attempt yet -- QA Lead Group may always remove (any
#      slot, not just their own); the ORIGINAL ADDER (TestExecution.
#      added_by_id, set once at add-to-cycle time) may remove only their own
#      addition. Anyone else (a different QA_ENGINEER who didn't add it) is
#      still blocked.
# Router-level require_roles widened back to include QA_ENGINEER (was
# QA_LEAD Group only) so path 3's self-remove case can even reach this
# function -- the actual gate lives here, not at the router.
def _execution_removal_block_reason(execution: models.TestExecution, current_user: models.User) -> Optional[str]:
    """None if current_user may remove this execution; otherwise the reason
    it's blocked (used both to raise a single-item 403 and to build the
    bulk-remove skip list)."""
    if current_user.has_role(Role.ADMIN):
        return None
    if execution.runs:
        return "already has recorded execution history in this cycle -- only an Administrator can remove it now"
    if current_user.has_role(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA):
        return None
    if execution.added_by_id and execution.added_by_id == current_user.id:
        return None
    return "was not added to this cycle by you -- only the QA Lead Group, an Administrator, or whoever added it can remove it before it has been executed"


def _require_can_remove_execution(execution: models.TestExecution, current_user: models.User) -> None:
    reason = _execution_removal_block_reason(execution, current_user)
    if reason:
        key = execution.test_case.test_case_key if execution.test_case else "This test case"
        raise HTTPException(403, f"{key} {reason}.")


def _execution_or_404(db: Session, execution_id: int, *, lock: bool = False) -> models.TestExecution:
    query = db.query(models.TestExecution).filter_by(id=execution_id)
    if lock:
        # Refresh a previously loaded identity after waiting for another worker.
        # The lock lasts through validation, attempt allocation and commit.
        query = query.populate_existing().with_for_update()
    obj = query.one_or_none()
    if not obj:
        raise HTTPException(404, "Execution not found")
    return obj


def _runner_or_404(db: Session, user_id: int, *, workspace_id: int | None = None, project: models.TestProject | None = None, cycle_owner: bool = False) -> models.User:
    target = db.get(models.User, user_id)
    if not target or not target.is_active:
        raise HTTPException(404, "Selected runner was not found or is inactive")
    if not target.show_in_user_dropdowns:
        raise HTTPException(400, "The selected user is hidden from assignment dropdowns")
    # A runner is an execution assignee, so require the explicit operational
    # role. QA Leads, QA executives, and Administrators may retain assignment
    # administration privileges without automatically becoming runners.
    if not (set(target.roles) & set(_EXEC_ROLES) if cycle_owner else Role.QA_ENGINEER in target.roles):
        raise HTTPException(400, "Runner must have the QA Engineer (QA) role")
    target_workspace_id = workspace_id if workspace_id is not None else current_workspace_id()
    if target_workspace_id is None or target_workspace_id not in selectable_workspace_ids(db, target):
        raise HTTPException(400, "Runner must have access to this Test Project's workspace")
    from ..workflow_authority import admin_department_allowed
    from ..workspace_service import inherited_workspace_access_mode
    if inherited_workspace_access_mode(db, target, target_workspace_id) == 'PARENT_VIEWER' or Role.VIEW_ONLY in target.roles:
        raise HTTPException(400, "Runner must have execution access in the cycle's workspace")
    if project is not None and not admin_department_allowed(target, project.department):
        raise HTTPException(400, "This administrator cannot execute outside their own department")
    return target


@router.get("/projects/{project_id}/cycle-owner-candidates", response_model=List[schemas.UserOption])
def cycle_owner_candidates(project_id: int, cycle_id: int | None = None,
                           db: Session = Depends(get_db),
                           current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    project = _get_project_or_404(db, project_id)
    require_can_execute_project(db, project_id, current_user)
    workspace_id = current_workspace_id() or project.qa_workspace_id
    if cycle_id is not None:
        cycle = _get_cycle_or_404(db, cycle_id)
        if cycle.project_id != project_id:
            raise HTTPException(400, "Cycle does not belong to this project")
        _require_cycle_visibility(db, cycle, current_user)
        workspace_id = cycle.origin_workspace_id or project.qa_workspace_id
    eligible = []
    for candidate in db.query(models.User).filter(models.User.is_active == True).order_by(models.User.full_name).all():
        try:
            _runner_or_404(db, candidate.id, workspace_id=workspace_id, project=project, cycle_owner=True)
            eligible.append(candidate)
        except HTTPException:
            continue
    return eligible


def _require_qa_assignment_manager(current_user: models.User) -> None:
    """Assignment is available to the whole Test Management execution team.

    require_roles(*_EXEC_ROLES) checks both the QA permission profile and
    membership in the selected workspace.
    """
    if current_user.has_role(Role.ADMIN):
        return
    if not current_user.has_qa_workspace_role(*_EXEC_ROLES, workspace_id=current_workspace_id()):
        raise HTTPException(403, "Only QA members of the active workspace can assign testcase runners")


def _validate_result_evidence(files: List[UploadFile]) -> None:
    """Validate inline screenshots and general execution attachments together."""
    if not files:
        return
    validate_document_uploads(files)
    images = [upload for upload in files if (upload.content_type or "").lower() in _RESULT_IMAGE_TYPES]
    if len(images) > _RESULT_IMAGE_LIMIT:
        raise HTTPException(400, f"Actual Result can contain at most {_RESULT_IMAGE_LIMIT} new images per save")
    for image in images:
        image.file.seek(0, os.SEEK_END)
        size = image.file.tell()
        image.file.seek(0)
        if size > _RESULT_IMAGE_MAX_BYTES:
            raise HTTPException(400, f"'{image.filename or 'pasted image'}' exceeds the 10 MB image limit")


def _require_assigned_runner(obj: models.TestExecution, current_user: models.User) -> None:
    if current_user.has_role(Role.ADMIN):
        return
    if not obj.assigned_to_id:
        raise HTTPException(400, "This testcase is unassigned. A QA Engineer or QA Lead from the Test Management team must assign a runner before execution")
    if obj.assigned_to_id != current_user.id:
        raise HTTPException(
            403,
            f"This testcase is assigned to {obj.assigned_to_name or 'another runner'}. "
            "Ask a QA Engineer or QA Lead from the Test Management team to reassign it before recording an attempt.",
        )


# Governed statuses (defects.py) that no longer represent unresolved
# development work. A rejected report is a disposition, not an outstanding
# fix, so it releases the linked execution just like Duplicate/Not a Defect.
# "Not a Defect Review" remains active and blocks further
# execution; final "Not a Defect" is included only because the revised flow
# requires an independent QA reviewer to confirm that outcome first. A
# Duplicate delegates remediation to its canonical defect, so the duplicate
# record itself must not keep every execution/testcase linked to it locked.
# The canonical defect still blocks any execution to which it is itself
# linked while that canonical record remains active.
_DEFECT_RETEST_CLEAR_STATUSES = (
    "Deferred", "Closed", "Rejected", "Duplicate", "Not a Defect", "Change Request Raised",
)

_EXTERNAL_DEFECT_RETEST_CLEAR_STATUSES = {'RESOLVED', 'CLOSED'}


def _active_external_defects(db: Session, execution_id: int):
    links = db.query(models.TestRunDefect).join(models.TestExecutionRun).filter(
        models.TestExecutionRun.execution_id == execution_id,
        or_(models.TestRunDefect.defect_url.is_(None), ~models.TestRunDefect.defect_url.startswith('/defects')),
    ).all()
    return [link for link in links if (link.defect_status or 'Open').strip().upper()
            not in _EXTERNAL_DEFECT_RETEST_CLEAR_STATUSES]
# These dispositions do not represent a delivered fix and therefore do not
# need environment verification, including for modern workflows.
# ``Closed`` is deliberately absent: a modern Closed defect clears only when
# its verification covers this execution's environment. Recorded build values
# are retained for traceability but never partition verification coverage.
_DEFECT_UNCONDITIONAL_CLEAR_STATUSES = (
    "Deferred", "Rejected", "Duplicate", "Not a Defect", "Change Request Raised",
)
# A modern Closed defect normally represents a delivered fix and therefore
# remains locked until verification covers the execution environment. Risk
# acceptance is different: it is an authorized terminal disposition and has
# no fix to verify, so keeping the testcase locked would make that workflow
# impossible to finish.
_DEFECT_UNCONDITIONAL_CLEAR_RESOLUTIONS = ("Accepted Risk",)
_DEFECT_CYCLE_COMPLETION_BLOCKING_STATUSES = (
    "New", "Triaged", "Assigned", "In Progress", "Resolved", "Retest", "Reopened",
    "Not a Defect Review",
    "Ready for QA", "QA Testing", "Business Acceptance", "Ready for Release", "Production Verification",
)


def _execution_lock_state(db: Session, execution_id: int):
    """Returns (active_defects, has_prior_failed_or_blocked, defects) for the status gate.
    active_defects -- every governed Defect (defects.py) linked to this slot
    through its primary execution or an additional execution trace, whose
    own status is not yet Deferred/Duplicate/QA-confirmed Not a Defect/
    Change Request Raised, or a properly verified Closed status; a
    non-empty list here is what drives the full lock. The second value is True
    if any attempt ever recorded on this slot (TestExecutionRun.status) was
    'Fail' or 'Blocked'. It enables Retest Passed and drives the permanent
    'Pass'/'NA' block for the rest of this slot's history, regardless of
    whether a defect is linked right now. The mirrored current status is a
    compatibility fallback for results saved before run history existed."""
    defects = db.query(models.Defect).filter(or_(
        models.Defect.execution_id == execution_id,
        models.Defect.execution_links.any(models.DefectExecutionLink.execution_id == execution_id),
    )).all()
    from ..defect_workflow import verified_for
    execution = db.get(models.TestExecution, execution_id) if any(getattr(d, 'workflow_json', None) for d in defects) else None
    cycle = execution.cycle if execution else None
    active_defects = [d for d in defects if _defect_blocks_execution(d, cycle, verified_for)]
    has_prior_failed_or_blocked = db.query(models.TestExecutionRun.id).filter(
        models.TestExecutionRun.execution_id == execution_id,
        models.TestExecutionRun.status.in_(("Fail", "Blocked")),
    ).first() is not None
    if not has_prior_failed_or_blocked:
        legacy_status = db.query(models.TestExecution.status).filter(
            models.TestExecution.id == execution_id,
        ).scalar()
        has_prior_failed_or_blocked = legacy_status in ("Fail", "Blocked")
    return active_defects, has_prior_failed_or_blocked, defects


def _defect_blocks_execution(defect, cycle, verification_check=None) -> bool:
    """Return whether one governed defect still locks a linked execution.

    Non-remediation outcomes short-circuit before environment verification. This is
    particularly important for Duplicate: a duplicate has no fix or
    verification of its own, so ``verified_for`` can never clear it. The same
    applies to a modern Accepted Risk closure. Legacy Closed defects retain
    their historic clear behavior, while modern Fixed closures still need
    verification for the execution's environment.
    Any active canonical defect remains independently authoritative when
    linked.
    """
    if (
        defect.status in _DEFECT_UNCONDITIONAL_CLEAR_STATUSES
        or (
            defect.status == "Closed"
            and getattr(defect, "resolution_type", None)
            in _DEFECT_UNCONDITIONAL_CLEAR_RESOLUTIONS
        )
    ):
        return False
    if not getattr(defect, "workflow_json", None):
        return defect.status not in _DEFECT_RETEST_CLEAR_STATUSES
    if verification_check is None:
        from ..defect_workflow import verified_for as verification_check
    return not (
        cycle
        and verification_check(defect, cycle.environment)
    )


def _execution_status_gate(db: Session, execution_id: int, status_value: str,
                           defect_key: str = "") -> "str | None":
    """Reported directly, in two parts, in this order:

    1. "testcase already failed, and defect also linked, then why again
       allowing to marked failed" -- clarified into a full spec: while ANY
       governed Defect linked to this slot is still active (not Deferred,
       Duplicate, another terminal disposition, or verified Closed), the
       execution is completely locked -- no new attempt of any
       status (Pass/Fail/Blocked/NA/Retest Passed) may be recorded through
       any endpoint, matching the earlier-reported "keep the execution
       status as Fail... prevent status modification through the UI/APIs/
       bulk updates" requirement. There is deliberately no exception here,
       including for a fresh 'Fail' -- while a defect is open, the defect is
       what needs attention, not another execution attempt.

    2. 'Retest Passed' is never a first-attempt/general result. It requires
       at least one earlier 'Fail' or 'Blocked' attempt on the same slot.

    3. Once every linked defect clears (or none was ever linked), but this
       slot has EVER recorded a 'Fail' or 'Blocked': 'Pass' remains permanently blocked
       for the rest of this slot's history (a defect-corrected pass is
       always 'Retest Passed', never 'Pass' -- keeps "clean first try" and
       "passed after a fix" distinguishable in reporting). 'NA' is allowed
       only when a linked defect is Change Request Raised with a populated
       CR/enhancement reference. 'Retest Passed'
       and 'Blocked' are available. A fresh 'Fail' (failed again on retest)
       requires a defect_key that resolves to an existing, currently-active
       governed Defect -- reopen the existing one, link a different active
       one, or create a new one in Defect Management first, then reference
       its key here. This is deliberately NOT auto-reopened from here: doing
       so would mutate defects.py's own Defect.status state machine (and its
       audit trail) as a side effect of a Test Execution save, which is a
       bigger, riskier change than this endpoint owning -- the tester takes
       that action explicitly in Defect Management, then comes back here.

    Returns a human-readable reason, or None if nothing blocks status_value."""
    if status_value not in ("Pass", "Fail", "Blocked", "NA", "Retest Passed"):
        return None
    active_defects, has_prior_failed_or_blocked, linked_defects = _execution_lock_state(db, execution_id)
    if active_defects:
        names = ", ".join(f"{d.defect_key} ({d.status})" for d in active_defects)
        return (
            f"Linked defect verification does not cover this execution ({names}). "
            "Check the environment in Edit Cycle. A Closed workflow defect needs verification in that same "
            "environment, regardless of build number."
        )
    external_defects = _active_external_defects(db, execution_id)
    if external_defects:
        names = ', '.join(f'{link.defect_key} ({link.defect_status or "Open"})' for link in external_defects)
        return (f'External defects are still unresolved ({names}). Confirm the fix in the external tracker '
                'and update each recorded status to Resolved or Closed before retesting.')
    if status_value == "Retest Passed" and not has_prior_failed_or_blocked:
        return (
            "'Retest Passed' is available only after this testcase has a previous Failed or "
            "Blocked execution attempt."
        )
    change_request_defects = [d for d in linked_defects if d.status == "Change Request Raised"]
    if status_value == "NA" and change_request_defects:
        missing_reference = [d for d in change_request_defects if not (d.related_cr_number or "").strip()]
        if missing_reference:
            names = ", ".join(d.defect_key for d in missing_reference)
            return (
                "NA cannot be recorded because the linked Change Request Raised defect(s) "
                f"do not have a CR/enhancement reference: {names}. Update the defect decision first."
            )
        return None
    if not has_prior_failed_or_blocked:
        return None
    if status_value in ("Pass", "NA"):
        return (
            f"this test case failed or was blocked earlier in its history -- '{status_value}' is no longer available. "
            "Select 'Retest Passed' after a delivered fix, or 'NA' only when the finding was converted to a "
            "Change Request Raised defect with a valid CR reference."
        )
    if status_value == "Fail":
        if not defect_key:
            return (
                "this test case is failing again after a resolved defect -- reopen the existing defect, "
                "link another active defect, or create a new defect in Defect Management, then reference "
                "its Defect Key here before recording this Fail."
            )
        governed = db.query(models.Defect).filter(models.Defect.defect_key == defect_key).first()
        if not governed:
            return (
                f"'{defect_key}' is not a known governed defect -- create it in Defect Management first, "
                "then reference its Defect Key here."
            )
        if governed.status == "Duplicate":
            canonical = getattr(governed, "duplicate_of", None)
            canonical_hint = (
                f"its canonical defect '{canonical.defect_key}'"
                if canonical else "its canonical defect"
            )
            return (
                f"defect '{defect_key}' is marked Duplicate and cannot own a repeat failure -- "
                f"reference/link {canonical_hint} if it is active (reopen the canonical defect first if needed), "
                "or link/create another active defect."
            )
        if governed.status in _DEFECT_RETEST_CLEAR_STATUSES:
            return (
                f"defect '{defect_key}' is still {governed.status} -- reopen it in Defect Management "
                "before referencing it here."
            )
    return None


def _prepare_execution_update(db: Session, obj: models.TestExecution, status_value: str,
                              current_user: models.User, defect_key: str = "") -> models.TestCycle:
    _execution_or_404(db, obj.id, lock=True)
    cycle = _get_cycle_or_404(db, obj.cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    _require_open_cycle(cycle)
    _require_cycle_in_progress(cycle)
    _require_execution_context(cycle.environment, cycle.build)
    # SRS CYC-004/CYC-006 -- this slot is pinned to the exact TestCaseVersion
    # that was Approved when it was added (or last explicitly upgraded), and
    # stays executable even if the live testcase later moves into a new
    # Draft revision. Only a slot that was somehow never pinned at all
    # (shouldn't happen post add_test_cases_to_cycle, but defensive) is
    # blocked.
    if not obj.pinned_version_id:
        raise HTTPException(400, "This testcase slot has no pinned approved version and cannot be executed")
    from ..constants import TEST_EXECUTION_STATUSES
    if status_value not in TEST_EXECUTION_STATUSES:
        raise HTTPException(400, f"Invalid execution status '{status_value}'")
    violation = _execution_status_gate(db, obj.id, status_value, defect_key)
    if violation:
        raise HTTPException(400, f"Cannot record '{status_value}': {violation}")
    _require_assigned_runner(obj, current_user)
    return cycle


def _validate_defect_values(defect_key: str, defect_url: str = "") -> tuple[str, str]:
    key = defect_key.strip()
    url = defect_url.strip()
    if len(key) > 100:
        raise HTTPException(400, "Defect key cannot exceed 100 characters")
    if len(url) > 500:
        raise HTTPException(400, "Defect URL cannot exceed 500 characters")
    if url:
        parsed = urlparse(url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise HTTPException(400, "Defect URL must be a complete http:// or https:// link")
    return key, url


def _link_defect(db: Session, run: models.TestExecutionRun, payload: schemas.TestRunDefectCreate,
                 current_user: models.User) -> models.TestRunDefect:
    key, url = _validate_defect_values(payload.defect_key, payload.defect_url or "")
    if not key:
        raise HTTPException(400, "Defect key is required")
    if len((payload.title or "").strip()) > 255:
        raise HTTPException(400, "Defect title cannot exceed 255 characters")
    if len((payload.defect_status or "").strip()) > 40:
        raise HTTPException(400, "Defect status cannot exceed 40 characters")
    if len((payload.notes or "").strip()) > 5000:
        raise HTTPException(400, "Defect notes cannot exceed 5,000 characters")
    # One row per key, with all distinct defects retained on the same attempt.
    # Include pending rows because production sessions use autoflush=False.
    existing = next((link for link in db.new if isinstance(link, models.TestRunDefect)
                     and link.run_id == run.id and link.defect_key == key), None)
    if existing is None:
        existing = db.query(models.TestRunDefect).filter_by(run_id=run.id, defect_key=key).first()
    if existing:
        raise HTTPException(409, f"Defect '{key}' is already linked to this attempt")
    defect = models.TestRunDefect(
        run_id=run.id,
        defect_key=key,
        defect_url=url or None,
        title=(payload.title or "").strip() or None,
        defect_status=(payload.defect_status or "").strip() or None,
        notes=(payload.notes or "").strip() or None,
        linked_by_id=current_user.id,
    )
    db.add(defect)
    db.add(models.ApprovalAction(
        entity_type="TEST_CASE", entity_id=run.execution.test_case_id,
        step_name=f"Attempt #{run.attempt_no} Defect",
        actor_id=current_user.id, actor_role=current_user.roles_csv,
        decision="Defect Linked", comments=f"Linked defect {key} to execution #{run.execution_id}, attempt #{run.attempt_no}.",
    ))
    return defect


def _migrate_legacy_result_if_needed(db: Session, obj: models.TestExecution) -> None:
    """One-time, lazy migration for a row saved before per-attempt history
    existed. Before this feature shipped, a TestExecution could only ever
    hold a single result, overwritten in place on every run -- so whatever
    is on it right now (if it was ever actually run at all) IS the one and
    only attempt that existed. The first time a *new* attempt is recorded
    after upgrading, preserve that prior result as Run #1 -- including
    re-pointing its already-uploaded evidence images onto the new row --
    before it gets overwritten with the new attempt's result. A no-op once
    this has run once (or for a row that's never been executed, or that
    already has real attempt history)."""
    if obj.status == "Not Executed":
        return
    if db.query(models.TestExecutionRun).filter_by(execution_id=obj.id).first():
        return
    legacy_run = models.TestExecutionRun(
        execution_id=obj.id, attempt_no=1, status=obj.status,
        actual_result=obj.actual_result, test_run_artifacts=obj.test_run_artifacts,
        defect_id=obj.defect_id, executed_by_id=obj.executed_by_id,
        executed_at=obj.executed_at or obj.created_at,
    )
    db.add(legacy_run)
    db.flush()
    # RequestDocument's (module, request_id) pair is a loose polymorphic
    # association, not a real FK -- so "moving" an already-uploaded image
    # from the execution row onto its new Run #1 is just updating which id
    # it's keyed under, no file move needed (folder_name on disk was never
    # derived from this id -- see documents.py::save_documents).
    db.query(models.RequestDocument).filter_by(
        module=_RESULT_IMAGE_MODULE, request_id=obj.id,
    ).update({"request_id": legacy_run.id})


def _record_attempt(db: Session, obj: models.TestExecution, status_value: str,
                     actual_result, test_run_artifacts, defect_id,
                     current_user: models.User) -> models.TestExecutionRun:
    """Records a new attempt instead of overwriting the last one -- see
    models.TestExecutionRun's own docstring for why. TestExecution's own
    columns are then updated to mirror this newest attempt, purely so every
    existing list/filter/report that reads those columns directly keeps
    working unchanged."""
    _migrate_legacy_result_if_needed(db, obj)
    next_attempt_no = (db.query(func.max(models.TestExecutionRun.attempt_no))
                       .filter_by(execution_id=obj.id).scalar() or 0) + 1
    executed_at = models.now()
    run = models.TestExecutionRun(
        execution_id=obj.id, attempt_no=next_attempt_no, status=status_value,
        actual_result=actual_result, test_run_artifacts=test_run_artifacts,
        defect_id=defect_id, executed_by_id=current_user.id, executed_at=executed_at,
    )
    db.add(run)
    db.flush()
    obj.status = status_value
    obj.actual_result = actual_result
    obj.test_run_artifacts = test_run_artifacts
    obj.defect_id = defect_id
    obj.executed_by_id = current_user.id
    obj.executed_at = executed_at
    # SRS EXE-007 "optimistic concurrency" -- bumped on every attempt so a
    # caller that read this slot before a concurrent save (see
    # update_execution's own expected_run_version check) can detect it.
    obj.run_version = (obj.run_version or 0) + 1
    db.add(models.ApprovalAction(
        entity_type="TEST_CASE", entity_id=obj.test_case_id,
        step_name=f"Test Execution Attempt #{next_attempt_no}",
        actor_id=current_user.id, actor_role=current_user.roles_csv,
        decision="Attempt Recorded",
        comments=(
            f"{obj.test_case.test_case_key if obj.test_case else f'Testcase #{obj.test_case_id}'} "
            f"recorded as {status_value} by {current_user.full_name}."
        ),
    ))
    return run


def _run_or_404(db: Session, obj: models.TestExecution, run_id: int) -> models.TestExecutionRun:
    run = db.query(models.TestExecutionRun).filter_by(id=run_id, execution_id=obj.id).first()
    if not run:
        raise HTTPException(404, "Execution attempt not found")
    return run


def _latest_run_or_404(db: Session, obj: models.TestExecution) -> models.TestExecutionRun:
    run = (db.query(models.TestExecutionRun).filter_by(execution_id=obj.id)
           .order_by(models.TestExecutionRun.attempt_no.desc()).first())
    if not run:
        raise HTTPException(404, "This test case has not been executed yet")
    return run


# ---- Cycle Folders ----
# Reported directly: "Create Test Cycle Folder, in which I can give access
# department based or user level, same behaviour like project has. Under
# this folder create test cycle." Flat (no nesting -- see
# models.TestCycleFolder's own docstring and ORACLE_MIGRATION_2026-07.md
# section 147 for the full design decision), and deliberately RESTRICTING
# (the opposite of TestProjectViewGrant's widen-only semantics) once a
# folder has at least one access grant.
def _hidden_cycle_folder_ids(db: Session, project_id: int, current_user: models.User) -> List[int]:
    """Folder ids in this project this user cannot view (see
    deps.py::can_view_cycle_folder) -- used to exclude their cycles from the
    whole-project ("All cycles", no folder_id) list. Unfiled cycles
    (folder_id IS NULL) are never affected by this."""
    folders = (
        db.query(models.TestCycleFolder).filter_by(project_id=project_id)
        .options(selectinload(models.TestCycleFolder.access_grants))
        .all()
    )
    return [f.id for f in folders if f.access_grants and not can_view_cycle_folder(f, current_user)]


@router.get("/projects/{project_id}/cycle-folders", response_model=schemas.TestCycleFolderListOut)
def list_cycle_folders(project_id: int, db: Session = Depends(get_db),
                        current_user: models.User = Depends(get_current_user)):
    """A restricted folder this user has no access to is omitted entirely,
    not just its cycles -- a restricted folder's very existence is part of
    what it restricts, same as this app's other access boundaries fail
    closed rather than half-revealing what's hidden."""
    _get_project_or_404(db, project_id)
    require_project_visibility(db, project_id, current_user)
    all_folders = (
        db.query(models.TestCycleFolder).filter_by(project_id=project_id)
        .options(selectinload(models.TestCycleFolder.access_grants))
        .order_by(models.TestCycleFolder.name)
        .all()
    )
    visible = [f for f in all_folders if can_view_cycle_folder(f, current_user)]
    counts = dict(
        db.query(models.TestCycle.folder_id, func.count(models.TestCycle.id))
        .filter(models.TestCycle.project_id == project_id, models.TestCycle.folder_id.isnot(None))
        .group_by(models.TestCycle.folder_id).all()
    )
    for f in visible:
        f.cycle_count = counts.get(f.id, 0)
    unfiled_count = db.query(models.TestCycle).filter_by(project_id=project_id, folder_id=None).count()
    hidden_ids = [f.id for f in all_folders if f not in visible]
    total_q = db.query(models.TestCycle).filter(models.TestCycle.project_id == project_id)
    if hidden_ids:
        total_q = total_q.filter(or_(models.TestCycle.folder_id.is_(None), ~models.TestCycle.folder_id.in_(hidden_ids)))
    total = total_q.count()
    return schemas.TestCycleFolderListOut(folders=visible, unfiled_count=unfiled_count, total=total)


@router.post("/projects/{project_id}/cycle-folders", response_model=schemas.TestCycleFolderOut)
def create_cycle_folder(project_id: int, payload: schemas.TestCycleFolderCreate, db: Session = Depends(get_db),
                         current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    _require_active_project(db, project_id)
    require_can_execute_project(db, project_id, current_user)
    name = payload.name.strip()
    if not name:
        raise HTTPException(400, "Folder name cannot be blank")
    obj = models.TestCycleFolder(project_id=project_id, name=name, created_by_id=current_user.id)
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@router.patch("/cycle-folders/{folder_id}", response_model=schemas.TestCycleFolderOut)
def rename_cycle_folder(folder_id: int, payload: schemas.TestCycleFolderCreate, db: Session = Depends(get_db),
                         current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    obj = _get_cycle_folder_or_404(db, folder_id)
    require_project_visibility(db, obj.project_id, current_user)
    _require_active_project(db, obj.project_id)
    require_can_execute_project(db, obj.project_id, current_user)
    require_can_view_cycle_folder(obj, current_user)
    name = payload.name.strip()
    if not name:
        raise HTTPException(400, "Folder name cannot be blank")
    obj.name = name
    db.commit()
    db.refresh(obj)
    return obj


@router.delete("/cycle-folders/{folder_id}", status_code=204)
def delete_cycle_folder(folder_id: int, db: Session = Depends(get_db),
                         current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    """Governance-tier action, same as Test Repository's own delete_folder
    (require_can_manage_execution_governance -- QA Lead Group only; Admin
    always bypasses via has_role). Only an EMPTY folder can be deleted --
    move its cycles out first, same "never silently orphan/cascade-delete
    real content just by removing its folder" convention."""
    obj = _get_cycle_folder_or_404(db, folder_id)
    require_project_visibility(db, obj.project_id, current_user)
    require_can_view_cycle_folder(obj, current_user)
    _require_active_project(db, obj.project_id)
    require_can_manage_execution_governance(db, obj.project_id, current_user)
    has_cycles = db.query(models.TestCycle).filter_by(folder_id=folder_id).first()
    if has_cycles:
        raise HTTPException(400, "This folder still has test cycles in it -- move or delete them first")
    db.delete(obj)
    db.commit()


@router.get("/cycle-folders/{folder_id}/access", response_model=List[schemas.TestCycleFolderAccessOut])
def list_cycle_folder_access(folder_id: int, db: Session = Depends(get_db),
                              current_user: models.User = Depends(get_current_user)):
    obj = _get_cycle_folder_or_404(db, folder_id)
    require_project_visibility(db, obj.project_id, current_user)
    require_can_view_cycle_folder(obj, current_user)
    return (
        db.query(models.TestCycleFolderAccess).filter_by(folder_id=obj.id)
        .order_by(models.TestCycleFolderAccess.created_at).all()
    )


@router.post("/cycle-folders/{folder_id}/access", response_model=schemas.TestCycleFolderAccessOut)
def create_cycle_folder_access(folder_id: int, payload: schemas.TestCycleFolderAccessCreate,
                                db: Session = Depends(get_db),
                                current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    """Grants restricted access to this folder to a department or a
    specific user -- see models.TestCycleFolder's own docstring for the
    restrict-not-widen semantics. Reported directly: "practically qa
    engineer can also grant access" -- gated the same as folder creation
    itself (require_can_execute_project -- QA_ENGINEER/QA_LEAD/
    CHIEF_MANAGER_QA/AGM_QA), NOT require_can_manage_execution_governance
    (QA Lead Group only), which folder DELETION still uses -- granting/
    revoking access is treated as an ordinary authoring action on a folder
    someone with execute access already made, not a governance-tier one."""
    obj = _get_cycle_folder_or_404(db, folder_id)
    require_project_visibility(db, obj.project_id, current_user)
    require_can_view_cycle_folder(obj, current_user)
    _require_active_project(db, obj.project_id)
    require_can_execute_project(db, obj.project_id, current_user)
    department = (payload.department or "").strip() or None
    user_id = payload.user_id
    if bool(department) == bool(user_id):
        raise HTTPException(400, "Grant exactly one of a department or a user, not both and not neither.")
    if department:
        who = department
        department_row = db.query(models.Department).filter(
            models.Department.name == department,
            models.Department.is_active == True,  # noqa: E712 - Oracle boolean column
        ).first()
        if not department_row:
            raise HTTPException(400, "Select an active department from the system department list")
        existing = db.query(models.TestCycleFolderAccess).filter_by(folder_id=obj.id, department=department).first()
        if existing:
            raise HTTPException(409, f"{department} already has access to this folder")
    else:
        target_user = db.get(models.User, user_id)
        if not target_user:
            raise HTTPException(404, "User not found")
        who = target_user.full_name
        existing = db.query(models.TestCycleFolderAccess).filter_by(folder_id=obj.id, user_id=user_id).first()
        if existing:
            raise HTTPException(409, f"{who} already has access to this folder")
    grant = models.TestCycleFolderAccess(
        folder_id=obj.id, department=department, user_id=user_id, granted_by_id=current_user.id,
    )
    db.add(grant)
    try:
        db.commit()
    except IntegrityError:
        # Reported directly (vague at first -- "sometimes getting key
        # issue" on an unnamed modal): the `existing` pre-check above gives
        # a fast, friendly error in the common case, but leaves a race
        # window between two near-simultaneous grant requests for the same
        # department/user -- both pass the check, both insert, and the
        # second one's commit trips uq_qap_tcfa_folder_department/
        # uq_qap_tcfa_folder_user (ORA-00001), previously uncaught and
        # surfaced as a raw 500. Same fix shape as auth.py's own
        # concurrent-first-login handling.
        db.rollback()
        raise HTTPException(409, f"{who} already has access to this folder")
    db.refresh(grant)
    return grant


@router.delete("/cycle-folders/{folder_id}/access/{grant_id}", status_code=204)
def delete_cycle_folder_access(folder_id: int, grant_id: int, db: Session = Depends(get_db),
                                current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    """Same gate as create_cycle_folder_access above -- see that function's
    own docstring."""
    obj = _get_cycle_folder_or_404(db, folder_id)
    require_project_visibility(db, obj.project_id, current_user)
    require_can_view_cycle_folder(obj, current_user)
    _require_active_project(db, obj.project_id)
    require_can_execute_project(db, obj.project_id, current_user)
    grant = db.query(models.TestCycleFolderAccess).filter_by(id=grant_id, folder_id=obj.id).first()
    if not grant:
        raise HTTPException(404, "Access grant not found")
    db.delete(grant)
    db.commit()


# ---- Cycles ----
@router.get("/projects/{project_id}/cycles", response_model=pagination.Page[schemas.TestCycleOut])
def list_cycles(project_id: int, params: pagination.PageParams = Depends(),
                 folder_id: Optional[str] = Query(
                     None,
                     description="Filter to one folder's cycles by numeric id, the literal "
                                 "'unfiled' for folder_id IS NULL, or omitted for every cycle "
                                 "this user can see across the whole project (a restricted "
                                 "folder's cycles are excluded from that whole-project view "
                                 "unless this user has access to it -- see "
                                 "deps.py::can_view_cycle_folder).",
                 ),
                 db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    # SRS 7.2 pagination rollout (task #82) -- like Test Projects, Test
    # Cycles is a flat, already-lightweight list (TestCycleOut has no heavy
    # nested arrays) that's never browsed through the app's real paginated
    # <Table>; every screen that lists cycles uses it as a complete
    # picker/aggregation source (project cycle picker, MyExecutions'
    # per-project fan-out, reports). Wrapped in Page[T] purely for
    # API-contract consistency -- frontend consumers request
    # page_size=100 and unwrap .items rather than getting a real pager UI.
    _get_project_or_404(db, project_id)
    require_project_visibility(db, project_id, current_user)
    q = db.query(models.TestCycle).filter_by(project_id=project_id)
    if folder_id == "unfiled":
        q = q.filter(models.TestCycle.folder_id.is_(None))
    elif folder_id:
        try:
            folder_id_int = int(folder_id)
        except ValueError:
            raise HTTPException(400, "folder_id must be numeric or 'unfiled'")
        folder = _get_cycle_folder_or_404(db, folder_id_int)
        if folder.project_id != project_id:
            raise HTTPException(404, "Folder not found in this project")
        require_can_view_cycle_folder(folder, current_user)
        q = q.filter(models.TestCycle.folder_id == folder_id_int)
    else:
        hidden_ids = _hidden_cycle_folder_ids(db, project_id, current_user)
        if hidden_ids:
            q = q.filter(or_(models.TestCycle.folder_id.is_(None), ~models.TestCycle.folder_id.in_(hidden_ids)))
    q = pagination.apply_search(q, params, models.TestCycle.name, models.TestCycle.cycle_key)
    q = pagination.apply_status_filter(q, params, models.TestCycle.status)
    q = pagination.apply_sort(q, params, sortable={"name": models.TestCycle.name},
                               default_column=models.TestCycle.created_at, id_column=models.TestCycle.id)
    result = pagination.paginate(q, params)
    _attach_request_link_permissions(db, result.items, current_user)
    return pagination.to_page_response(result, params)


@router.get(
    "/projects/{project_id}/functional-request-options",
    response_model=List[schemas.LinkedRequestRef],
)
def list_functional_request_options(
    project_id: int,
    cycle_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Return Functional requests that can actually be linked to this project.

    The cycle form previously loaded only the first page of the general QA
    Request register and filtered it in the browser. Pagination and unrelated
    register filters could therefore hide valid choices. This query applies
    the same application and workspace rules enforced when the cycle is saved.
    """
    project = _get_project_or_404(db, project_id)
    require_can_execute_project(db, project.id, current_user)
    prospective_cycle_status = "Draft"
    if cycle_id is not None:
        cycle = db.query(models.TestCycle).filter_by(
            id=cycle_id, project_id=project_id,
        ).one_or_none()
        if not cycle:
            raise HTTPException(404, "Test Cycle not found in this project")
        _require_cycle_visibility(db, cycle, current_user)
        prospective_cycle_status = cycle.status
    linkable_statuses = set(CYCLE_LINKABLE_FUNCTIONAL_STATUSES)
    if prospective_cycle_status != "Completed":
        linkable_statuses.discard(QAStatus.QA_COMPLETED)
    return (
        db.query(models.FunctionalRequest)
        .join(models.QARequest, models.FunctionalRequest.qa_request_id == models.QARequest.id)
        .filter(
            models.FunctionalRequest.request_id.isnot(None),
            models.FunctionalRequest.status.in_(sorted(linkable_statuses)),
            models.QARequest.qa_workspace_id == getattr(current_user, "active_qa_workspace_id", project.qa_workspace_id),
            models.QARequest.application_master_id == project.application_master_id,
        )
        .order_by(models.FunctionalRequest.created_at.desc(), models.FunctionalRequest.id.desc())
        .all()
    )


@router.post("/projects/{project_id}/cycles", response_model=schemas.TestCycleOut)
def create_cycle(project_id: int, payload: schemas.TestCycleCreate, db: Session = Depends(get_db),
                  current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    """Create a standalone or Functional-linked Test Cycle."""
    _require_active_project(db, project_id)
    require_can_execute_project(db, project_id, current_user)
    name = payload.name.strip()
    if not name:
        raise HTTPException(400, "Cycle name cannot be blank")
    if payload.start_date > payload.end_date:
        raise HTTPException(400, "Start date cannot be after end date")
    if payload.owner_id:
        _runner_or_404(db, payload.owner_id, workspace_id=current_workspace_id(),
                       project=_get_project_or_404(db, project_id), cycle_owner=True)
    if payload.folder_id is not None:
        folder = db.query(models.TestCycleFolder).filter_by(id=payload.folder_id, project_id=project_id).first()
        if not folder:
            raise HTTPException(404, "Selected folder not found in this project")
        require_can_view_cycle_folder(folder, current_user)
    project = _get_project_or_404(db, project_id)
    linked_request = None
    if payload.linked_request_id is not None:
        linked_request = (
            db.query(models.FunctionalRequest)
            .filter(models.FunctionalRequest.id == payload.linked_request_id)
            .populate_existing()
            .with_for_update()
            .one_or_none()
        )
        if not linked_request or not linked_request.request_id:
            raise HTTPException(404, "Functional QA Request not found")
        if (project.application_master_id is not None
                and linked_request.application_master_id != project.application_master_id):
            raise HTTPException(400, "Select a Functional QA Request for this Test Project's application")
        request_workspace_id = linked_request.qa_request.qa_workspace_id if linked_request.qa_request else None
        if getattr(current_user, "active_qa_workspace_id", project.qa_workspace_id) != request_workspace_id:
            raise HTTPException(400, "The Test Cycle and Functional QA Request must belong to the same workspace")
        require_cycle_request_linkable(linked_request, "Draft")
    obj = models.TestCycle(
        project_id=project_id, name=name, description=payload.description,
        start_date=payload.start_date, end_date=payload.end_date, created_by_id=current_user.id,
        cycle_type=payload.cycle_type, environment=payload.environment,
        build=payload.build, owner_id=payload.owner_id, folder_id=payload.folder_id,
    )
    db.add(obj)
    db.flush()
    db.add(models.ApprovalAction(
        entity_type="TEST_CYCLE", entity_id=obj.id, step_name="Cycle",
        actor_id=current_user.id, actor_role=current_user.roles_csv,
        decision="Created", comments=f"Created test cycle {obj.cycle_key} - {obj.name}.",
    ))
    if obj.owner_id is not None:
        reassignment.record_assignment_change(
            db, "TEST_CYCLE", obj.id, "CYCLE_OWNER", current_user,
            [], [obj.owner_id], "Assigned during cycle creation",
        )
    if linked_request is not None:
        obj.child_request_link = models.TestCycleChildRequestLink(
            child_type="Functional", child_id=linked_request.id,
            child_key=linked_request.request_id,
        )
    db.commit()
    db.refresh(obj)
    _attach_request_link_permissions(db, [obj], current_user)
    return obj


@router.get("/cycles/{cycle_id}", response_model=schemas.TestCycleOut)
def get_cycle(cycle_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user)):
    obj = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, obj, current_user)
    _attach_request_link_permissions(db, [obj], current_user)
    return obj


@router.patch("/cycles/{cycle_id}", response_model=schemas.TestCycleOut)
def update_cycle(cycle_id: int, payload: schemas.TestCycleUpdate, db: Session = Depends(get_db),
                  current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    """Edit cycle metadata and enforce the controlled five-state lifecycle."""
    data = payload.model_dump(exclude_unset=True)
    # Authorize against a read-only preview before taking workflow locks, then
    # acquire the Functional parent(s), Test Cycle and link row in the same
    # order as Retest/governed unlink. The checks are repeated on the locked
    # cycle so a concurrent metadata move cannot widen access.
    preview = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, preview, current_user)
    _require_active_project(db, preview.project_id)
    require_can_execute_project(db, preview.project_id, current_user)
    link_changed = "linked_request_type" in data or "linked_request_id" in data
    proposed_functional_request_id = data.get("linked_request_id") if link_changed else None
    obj, locked_functional_requests = _lock_cycle_update_scope(
        db,
        cycle_id,
        proposed_functional_request_id=proposed_functional_request_id,
    )
    _require_cycle_visibility(db, obj, current_user)
    _require_active_project(db, obj.project_id)
    require_can_execute_project(db, obj.project_id, current_user)
    blocking_reason = (data.pop("blocking_reason", None) or "").strip()
    remarks = (data.pop("remarks", None) or "").strip()
    conditional_clearance = data.pop("conditional_clearance", False)
    if len(blocking_reason) > 5000 or len(remarks) > 5000:
        raise HTTPException(400, "Blocking reason and remarks cannot exceed 5,000 characters")
    if conditional_clearance:
        if data != {"status": "Completed"}:
            raise HTTPException(400, "Conditional completion requires only a transition to Completed; edit other cycle fields separately")
        if not current_user.has_role(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA):
            raise HTTPException(403, "A QA Lead Group member must complete a cycle for Conditional Clearance")
        from ..certificate_summary import has_documented_text
        if not has_documented_text(remarks):
            raise HTTPException(400, "A reason is required to complete a cycle for Conditional Clearance")
        if not db.query(models.TestExecution.id).filter(
            models.TestExecution.cycle_id == obj.id,
            models.TestExecution.status.in_(("Pass", "Retest Passed", "NA", "Fail", "Blocked")),
        ).first():
            raise HTTPException(400, "Conditional completion requires at least one recorded test result")
    previous_status = obj.status
    previous_link_type = obj.linked_request_type
    previous_link_key = obj.linked_request_key
    tracked_fields = {
        "name": "Name", "description": "Description", "start_date": "Start date",
        "end_date": "End date", "cycle_type": "Cycle type", "environment": "Environment",
        "build": "Build", "owner_id": "Owner",
    }
    previous_values = {field: getattr(obj, field) for field in tracked_fields}
    transition_action = None
    if "status" in data:
        new_status = data["status"]
        transition_action = _validate_cycle_transition(previous_status, new_status, blocking_reason)
        if new_status == "Completed":
            if link_changed:
                raise HTTPException(
                    400,
                    "Completing a Test Cycle cannot be combined with linking, replacing, or "
                    "removing its QA Request. Save the request link separately, refresh, and "
                    "then complete the cycle.",
                )
            _require_completion_link_status(
                obj,
                locked_functional_requests,
            )
            # Recorded is not the same as successfully completed. Validate
            # every slot, independent of defect links, roles and UI pagination.
            incomplete_executions = db.query(models.TestExecution).options(
                joinedload(models.TestExecution.test_case)
            ).filter(
                models.TestExecution.cycle_id == obj.id,
                or_(models.TestExecution.status.is_(None),
                    models.TestExecution.status.notin_(("Pass", "Retest Passed", "NA"))),
            ).all()
            if conditional_clearance and any(execution.status not in ("Fail", "Blocked", "Not Executed")
                                             for execution in incomplete_executions):
                raise HTTPException(400, "Conditional completion requires recognized test execution statuses")
            if incomplete_executions and not conditional_clearance:
                labels = ", ".join(
                    f"{execution.test_case.test_case_key if execution.test_case else f'Testcase #{execution.test_case_id}'} ({execution.status or 'Not Executed'})"
                    for execution in incomplete_executions[:8]
                )
                suffix = "…" if len(incomplete_executions) > 8 else ""
                raise HTTPException(
                    400,
                    "Cannot complete this Test Cycle while testcases are Failed, Blocked or Not Executed. "
                    "Every testcase must be Pass, Retest Passed or NA. "
                    f"{len(incomplete_executions)} testcase(s) require attention: {labels}{suffix}",
                )
            severe = db.query(models.Defect).filter(
                or_(models.Defect.cycle_id == obj.id,
                    models.Defect.execution_links.any(models.DefectExecutionLink.execution.has(models.TestExecution.cycle_id == obj.id))),
                models.Defect.severity.in_(("Critical", "High")),
                or_(models.Defect.status.in_(_DEFECT_CYCLE_COMPLETION_BLOCKING_STATUSES),
                    and_(models.Defect.workflow_json.isnot(None), models.Defect.status == "Closed",
                         models.Defect.resolution_type == "Fixed")),
            ).all()
            from ..defect_workflow import verified_for
            severe = [d for d in severe if not verified_for(d, obj.environment)]
            if severe and not conditional_clearance:
                labels = ", ".join(defect.defect_key for defect in severe[:8])
                raise HTTPException(
                    400,
                    "This Test Cycle contains unresolved Critical or High severity defects. "
                    "Resolve, reject, defer with approval, or close these defects before completing the Test Cycle. "
                    f"Blocking defects: {labels}",
                )
            invalid_deferred = db.query(models.Defect).filter(
                or_(models.Defect.cycle_id == obj.id,
                    models.Defect.execution_links.any(models.DefectExecutionLink.execution.has(models.TestExecution.cycle_id == obj.id))),
                models.Defect.status == "Deferred",
                or_(models.Defect.target_release.is_(None), models.Defect.target_release == ""),
            ).all()
            if invalid_deferred:
                raise HTTPException(
                    400,
                    "Every deferred defect must have a Target Release before completing the Test Cycle. "
                    "Update these defects in Defect Management: "
                    + ", ".join(defect.defect_key for defect in invalid_deferred),
                )
            residual = db.query(models.Defect).filter(
                or_(models.Defect.cycle_id == obj.id,
                    models.Defect.execution_links.any(models.DefectExecutionLink.execution.has(models.TestExecution.cycle_id == obj.id))),
                models.Defect.severity.in_(("Medium", "Low")),
                or_(models.Defect.status.in_(_DEFECT_CYCLE_COMPLETION_BLOCKING_STATUSES),
                    and_(models.Defect.workflow_json.isnot(None), models.Defect.status == "Closed",
                         models.Defect.resolution_type == "Fixed")),
            ).all()
            residual = [d for d in residual if not verified_for(d, obj.environment)]
            if residual:
                # 2026-08 whole-module simplification: QA Lead Group system
                # role only -- the old per-project "Project Lead"/"Owner"
                # TestProjectMember carve-out is gone.
                manager = current_user.has_role(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA)
                if not manager:
                    raise HTTPException(
                        403,
                        "A QA Lead Group member must review the residual risk and complete this cycle "
                        "while Medium or Low defects remain open",
                    )
                if not remarks:
                    raise HTTPException(400, "Completion justification is required while Medium or Low defects remain open")
                missing_target = [defect.defect_key for defect in residual if not defect.target_release]
                if missing_target:
                    raise HTTPException(400, "Set a Target Release on every remaining Medium or Low defect before completing the cycle: " + ", ".join(missing_target))
            if conditional_clearance:
                transition_action = "Complete for Conditional Clearance"
    elif blocking_reason or remarks:
        raise HTTPException(400, "Blocking reason or transition remarks require a status change")
    # A Blocked cycle is frozen except for its one valid lifecycle action:
    # Resume Execution. It cannot smuggle metadata changes through alongside
    # that transition.
    link_only_change = data and set(data) <= {"linked_request_type", "linked_request_id"}
    if previous_status == "Blocked" and transition_action:
        if set(data) != {"status"}:
            raise HTTPException(400, "A Blocked Test Cycle can only be resumed; no other fields can be changed")
    elif previous_status == "Completed" and link_only_change:
        # 2026-08 -- reported directly: "once test cycle completed, then
        # test cycle is locked to edit. that is okay, but give option to
        # link QA request." Everything else about a Completed cycle stays
        # frozen (still routes through _require_open_cycle below for any
        # other field, same as before) -- this is narrowly scoped to a
        # request that changes ONLY the linked_request_type/
        # linked_request_id pair, so it can't be used to smuggle other
        # edits through alongside a link change. Replacing the Functional
        # QA Request a completed cycle is filed against stays useful
        # for traceability/reporting even though execution itself is done.
        pass
    else:
        _require_open_cycle(obj)
    if "owner_id" in data and data["owner_id"] is not None:
        _runner_or_404(db, data["owner_id"], workspace_id=obj.origin_workspace_id or obj.project.qa_workspace_id,
                       project=obj.project, cycle_owner=True)
    if "folder_id" in data and data["folder_id"] is not None:
        folder = db.query(models.TestCycleFolder).filter_by(id=data["folder_id"], project_id=obj.project_id).first()
        if not folder:
            raise HTTPException(404, "Destination folder not found in this project")
        require_can_view_cycle_folder(folder, current_user)
    # 2026-08 Reassignment Requirement -- changing (or clearing) the cycle
    # owner once one is already set is a reassignment: only the current
    # owner, their Department Head, or an Admin may do it, and a reason is
    # mandatory. Setting an owner for the first time keeps the existing
    # broad _EXEC_ROLES gate already enforced at the endpoint level.
    previous_owner_id = previous_values["owner_id"]
    owner_changed = "owner_id" in data and data["owner_id"] != previous_owner_id
    is_owner_reassignment = owner_changed and previous_owner_id is not None
    previous_owner = None
    owner_reason = None
    if is_owner_reassignment:
        previous_owner = db.get(models.User, previous_owner_id)
        reassignment.require_can_reassign(
            current_user, previous_owner_id,
            previous_owner.departments if previous_owner else None,
            qa_workspace_id=(obj.origin_workspace_id or obj.project.qa_workspace_id) if obj.project else None,
        )
        owner_reason = reassignment.require_reason(payload.reason)
    start_date = data.get("start_date", obj.start_date)
    end_date = data.get("end_date", obj.end_date)
    if start_date is None or end_date is None:
        raise HTTPException(400, "Start date and end date are required")
    if start_date > end_date:
        raise HTTPException(400, "Start date cannot be after end date")
    entering_ready = data.get("status") == "Ready" and obj.status != "Ready"
    link_type = data.pop("linked_request_type", None)
    link_id = data.pop("linked_request_id", None)
    if link_changed and link_id is not None and link_type != "Functional":
        raise HTTPException(400, "Only Functional QA Requests can be linked to Test Cycles")
    proposed_linked_request = None
    if link_changed and link_id is not None:
        proposed_linked_request = locked_functional_requests.get(link_id)
        if not proposed_linked_request or not proposed_linked_request.request_id:
            raise HTTPException(404, "Functional QA Request not found")
        if (
            obj.project.application_master_id is not None
            and proposed_linked_request.application_master_id
            != obj.project.application_master_id
        ):
            raise HTTPException(
                400,
                "Select a Functional QA Request for this Test Project's application",
            )
        request_workspace_id = (
            proposed_linked_request.qa_request.qa_workspace_id
            if proposed_linked_request.qa_request
            else None
        )
        if (obj.origin_workspace_id or obj.project.qa_workspace_id) != request_workspace_id:
            raise HTTPException(
                400,
                "The Test Cycle and Functional QA Request must belong to the same workspace",
            )
        require_cycle_request_linkable(
            proposed_linked_request,
            data.get("status", obj.status),
        )
    if (link_changed and obj.child_request_link
            and (link_type, link_id) != (previous_link_type, obj.linked_request_id)):
        _require_cycle_request_link_change_allowed(db, obj.child_request_link)
    if transition_action == "Start Execution":
        from ..execution_cycles import require_request_execution_started
        # Check both the existing and proposed link before mutating anything.
        # A combined relink/unlink + start request must not bypass the gate.
        request_ids = set()
        if obj.child_request_link:
            if obj.child_request_link.child_type != "Functional":
                raise HTTPException(400, "Only Functional QA Requests can be linked to Test Cycles")
            request_ids.add(obj.child_request_link.child_id)
        if link_changed and link_id is not None:
            request_ids.add(link_id)
        for request_id in sorted(request_ids):
            linked_request = locked_functional_requests.get(request_id)
            if not linked_request:
                raise HTTPException(404, "Linked Functional QA Request not found")
            require_request_execution_started(linked_request)
    if transition_action in ("Start Execution", "Resume Execution") or (
        obj.status == "In Progress" and ("build" in data or "environment" in data)
    ):
        _require_execution_context(data.get("environment", obj.environment), data.get("build", obj.build))
    for field, value in data.items():
        setattr(obj, field, value)
    if link_changed:
        if link_id is None:
            obj.child_request_link = None
        else:
            if obj.child_request_link:
                obj.child_request_link.child_type = "Functional"
                obj.child_request_link.child_id = proposed_linked_request.id
                obj.child_request_link.child_key = proposed_linked_request.request_id
            else:
                obj.child_request_link = models.TestCycleChildRequestLink(
                    child_type="Functional",
                    child_id=proposed_linked_request.id,
                    child_key=proposed_linked_request.request_id,
                )
    if obj.project.application_master_id is None:
        raise HTTPException(400, "Select an Application on this Test Project before continuing Test Lifecycle")
    if obj.child_request_link:
        current_linked_request = db.get(models.FunctionalRequest, obj.child_request_link.child_id)
        if not current_linked_request or not current_linked_request.request_id:
            raise HTTPException(400, "This cycle's Functional QA Request is no longer valid. Replace or remove the link before continuing")
        if (obj.project.application_master_id is not None
                and current_linked_request.application_master_id != obj.project.application_master_id):
            raise HTTPException(400, "Select a Functional QA Request for this Test Project's application")
    # 2026-08 "Test Approval Workflow" refactor, section 7 -- validated
    # against the FULLY-UPDATED obj (after link changes above have
    # already been applied in this same request), not the pre-update
    # snapshot, so a request that sets a new link and Ready in one go
    # is checked against what it's actually about to become.
    if entering_ready:
        _validate_cycle_ready(db, obj, start_date, end_date)
    if transition_action:
        details = [f"Status changed from {previous_status} to {obj.status}."]
        if blocking_reason:
            details.append(f"Blocking reason: {blocking_reason}")
        if remarks:
            details.append(f"Remarks: {remarks}")
        db.add(models.ApprovalAction(
            entity_type="TEST_CYCLE", entity_id=obj.id, step_name="Lifecycle",
            actor_id=current_user.id, actor_role=current_user.roles_csv,
            decision=transition_action, comments="\n".join(details),
        ))
        if transition_action in ("Block Execution", "Resume Execution"):
            _sync_linked_functional_request_status(db, obj, transition_action, current_user)
    if link_changed:
        new_link_type = obj.linked_request_type
        new_link_key = obj.linked_request_key
        if (previous_link_type, previous_link_key) != (new_link_type, new_link_key):
            decision = "Request Linked" if new_link_key else "Request Unlinked"
            comments = (
                f"Linked {new_link_type} request {new_link_key}."
                if new_link_key else f"Removed Functional request {previous_link_key}; cycle is now standalone."
            )
            if new_link_key and previous_link_key:
                comments += f" Replaced {previous_link_type} request {previous_link_key}."
            db.add(models.ApprovalAction(
                entity_type="TEST_CYCLE", entity_id=obj.id, step_name="Request Link",
                actor_id=current_user.id, actor_role=current_user.roles_csv,
                decision=decision, comments=comments,
            ))
    changed_labels = [
        label for field, label in tracked_fields.items()
        if field in data and previous_values[field] != getattr(obj, field)
    ]
    if changed_labels:
        db.add(models.ApprovalAction(
            entity_type="TEST_CYCLE", entity_id=obj.id, step_name="Cycle Details",
            actor_id=current_user.id, actor_role=current_user.roles_csv,
            decision="Updated", comments=f"Updated: {', '.join(changed_labels)}.",
        ))
    if is_owner_reassignment:
        new_owner = db.get(models.User, obj.owner_id) if obj.owner_id else None
        reassignment.record_reassignment(
            db, "TEST_CYCLE", obj.id, current_user,
            previous_owner.full_name if previous_owner else "Unassigned",
            new_owner.full_name if new_owner else "Unassigned",
            owner_reason, step_name="Owner Reassignment",
            assignment_role="CYCLE_OWNER",
            previous_assignee_ids=[previous_owner_id],
            new_assignee_ids=[obj.owner_id],
        )
    elif owner_changed:
        reassignment.record_assignment_change(
            db, "TEST_CYCLE", obj.id, "CYCLE_OWNER", current_user,
            [previous_owner_id], [obj.owner_id], payload.reason,
        )
    db.commit()
    db.refresh(obj)
    _attach_request_link_permissions(db, [obj], current_user)
    return obj


@router.delete("/cycles/{cycle_id}/request-link", response_model=schemas.TestCycleOut)
def unlink_cycle_request(cycle_id: int, db: Session = Depends(get_db),
                         current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    preview = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, preview, current_user)
    _require_active_project(db, preview.project_id)
    require_can_execute_project(db, preview.project_id, current_user)
    obj, locked_functional_requests = _lock_cycle_update_scope(db, cycle_id)
    _require_cycle_visibility(db, obj, current_user)
    _require_active_project(db, obj.project_id)
    require_can_execute_project(db, obj.project_id, current_user)
    _require_open_cycle(obj)
    link = obj.child_request_link
    if not link:
        raise HTTPException(404, "This test cycle does not have a linked request")
    locked_source = (
        locked_functional_requests.get(link.child_id)
        if link.child_type == "Functional"
        else None
    )
    _require_cycle_request_link_change_allowed(
        db, link, locked_functional_request=locked_source,
    )
    previous_key = link.child_key
    obj.child_request_link = None
    db.add(models.ApprovalAction(
        entity_type="TEST_CYCLE", entity_id=obj.id, step_name="Request Link",
        actor_id=current_user.id, actor_role=current_user.roles_csv,
        decision="Request Unlinked",
        comments=f"Removed Functional request {previous_key}; cycle is now standalone.",
    ))
    db.commit()
    db.refresh(obj)
    _attach_request_link_permissions(db, [obj], current_user)
    return obj


@router.post(
    "/cycles/{cycle_id}/request-link/qa-lead-group-unlink",
    response_model=schemas.TestCycleOut,
)
def qa_lead_group_unlink_cycle_request(
    cycle_id: int,
    payload: schemas.QALeadGroupCycleRequestUnlinkIn,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles(
        Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA,
    )),
):
    """Governed recovery for a wrong link after Functional execution starts.

    Normal link mutation remains locked. This dedicated command requires an
    explicit QA Lead Group role, a durable reason and impact confirmation,
    and serializes against certificate creation/retest through the Functional
    Request row lock. For a normal cycle it removes only the association row;
    execution history remains attached to the standalone Test Cycle. For an
    untouched re-execution child it is a governed retest cancellation: the
    lineage pointer is cleared and a held request can move from Execution In
    Progress back to QA Clearance Change Review so QA can select a replacement.
    """
    if not _is_qa_lead_group_member(current_user):
        raise HTTPException(
            403,
            "Governed unlink is available only to the QA Lead Group (QA Lead, Chief Manager QA, or AGM QA).",
        )
    # Discover/authorize from an unlocked snapshot, then use the shared
    # FunctionalRequest -> TestCycle -> association-row lock protocol. The
    # helper reloads and revalidates the link after every lock, so a concurrent
    # ordinary PATCH cannot redirect this override to a different request.
    preview = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, preview, current_user)
    _require_active_project(db, preview.project_id)
    require_can_execute_project(db, preview.project_id, current_user)
    preview_link = preview.child_request_link
    if not preview_link:
        raise HTTPException(404, "This test cycle does not have a linked request")
    if preview_link.child_type != "Functional":
        raise HTTPException(400, "QA Lead Group unlink supports only Functional QA Requests")
    obj, locked_functional_requests = _lock_cycle_update_scope(db, cycle_id)
    _require_cycle_visibility(db, obj, current_user)
    _require_active_project(db, obj.project_id)
    require_can_execute_project(db, obj.project_id, current_user)
    link = obj.child_request_link
    if not link or link.child_type != "Functional":
        raise HTTPException(
            409,
            "The Test Cycle link changed concurrently; refresh before unlinking",
        )
    functional_request = locked_functional_requests.get(link.child_id)
    if not functional_request or not functional_request.request_id:
        raise HTTPException(409, "The linked Functional QA Request no longer exists")
    if cycle_unlink_allowed(functional_request.status):
        raise HTTPException(
            409,
            "This link is not locked yet. Use the standard unlink action instead of the QA Lead Group override.",
        )
    blocker = _qa_lead_unlink_blocker(db, functional_request, obj)
    if blocker:
        raise HTTPException(409, blocker)

    previous_request_status = functional_request.status
    retest_reset_detail = ""
    lineage_parent_id = None
    lineage_parent_key = None
    if obj.reexecution_of_cycle_id is not None:
        # Serialize cancellation against every result/evidence mutation. All
        # execution writers lock the same slot row; populate_existing ensures
        # we inspect committed work if one of them completed first.
        db.query(models.TestExecution).filter(
            models.TestExecution.cycle_id == obj.id,
        ).order_by(models.TestExecution.id).populate_existing().with_for_update().all()
        if _reexecution_cycle_has_recorded_work(db, obj.id):
            raise HTTPException(
                409,
                "This re-execution cycle already contains recorded work and cannot be detached "
                "from its governed clearance lineage. Complete the retest or create a reviewed "
                "follow-up after preserving this evidence.",
            )
        lineage_parent = obj.reexecution_of_cycle
        lineage_parent_id = obj.reexecution_of_cycle_id
        lineage_parent_key = (
            lineage_parent.cycle_key
            if lineage_parent
            else f"cycle #{obj.reexecution_of_cycle_id}"
        )
        # An untouched child can be corrected safely, but it must stop
        # occupying the parent's unique successor slot so QA can select the
        # right source and create a replacement. If this was the mandatory
        # held-clearance retest, return the request to the explicit QA review
        # decision instead of letting old Completed evidence satisfy QA
        # Complete.
        obj.reexecution_of_cycle_id = None
        linked_certificate = (
            db.get(models.QASignOff, functional_request.signoff_id)
            if functional_request.signoff_id is not None
            else None
        )
        if linked_certificate and linked_certificate.status == "ISSUED_UNDER_REVIEW":
            functional_request.status = QAStatus.QA_CHANGE_REVIEW
            retest_reset_detail = (
                f" Cleared its re-execution lineage from {lineage_parent_key} and restored "
                "the Functional Request to QA Clearance Change Review; QA must select Retest "
                "again before QA can be completed."
            )
        else:
            retest_reset_detail = (
                f" Cleared its re-execution lineage from {lineage_parent_key}, allowing a "
                "governed replacement successor to be created."
            )

    execution_count = db.query(func.count(models.TestExecution.id)).filter(
        models.TestExecution.cycle_id == obj.id,
    ).scalar() or 0
    attempt_count = (
        db.query(func.count(models.TestExecutionRun.id))
        .join(
            models.TestExecution,
            models.TestExecution.id == models.TestExecutionRun.execution_id,
        )
        .filter(models.TestExecution.cycle_id == obj.id)
        .scalar()
        or 0
    )
    previous_key = functional_request.request_id
    if lineage_parent_id is not None:
        audit_decision = "Governed Retest Cancelled"
        audit_comments = (
            f"QA Lead Group cancelled untouched governed re-execution cycle {obj.cycle_key} "
            f"for Functional request {previous_key} while the request was "
            f"{previous_request_status}. Reason: {payload.reason}. Impact confirmed by the "
            f"actor. Preserved {execution_count} execution slot(s); no recorded execution "
            f"work was detached.{retest_reset_detail}"
        )
    else:
        audit_decision = "QA Lead Group Unlink"
        audit_comments = (
            f"QA Lead Group override removed Functional request {previous_key} from test cycle "
            f"{obj.cycle_key} while the request was {previous_request_status}. "
            f"Reason: {payload.reason}. Impact confirmed by the actor. "
            f"Preserved {execution_count} execution slot(s), {attempt_count} execution attempt(s), "
            "and all associated results, defects, and evidence; the cycle is now standalone."
        )
    obj.child_request_link = None
    request_status_changed = functional_request.status != previous_request_status
    audit_actions = [
        models.ApprovalAction(
            entity_type="TEST_CYCLE",
            entity_id=obj.id,
            step_name="Request Link",
            actor_id=current_user.id,
            actor_role=current_user.roles_csv,
            decision=audit_decision,
            comments=audit_comments,
        ),
        models.ApprovalAction(
            entity_type="FUNCTIONAL_REQUEST",
            entity_id=functional_request.id,
            step_name="Test Cycle Link",
            actor_id=current_user.id,
            actor_role=current_user.roles_csv,
            decision=audit_decision,
            comments=audit_comments,
            previous_state=previous_request_status if request_status_changed else None,
            new_state=functional_request.status if request_status_changed else None,
        ),
    ]
    if lineage_parent_id is not None:
        audit_actions.append(models.ApprovalAction(
            entity_type="TEST_CYCLE",
            entity_id=lineage_parent_id,
            step_name="Re-execution",
            actor_id=current_user.id,
            actor_role=current_user.roles_csv,
            decision="Successor Cancelled",
            comments=(
                f"Cleared untouched successor {obj.cycle_key} from {lineage_parent_key}; "
                "the unique successor pointer is available for a governed replacement. "
                f"Reason: {payload.reason}."
            ),
        ))
    db.add_all(audit_actions)
    db.commit()
    db.refresh(obj)
    _attach_request_link_permissions(db, [obj], current_user)
    return obj


@router.delete("/cycles/{cycle_id}")
def delete_cycle(cycle_id: int, db: Session = Depends(get_db),
                 current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    """Delete a Test Cycle. Governance is limited to the QA Lead Group
    (require_can_manage_execution_governance below rejects a plain
    QA_ENGINEER even though it passes this looser router-level check).

    2026-08 -- reported directly: "once execution history created then
    remove option should not be there for QA lead ... Administration can
    supersede everything." A QA Lead may only delete an EMPTY cycle (must
    remove every testcase slot first, via remove_execution/
    bulk_remove_executions -- itself now blocked per-slot once that slot has
    recorded history, see _require_can_remove_execution) -- unchanged, and
    already stricter than "once history exists" since it blocks on ANY
    slot being present, executed or not. An Administrator may override this
    and delete a non-empty cycle outright; doing so cascades to every
    execution slot, its full attempt history, and its evidence documents in
    one step (same cleanup bulk_remove_executions performs per-slot, applied
    to the whole cycle here), logged as a single audit row before the cycle
    itself is removed."""
    preview = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, preview, current_user)
    _require_active_project(db, preview.project_id)
    obj, locked_functional_requests = _lock_cycle_update_scope(db, cycle_id)
    _require_cycle_visibility(db, obj, current_user)
    _require_active_project(db, obj.project_id)
    _require_open_cycle(obj)
    require_can_manage_execution_governance(db, obj.project_id, current_user)
    link = obj.child_request_link
    locked_source = (
        locked_functional_requests.get(link.child_id)
        if link is not None and link.child_type == "Functional"
        else None
    )
    _require_cycle_request_link_change_allowed(
        db, link, locked_functional_request=locked_source,
    )
    executions = db.query(models.TestExecution).filter_by(cycle_id=cycle_id).all()
    is_admin_override = bool(executions) and current_user.has_role(Role.ADMIN)
    if executions and not is_admin_override:
        raise HTTPException(
            400,
            f"Cannot delete this Test Cycle because it contains {len(executions)} test case execution record"
            f"{'s' if len(executions) != 1 else ''}. Remove the test cases from the cycle first."
        )
    documents_by_id = {}
    if is_admin_override:
        # Polymorphic documents have no FK back to TestExecution/
        # TestExecutionRun (see remove_execution's own comment on this) --
        # cleaned up explicitly for every execution in the cycle, same as a
        # per-slot removal, rather than orphaning screenshots on disk.
        for execution in executions:
            for run in execution.runs:
                for document in doc_store.list_documents(db, _RESULT_IMAGE_MODULE, run.id):
                    documents_by_id[document.id] = document
            for document in doc_store.list_documents(db, _RESULT_IMAGE_MODULE, execution.id):
                documents_by_id[document.id] = document
        db.add(models.ApprovalAction(
            entity_type="TEST_CYCLE", entity_id=obj.id, step_name="Cycle Deletion",
            actor_id=current_user.id, actor_role=current_user.roles_csv,
            decision="Deleted (Administrator override)",
            comments=(
                f"{obj.cycle_key} - {obj.name} deleted with {len(executions)} test case execution record"
                f"{'s' if len(executions) != 1 else ''} and {len(documents_by_id)} evidence file"
                f"{'s' if len(documents_by_id) != 1 else ''} still attached, by Administrator override."
            ),
        ))
        for document in documents_by_id.values():
            db.delete(document)
    file_paths = [doc_store.full_path(document) for document in documents_by_id.values()]
    db.delete(obj)
    db.commit()
    # Database state is authoritative -- a stale/missing file is harmless and
    # must not turn a successfully committed deletion into a false API error.
    for path in file_paths:
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass
    return {"ok": True}


# ---- Executions (a test case's result within one cycle) ----
@router.get("/cycles/{cycle_id}/executions", response_model=pagination.Page[schemas.TestExecutionOut])
def list_executions(
    cycle_id: int,
    assignment: Optional[str] = Query(
        None, description="'mine', 'unassigned', or omitted for no extra assignment filter",
    ),
    cursor_mode: bool = Query(False, description="Use primary-key cursor pagination instead of OFFSET"),
    cursor: Optional[int] = Query(None, ge=0),
    params: pagination.PageParams = Depends(),
    db: Session = Depends(get_db), current_user: models.User = Depends(get_current_user),
):
    """SRS 7.2 pagination rollout -- was previously "every execution slot in
    the cycle" in one unpaginated call. `assignment` is a module-specific
    extra filter (like Test Cases' own `folder_id`/`tag`) resolved against
    the CURRENT user server-side, backing TestExecution.tsx's own "All /
    Mine / Unassigned" tab bar. See TestExecutionSummaryOut below for the
    progress bar / assignment stat / result tabs this list can no longer
    compute client-side from the complete cycle."""
    cycle = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    q = db.query(models.TestExecution).filter(models.TestExecution.cycle_id == cycle_id).options(*_LIST_EXECUTION_EAGER_LOADS)
    if assignment == "mine":
        if not current_user.has_qa_workspace_role(*_EXEC_ROLES, workspace_id=current_workspace_id()):
            raise HTTPException(403, "My execution assignments are restricted to the QA group")
        q = q.filter(models.TestExecution.assigned_to_id == current_user.id)
    elif assignment == "unassigned":
        q = q.filter(models.TestExecution.assigned_to_id.is_(None))
    q = pagination.apply_status_filter(q, params, models.TestExecution.status)
    if cursor_mode:
        return pagination.paginate_by_id(q, params, models.TestExecution.id, cursor)
    q = pagination.apply_sort(
        q, params, sortable={"status": models.TestExecution.status},
        default_column=models.TestExecution.id, id_column=models.TestExecution.id,
    )
    result = pagination.paginate(q, params)
    return pagination.to_page_response(result, params)


@router.get("/cycles/{cycle_id}/executions/summary", response_model=schemas.TestExecutionSummaryOut)
def get_execution_summary(cycle_id: int, db: Session = Depends(get_db),
                           current_user: models.User = Depends(get_current_user)):
    """The progress bar, assignment stat, "My queue" count, the All/Mine/
    Unassigned tab bar, and the per-result-status tab bar all used to be
    computed in the browser from the complete (unpaginated) cycle execution
    list -- now that the main list above is paginated, none of those has
    enough data on hand any more. Computed via SQL COUNT/GROUP BY against
    the whole cycle regardless of which page/status/assignment filter the
    main list currently has selected -- never a full-row fetch."""
    cycle = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    base = db.query(models.TestExecution).filter(models.TestExecution.cycle_id == cycle_id)
    total = base.count()
    status_counts = {
        status: count for status, count in
        db.query(models.TestExecution.status, func.count(models.TestExecution.id))
        .filter(models.TestExecution.cycle_id == cycle_id)
        .group_by(models.TestExecution.status).all()
    }
    executed_count = sum(count for status, count in status_counts.items() if status != "Not Executed")
    assigned_count = base.filter(models.TestExecution.assigned_to_id.isnot(None)).count()
    unassigned_count = total - assigned_count
    mine_count = base.filter(models.TestExecution.assigned_to_id == current_user.id).count()
    total_run_count = (
        db.query(func.count(models.TestExecutionRun.id))
        .join(models.TestExecution, models.TestExecution.id == models.TestExecutionRun.execution_id)
        .filter(models.TestExecution.cycle_id == cycle_id)
        .scalar()
    ) or 0
    return schemas.TestExecutionSummaryOut(
        total=total, status_counts=status_counts, executed_count=executed_count,
        assigned_count=assigned_count, unassigned_count=unassigned_count, mine_count=mine_count,
        total_run_count=total_run_count,
    )


@router.get("/executions/blocked-or-failed", response_model=List[schemas.DefectLinkableExecutionOut])
def list_blocked_failed_executions(db: Session = Depends(get_db),
                                    current_user: models.User = Depends(get_current_user)):
    """2026-08 -- reported directly: on Defect Management's page load, "if
    there are 30 project[s] then 30 api call[s] ... same for cycles,
    executions." Defects.tsx used to build its "pick a Failed/Blocked Test
    Execution" dropdown (for creating or linking a defect) by fetching every
    active project's cycles, then every one of THOSE cycles' Fail/Blocked
    executions, one round trip at a time -- N projects + N cycle-list calls +
    one execution-list call per cycle, scaling worse than linearly as the
    number of in-progress cycles grows. This single batch query replaces all
    of that: one SQL join across TestProject -> TestCycle -> TestExecution,
    filtered to active projects and Fail/Blocked status, scoped the same way
    every other cross-project list in this app is (deps.viewable_project_ids
    -- own department scope, widened by any 2026-08 "view-only access to
    department/user" CR grant).

    2026-08, further widened: Defect Management itself is no longer role-
    gated (see defects.py's own list_defects/defect_dashboard/export_defects
    and this router's own docstring update) -- open to any authenticated
    user, scoped by department exactly like every other module's register,
    so this picker only takes `get_current_user` too now rather than the
    retired DEFECT_MANAGEMENT_ROLES allow-list. Returns one flattened row
    per execution, each carrying its own project/cycle alongside it,
    mirroring the frontend's pre-existing `ExecutionContext` shape exactly
    so no consumer-side logic needs to change, only where the data comes
    from."""
    q = (
        db.query(models.TestExecution)
        .join(models.TestCycle, models.TestExecution.cycle_id == models.TestCycle.id)
        .join(models.TestProject, models.TestCycle.project_id == models.TestProject.id)
        .filter(models.TestProject.is_active == True)  # noqa: E712
        .filter(models.TestExecution.status.in_(("Fail", "Blocked")))
        .options(
            joinedload(models.TestExecution.cycle).joinedload(models.TestCycle.project),
            joinedload(models.TestExecution.pinned_version),
            *_LIST_EXECUTION_EAGER_LOADS,
        )
    )
    project_ids = viewable_project_ids(db, current_user)
    if project_ids is not None:
        q = q.filter(models.TestProject.id.in_(project_ids))
    executions = q.order_by(models.TestProject.id, models.TestCycle.id, models.TestExecution.id).all()
    executions = [
        execution for execution in executions
        if not execution.cycle.folder_id or can_view_cycle_folder(execution.cycle.folder, current_user)
    ]
    return [
        {"project": execution.cycle.project, "cycle": execution.cycle, "execution": execution,
         "feature_area": execution.pinned_version.module_name if execution.pinned_version else None}
        for execution in executions
    ]


@router.get("/my-executions", response_model=List[schemas.MyExecutionOut])
def list_my_executions(db: Session = Depends(get_db),
                       current_user: models.User = Depends(get_current_user)):
    """Return the current tester's actionable execution queue in one query.

    The former browser implementation fetched every project, then every
    project's cycles, then every in-progress cycle's assignments. Besides
    growing as projects × cycles, it could open dozens of simultaneous API
    requests for one page view. This joined query keeps the same eligibility,
    active-project and in-progress-cycle rules while loading the exact rows
    assigned to the current user only.
    """
    if not current_user.has_qa_workspace_role(*_EXEC_ROLES, workspace_id=current_workspace_id()):
        raise HTTPException(403, "My execution assignments are restricted to the QA group")
    q = (
        db.query(models.TestExecution)
        .join(models.TestCycle, models.TestExecution.cycle_id == models.TestCycle.id)
        .join(models.TestProject, models.TestCycle.project_id == models.TestProject.id)
        .filter(
            models.TestExecution.assigned_to_id == current_user.id,
            models.TestProject.is_active == True,  # noqa: E712
            or_(
                models.TestProject.is_archived == False,  # noqa: E712
                models.TestProject.is_archived.is_(None),
            ),
            models.TestCycle.status == "In Progress",
        )
        .options(
            joinedload(models.TestExecution.cycle).joinedload(models.TestCycle.project),
            *_LIST_EXECUTION_EAGER_LOADS,
        )
    )
    project_ids = viewable_project_ids(db, current_user)
    if project_ids is not None:
        q = q.filter(models.TestProject.id.in_(project_ids))
    executions = q.order_by(models.TestProject.name, models.TestCycle.name, models.TestExecution.id).all()
    executions = [
        execution for execution in executions
        if not execution.cycle.folder_id or can_view_cycle_folder(execution.cycle.folder, current_user)
    ]
    return [
        {"project": execution.cycle.project, "cycle": execution.cycle, "execution": execution}
        for execution in executions
    ]


@router.get("/cycles/{cycle_id}/candidate-authors", response_model=List[schemas.TestCaseCandidateAuthor])
def list_cycle_candidate_authors(
    cycle_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Creators of approved, unlinked testcases in this cycle's project."""
    cycle = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    require_can_execute_project(db, cycle.project_id, current_user)
    rows = (
        _cycle_candidate_query(db, cycle)
        .join(models.User, models.User.id == models.TestCase.created_by_id)
        .with_entities(models.User.id, models.User.full_name)
        .distinct()
        .order_by(models.User.full_name, models.User.id)
        .all()
    )
    return [{"id": author_id, "name": name} for author_id, name in rows]


@router.get("/cycles/{cycle_id}/candidate-test-cases", response_model=schemas.TestCaseCandidatePage)
def list_cycle_candidate_test_cases(
    cycle_id: int,
    cursor: Optional[int] = Query(None, ge=0),
    page_size: int = Query(25, ge=5, le=100),
    search: Optional[str] = Query(None),
    priority: Optional[str] = Query(None),
    test_type: Optional[str] = Query(None),
    created_by_id: Optional[int] = Query(None, ge=1),
    sort_order: Literal["newest", "oldest"] = Query("newest"),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Cursor-paginated approved testcases eligible for this cycle.

    The result is computed entirely in Oracle with a correlated NOT EXISTS;
    neither the full repository nor the cycle's full execution-id set is
    transferred to the browser.
    """
    cycle = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    require_can_execute_project(db, cycle.project_id, current_user)
    base = _cycle_candidate_query(db, cycle, search, priority, test_type, created_by_id)
    total = base.order_by(None).count()
    page_query = base
    if cursor is not None:
        page_query = page_query.filter(
            models.TestCase.id < cursor if sort_order == "newest" else models.TestCase.id > cursor
        )
    id_order = models.TestCase.id.desc() if sort_order == "newest" else models.TestCase.id.asc()
    rows = page_query.options(joinedload(models.TestCase.created_by),
                              joinedload(models.TestCase.current_approved_version)).order_by(id_order).limit(page_size + 1).all()
    has_more = len(rows) > page_size
    items = rows[:page_size]
    return {
        "items": [{
            "id": case.id, "test_case_key": case.test_case_key,
            "test_scenario": case.current_approved_version.test_scenario,
            "test_type": case.current_approved_version.test_type,
            "priority": case.current_approved_version.priority,
            "module_name": case.current_approved_version.module_name,
            "version": case.current_approved_version.version,
            "created_at": case.created_at, "created_by_id": case.created_by_id,
            "created_by_name": case.created_by_name,
        } for case in items],
        "total": total,
        "next_cursor": items[-1].id if has_more and items else None,
        "has_more": has_more,
    }


@router.get("/executions/{execution_id}", response_model=schemas.TestExecutionOut)
def get_execution(execution_id: int, db: Session = Depends(get_db),
                   current_user: models.User = Depends(get_current_user)):
    """PAG-006-adjacent -- didn't exist before this pagination pass, because
    the list endpoint used to hand back every execution in the cycle at
    once so no caller ever needed to fetch just one by id. Now that the list
    is paginated, TestExecution.tsx's own `?execution=<id>` deep-link (from
    defect traceability) needs this to open a specific slot even when it
    isn't on whatever page happens to be loaded."""
    obj = _execution_or_404(db, execution_id)
    _require_execution_visibility(db, obj, current_user)
    return obj


@router.get("/cycles/{cycle_id}/export-xlsx")
def export_test_cycle(
    cycle_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    """Export one complete test lifecycle, including every retained run."""
    cycle = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    project = _get_project_or_404(db, cycle.project_id)
    executions = (db.query(models.TestExecution).filter_by(cycle_id=cycle_id)
                  .order_by(models.TestExecution.id).all())

    folders = db.query(models.TestFolder).filter_by(project_id=project.id).all()
    folder_by_id = {folder.id: folder for folder in folders}

    def folder_path(folder_id):
        if not folder_id:
            return "Unfiled"
        parts, seen = [], set()
        current = folder_by_id.get(folder_id)
        while current and current.id not in seen:
            seen.add(current.id)
            parts.append(current.name)
            current = folder_by_id.get(current.parent_id)
        return " / ".join(reversed(parts)) or "Unfiled"

    real_run_ids = {run.id for execution in executions for run in execution.runs}
    legacy_execution_ids = {
        execution.id for execution in executions
        if not execution.runs and execution.status != "Not Executed"
    }
    evidence_keys = real_run_ids | legacy_execution_ids
    documents = []
    if evidence_keys:
        documents = (db.query(models.RequestDocument).filter(
            models.RequestDocument.module == _RESULT_IMAGE_MODULE,
            models.RequestDocument.request_id.in_(evidence_keys),
        ).order_by(models.RequestDocument.uploaded_at).all())
    docs_by_owner = {}
    for document in documents:
        docs_by_owner.setdefault(document.request_id, []).append(document)
    uploader_ids = {document.uploaded_by_id for document in documents if document.uploaded_by_id}
    uploader_names = {}
    if uploader_ids:
        uploader_names = {
            user.id: user.full_name
            for user in db.query(models.User).filter(models.User.id.in_(uploader_ids)).all()
        }

    actions = (db.query(models.ApprovalAction).filter_by(
        entity_type="TEST_CYCLE", entity_id=cycle.id,
    ).order_by(models.ApprovalAction.created_at).all())

    run_rows = []
    defect_rows = []
    evidence_rows = []
    for execution in executions:
        case = execution.test_case
        runs = list(execution.runs)
        if not runs and execution.status != "Not Executed":
            # Pre-attempt-history records are still retained in exports as a
            # clearly labelled legacy attempt instead of disappearing.
            run_rows.append([
                case.test_case_key, 1, execution.status, execution.actual_result,
                execution.test_run_artifacts, execution.defect_id,
                execution.executed_by_name, execution.executed_at,
                len(docs_by_owner.get(execution.id, [])),
                ", ".join(doc.file_name for doc in docs_by_owner.get(execution.id, [])),
                "Legacy current result (recorded before attempt history was enabled)",
            ])
            for document in docs_by_owner.get(execution.id, []):
                evidence_rows.append([
                    case.test_case_key, 1, document.file_name, document.content_type,
                    round((document.file_size or 0) / 1024, 2),
                    uploader_names.get(document.uploaded_by_id, "Unknown user"), document.uploaded_at,
                ])
        for run in runs:
            run_docs = docs_by_owner.get(run.id, [])
            structured_keys = ", ".join(defect.defect_key for defect in run.defects)
            run_rows.append([
                case.test_case_key, run.attempt_no, run.status, run.actual_result,
                run.test_run_artifacts, structured_keys or run.defect_id,
                run.executed_by_name, run.executed_at, len(run_docs),
                ", ".join(document.file_name for document in run_docs), "",
            ])
            for defect in run.defects:
                defect_rows.append([
                    case.test_case_key, run.attempt_no, defect.defect_key,
                    defect.defect_url, defect.title, defect.defect_status, defect.notes,
                    defect.linked_by_name, defect.created_at,
                ])
            for document in run_docs:
                evidence_rows.append([
                    case.test_case_key, run.attempt_no, document.file_name, document.content_type,
                    round((document.file_size or 0) / 1024, 2),
                    uploader_names.get(document.uploaded_by_id, "Unknown user"), document.uploaded_at,
                ])

    workbook = new_workbook()
    executed_count = sum(execution.status != "Not Executed" for execution in executions)
    pass_count = sum(execution.status in {"Pass", "Retest Passed"} for execution in executions)
    add_summary_sheet(
        workbook,
        f"{cycle.cycle_key} · Test Lifecycle",
        "Complete selected-cycle snapshot with assignments, attempts, evidence, and defect links.",
        [
            ("Cycle", cycle.name), ("Cycle ID", cycle.cycle_key),
            ("Project", f"{project.project_key} · {project.name}"), ("Cycle status", cycle.status),
            ("Start date", cycle.start_date or "—"), ("End date", cycle.end_date or "—"),
            ("Generated by", current_user.full_name), ("Generated at", models.now()),
        ],
        [
            ("Testcases", len(executions)), ("Executed", executed_count),
            ("Passed", pass_count),
            ("Failed", sum(execution.status == "Fail" for execution in executions)),
            ("Blocked", sum(execution.status == "Blocked" for execution in executions)),
            ("Unassigned", sum(not execution.assigned_to_id for execution in executions)),
            ("Attempts", len(run_rows)), ("Defect links", len(defect_rows)),
            ("Evidence files", len(evidence_rows)),
        ],
    )
    add_table_sheet(
        workbook, "Cycle Testcases", "Cycle Testcases", [
            "Test Case ID", "Version", "Folder Path", "Epic ID", "CR Number",
            "Feature ID", "User Story ID", "Test Type", "Module", "Priority",
            "Scenario", "Pre-Condition", "Latest Result", "Latest Actual Result",
            "Latest Artifact", "Latest Defect Summary", "Assigned To", "Assigned By",
            "Assigned At", "Last Runner", "Last Run At", "Attempt Count",
        ], [[
            execution.test_case.test_case_key, execution.test_case.version,
            folder_path(execution.test_case.folder_id), execution.test_case.epic_id,
            execution.test_case.cr_number, execution.test_case.feature_id,
            execution.test_case.user_story_id, execution.test_case.test_type,
            execution.test_case.module_name, execution.test_case.priority,
            execution.test_case.test_scenario, execution.test_case.pre_condition,
            execution.status, execution.actual_result, execution.test_run_artifacts,
            ", ".join(defect.defect_key for run in execution.runs for defect in run.defects)
            or execution.defect_id,
            execution.assigned_to_name, execution.assigned_by_name, execution.assigned_at,
            execution.executed_by_name, execution.executed_at,
            len(execution.runs) or (1 if execution.status != "Not Executed" else 0),
        ] for execution in executions],
        subtitle="One row per testcase slot; Latest Result mirrors the newest attempt.",
        wrap_headers={"Scenario", "Pre-Condition", "Latest Actual Result"},
        date_headers={"Assigned At", "Last Run At"}, status_headers={"Latest Result"},
        widths={"Scenario": 38, "Pre-Condition": 38, "Latest Actual Result": 48},
    )
    add_table_sheet(
        workbook, "Test Steps", "Test Steps", [
            "Test Case ID", "Version", "Step No", "Step", "Expected Result",
        ], [[
            execution.test_case.test_case_key, execution.test_case.version, step.step_no,
            step.step_text, step.expected_result,
        ] for execution in executions for step in execution.test_case.steps],
        subtitle="Definition used by each testcase in this cycle.",
        wrap_headers={"Step", "Expected Result"}, widths={"Step": 52, "Expected Result": 52},
    )
    add_table_sheet(
        workbook, "Execution Attempts", "Execution Attempt History", [
            "Test Case ID", "Attempt No", "Result", "Actual Result", "Artifact",
            "Defect Summary", "Executed By", "Executed At", "Evidence Count",
            "Evidence Files", "History Note",
        ], run_rows,
        subtitle="Every retained execution attempt; later retests never overwrite earlier results.",
        wrap_headers={"Actual Result", "Evidence Files", "History Note"},
        date_headers={"Executed At"}, status_headers={"Result"},
        widths={"Actual Result": 52, "Evidence Files": 38, "History Note": 40},
    )
    add_table_sheet(
        workbook, "Defect Links", "Structured Defect Links", [
            "Test Case ID", "Attempt No", "Defect Key", "Defect URL", "Title",
            "Defect Status", "Notes", "Linked By", "Linked At",
        ], defect_rows,
        subtitle="Defects are tied to the exact execution attempt where they were observed.",
        wrap_headers={"Title", "Notes"}, date_headers={"Linked At"},
        status_headers={"Defect Status"}, widths={"Defect URL": 42, "Notes": 48},
    )
    add_table_sheet(
        workbook, "Evidence Index", "Execution Evidence Index", [
            "Test Case ID", "Attempt No", "File Name", "Content Type", "Size (KB)",
            "Uploaded By", "Uploaded At",
        ], evidence_rows,
        subtitle="Evidence metadata index. Binary files remain protected in the portal.",
        date_headers={"Uploaded At"}, widths={"File Name": 42, "Content Type": 24},
    )
    add_table_sheet(
        workbook, "Cycle Activity", "Cycle Activity History", [
            "Activity", "Decision", "Actor", "Role Snapshot", "Comments", "Timestamp",
        ], [[
            action.step_name, action.decision, action.actor_name or "System",
            format_role_labels(action.actor_role), action.comments, action.created_at,
        ] for action in actions],
        subtitle="Assignments, execution actions, defect links, and membership changes.",
        wrap_headers={"Comments"}, date_headers={"Timestamp"}, status_headers={"Decision"},
        widths={"Comments": 56, "Role Snapshot": 28},
    )
    return workbook_response(workbook, f"{cycle.cycle_key}_test_lifecycle.xlsx")


@router.post("/cycles/{cycle_id}/export-xlsx/jobs")
def queue_test_cycle_export(
    cycle_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    cycle = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    filename = f"{cycle.cycle_key}_test_lifecycle.xlsx"
    user_id = current_user.id
    actor_workspace_id = getattr(current_user, "active_qa_workspace_id", None)

    spec = make_spec("TEST_CYCLE_EXPORT", user_id, actor_workspace_id,
                     cycle_id=cycle_id, filename=filename)
    return jobs.enqueue(background_tasks, "TEST_CYCLE_EXPORT", user_id, spec)


@router.post("/cycles/{cycle_id}/executions", response_model=List[schemas.TestExecutionOut])
def add_test_cases_to_cycle(cycle_id: int, payload: schemas.TestExecutionAdd, db: Session = Depends(get_db),
                             current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    """Adds one or more existing Repository test cases to this cycle,
    creating a Not-Executed TestExecution row for each -- silently skips any
    that are already in this cycle (the (cycle_id, test_case_id) unique
    constraint means re-adding one would otherwise 500)."""
    preview = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, preview, current_user)
    _require_active_project(db, preview.project_id)
    require_can_execute_project(db, preview.project_id, current_user)
    # Serialize scope expansion against lifecycle completion/relink using the
    # established Functional parent -> Test Cycle -> link lock order. If add
    # wins, a concurrent completion sees the new Not Executed rows and stops;
    # if completion wins, the locked status below rejects this mutation.
    cycle, _ = _lock_cycle_update_scope(db, cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    _require_open_cycle(cycle)
    assigned_runner = None
    if payload.assigned_to_id is not None:
        _require_qa_assignment_manager(current_user)
        assigned_runner = _runner_or_404(
            db, payload.assigned_to_id, workspace_id=(cycle.origin_workspace_id or cycle.project.qa_workspace_id), project=cycle.project,
        )
    requested_ids = list(dict.fromkeys(payload.test_case_ids))
    already = set()
    # Only inspect requested IDs. The previous query loaded every testcase
    # already in a large cycle even when the user selected a single row.
    for id_batch in _in_batches(requested_ids):
        already.update(
            row[0] for row in db.query(models.TestExecution.test_case_id).filter(
                models.TestExecution.cycle_id == cycle_id,
                models.TestExecution.test_case_id.in_(id_batch),
            ).all()
        )
    # Do not put the whole UI selection into one IN clause: Oracle limits an
    # IN expression to 1,000 values (ORA-01795). Query bounded batches and
    # merge them into the same identity map used by the validation/creation
    # logic below. Eager-loading the approved version also prevents one lazy
    # SELECT per selected case during eligibility validation.
    selected_cases = []
    for id_batch in _in_batches(requested_ids):
        selected_cases.extend(
            db.query(models.TestCase)
            .options(joinedload(models.TestCase.current_approved_version))
            .filter(
                models.TestCase.project_id == cycle.project_id,
                models.TestCase.id.in_(id_batch),
            )
            .all()
        )
    selected_by_id = {case.id: case for case in selected_cases}
    missing = [case_id for case_id in requested_ids if case_id not in selected_by_id]
    if missing:
        raise HTTPException(404, f"{len(missing)} selected test case(s) were not found in this project")
    # SRS CYC-003 "Only approved, non-archived testcase versions... shall be
    # selectable for a new cycle item." A case whose approved baseline has
    # itself been Archived (TC-006) is excluded even though
    # current_approved_version_id is still set -- Archived is reachable only
    # from Approved, so this also naturally excludes a case that was never
    # approved at all (current_approved_version stays None). Recycled rejected
    # cases can retain an Approved baseline but must not enter new cycles.
    not_selectable = [
        case.test_case_key for case in selected_cases
        if case.is_deleted or not case.current_approved_version or case.current_approved_version.status != "Approved"
    ]
    if not_selectable:
        preview = ", ".join(not_selectable[:5])
        suffix = "…" if len(not_selectable) > 5 else ""
        raise HTTPException(
            400,
            f"Cannot add {len(not_selectable)} test case(s) because they are in the Recycle Bin or have no Approved, "
            f"non-archived version: {preview}{suffix}",
        )
    # Require the reason only when this request would actually expand the
    # scope. A harmless retry containing only already-present testcase IDs
    # stays idempotent and does not manufacture a misleading audit event.
    new_case_ids = [case_id for case_id in requested_ids if case_id not in already]
    scope_expansion_reason = (
        _scope_expansion_reason(db, cycle, payload.reason)
        if new_case_ids else None
    )
    created = []
    for case_id in requested_ids:
        if case_id in already:
            continue
        case = selected_by_id[case_id]
        obj = models.TestExecution(
            cycle_id=cycle_id, test_case_id=case_id, status="Not Executed",
            # SRS CYC-004 "Each cycle item shall store the exact
            # TestCaseVersion ID selected at the time it is added."
            pinned_version_id=case.current_approved_version_id,
            assigned_to_id=assigned_runner.id if assigned_runner else None,
            assigned_by_id=current_user.id if assigned_runner else None,
            assigned_at=models.now() if assigned_runner else None,
            # Scenario 1 self-remove fix -- see _execution_removal_block_
            # reason below for how this is used.
            added_by_id=current_user.id,
        )
        db.add(obj)
        created.append(obj)
        already.add(case_id)
    if assigned_runner and created:
        db.flush()
        for execution in created:
            reassignment.record_assignment_change(
                db, "TEST_EXECUTION", execution.id, "EXECUTION_RUNNER", current_user,
                [], [assigned_runner.id], "Assigned when added to test cycle",
            )
    assignment_actions = []
    for execution in created:
        action = models.ApprovalAction(
            entity_type="TEST_CASE", entity_id=execution.test_case_id, step_name="Test Cycle",
            actor_id=current_user.id, actor_role=current_user.roles_csv, decision="Added to Cycle",
            comments=(
                f"Added to {cycle.cycle_key} - {cycle.name}."
                + (f" Assigned to {assigned_runner.full_name}." if assigned_runner else "")
            ),
        )
        db.add(action)
        assignment_actions.append(action)
    if scope_expansion_reason and created:
        added_keys = [selected_by_id[execution.test_case_id].test_case_key for execution in created]
        preview = ", ".join(added_keys[:10])
        suffix = f" and {len(added_keys) - 10} more" if len(added_keys) > 10 else ""
        db.add(models.ApprovalAction(
            entity_type="TEST_CYCLE",
            entity_id=cycle.id,
            step_name="Testcase Scope",
            actor_id=current_user.id,
            actor_role=current_user.roles_csv,
            decision="Scope Expanded After Execution Started",
            comments=(
                f"Added {len(created)} approved testcase(s) as Not Executed without changing existing "
                f"attempts or evidence: {preview}{suffix}. Reason: {scope_expansion_reason}"
            ),
        ))
    if assigned_runner and created:
        email_notifications.queue_test_cycle_assignment_notification(
            db,
            action=assignment_actions[0],
            recipient=assigned_runner,
            cycle=cycle,
            test_cases=[selected_by_id[execution.test_case_id] for execution in created],
        )
    jobs.commit_or_flush(db)
    if not created:
        return []
    # Perf tuning (2026-08, reported directly: "if i have 3500 testcase
    # present, then it's allowing all in one go, then application going to
    # loading stage and though it's completing the process still getting
    # timeout error") -- this used to be `for obj in created: db.refresh(obj)`,
    # one individual SELECT per created row just to repopulate server-side
    # defaults after commit, PLUS response_model serialization then lazily
    # loaded test_case/assigned_to/assigned_by/executed_by/added_by/runs/
    # linked_defects on top of that (no eager-loading at all) -- for a
    # 3,500-testcase selection that was on the order of 3,500+ extra
    # queries, comfortably enough to blow past api.ts's request timeout even
    # though the transaction itself had already committed successfully
    # (matching what was reported: the add completes, but the UI times out
    # anyway). Replaced with one Oracle-safe batched requery using the same
    # eager-load set list_executions itself uses, so this response costs a
    # small constant number of queries regardless of selection size.
    created_ids = [obj.id for obj in created]
    refreshed = []
    for id_batch in _in_batches(created_ids):
        refreshed.extend(
            db.query(models.TestExecution)
            .options(*_LIST_EXECUTION_EAGER_LOADS)
            .filter(models.TestExecution.id.in_(id_batch))
            .all()
        )
    order = {execution_id: index for index, execution_id in enumerate(created_ids)}
    refreshed.sort(key=lambda execution: order[execution.id])
    return refreshed


@router.post("/cycles/{cycle_id}/executions/from-selection", response_model=schemas.TestExecutionAddResult)
def add_test_cases_from_server_selection(
    cycle_id: int,
    payload: schemas.TestExecutionCandidateSelection,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles(*_EXEC_ROLES)),
):
    """Add explicit IDs or every testcase matching the server-side filter.

    ``all_matching`` keeps the HTTP payload small and avoids Oracle's
    1,000-expression IN limit. Explicit exclusions are applied as several
    Oracle-safe NOT IN predicates before IDs are materialized server-side.
    """
    cycle = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    if payload.selection_mode == "all_matching":
        query = _cycle_candidate_query(db, cycle, payload.search, payload.priority, payload.test_type, payload.created_by_id)
        for id_batch in _in_batches(list(dict.fromkeys(payload.excluded_ids))):
            query = query.filter(~models.TestCase.id.in_(id_batch))
        selected_ids = [row[0] for row in query.with_entities(models.TestCase.id).order_by(models.TestCase.id).all()]
    else:
        selected_ids = list(dict.fromkeys(payload.test_case_ids))
    if not selected_ids:
        raise HTTPException(400, "Pick at least one test case")
    if len(selected_ids) > 500:
        user_id = current_user.id
        actor_workspace_id = getattr(current_user, "active_qa_workspace_id", None)
        assigned_to_id = payload.assigned_to_id
        scope_expansion_reason = payload.reason

        spec = make_spec("ADD_TESTCASES_TO_CYCLE", user_id, actor_workspace_id,
                         cycle_id=cycle_id, test_case_ids=selected_ids,
                         assigned_to_id=assigned_to_id, reason=scope_expansion_reason)
        job = jobs.enqueue(background_tasks, "ADD_TESTCASES_TO_CYCLE", user_id, spec)
        return {
            "created_count": 0,
            "skipped_count": 0,
            "job_id": job["id"],
            "status": job["status"],
        }
    created = add_test_cases_to_cycle(
        cycle_id,
        schemas.TestExecutionAdd(
            test_case_ids=selected_ids,
            assigned_to_id=payload.assigned_to_id,
            reason=payload.reason,
        ),
        db,
        current_user,
    )
    return {"created_count": len(created), "skipped_count": len(selected_ids) - len(created)}


@router.patch("/executions/{execution_id}/assign", response_model=schemas.TestExecutionOut)
def assign_execution(execution_id: int, payload: schemas.TestExecutionAssign,
                     db: Session = Depends(get_db),
                     current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    """QA runner management for one testcase slot in a
    cycle.

    2026-08 Reassignment CR, reported directly: "Everywhere the system
    provides an Assign option ... it must also provide a Reassign option
    ... Reassignment shall be permitted to: the current assignee, the
    Department Head of the department to which the current assignee
    belongs, or Admin users." Then, reported directly again: "for test
    execution reassignment of testcase can be perform by any QA user,
    otherwise it will be hectic for qa lead" -- unlike Functional/
    Performance tester and SAST/DAST analyst reassignment (which do apply
    the CR's narrower list, now widened back to also include QA_LEAD),
    runner reassignment here stays on the SAME broad gate as the first
    assignment (_require_qa_assignment_manager -- any Test Management
    execution-role member in an eligible department), for both first
    assignment and reassignment; a reason is still mandatory once the
    execution already has a runner. Deliberately covers explicit
    unassignment too, not just a hand-off to a named person, so the
    reason requirement can't be bypassed by unassigning and having someone
    else assign fresh."""
    obj = _execution_or_404(db, execution_id, lock=True)
    cycle = _get_cycle_or_404(db, obj.cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    _require_open_cycle(cycle)
    previous_id = obj.assigned_to_id
    previous_name = obj.assigned_to_name
    previous_assigned_at = obj.assigned_at
    is_reassignment = previous_id is not None
    _require_qa_assignment_manager(current_user)
    if is_reassignment:
        reassignment.require_reason(payload.reason)
    target = None
    if payload.assigned_to_id is not None:
        target = _runner_or_404(
            db, payload.assigned_to_id, workspace_id=(cycle.origin_workspace_id or cycle.project.qa_workspace_id), project=cycle.project,
        )
    obj.assigned_to_id = target.id if target else None
    obj.assigned_by_id = current_user.id
    obj.assigned_at = models.now()
    test_case_label = obj.test_case.test_case_key if obj.test_case else f"Testcase #{obj.test_case_id}"
    assignment_action = models.ApprovalAction(
        entity_type="TEST_CASE", entity_id=obj.test_case_id, step_name="Testcase Assignment",
        actor_id=current_user.id, actor_role=current_user.roles_csv,
        decision="Assigned" if target else "Unassigned",
        comments=(
            f"{test_case_label} "
            f"{'assigned to ' + target.full_name if target else 'unassigned'}"
            + (f" (previously {previous_name})" if previous_name else "")
        ),
    )
    db.add(assignment_action)
    if is_reassignment:
        reassignment.record_reassignment(
            db, "TEST_CASE", obj.test_case_id, current_user,
            previous_name or "Unassigned", target.full_name if target else "Unassigned", payload.reason,
            assignment_role="EXECUTION_RUNNER",
            previous_assignee_ids=[previous_id],
            new_assignee_ids=[target.id if target else None],
            previous_assigned_at=previous_assigned_at,
            assignment_entity_type="TEST_EXECUTION",
            assignment_entity_id=obj.id,
        )
    else:
        reassignment.record_assignment_change(
            db, "TEST_EXECUTION", obj.id, "EXECUTION_RUNNER", current_user,
            [previous_id], [target.id if target else None], payload.reason,
            previous_assigned_at=previous_assigned_at,
        )
    if target:
        email_notifications.queue_test_cycle_assignment_notification(
            db, action=assignment_action, recipient=target, cycle=cycle,
            test_cases=[obj.test_case],
        )
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/cycles/{cycle_id}/executions/bulk-assign", response_model=List[schemas.TestExecutionOut])
def bulk_assign_executions(cycle_id: int, payload: schemas.TestExecutionBulkAssign,
                           db: Session = Depends(get_db),
                           current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    """Atomically assign one runner to selected testcase slots in a cycle.

    2026-08 Reassignment CR, then reported directly again ("for test
    execution reassignment of testcase can be perform by any QA user,
    otherwise it will be hectic for qa lead") -- same broad
    _require_qa_assignment_manager gate for both first assignment and
    reassignment (see assign_execution's own docstring for the full
    reasoning); a reason is mandatory the moment any selected row already
    has a runner, checked per-row since a batch can freely mix currently-
    unassigned and currently-assigned executions.
    """
    cycle = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    _require_open_cycle(cycle)
    _require_qa_assignment_manager(current_user)

    execution_ids = list(dict.fromkeys(payload.execution_ids))
    if not execution_ids:
        raise HTTPException(400, "Select at least one testcase for bulk assignment")
    if len(execution_ids) > 100:
        raise HTTPException(400, "Bulk assignment supports at most 100 testcases at a time")
    target = _runner_or_404(
        db, payload.assigned_to_id, workspace_id=(cycle.origin_workspace_id or cycle.project.qa_workspace_id), project=cycle.project,
    )
    executions = db.query(models.TestExecution).filter(models.TestExecution.id.in_(execution_ids)).all()
    found_by_id = {execution.id: execution for execution in executions}
    missing = [str(execution_id) for execution_id in execution_ids if execution_id not in found_by_id]
    if missing:
        raise HTTPException(404, f"Execution record(s) not found: {', '.join(missing)}")
    wrong_cycle = [execution for execution in executions if execution.cycle_id != cycle_id]
    if wrong_cycle:
        raise HTTPException(400, "Every selected testcase must belong to the current Test Cycle")

    ordered = [found_by_id[execution_id] for execution_id in execution_ids]
    previously_assigned = [execution for execution in ordered if execution.assigned_to_id is not None]
    if previously_assigned:
        reassignment.require_reason(payload.reason)

    previous_names = {execution.id: execution.assigned_to_name for execution in ordered}
    previous_ids = {execution.id: execution.assigned_to_id for execution in ordered}
    previous_assigned_at = {execution.id: execution.assigned_at for execution in ordered}
    for execution in ordered:
        execution.assigned_to_id = target.id
        execution.assigned_by_id = current_user.id
        execution.assigned_at = models.now()
    labels = [
        execution.test_case.test_case_key if execution.test_case else f"Testcase #{execution.test_case_id}"
        for execution in ordered
    ]
    assignment_actions = []
    for execution, label in zip(ordered, labels):
        action = models.ApprovalAction(
            entity_type="TEST_CASE", entity_id=execution.test_case_id, step_name="Testcase Assignment",
            actor_id=current_user.id, actor_role=current_user.roles_csv, decision="Assigned",
            comments=f"{label} assigned to {target.full_name} in {cycle.cycle_key}.",
        )
        db.add(action)
        assignment_actions.append(action)
        if execution.id in {e.id for e in previously_assigned}:
            reassignment.record_reassignment(
                db, "TEST_CASE", execution.test_case_id, current_user,
                previous_names[execution.id] or "Unassigned", target.full_name, payload.reason,
                assignment_role="EXECUTION_RUNNER",
                previous_assignee_ids=[previous_ids[execution.id]],
                new_assignee_ids=[target.id],
                previous_assigned_at=previous_assigned_at[execution.id],
                assignment_entity_type="TEST_EXECUTION",
                assignment_entity_id=execution.id,
            )
        else:
            reassignment.record_assignment_change(
                db, "TEST_EXECUTION", execution.id, "EXECUTION_RUNNER", current_user,
                [previous_ids[execution.id]], [target.id], payload.reason,
                previous_assigned_at=previous_assigned_at[execution.id],
            )
    email_notifications.queue_test_cycle_assignment_notification(
        db, action=assignment_actions[0], recipient=target, cycle=cycle,
        test_cases=[execution.test_case for execution in ordered],
    )
    db.commit()
    for execution in ordered:
        db.refresh(execution)
    return ordered


@router.post("/executions/{execution_id}/upgrade-version", response_model=schemas.TestExecutionOut)
def upgrade_execution_version(execution_id: int, payload: schemas.TestExecutionVersionUpgrade,
                              db: Session = Depends(get_db),
                              current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    """SRS CYC-006 "An authorized user may upgrade an unexecuted cycle item
    to a newer approved version after reviewing a change summary. Executed
    items shall remain pinned." Rejected once any attempt exists (use
    versions-compare in test_repository.py to build the "change summary"
    the SRS describes -- this endpoint only performs the pin change itself
    once the caller has reviewed it)."""
    obj = _execution_or_404(db, execution_id, lock=True)
    cycle = _get_cycle_or_404(db, obj.cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    _require_open_cycle(cycle)
    if obj.runs:
        raise HTTPException(400, "This testcase has already been executed in this cycle -- its pinned version cannot change")
    target = db.get(models.TestCaseVersion, payload.target_version_id)
    if not target or target.test_case_id != obj.test_case_id:
        raise HTTPException(404, "Target version not found on this testcase")
    if target.status != "Approved":
        raise HTTPException(400, "Only an Approved version can be pinned to a cycle item")
    previous_label = obj.pinned_version_label
    obj.pinned_version_id = target.id
    db.add(models.ApprovalAction(
        entity_type="TEST_CASE", entity_id=obj.test_case_id, step_name="Version Upgrade",
        actor_id=current_user.id, actor_role=current_user.roles_csv, decision="Version Upgraded",
        comments=(
            f"{obj.test_case.test_case_key if obj.test_case else f'Testcase #{obj.test_case_id}'} "
            f"pinned version upgraded from {previous_label or 'none'} to {target.version}."
        ),
    ))
    db.commit()
    db.refresh(obj)
    return obj


@router.patch("/executions/{execution_id}", response_model=schemas.TestExecutionOut)
def update_execution(execution_id: int, payload: schemas.TestExecutionUpdate, db: Session = Depends(get_db),
                      current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    """Records a new execution attempt (see models.TestExecutionRun) --
    reported directly, this used to overwrite the row's own result in
    place, silently destroying any prior attempt (e.g. a Fail with attached
    evidence, once a later retest logged a Pass)."""
    obj = _execution_or_404(db, execution_id, lock=True)
    defect_key, _ = _validate_defect_values(payload.defect_id or "")
    _prepare_execution_update(db, obj, payload.status, current_user, defect_key)
    if payload.expected_run_version is not None and payload.expected_run_version != (obj.run_version or 0):
        raise HTTPException(
            409,
            "This testcase's result was updated by someone else since you loaded it. "
            "Refresh and try again.",
        )
    if defect_key and payload.status not in {"Fail", "Blocked"}:
        raise HTTPException(400, "A defect can only be linked when the latest attempt result is Fail or Blocked")
    run = _record_attempt(db, obj, payload.status, payload.actual_result,
                          payload.test_run_artifacts, defect_key or None, current_user)
    if defect_key:
        _link_defect(db, run, schemas.TestRunDefectCreate(defect_key=defect_key), current_user)
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/cycles/{cycle_id}/executions/bulk-result", response_model=List[schemas.TestExecutionOut])
def bulk_update_execution_results(
    cycle_id: int,
    payload: schemas.TestExecutionBulkResult,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles(*_EXEC_ROLES)),
):
    """Record one new attempt on every selected testcase slot.

    Validation deliberately finishes for the whole selection before the
    first attempt is written. This prevents a bulk action from reporting a
    vague partial success and preserves the existing assigned-runner rule.
    """
    cycle = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    _require_open_cycle(cycle)
    _require_cycle_in_progress(cycle)
    execution_ids = list(dict.fromkeys(payload.execution_ids))
    if not execution_ids:
        raise HTTPException(400, "Select at least one testcase for bulk execution")
    if len(execution_ids) > 100:
        raise HTTPException(400, "Bulk execution supports at most 100 testcases at a time")
    operation_label = "Bulk execution" if len(execution_ids) > 1 else "Execution"

    from ..constants import TEST_EXECUTION_STATUSES
    if payload.status not in TEST_EXECUTION_STATUSES or payload.status == "Not Executed":
        raise HTTPException(400, f"'{payload.status}' is not a recordable execution result")

    actual_result = (payload.actual_result or "").strip()
    artifacts = (payload.test_run_artifacts or "").strip()
    if len(actual_result) > 10000:
        raise HTTPException(400, "Actual Result cannot exceed 10,000 characters")
    if len(artifacts) > 255:
        raise HTTPException(400, "Test Run Artifacts cannot exceed 255 characters")
    defect_key, defect_url = _validate_defect_values(payload.defect_id or "", payload.defect_url or "")
    if defect_key and payload.status not in {"Fail", "Blocked"}:
        raise HTTPException(400, "A defect can only be linked when the latest attempt result is Fail or Blocked")
    if not defect_key and any((value or "").strip() for value in (
        payload.defect_url, payload.defect_title, payload.defect_status, payload.defect_notes,
    )):
        raise HTTPException(400, "Enter a Defect Key before adding defect URL, title, status, or notes")
    if len((payload.defect_title or "").strip()) > 255:
        raise HTTPException(400, "Defect title cannot exceed 255 characters")
    if len((payload.defect_status or "").strip()) > 40:
        raise HTTPException(400, "Defect status cannot exceed 40 characters")
    if len((payload.defect_notes or "").strip()) > 5000:
        raise HTTPException(400, "Defect notes cannot exceed 5,000 characters")

    # Lock in stable order before validating any selected slot. This prevents
    # two workers allocating the same attempt number or checking stale results.
    found = (db.query(models.TestExecution).filter(models.TestExecution.id.in_(execution_ids))
             .order_by(models.TestExecution.id).populate_existing().with_for_update().all())
    found_by_id = {execution.id: execution for execution in found}
    missing = [str(execution_id) for execution_id in execution_ids if execution_id not in found_by_id]
    if missing:
        raise HTTPException(
            404,
            f"{operation_label} stopped. Execution record(s) not found: {', '.join(missing)}. No attempt was saved.",
        )
    wrong_cycle = [
        execution for execution in found
        if execution.cycle_id != cycle_id
    ]
    if wrong_cycle:
        labels = ", ".join(
            execution.test_case.test_case_key if execution.test_case else f"Execution #{execution.id}"
            for execution in wrong_cycle
        )
        raise HTTPException(
            400,
            f"{operation_label} stopped. These testcases do not belong to the selected cycle: {labels}. No attempt was saved.",
        )

    ordered = [found_by_id[execution_id] for execution_id in execution_ids]
    unpinned = [
        execution.test_case.test_case_key if execution.test_case else f"Execution #{execution.id}"
        for execution in ordered if not execution.pinned_version_id
    ]
    if unpinned:
        raise HTTPException(
            400,
            f"{operation_label} stopped. These testcase slots have no pinned approved version: "
            f"{', '.join(unpinned)}. No attempt was saved.",
        )

    # Same lock/gate as the single-execution path (see
    # _execution_status_gate) -- checked for the whole selection up front so
    # a bulk status change either fully succeeds or saves nothing.
    defect_blocked = []
    for execution in ordered:
        violation = _execution_status_gate(db, execution.id, payload.status, defect_key)
        if violation:
            label = execution.test_case.test_case_key if execution.test_case else f"Execution #{execution.id}"
            defect_blocked.append(f"{label} ({violation})")
    if defect_blocked:
        raise HTTPException(
            400,
            f"{operation_label} stopped. Cannot record '{payload.status}': "
            f"{'; '.join(defect_blocked)}. No attempt was saved.",
        )

    if not current_user.has_role(Role.ADMIN):
        unassigned = [
            execution.test_case.test_case_key if execution.test_case else f"Execution #{execution.id}"
            for execution in ordered if not execution.assigned_to_id
        ]
        assigned_elsewhere = [
            f"{execution.test_case.test_case_key if execution.test_case else f'Execution #{execution.id}'} "
            f"({execution.assigned_to_name or 'another runner'})"
            for execution in ordered
            if execution.assigned_to_id and execution.assigned_to_id != current_user.id
        ]
        blockers = []
        if unassigned:
            blockers.append(f"unassigned: {', '.join(unassigned)}")
        if assigned_elsewhere:
            blockers.append(f"assigned to another runner: {', '.join(assigned_elsewhere)}")
        if blockers:
            raise HTTPException(
                403,
                f"{operation_label} stopped because only the assigned runner can record an attempt; "
                + "; ".join(blockers)
                + ". Reassign those testcases or select only your assignments. No attempt was saved.",
            )

    for execution in ordered:
        run = _record_attempt(
            db, execution, payload.status, actual_result or None, artifacts or None,
            defect_key or None, current_user,
        )
        if defect_key:
            _link_defect(db, run, schemas.TestRunDefectCreate(
                defect_key=defect_key,
                defect_url=defect_url or None,
                title=(payload.defect_title or "").strip() or None,
                defect_status=(payload.defect_status or "").strip() or None,
                notes=(payload.defect_notes or "").strip() or None,
            ), current_user)

    try:
        db.commit()
    except Exception:
        db.rollback()
        raise
    for execution in ordered:
        db.refresh(execution)
    return ordered


@router.post("/executions/{execution_id}/rich-result", response_model=schemas.TestExecutionOut)
def update_rich_execution_result(
    execution_id: int,
    status_value: str = Form(..., alias="status"),
    actual_result: str = Form(""),
    test_run_artifacts: str = Form(""),
    defect_id: str = Form(""),
    defect_url: str = Form(""),
    defect_title: str = Form(""),
    defect_status: str = Form(""),
    defect_notes: str = Form(""),
    files: List[UploadFile] = File(default=[]),
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles(*_EXEC_ROLES)),
):
    """Save formatted Actual Result text and pasted/uploaded screenshots as a
    new execution attempt (see models.TestExecutionRun) -- reported
    directly, this used to overwrite the row's own result in place,
    silently destroying any prior attempt (e.g. a Fail with attached
    evidence, once a later retest logged a Pass).

    Text is retained as safe Markdown; images are authenticated documents
    linked to this exact attempt (not the execution slot as a whole), never
    embedded as unbounded base64 data.
    """
    obj = _execution_or_404(db, execution_id, lock=True)
    defect_key, validated_defect_url = _validate_defect_values(defect_id, defect_url)
    _prepare_execution_update(db, obj, status_value, current_user, defect_key)
    result_text = actual_result.strip()
    if len(result_text) > 10000:
        raise HTTPException(400, "Actual Result cannot exceed 10,000 characters")
    _validate_result_evidence(files)
    if defect_key and status_value not in {"Fail", "Blocked"}:
        raise HTTPException(400, "A defect can only be linked when the latest attempt result is Fail or Blocked")
    if not defect_key and any(value.strip() for value in (defect_url, defect_title, defect_notes)):
        raise HTTPException(400, "Enter a Defect Key before adding defect URL, title, or notes")
    run = _record_attempt(db, obj, status_value, result_text or None,
                           test_run_artifacts.strip() or None, defect_key or None, current_user)
    if defect_key:
        _link_defect(db, run, schemas.TestRunDefectCreate(
            defect_key=defect_key, defect_url=validated_defect_url or None,
            title=defect_title or None, defect_status=defect_status or None,
            notes=defect_notes or None,
        ), current_user)
    if files:
        # save_documents commits the pending execution/run update and
        # document metadata in the same DB transaction after the files are
        # written. Keyed by this specific attempt's own id (run.id), not
        # the execution slot's id, so each attempt's evidence stays separate.
        doc_store.save_documents(
            db, _RESULT_IMAGE_MODULE, run.id, f"execution-{obj.id}-attempt-{run.attempt_no}", files, current_user.id
        )
    else:
        db.commit()
    db.refresh(obj)
    return obj


@router.get("/executions/{execution_id}/runs", response_model=List[schemas.TestExecutionRunOut])
def list_execution_runs(execution_id: int, db: Session = Depends(get_db),
                        current_user: models.User = Depends(get_current_user)):
    """Full attempt-by-attempt history for this test case's slot in this
    cycle, oldest first -- see models.TestExecutionRun."""
    obj = _execution_or_404(db, execution_id)
    _require_execution_visibility(db, obj, current_user)
    return (db.query(models.TestExecutionRun).filter_by(execution_id=obj.id)
            .order_by(models.TestExecutionRun.attempt_no).all())


@router.post("/executions/{execution_id}/runs/{run_id}/defects", response_model=schemas.TestRunDefectOut)
def add_run_defect(execution_id: int, run_id: int, payload: schemas.TestRunDefectCreate,
                   db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    obj = _execution_or_404(db, execution_id, lock=True)
    cycle = _get_cycle_or_404(db, obj.cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    _require_open_cycle(cycle)
    _require_assigned_runner(obj, current_user)
    run = _run_or_404(db, obj, run_id)
    latest_run = _latest_run_or_404(db, obj)
    if run.id != latest_run.id:
        raise HTTPException(400, "Defects can only be linked to the latest execution attempt")
    if run.status not in {"Fail", "Blocked"}:
        raise HTTPException(400, "A defect can only be linked when the latest attempt result is Fail or Blocked")
    defect = _link_defect(db, run, payload, current_user)
    db.commit()
    db.refresh(defect)
    return defect


def _governed_defect_linked_to_execution(
    db: Session,
    execution_id: int,
    defect_key: str,
) -> "models.Defect | None":
    """Return the governed defect behind one internal attempt link.

    ``TestRunDefect`` also stores genuinely external references, so matching
    by key alone is not enough.  An attempt link is internal only when the
    governed defect is still linked to this exact execution through either
    its primary FK or the additional-execution trace table.
    """
    return (
        db.query(models.Defect)
        .filter(models.Defect.defect_key == defect_key)
        .filter(or_(
            models.Defect.execution_id == execution_id,
            models.Defect.execution_links.any(
                models.DefectExecutionLink.execution_id == execution_id,
            ),
        ))
        .populate_existing()
        .with_for_update()
        .one_or_none()
    )


def _detach_governed_defect_execution(
    db: Session,
    defect: models.Defect,
    execution: models.TestExecution,
    current_user: models.User,
) -> None:
    """Detach one execution while preserving the governed defect itself.

    Additional traces are independent rows and can simply be removed.  If
    the execution is the primary trace, the oldest additional trace (lowest
    link id) is promoted so a still-linked defect never loses the primary
    cycle/project context used by visibility, ownership, and workflow.
    ``DefectTestCaseLink`` is deliberately retained: it can be an explicit
    testcase-level trace rather than one derived solely from this execution.
    """
    old_cycle_id = defect.cycle_id
    old_test_case_id = defect.primary_test_case_id
    promoted_execution_id = None

    if defect.execution_id == execution.id:
        # Oracle rejects FOR UPDATE when SQLAlchemy's .first() adds
        # FETCH FIRST 1 ROWS ONLY (ORA-02014). Lock the small, ordered set of
        # remaining trace rows without a row-limit clause, then promote the
        # first one in Python. Locking all candidates also serializes two
        # concurrent unlink/promote requests deterministically.
        promotion_candidates = (
            db.query(models.DefectExecutionLink)
            .filter(
                models.DefectExecutionLink.defect_id == defect.id,
                models.DefectExecutionLink.execution_id != execution.id,
            )
            .order_by(models.DefectExecutionLink.id.asc())
            .with_for_update()
            .all()
        )
        promoted_link = promotion_candidates[0] if promotion_candidates else None
        if promoted_link:
            promoted = (
                db.query(models.TestExecution)
                .filter_by(id=promoted_link.execution_id)
                .populate_existing()
                .with_for_update()
                .one_or_none()
            )
            if not promoted:
                raise HTTPException(
                    409,
                    "The defect's remaining execution link is no longer valid. Refresh and try again.",
                )
            defect.execution_id = promoted.id
            defect.cycle_id = promoted.cycle_id
            defect.primary_test_case_id = promoted.test_case_id
            promoted_execution_id = promoted.id
            db.delete(promoted_link)
        else:
            defect.execution_id = None
            defect.cycle_id = None
            defect.primary_test_case_id = None
    else:
        additional_link = (
            db.query(models.DefectExecutionLink)
            .filter_by(defect_id=defect.id, execution_id=execution.id)
            .with_for_update()
            .one_or_none()
        )
        if not additional_link:
            raise HTTPException(409, "The governed defect link changed. Refresh and try again.")
        db.delete(additional_link)

    promotion_note = (
        f" Promoted execution #{promoted_execution_id} as the primary trace."
        if promoted_execution_id else ""
    )
    db.add(models.ApprovalAction(
        entity_type="DEFECT", entity_id=defect.id,
        step_name="Traceability",
        actor_id=current_user.id, actor_role=current_user.roles_csv,
        decision="Execution Unlinked",
        comments=(
            f"Unlinked {defect.defect_key} from execution #{execution.id} "
            f"(cycle #{execution.cycle_id}, testcase #{execution.test_case_id}; "
            f"previous primary cycle/testcase #{old_cycle_id or '—'}/#{old_test_case_id or '—'})."
            f"{promotion_note}"
        ),
    ))


def _unlink_attempt_defect(
    db: Session,
    execution: models.TestExecution,
    run: models.TestExecutionRun,
    attempt_defect: models.TestRunDefect,
    current_user: models.User,
) -> "models.Defect | None":
    """Remove one attempt link and, when internal, its governed trace."""
    # Internal links are written by defects.py with a portal-relative URL.
    # External-link validation accepts only absolute http(s) URLs, so this
    # marker prevents a coincidentally identical external key from detaching
    # a governed defect that is also linked to this execution.
    internal_reference = (attempt_defect.defect_url or "").startswith("/defects")
    governed = (
        _governed_defect_linked_to_execution(
            db, execution.id, attempt_defect.defect_key,
        )
        if internal_reference else None
    )
    if governed:
        remaining_internal_link = db.query(models.TestRunDefect.id).join(models.TestExecutionRun).filter(
            models.TestExecutionRun.execution_id == execution.id,
            models.TestRunDefect.id != attempt_defect.id,
            models.TestRunDefect.defect_key == attempt_defect.defect_key,
            models.TestRunDefect.defect_url.startswith('/defects'),
        ).first()
        if not remaining_internal_link:
            _detach_governed_defect_execution(db, governed, execution, current_user)

    # ``defect_id`` predates structured TestRunDefect rows and mirrors only
    # a free-text key.  Keep it in sync when it represents the selected link.
    if run.defect_id == attempt_defect.defect_key:
        run.defect_id = None
    latest_run_id = (
        db.query(models.TestExecutionRun.id)
        .filter(models.TestExecutionRun.execution_id == execution.id)
        .order_by(
            models.TestExecutionRun.attempt_no.desc(),
            models.TestExecutionRun.id.desc(),
        )
        .limit(1)
        .scalar()
    )
    if latest_run_id == run.id and execution.defect_id == attempt_defect.defect_key:
        execution.defect_id = None

    db.add(models.ApprovalAction(
        entity_type="TEST_CASE", entity_id=execution.test_case_id,
        step_name=f"Attempt #{run.attempt_no} Defect",
        actor_id=current_user.id, actor_role=current_user.roles_csv,
        decision="Defect Unlinked",
        comments=(
            f"Unlinked defect {attempt_defect.defect_key} from execution "
            f"attempt #{run.attempt_no}."
        ),
    ))
    db.delete(attempt_defect)
    return governed


def _reload_execution_for_response(db: Session, execution_id: int) -> models.TestExecution:
    """Reload every TestExecutionOut relationship after a link mutation."""
    return (
        db.query(models.TestExecution)
        .options(*_LIST_EXECUTION_EAGER_LOADS)
        .filter(models.TestExecution.id == execution_id)
        .populate_existing()
        .one()
    )


@router.patch('/executions/{execution_id}/runs/{run_id}/defects/{defect_id}', response_model=schemas.TestExecutionOut)
def update_external_run_defect(execution_id: int, run_id: int, defect_id: int,
                               payload: schemas.TestRunDefectStatusUpdate,
                               db: Session = Depends(get_db),
                               current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    obj = _execution_or_404(db, execution_id, lock=True)
    cycle = _get_cycle_or_404(db, obj.cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    _require_open_cycle(cycle)
    _require_assigned_runner(obj, current_user)
    _run_or_404(db, obj, run_id)
    link = db.query(models.TestRunDefect).filter_by(id=defect_id, run_id=run_id).populate_existing().one_or_none()
    if not link:
        raise HTTPException(404, 'Defect link not found on this attempt')
    if (link.defect_url or '').startswith('/defects'):
        raise HTTPException(400, 'Update governed defect status through Defect Management')
    if 'expected_status' in payload.model_fields_set and link.defect_status != payload.expected_status:
        raise HTTPException(409, 'This external defect status changed. Refresh before updating it')
    if link.defect_status != payload.defect_status:
        previous = link.defect_status or 'Open'
        link.defect_status = payload.defect_status
        db.add(models.ApprovalAction(
            entity_type='TEST_CASE', entity_id=obj.test_case_id, step_name='External Defect Status',
            actor_id=current_user.id, actor_role=current_user.roles_csv, decision='External Defect Status Updated',
            comments=f'{link.defect_key} on execution #{obj.id}, attempt #{link.run.attempt_no}: '
                     f'{previous} → {payload.defect_status}. Reason: {payload.reason}',
        ))
        db.commit()
    return _reload_execution_for_response(db, obj.id)


@router.delete(
    "/executions/{execution_id}/runs/{run_id}/defects/{defect_id}",
    response_model=schemas.TestExecutionOut,
)
def remove_run_defect(execution_id: int, run_id: int, defect_id: int,
                      db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    obj = _execution_or_404(db, execution_id, lock=True)
    cycle = _get_cycle_or_404(db, obj.cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    _require_open_cycle(cycle)
    run = _run_or_404(db, obj, run_id)
    attempt_defect = (
        db.query(models.TestRunDefect)
        .filter_by(id=defect_id, run_id=run.id)
        .with_for_update()
        .one_or_none()
    )
    if not attempt_defect:
        raise HTTPException(404, "Defect link not found")
    if not (
        current_user.has_role(Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA)
        or attempt_defect.linked_by_id == current_user.id
    ):
        raise HTTPException(
            403,
            "Only the person who linked this defect, a QA Lead Group member, or an Administrator can remove it",
        )
    _unlink_attempt_defect(db, obj, run, attempt_defect, current_user)
    db.commit()
    return _reload_execution_for_response(db, obj.id)


@router.get("/executions/{execution_id}/runs/{run_id}/images", response_model=List[schemas.RequestDocumentOut])
def list_run_images(execution_id: int, run_id: int, db: Session = Depends(get_db),
                    current_user: models.User = Depends(get_current_user)):
    obj = _execution_or_404(db, execution_id)
    _require_execution_visibility(db, obj, current_user)
    run = _run_or_404(db, obj, run_id)
    return doc_store.list_documents(db, _RESULT_IMAGE_MODULE, run.id)


@router.get("/executions/{execution_id}/runs/{run_id}/images/{document_id}/download")
def download_run_image(execution_id: int, run_id: int, document_id: int, db: Session = Depends(get_db),
                       current_user: models.User = Depends(get_current_user)):
    obj = _execution_or_404(db, execution_id)
    _require_execution_visibility(db, obj, current_user)
    run = _run_or_404(db, obj, run_id)
    document = doc_store.get_document_or_404(db, _RESULT_IMAGE_MODULE, run.id, document_id)
    path = doc_store.full_path(document)
    if not os.path.exists(path):
        raise HTTPException(404, "Actual Result image is missing from storage")
    return FileResponse(path, filename=document.file_name, media_type=document.content_type or "application/octet-stream")


@router.delete("/executions/{execution_id}/runs/{run_id}/images/{document_id}")
def delete_run_image(execution_id: int, run_id: int, document_id: int, db: Session = Depends(get_db),
                     current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    obj = _execution_or_404(db, execution_id)
    cycle = _get_cycle_or_404(db, obj.cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    _require_open_cycle(cycle)
    run = _run_or_404(db, obj, run_id)
    document = doc_store.get_document_or_404(db, _RESULT_IMAGE_MODULE, run.id, document_id)
    if not doc_store.can_delete_document(document, current_user):
        raise HTTPException(403, "Only the person who uploaded this image or an Administrator can delete it")
    doc_store.delete_document(db, document)
    return {"ok": True}


# ---- Backward-compatible "current result images" endpoints -- these now
# resolve to the LATEST attempt's evidence (see _latest_run_or_404), since
# result-recording itself moved from "the one and only result" to
# "attempt N of the history below" (models.TestExecutionRun). Prefer the
# /runs/{run_id}/images endpoints above for browsing a *specific* attempt's
# evidence instead of just the newest one. ----
@router.get("/executions/{execution_id}/result-images", response_model=List[schemas.RequestDocumentOut])
def list_result_images(execution_id: int, db: Session = Depends(get_db),
                       current_user: models.User = Depends(get_current_user)):
    obj = _execution_or_404(db, execution_id)
    _require_execution_visibility(db, obj, current_user)
    run = (db.query(models.TestExecutionRun).filter_by(execution_id=obj.id)
           .order_by(models.TestExecutionRun.attempt_no.desc()).first())
    if not run:
        return []
    return doc_store.list_documents(db, _RESULT_IMAGE_MODULE, run.id)


@router.get("/executions/{execution_id}/result-images/{document_id}/download")
def download_result_image(execution_id: int, document_id: int, db: Session = Depends(get_db),
                          current_user: models.User = Depends(get_current_user)):
    obj = _execution_or_404(db, execution_id)
    _require_execution_visibility(db, obj, current_user)
    run = _latest_run_or_404(db, obj)
    document = doc_store.get_document_or_404(db, _RESULT_IMAGE_MODULE, run.id, document_id)
    path = doc_store.full_path(document)
    if not os.path.exists(path):
        raise HTTPException(404, "Actual Result image is missing from storage")
    return FileResponse(path, filename=document.file_name, media_type=document.content_type or "application/octet-stream")


@router.delete("/executions/{execution_id}/result-images/{document_id}")
def delete_result_image(execution_id: int, document_id: int, db: Session = Depends(get_db),
                        current_user: models.User = Depends(require_roles(*_EXEC_ROLES))):
    obj = _execution_or_404(db, execution_id)
    cycle = _get_cycle_or_404(db, obj.cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    require_can_execute_project(db, cycle.project_id, current_user)
    _require_open_cycle(cycle)
    run = _latest_run_or_404(db, obj)
    document = doc_store.get_document_or_404(db, _RESULT_IMAGE_MODULE, run.id, document_id)
    if not doc_store.can_delete_document(document, current_user):
        raise HTTPException(403, "Only the person who uploaded this image or an Administrator can delete it")
    doc_store.delete_document(db, document)
    return {"ok": True}


@router.delete("/executions/{execution_id}")
def remove_execution(execution_id: int, db: Session = Depends(get_db),
                      current_user: models.User = Depends(
                          require_roles(Role.QA_ENGINEER, Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA))):
    """Removes a test case from a cycle entirely (not the same as recording
    a result) -- e.g. it was added by mistake.

    2026-08 -- reported directly, refined by Scenario 1: QA Lead Group may
    always remove a not-yet-executed slot; a plain QA_ENGINEER may only
    remove one they personally added to the cycle (TestExecution.
    added_by_id), and only before it's been executed. Once a slot has any
    recorded attempt, only an Administrator may remove it, regardless of who
    added it or QA Lead standing -- see _execution_removal_block_reason's
    own docstring for the full priority order."""
    obj = db.get(models.TestExecution, execution_id)
    if not obj:
        raise HTTPException(404, "Execution not found")
    cycle = _get_cycle_or_404(db, obj.cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    _require_open_cycle(cycle)
    _require_can_remove_execution(obj, current_user)
    # Polymorphic documents have no FK back to TestExecution/TestExecutionRun,
    # so remove the protected files and their metadata explicitly rather than
    # orphaning screenshots when the execution itself is deliberately
    # removed -- every attempt's own evidence (models.TestExecutionRun), not
    # just the legacy execution-keyed slot from before per-attempt history
    # existed.
    for run in obj.runs:
        for document in doc_store.list_documents(db, _RESULT_IMAGE_MODULE, run.id):
            doc_store.delete_document(db, document)
    for document in doc_store.list_documents(db, _RESULT_IMAGE_MODULE, obj.id):
        doc_store.delete_document(db, document)
    db.delete(obj)
    db.commit()
    return {"ok": True}


@router.post("/cycles/{cycle_id}/executions/bulk-remove", response_model=schemas.TestExecutionBulkRemoveResult)
def bulk_remove_executions(
    cycle_id: int,
    payload: schemas.TestExecutionBulkRemove,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(require_roles(Role.QA_ENGINEER, Role.QA_LEAD, Role.CHIEF_MANAGER_QA, Role.AGM_QA)),
):
    """Remove several testcase slots, their attempts, linked defects and
    evidence metadata from one cycle as one governed database transaction.

    2026-08 -- reported directly, refined by Scenario 1: same per-execution
    eligibility as remove_execution above (see _execution_removal_block_
    reason) -- QA Lead Group may remove any not-yet-executed slot, a plain
    QA_ENGINEER only one they personally added, Admin always. Any selected
    slot the caller isn't eligible to remove stops the WHOLE batch below
    (all-or-nothing, matching this codebase's established atomic
    bulk-endpoint convention -- see _selected_project_cases in
    test_repository.py for the same pattern; the frontend is expected to
    have already filtered the selection down to what it knows is eligible,
    same "safety net, not primary UX path" reasoning used throughout). Files
    are unlinked only after the database commit succeeds, so a failed
    transaction cannot leave retained rows pointing at evidence that was
    already destroyed.
    """
    _require_qa_assignment_manager(current_user)
    cycle = _get_cycle_or_404(db, cycle_id)
    _require_cycle_visibility(db, cycle, current_user)
    _require_active_project(db, cycle.project_id)
    _require_open_cycle(cycle)
    execution_ids = list(dict.fromkeys(payload.execution_ids))
    if not execution_ids:
        raise HTTPException(400, "Select at least one testcase to remove from the cycle")
    if len(execution_ids) > 100:
        raise HTTPException(400, "Bulk removal supports at most 100 testcases at a time")
    operation_label = "Bulk removal" if len(execution_ids) > 1 else "Removal"

    found = db.query(models.TestExecution).filter(models.TestExecution.id.in_(execution_ids)).all()
    found_by_id = {execution.id: execution for execution in found}
    missing = [str(execution_id) for execution_id in execution_ids if execution_id not in found_by_id]
    if missing:
        raise HTTPException(
            404,
            f"{operation_label} stopped. Execution record(s) not found: {', '.join(missing)}. Nothing was removed.",
        )
    ordered = [found_by_id[execution_id] for execution_id in execution_ids]
    wrong_cycle = [execution for execution in ordered if execution.cycle_id != cycle_id]
    if wrong_cycle:
        labels = ", ".join(
            execution.test_case.test_case_key if execution.test_case else f"Execution #{execution.id}"
            for execution in wrong_cycle
        )
        raise HTTPException(
            400,
            f"{operation_label} stopped. These testcases do not belong to the selected cycle: {labels}. Nothing was removed.",
        )
    ineligible = [
        (execution, reason) for execution in ordered
        if (reason := _execution_removal_block_reason(execution, current_user))
    ]
    if ineligible:
        labels = ", ".join(
            execution.test_case.test_case_key if execution.test_case else f"Execution #{execution.id}"
            for execution, _reason in ineligible[:5]
        )
        suffix = f" and {len(ineligible) - 5} more" if len(ineligible) > 5 else ""
        raise HTTPException(
            403,
            f"{operation_label} stopped. These testcase(s) cannot be removed by you right now: {labels}{suffix}. "
            "Nothing was removed.",
        )

    removed_keys = [
        execution.test_case.test_case_key if execution.test_case else f"Testcase #{execution.test_case_id}"
        for execution in ordered
    ]
    # Capture cascade impact before deleting the execution rows. The result
    # response reports this value after commit, when the ORM collections may
    # already be expired/deleted.
    removed_attempt_count = sum(len(execution.runs) for execution in ordered)
    documents_by_id = {}
    for execution in ordered:
        # Current evidence belongs to individual TestExecutionRun rows. The
        # execution-id lookup also includes screenshots created by the older
        # pre-attempt implementation. De-duplicate because numeric ids from
        # those two namespaces can coincide.
        for run in execution.runs:
            for document in doc_store.list_documents(db, _RESULT_IMAGE_MODULE, run.id):
                documents_by_id[document.id] = document
        for document in doc_store.list_documents(db, _RESULT_IMAGE_MODULE, execution.id):
            documents_by_id[document.id] = document

    file_paths = [doc_store.full_path(document) for document in documents_by_id.values()]
    for execution, test_case_key in zip(ordered, removed_keys):
        db.add(models.ApprovalAction(
            entity_type="TEST_CASE", entity_id=execution.test_case_id, step_name="Test Cycle",
            actor_id=current_user.id, actor_role=current_user.roles_csv, decision="Removed from Cycle",
            comments=f"{test_case_key} removed from {cycle.cycle_key} - {cycle.name}.",
        ))
    for document in documents_by_id.values():
        db.delete(document)
    for execution in ordered:
        db.delete(execution)
    try:
        db.commit()
    except Exception:
        db.rollback()
        raise

    # Database state is authoritative. A stale/missing file is harmless and
    # must not turn a successfully committed removal into a false API error.
    for path in file_paths:
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass
    return schemas.TestExecutionBulkRemoveResult(
        removed_count=len(ordered),
        removed_execution_ids=execution_ids,
        removed_test_case_keys=removed_keys,
        removed_attempt_count=removed_attempt_count,
        removed_evidence_count=len(documents_by_id),
    )
