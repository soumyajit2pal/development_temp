import React, { ReactNode, Suspense, useEffect, useState } from 'react'
import { Routes, Route, Navigate, Link, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from './context/AuthContext'
import Layout from './components/Layout'
import WorkspaceTransition from './components/WorkspaceTransition'
import { internalNavigationPath } from './requestNavigation'
import RequestViewer from './components/RequestViewer'
import DepartmentPrompt from './components/DepartmentPrompt'
import EmailCompletionPrompt from './components/EmailCompletionPrompt'
import { LoginNoticeCoordinator, MaintenanceWindowBanner, MaintenanceWindowProvider } from './components/MaintenanceWindowNotice'
import { UserOut } from './types'
import { hasWorkspaceRole, isViewOnly, uniqueWorkspaceAccess } from './constants'
import { ADMIN_ACCESS_DENIED_EVENT, HttpError, api } from './api'
import { lazyModule } from './lazyModule'

// Cross-cutting pages -- not owned by any one domain module (the QA Request
// gateway feeds every module, the Dashboard summarizes across all of
// them, Login is pre-auth). Loaded eagerly since they're on the app's
// default/most-common paths.
import Login from './Login'
import Dashboard from './Dashboard'
import QARequests from './QARequests'
import ModuleBoundary from './components/ModuleBoundary'
import ApiActivityIndicator from './components/ApiActivityIndicator'
import GlobalButtonTooltips from './components/GlobalButtonTooltips'
import GlobalToastCenter from './components/GlobalToastCenter'
import AppVersion from './components/AppVersion'

const Help = lazyModule(() => import('./Help'), { displayName: 'Help' })

// The 4 domain modules (Functional / Security / Specialised Testing /
// Governance) live under src/modules/<group>/ as plain local folders in
// this same app/build -- not separately deployed. `lazyModule()` still
// code-splits each into its own chunk (so e.g. visiting only "/sast" never
// downloads the Governance or Specialised Testing code), it's just resolved from
// this repo's own filesystem at build time instead of fetched from another
// origin's remoteEntry.js at runtime. This project previously used real
// Module Federation (separate images/deploys per module) and reverted to
// this single-app model -- see README "Frontend architecture" for why.
const Functional = lazyModule(() => import('./modules/functional/Functional'), { displayName: 'Functional' })
const SAST = lazyModule(() => import('./modules/security/SAST'), { displayName: 'SAST' })
const DAST = lazyModule(() => import('./modules/security/DAST'), { displayName: 'DAST' })
const Suppression = lazyModule(() => import('./modules/security/Suppression'), { displayName: 'Suppression' })
const Performance = lazyModule(() => import('./modules/specialised-testing/Performance'), { displayName: 'Performance' })
const SignOff = lazyModule(() => import('./modules/governance/SignOff'), { displayName: 'SignOff' })
const SignatureVerification = lazyModule(() => import('./modules/governance/SignatureVerification'), { displayName: 'SignatureVerification' })
const PendingApprovals = lazyModule(() => import('./modules/governance/PendingApprovals'), { displayName: 'PendingApprovals' })
const Approvals = lazyModule(() => import('./modules/governance/Approvals'), { displayName: 'Approvals' })
const Reports = lazyModule(() => import('./modules/governance/Reports'), { displayName: 'Reports' })
const Admin = lazyModule(() => import('./modules/governance/Admin'), { displayName: 'Admin' })
const DepartmentAdmin = lazyModule(() => import('./modules/governance/DepartmentAdmin'), { displayName: 'DepartmentAdmin' })
const ParentWorkspaceAdmin = lazyModule(() => import('./modules/governance/ParentWorkspaceAdmin'), { displayName: 'ParentWorkspaceAdmin' })
const AuditLog = lazyModule(() => import('./modules/governance/AuditLog'), { displayName: 'AuditLog' })
const ChecklistConfig = lazyModule(() => import('./modules/governance/ChecklistConfig'), { displayName: 'ChecklistConfig' })
const RequestTypeConfig = lazyModule(() => import('./modules/governance/RequestTypeConfig'), { displayName: 'RequestTypeConfig' })
const DocumentPortal = lazyModule(() => import('./modules/governance/DocumentPortal'), { displayName: 'DocumentPortal' })

const DOCUMENT_PORTAL_ROLES = new Set([
  'DOCUMENT_PORTAL_VIEWER',
  'DOCUMENT_PORTAL_CONTRIBUTOR',
  'DOCUMENT_PORTAL_MANAGER',
])

function isDocumentPortalOnly(user: UserOut | null): boolean {
  const roles = user?.roles || []
  return roles.length > 0 && roles.every((role) => DOCUMENT_PORTAL_ROLES.has(role))
}

function DocumentPortalOnlyAccessDenied() {
  return (
    <section className="card empty-state" role="alert" aria-live="polite">
      <h2>You don’t have access to this module</h2>
      <p className="msg">Your account has access only to Document Portal. Contact an Administrator if you need access to another module.</p>
    </section>
  )
}

function isAccessApprovalPending(user: UserOut | null): boolean {
  return !!user && user.needs_role_review && !user.needs_department_selection
}

function isWorkspaceAccessMissing(user: UserOut | null): boolean {
  if (!user || user.needs_department_selection) return false
  // DEFAULT is the fixed onboarding workspace, not an operational assignment.
  // Check all memberships, not the currently selected or preferred workspace.
  return !uniqueWorkspaceAccess(user).some(access => {
    const key = access.workspace_key?.trim().toUpperCase()
    if (key) return key !== 'DEFAULT'
    const name = access.workspace_name?.trim().toLowerCase()
    return !!name && name !== 'default workspace'
  })
}

function isLdapEmailCompletionRequired(user: UserOut | null): boolean {
  return !!user
    && user.login_type === 'LDAP'
    && (user.needs_email_confirmation || (
      !user.needs_department_selection
      && !user.needs_role_review
      && user.roles.length > 0
      && !user.email?.trim()
    ))
}

function AccessApprovalPending() {
  const { refreshUser, logout } = useAuth()
  const [checking, setChecking] = useState(false)

  async function checkApprovalStatus() {
    setChecking(true)
    try {
      await refreshUser()
    } catch {
      // Keep the pending state visible if the status check is temporarily
      // unavailable; the next check can safely be retried.
    } finally {
      setChecking(false)
    }
  }

  return (
    <main className="access-pending-page">
      <section className="access-pending-card" role="status" aria-live="polite">
        <div className="access-pending-brand">
          <img className="qualityops-app-logo" src="/qualityops-logo.png" alt="" aria-hidden="true" />
          <div>
            <strong>Quality<em>Ops</em></strong>
            <img className="bank-wordmark" src="/bank-of-maharashtra-wordmark.png" alt="Bank of Maharashtra" />
          </div>
        </div>
        <span className="access-pending-status" aria-hidden="true">✓</span>
        <p className="access-pending-kicker">Account registration received</p>
        <h1>Access approval pending</h1>
        <p className="access-pending-message">
          Your department has been submitted. An Administrator or Department Coordinator must assign your portal role before you can use QualityOps.
        </p>
        <div className="access-pending-note">
          The application navigation will become available automatically after your access is approved.
        </div>
        <div className="access-pending-actions">
          <button className="btn btn-primary" onClick={checkApprovalStatus} disabled={checking}>
            {checking ? 'Checking…' : 'Check approval status'}
          </button>
          <button className="btn" onClick={logout}>Log out</button>
        </div>
        <div className="access-pending-version"><AppVersion /></div>
      </section>
    </main>
  )
}

function WorkspaceAccessRequired() {
  const { refreshUser, logout } = useAuth()
  const [checking, setChecking] = useState(false)

  async function checkWorkspaceAccess() {
    setChecking(true)
    try {
      await refreshUser()
    } catch {
      // Keep the fail-closed screen available during a transient API error.
    } finally {
      setChecking(false)
    }
  }

  return (
    <main className="access-pending-page">
      <section className="access-pending-card" role="alert" aria-live="polite">
        <div className="access-pending-brand">
          <img className="qualityops-app-logo" src="/qualityops-logo.png" alt="" aria-hidden="true" />
          <div>
            <strong>Quality<em>Ops</em></strong>
            <img className="bank-wordmark" src="/bank-of-maharashtra-wordmark.png" alt="Bank of Maharashtra" />
          </div>
        </div>
        <span className="access-pending-status" aria-hidden="true">!</span>
        <p className="access-pending-kicker">Workspace access required</p>
        <h1>You don’t have an assigned workspace</h1>
        <p className="access-pending-message">
          Please ask your department coordinator to assign you to the appropriate workspace before accessing the portal.
        </p>
        <div className="access-pending-note">
          If your department coordinator has updated your access, select “Check workspace access” below.
        </div>
        <div className="access-pending-actions">
          <button className="btn btn-primary" onClick={checkWorkspaceAccess} disabled={checking}>
            {checking ? 'Checking…' : 'Check workspace access'}
          </button>
          <button className="btn" onClick={logout}>Log out</button>
        </div>
        <div className="access-pending-version"><AppVersion /></div>
      </section>
    </main>
  )
}

function DocumentOnlyAccessGuard({ children, user }: { children: ReactNode; user: UserOut }) {
  const location = useLocation()
  if (isDocumentPortalOnly(user) && !location.pathname.startsWith('/document-portal')) {
    return <DocumentPortalOnlyAccessDenied />
  }
  return <>{children}</>
}

// Test Management module (Project Management / Test Repository / Test
// Execution) -- a Zephyr-style test case management layer, kept as its own
// nav group rather than folded into Functional/Specialised Testing since
// it's a distinct workflow (author/import/execute test cases) rather than a
// request-approval flow like every other module.
const TestProjects = lazyModule(() => import('./modules/test-management/TestProjects'), { displayName: 'TestProjects' })
const TestRepository = lazyModule(() => import('./modules/test-management/TestRepository'), { displayName: 'TestRepository' })
const TestExecution = lazyModule(() => import('./modules/test-management/TestExecution'), { displayName: 'TestExecution' })
const Defects = lazyModule(() => import('./modules/test-management/Defects'), { displayName: 'Defects' })
// SRS EXE-002 "My Executions" -- the signed-in user's actionable items
// across every authorized project.
const MyExecutions = lazyModule(() => import('./modules/test-management/MyExecutions'), { displayName: 'MyExecutions' })
// SRS section 11 -- the 8 Test Management reporting views.
const TestReports = lazyModule(() => import('./modules/test-management/TestReports'), { displayName: 'TestReports' })

// Onboarding is a standalone signed-in state. Mounting the portal behind a
// blocking modal still runs dashboard/navigation effects and requests data
// that the backend correctly denies until access approval is complete.
function AuthenticatedChrome({ user, children }: { user: UserOut; children: ReactNode }) {
  let onboarding: ReactNode | null = null
  if (isLdapEmailCompletionRequired(user)) {
    onboarding = <main className="access-pending-page" aria-label="Confirm notification email"><EmailCompletionPrompt /></main>
  }
  else if (user.needs_department_selection) {
    onboarding = <main className="access-pending-page" aria-label="Complete account setup"><DepartmentPrompt /></main>
  }
  else if (isWorkspaceAccessMissing(user)) onboarding = <WorkspaceAccessRequired />
  else if (isAccessApprovalPending(user)) onboarding = <AccessApprovalPending />
  if (onboarding) {
    return (
      <MaintenanceWindowProvider>
        <div className="maintenance-onboarding-shell">
          <MaintenanceWindowBanner />
          {onboarding}
          <LoginNoticeCoordinator includePendingApprovals={false} />
        </div>
      </MaintenanceWindowProvider>
    )
  }
  return (
    <MaintenanceWindowProvider>
      <RequestViewer>
        <Layout>
          {children}
          <LoginNoticeCoordinator />
        </Layout>
      </RequestViewer>
    </MaintenanceWindowProvider>
  )
}

// Reported directly (twice now): "there are lots of api calling, sometime
// same api calling multiple time" -- traced (see ORACLE_MIGRATION_2026-07.md
// section 185) to every protected route independently wrapping its OWN
// `<Protected><Page /></Protected>` instance with no shared parent route --
// so Layout (sidebar/topbar, and its pending-approvals badge fetch) actually
// unmounted and remounted on every single navigation between pages, not just
// re-ran an effect. Section 185 papered over the symptom with a short-lived
// cache; THIS is the real fix: one pathless parent route
// (`<Route element={<ProtectedLayout />}>`, a React Router v6 "layout
// route") wrapping every protected page below it via `<Outlet/>`, so
// `AuthenticatedChrome`/`Layout` mounts ONCE for the whole signed-in session
// and only the `<Outlet/>` content swaps as you navigate between its child
// routes -- the sidebar, topbar, and the badge fetch no longer tear down and
// rebuild on every click. `/login` and `/help` stay outside this group
// deliberately: `/login` must render with no chrome at all, and `/help` must
// still work when signed OUT (see HelpRoute below, unchanged in shape from
// before), which a route nested under an auth-gated parent could never do.
function ProtectedLayout() {
  const { user, loading } = useAuth()
  const location = useLocation()
  if (loading) return <ModuleFallback />
  if (!user) return <Navigate to="/login" replace state={{ from: `${location.pathname}${location.search}${location.hash}` }} />
  // A provisioned account awaiting role approval has no portal access yet,
  // so do not mount Layout at all. Besides hiding the sidebar/topbar, this
  // prevents their navigation-specific API calls from running while the
  // backend pending-access guard intentionally permits only /me and logout.
  return (
    <AuthenticatedChrome user={user}>
      <DocumentOnlyAccessGuard user={user}>
        <Outlet />
      </DocumentOnlyAccessGuard>
    </AuthenticatedChrome>
  )
}

function LoginRoute() {
  const { user, loading } = useAuth()
  const location = useLocation()
  const requested = internalNavigationPath(typeof location.state?.from === 'string' ? location.state.from : null) || '/'
  if (loading) return <ModuleFallback />
  return user ? <Navigate to={requested} replace /> : <Login />
}

function QaGroupOnly({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  return hasWorkspaceRole(user, 'QA_ENGINEER', 'QA_LEAD', 'SECURITY_ANALYST', 'CHIEF_MANAGER_QA', 'AGM_QA') ? <>{children}</> : <Navigate to="/" replace />
}

function AdminOnly({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  const clientEligible = !!user?.roles.includes('ADMIN') && !isViewOnly(user)
  const [state, setState] = useState<'checking' | 'allowed' | 'denied' | 'unavailable'>('checking')
  const [attempt, setAttempt] = useState(0)

  useEffect(() => {
    let active = true
    const denied = () => { if (active) setState('denied') }
    window.addEventListener(ADMIN_ACCESS_DENIED_EVENT, denied)
    if (!clientEligible) {
      setState('denied')
      return () => {
        active = false
        window.removeEventListener(ADMIN_ACCESS_DENIED_EVENT, denied)
      }
    }
    setState('checking')
    void api.verifyAdminAccess()
      .then(() => { if (active) setState('allowed') })
      .catch((error) => {
        if (!active) return
        setState(error instanceof HttpError && (error.status === 401 || error.status === 403)
          ? 'denied'
          : 'unavailable')
      })
    return () => {
      active = false
      window.removeEventListener(ADMIN_ACCESS_DENIED_EVENT, denied)
    }
  }, [clientEligible, user?.id, attempt])

  if (state === 'denied') return <Navigate to="/" replace />
  if (state === 'unavailable') {
    return (
      <section className="card empty-state" role="alert" aria-live="polite">
        <h2>Administrator access could not be verified</h2>
        <p className="msg">The server did not confirm this Administrator session. No administration tools were loaded.</p>
        <button className="btn btn-primary" type="button" onClick={() => setAttempt((value) => value + 1)}>Retry access check</button>
      </section>
    )
  }
  if (state !== 'allowed') return <ModuleFallback />
  return <>{children}</>
}

function DocumentPortalOnly({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  return user?.roles.some((role) => ['ADMIN', 'DOCUMENT_PORTAL_VIEWER', 'DOCUMENT_PORTAL_CONTRIBUTOR', 'DOCUMENT_PORTAL_MANAGER'].includes(role))
    ? <>{children}</> : <Navigate to="/" replace />
}

// Reported directly: "Help & user Manual should come on login page as well,
// without login atleast user can read" -- Help.tsx is entirely static
// content (no API calls, no auth-scoped data, see its own file), so there's
// nothing that actually requires being signed in to view it. Routes to this
// same /help path either way: signed-in users still get the normal
// Layout/DepartmentPrompt/PendingApprovalsNotice chrome via
// AuthenticatedChrome above (a deliberate one-off exception to "everything
// protected lives under ProtectedLayout" -- /help itself must remain
// reachable signed OUT, which a route nested under an auth-gated parent
// could never be); a signed-out visitor instead gets PublicHelp below, a
// minimal standalone shell (brand mark + a way back to the login page)
// around the exact same <Help /> content, rather than a second copy of the
// manual to keep in sync.
function HelpRoute() {
  const { user, loading } = useAuth()
  if (loading) return <ModuleFallback />
  if (user) return (
    <AuthenticatedChrome user={user}>
      {isDocumentPortalOnly(user) ? <DocumentPortalOnlyAccessDenied /> : <Help />}
    </AuthenticatedChrome>
  )
  return <PublicHelp />
}

function PublicHelp() {
  return (
    <div className="public-help-shell">
      <div className="public-help-topbar">
        <Link to="/help" className="public-help-brand">
          <img className="qualityops-app-logo" src="/qualityops-logo.png" alt="" aria-hidden="true" />
          <div>
            <strong>Quality<em>Ops</em></strong>
            <img className="bank-wordmark public-bank-wordmark" src="/bank-of-maharashtra-wordmark.png" alt="Bank of Maharashtra" />
          </div>
        </Link>
        <div className="public-help-actions"><AppVersion /><Link to="/login" className="public-help-back">← Back to sign in</Link></div>
      </div>
      <Help />
    </div>
  )
}

// Fallback shown while a lazy-loaded module's chunk is still downloading
// (typically instant on a warm cache, briefly visible on first visit to a
// module or right after a fresh deploy) -- matches ProtectedLayout's own
// plain-text loading state above rather than introducing a spinner
// component just for this.
function ModuleFallback() {
  return (
    <div className="route-loading" role="status" aria-label="Loading page">
      <div className="route-loading-title" />
      <div className="route-loading-toolbar" />
      <div className="route-loading-card" />
      <div className="route-loading-card route-loading-card-short" />
    </div>
  )
}

export default function App() {
  return (
    <>
      <WorkspaceTransition />
      <GlobalButtonTooltips />
      <ApiActivityIndicator />
      <GlobalToastCenter />
      <Suspense fallback={<ModuleFallback />}>
        <Routes>
        <Route path="/login" element={<LoginRoute />} />
        <Route path="/help" element={<HelpRoute />} />

        {/* Every protected page below shares this one pathless layout route
            -- see ProtectedLayout's own comment above for why. */}
        <Route element={<ProtectedLayout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/qa-requests" element={<QARequests />} />

          {/* Functional module. Each lazy route is wrapped in its own
              ModuleBoundary instance (not one boundary around the whole
              <Routes>) so a failed chunk load shows a clear, actionable
              error for just that module instead of silently blanking the
              entire app, and so navigating away from a failed module to a
              working one gets a fresh boundary instead of a stuck error
              screen. */}
          <Route path="/functional-requests" element={<ModuleBoundary moduleName="Functional"><Functional /></ModuleBoundary>} />

          {/* Security module */}
          <Route path="/sast" element={<ModuleBoundary moduleName="Security"><SAST /></ModuleBoundary>} />
          <Route path="/dast" element={<ModuleBoundary moduleName="Security"><DAST /></ModuleBoundary>} />
          <Route path="/suppression" element={<ModuleBoundary moduleName="Security"><Suppression /></ModuleBoundary>} />

          {/* Specialised Testing module */}
          <Route path="/performance" element={<ModuleBoundary moduleName="Specialised Testing"><Performance /></ModuleBoundary>} />

          {/* Governance module */}
          <Route path="/signoff" element={<ModuleBoundary moduleName="Governance"><SignOff /></ModuleBoundary>} />
          <Route path="/verify-signature" element={<ModuleBoundary moduleName="Governance"><SignatureVerification /></ModuleBoundary>} />
          <Route path="/pending-approvals" element={<ModuleBoundary moduleName="Governance"><PendingApprovals /></ModuleBoundary>} />
          <Route path="/approvals" element={<ModuleBoundary moduleName="Governance"><Approvals /></ModuleBoundary>} />
          <Route path="/reports" element={<ModuleBoundary moduleName="Governance"><Reports /></ModuleBoundary>} />
          <Route path="/admin" element={<AdminOnly><ModuleBoundary moduleName="Governance"><Admin /></ModuleBoundary></AdminOnly>} />
          <Route path="/department-admin" element={<ModuleBoundary moduleName="Governance"><DepartmentAdmin /></ModuleBoundary>} />
          <Route path="/workspace-admin" element={<ModuleBoundary moduleName="Governance"><ParentWorkspaceAdmin /></ModuleBoundary>} />
          <Route path="/audit-log" element={<ModuleBoundary moduleName="Governance"><AuditLog /></ModuleBoundary>} />
          <Route path="/checklist-config" element={<AdminOnly><ModuleBoundary moduleName="Governance"><ChecklistConfig /></ModuleBoundary></AdminOnly>} />
          <Route path="/request-type-config" element={<AdminOnly><ModuleBoundary moduleName="Governance"><RequestTypeConfig /></ModuleBoundary></AdminOnly>} />
          <Route path="/document-portal" element={<DocumentPortalOnly><ModuleBoundary moduleName="Document Portal"><DocumentPortal /></ModuleBoundary></DocumentPortalOnly>} />

          {/* Test Management module */}
          <Route path="/test-projects" element={<ModuleBoundary moduleName="Test Management"><TestProjects /></ModuleBoundary>} />
          <Route path="/test-repository" element={<ModuleBoundary moduleName="Test Management"><TestRepository /></ModuleBoundary>} />
          <Route path="/test-execution" element={<ModuleBoundary moduleName="Test Management"><TestExecution /></ModuleBoundary>} />
          <Route path="/defects" element={<ModuleBoundary moduleName="Defect Management"><Defects /></ModuleBoundary>} />
          <Route path="/my-executions" element={<QaGroupOnly><ModuleBoundary moduleName="Test Management"><MyExecutions /></ModuleBoundary></QaGroupOnly>} />
          <Route path="/test-reports" element={<ModuleBoundary moduleName="Test Management"><TestReports /></ModuleBoundary>} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Suspense>
    </>
  )
}
