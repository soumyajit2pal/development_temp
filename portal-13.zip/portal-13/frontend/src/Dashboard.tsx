import WorkflowStatusBadge from './components/WorkflowStatusBadge'
import { useRequestNavigation } from './hooks/useRequestNavigation'
import React, { useEffect, useState, useMemo, useRef } from 'react'

import { api } from './api'
import { runIndependentLoads } from './independentLoads'
import { formatDateIST, formatDateTimeIST } from './time'
import { useAuth } from './context/AuthContext'
import { Card, MetricCard, BarChart, Table, Badge, ErrorText, Modal, TableColumn, EmptyState } from './components/Common'
import SearchableSelect from './components/SearchableSelect'
import ClearableSearchInput from './components/ClearableSearchInput'
import ActiveProjectsBrowser from './components/ActiveProjectsBrowser'
import TesterActivityChart from './components/TesterActivityChart'
import TesterOccupancyTrend from './components/TesterOccupancyTrend'
import { hasRecordedTesterActivity, TesterActivityRow } from './testerActivity'
import DefectsBrowser from './components/DefectsBrowser'
import {
  IconGrid, IconWarning, IconApprove, IconWorkflow, IconCheckCircle,
} from './components/Icons'
import {
  ApprovalActionOut, ProjectWiseOut, ThreeWOut, ThreeWItem, ThreeWDetailOut, DashboardSummaryOut,
  SecuritySastDashboard, SecurityDastDashboard, SecurityInsightMetric, SecurityInsightDetail, SuppressionDashboard,
  DashboardAttentionMetric, DashboardAttentionOut, DashboardAttentionRow,
  FortifySuppressedSeverity, FortifySuppressionDetailOut, FortifySuppressionDetailRow,
} from './types'
import { formatRoleLabels } from './constants'

// A single request, whatever its underlying type, reduced to the handful of
// fields "My Requests & My Department" needs -- lets that section show one
// combined, sortable list across the QA Request gateway and every linked
// child request type instead of six separate tables.
interface UnifiedRequestRow {
  children?: { id: number; request_id: string; type: string; status: string }[]
  id: number
  // `id` is each row's raw primary key from its OWN source table (QARequest,
  // FunctionalRequest, SASTRequest, DASTRequest, PerformanceRequest) -- those
  // are five independent auto-increment sequences, so the same numeric id
  // can (and does) show up in more than one of them at once. `uid` below is
  // the value actually handed to <Table rowKey> so React always has a
  // globally-unique key across the merged list; `id` is kept only for
  // display/back-compat, not for keying.
  uid: string
  request_id: string
  type: string
  application_name: string
  department?: string | null
  status: string
  requester_id?: number | null
  created_at: string
  // Reported directly: "IN dashboard also show change description" --
  // delegated from the QA Request gateway on every source type this unifies
  // (see backend models.QARequest.change_description and each child
  // request's own delegated property), same as application_name/department
  // above.
  change_description?: string | null
}

interface DashboardRequestsPage {
  items: UnifiedRequestRow[]
  page: number
  page_size: number
  total: number
  total_pages: number
  has_next: boolean
  has_previous: boolean
  next_cursor?: string | null
  active_total: number
  terminal_total: number
}

const TYPE_TO_PATH: Record<string, string> = {
  'QA Request': '/qa-requests',
  'Functional QA': '/functional-requests',
  SAST: '/sast',
  DAST: '/dast',
  Performance: '/performance',
}

const DONUT_COLORS = ['#4f46e5', '#16a34a', '#d97706', '#dc2626', '#7c3aed']
const AGEING_BUCKET_ORDER = ['0-3 days', '4-7 days', '8-15 days', '16-30 days', '30+ days']
const AGEING_BUCKET_COLORS: Record<string, string> = {
  '0-3 days': '#60a5fa',
  '4-7 days': '#2563eb',
  '8-15 days': '#d97706',
  '16-30 days': '#dc2626',
  '30+ days': '#991b1b',
}

// Mirrors backend/app/deps.py::DASHBOARD_DEPARTMENT_UNRESTRICTED_ROLES so
// Portfolio Analytics explains why two signed-in users can legitimately see
// different totals. Keep this as display-only context; the API remains the
// authority that enforces the actual record scope.
const ORGANISATION_WIDE_PORTFOLIO_ROLES = new Set([
  'ADMIN', 'QA_LEAD', 'QA_ENGINEER', 'SECURITY_ANALYST',
  'CHIEF_MANAGER_QA', 'AGM_QA', 'SCALE_6_PLUS', 'VIEW_ONLY',
])

// "Raised" date-range filter -- reported directly ("add filter like within 1
// hr raised, 1 month, from date to to date"). Applies to whatever on-screen
// data is actually keyed by a raise/created timestamp (the "Active requests"
// stat + its footline, and Recent Activity) -- the other three At-a-Glance
// cards are backend-aggregated all-time counts (distinct applications, open
// findings, pending-approval gates) with no per-request created_at of their
// own to filter by, so they intentionally stay as-is; a note next to the
// filter says so rather than silently doing nothing.
type RaisedRangePreset = '7d' | '30d' | '3m' | '6m' | 'custom'
interface RaisedRange {
  preset: RaisedRangePreset
  from: string
  to: string
}
// A rolling 7-day view is the operational default. Historical data remains
// available in Reports & Export Centre, where it does not burden every
// dashboard visit.
const DEFAULT_RAISED_RANGE: RaisedRange = { preset: '7d', from: '', to: '' }
const IST_OFFSET_MS = 5.5 * 60 * 60 * 1000

/** Format an instant for API filters without converting it to UTC/GMT. */
function toIstApiDateTime(date: Date): string {
  return new Date(date.getTime() + IST_OFFSET_MS).toISOString().replace('Z', '+05:30')
}

function toIstDateInputValue(date: Date): string {
  return new Date(date.getTime() + IST_OFFSET_MS).toISOString().slice(0, 10)
}

/** Date-only inputs represent calendar dates in the QualityOps's IST timezone. */
function istDateAt(date: string, time: string): Date {
  return new Date(`${date}T${time}+05:30`)
}

function rangeBounds(range: RaisedRange): { start?: Date; end?: Date } {
  if (range.preset === '7d') return { start: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), end: new Date() }
  if (range.preset === '30d') return { start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), end: new Date() }
  if (range.preset === '3m' || range.preset === '6m') {
    const start = new Date(); start.setMonth(start.getMonth() - (range.preset === '3m' ? 3 : 6))
    return { start, end: new Date() }
  }
  const start = range.from ? istDateAt(range.from, '00:00:00') : undefined
  const end = range.to ? istDateAt(range.to, '23:59:59.999') : undefined
  return { start, end }
}

function rangeQuery(range: RaisedRange): string {
  const { start, end } = rangeBounds(range)
  const params = new URLSearchParams()
  if (start) params.set('date_from', toIstApiDateTime(start))
  if (end) params.set('date_to', toIstApiDateTime(end))
  const query = params.toString()
  return query ? `?${query}` : ''
}

function isWithinRaisedRange(dateStr: string, range: RaisedRange): boolean {
  const t = new Date(dateStr).getTime()
  const { start, end } = rangeBounds(range)
  return (!start || t >= start.getTime()) && (!end || t <= end.getTime())
}

function timeAgo(dateStr: string): string {
  const diffMs = Date.now() - new Date(dateStr).getTime()
  const mins = Math.max(1, Math.round(diffMs / 60000))
  if (mins < 60) return `${mins} min ago`
  const hrs = Math.round(mins / 60)
  if (hrs < 24) return `${hrs} hr${hrs > 1 ? 's' : ''} ago`
  const days = Math.round(hrs / 24)
  return `${days} day${days > 1 ? 's' : ''} ago`
}

/** A page-shaped loading state preserves the dashboard layout while data loads. */
function Shimmer({ className = '' }: { className?: string }) {
  return <span className={`shimmer ${className}`} aria-hidden="true" />
}

function DashboardLoadingSkeleton({ variant = 'dashboard' }: { variant?: 'dashboard' | 'requests' | 'insights' }) {
  if (variant === 'requests') {
    return (
      <div className="dashboard-loading dashboard-loading-requests" role="status" aria-label="Loading requests" aria-busy="true">
        <Shimmer className="dashboard-loading-note" />
        <section className="dashboard-loading-panel">
          <div className="dashboard-loading-tabs"><Shimmer /><Shimmer /></div>
          <div className="dashboard-loading-metrics">
            {[0, 1, 2].map((item) => <div key={item}><Shimmer className="dashboard-loading-icon" /><Shimmer className="dashboard-loading-value" /><Shimmer className="dashboard-loading-label" /></div>)}
          </div>
          <div className="dashboard-loading-table">
            <div className="dashboard-loading-table-head"><Shimmer /><Shimmer /><Shimmer /><Shimmer /></div>
            {[0, 1, 2, 3, 4].map((item) => <div key={item} className="dashboard-loading-table-row"><Shimmer /><Shimmer /><Shimmer /><Shimmer /></div>)}
          </div>
        </section>
      </div>
    )
  }

  return (
    <div className={`dashboard-loading dashboard-loading-${variant}`} role="status" aria-label="Loading dashboard data" aria-busy="true">
      <div className="dashboard-loading-metrics">
        {[0, 1, 2, 3].map((item) => <div key={item}><Shimmer className="dashboard-loading-icon" /><Shimmer className="dashboard-loading-value" /><Shimmer className="dashboard-loading-label" /></div>)}
      </div>
      <section className="dashboard-loading-panel">
        <div className="dashboard-loading-section-head"><Shimmer /><Shimmer /></div>
        <div className="dashboard-loading-columns"><Shimmer /><Shimmer /><Shimmer /></div>
      </section>
      <div className="dashboard-loading-secondary"><Shimmer /><Shimmer /></div>
    </div>
  )
}

function downloadCsv<T extends Record<string, any>>(filename: string, rows: T[], columns: { key: string; header: string }[]) {
  const header = columns.map((c) => c.header).join(',')
  const lines = rows.map((r) => columns.map((c) => `"${String(r[c.key] ?? '').replace(/"/g, '""')}"`).join(','))
  const blob = new Blob([[header, ...lines].join('\n')], { type: 'text/csv' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename
  document.body.appendChild(a); a.click(); a.remove()
  URL.revokeObjectURL(url)
}

function Sparkline({ values }: { values?: Record<string, number> | null }) {
  const entries = Object.entries(values || {})
  if (entries.length === 0) return null
  const max = Math.max(1, ...entries.map(([, v]) => v))
  const riskColors: Record<string, string> = {
    critical: '#c9363e',
    high: '#e66a24',
    medium: '#d2a91e',
    low: '#2f8a57',
  }
  return (
    <div className="sparkline">
      {entries.map(([k, v]) => (
        <div
          key={k}
          className={`bar ${v > 0 ? 'filled' : ''}`}
          style={{
            height: `${Math.max(10, (v / max) * 100)}%`,
            ...(v > 0 ? { background: riskColors[k.trim().toLowerCase()] || '#16788b' } : {}),
          }}
          title={`${k}: ${v}`}
        />
      ))}
    </div>
  )
}

interface Segment {
  label: string
  value: number
  color: string
}

function SegmentBar({ segments }: { segments: Segment[] }) {
  const total = segments.reduce((s, x) => s + x.value, 0) || 1
  return (
    <div className="segment-bar">
      {segments.filter((s) => s.value > 0).map((s) => (
        <div key={s.label} style={{ width: `${(s.value / total) * 100}%`, background: s.color }} title={`${s.label}: ${s.value}`} />
      ))}
      {total === 0 && <div style={{ width: '100%', background: '#eef0f3' }} />}
    </div>
  )
}

interface StatCardProps {
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>
  iconClass: string
  tag?: string
  value: React.ReactNode
  label: React.ReactNode
  // One plain-English line describing exactly what's being counted --
  // reported directly ("what is Active Projects, what is pending Approval,
  // what is Active requests") -- these four numbers each use a different
  // scope/definition under the hood (distinct project epics vs. individual
  // requests vs. specific approval-gate statuses), so they were never meant
  // to add up to each other -- without this line there was nothing on
  // screen saying so. Displayed through the accessible information control
  // so cards stay compact without losing the metric definition.
  hint?: React.ReactNode
  footline?: React.ReactNode
  spark?: Record<string, number>
  segments?: Segment[]
  onOpen?: () => void
  loading?: boolean
}

function StatCard({ icon: Icon, iconClass, tag, value, label, hint, footline, spark, segments, onOpen, loading }: StatCardProps) {
  return (
    <div
      className={`stat-card stat-card-${iconClass}${onOpen ? ' stat-card-drilldown' : ''}`}
      role={onOpen ? 'button' : undefined}
      tabIndex={onOpen ? 0 : undefined}
      onClick={onOpen}
      onKeyDown={onOpen ? (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault()
          onOpen()
        }
      } : undefined}
    >
      <div className="top-row">
        <div className={`icon-chip ${iconClass}`}><Icon width={17} height={17} /></div>
        <div className="stat-card-meta">
          {tag && <span className="chip-tag">{tag}</span>}
          {(hint || footline) && !onOpen && (
            <span className="stat-card-info" onClick={(event) => event.stopPropagation()}>
              <button type="button" aria-label={`About ${String(label)}`}>i</button>
              <span className="stat-card-tooltip" role="tooltip">
                {hint && <span>{hint}</span>}
                {footline && <small>{footline}</small>}
              </span>
            </span>
          )}
        </div>
      </div>
      <div className="value">{value}</div>
      <div className="label">{label}</div>
      {onOpen && hint && <div className="hint">{hint}</div>}
      {spark && <Sparkline values={spark} />}
      {segments && <SegmentBar segments={segments} />}
      {onOpen && footline && <div className="footline">{footline}</div>}
      {onOpen && (
        <span className="stat-card-drilldown-label">
          {loading ? 'Loading records…' : 'View consolidated data'} <b aria-hidden="true">→</b>
        </span>
      )}
    </div>
  )
}

function Donut({ data, size = 128 }: { data?: Record<string, number> | null; size?: number }) {
  const entries = Object.entries(data || {})
    .filter(([, v]) => v > 0)
    .sort(([left], [right]) => {
      const leftIndex = AGEING_BUCKET_ORDER.indexOf(left)
      const rightIndex = AGEING_BUCKET_ORDER.indexOf(right)
      if (leftIndex === -1 || rightIndex === -1) return left.localeCompare(right)
      return leftIndex - rightIndex
    })
  const total = entries.reduce((s, [, v]) => s + v, 0)
  let acc = 0
  const colorFor = (label: string, index: number) => AGEING_BUCKET_COLORS[label] || DONUT_COLORS[index % DONUT_COLORS.length]
  const stops = entries.map(([label, v], i) => {
    const start = (acc / (total || 1)) * 360
    acc += v
    const end = (acc / (total || 1)) * 360
    return `${colorFor(label, i)} ${start}deg ${end}deg`
  })
  const bg = total > 0 ? `conic-gradient(${stops.join(', ')})` : '#eef0f3'
  return (
    <div className="donut-wrap">
      <div className="donut" style={{ background: bg, width: size, height: size }}>
        <div className="donut-center">
          <span className="num">{total}</span>
          <span className="lbl">pending</span>
        </div>
      </div>
      <div className="donut-legend">
        {entries.map(([label, v], i) => (
          <div className="row" key={label}>
            <span><span className="dot" style={{ background: colorFor(label, i) }} />{label}</span>
            <strong>{v}</strong>
          </div>
        ))}
        {entries.length === 0 && <span className="muted small">No pending items.</span>}
      </div>
    </div>
  )
}

// The actual Functional Request lifecycle. Counts below are mutually
// exclusive current-stage counts, not a cumulative "has reached this point"
// funnel; that distinction keeps the numbers consistent with the widget's
// "current workflow stage" description.
const LIFECYCLE_STAGES = [
  { key: 'request', label: 'Requester' },
  { key: 'sm-approval', label: 'SM Approval' },
  { key: 'department-head-approval', label: 'Department Head Approval' },
  { key: 'qa-activity', label: 'QA Activity' },
  { key: 'signoff', label: 'Clearance' },
  { key: 'closed', label: 'Closed' },
]

const STATUS_STAGE_INDEX: Record<string, number> = {
  DRAFT: 0, RETURNED_BY_SM: 0, SM_REJECTED: 0,
  RETURNED_BY_DEPARTMENT_HEAD: 0, RETURNED_BY_QA_LEAD: 0,
  SUBMITTED: 1, SM_APPROVAL_PENDING: 1,
  DEPARTMENT_HEAD_APPROVAL_PENDING: 2, DEPARTMENT_HEAD_REJECTED: 2,
  QA_LEAD_ASSIGNED: 3, READINESS_VERIFICATION: 3, QA_ACTIVITY_INITIATED: 3,
  PLANNING: 3, TESTER_ASSIGNED: 3, TEST_DESIGN: 3, EXECUTION_IN_PROGRESS: 3,
  DEFECT_RAISED: 3, WAITING_FOR_FIX: 3, RETESTING: 3, QA_COMPLETED: 3,
  QA_SIGNOFF_PENDING: 4, QA_SIGNED_OFF: 4, REQUESTER_VERIFICATION: 4,
  QA_CHANGE_REVIEW: 4,
  CLOSED: 5,
}

// DSH-001..004 -- takes a raw per-status count dict (Functional Testing
// Requests -- see FunctionalOut; the QA Request gateway itself only has
// Draft/Submitted/Raised/Cancelled, see constants.GATEWAY_STATUSES) rather
// than the full row list this used to filter/count client-side. CANCELLED
// is excluded the same way it always was (it also never appears in
// STATUS_STAGE_INDEX, so this filter is belt-and-suspenders, not load-
// bearing).
function lifecycleDistribution(statusCounts: Record<string, number>) {
  const eligible = Object.entries(statusCounts).filter(([status]) => status !== 'CANCELLED')
  return LIFECYCLE_STAGES.map((stage, i) => {
    const count = eligible.reduce((sum, [status, c]) => sum + (STATUS_STAGE_INDEX[status] === i ? c : 0), 0)
    return { ...stage, count }
  })
}

// Fed with Functional Testing Requests' per-status counts (see
// DashboardSummaryOut.functional_status_counts) rather than full rows.
function LifecycleStepper({ statusCounts }: { statusCounts: Record<string, number> }) {
  const distribution = lifecycleDistribution(statusCounts)
  const total = distribution.reduce((sum, stage) => sum + stage.count, 0)
  return (
    <div className="lifecycle-distribution">
      <div className="lifecycle-distribution-summary">
        <div><span>Current portfolio</span><strong>{total}</strong></div>
        <p>Each request appears once at its current workflow stage.</p>
      </div>
      <div className="lifecycle-stage-list">
        {distribution.map((stage, index) => {
          const percentage = total ? Math.round((stage.count / total) * 100) : 0
          return <div className={`lifecycle-stage-row stage-${index}`} key={stage.key}>
            <span className="lifecycle-stage-index">{index + 1}</span>
            <div className="lifecycle-stage-copy">
              <div><strong>{stage.label}</strong><span>{percentage}%</span></div>
              <i><b style={{ width: `${percentage}%` }} /></i>
            </div>
            <strong className="lifecycle-stage-count">{stage.count}</strong>
          </div>
        })}
      </div>
      {total === 0 && <span className="muted small">No Functional requests raised yet.</span>}
    </div>
  )
}

function ACTIVITY_ICON(decision?: string | null) {
  if (decision === 'Approved' || decision === 'Completed' || decision === 'Started') return { cls: 'green', Icon: IconCheckCircle }
  if (decision === 'Rejected' || decision === 'Returned') return { cls: 'amber', Icon: IconWarning }
  return { cls: 'blue', Icon: IconApprove }
}

function RecentActivity({ items }: { items: ApprovalActionOut[] }) {
  if (items.length === 0) return <EmptyState compact title="No activity recorded" description="Recent workflow actions will appear here." />
  return (
    <div>
      {items.map((a) => {
        const { cls, Icon } = ACTIVITY_ICON(a.decision)
        return (
          <div className="activity-item" key={a.id}>
            <div className={`icon-wrap ${cls}`}><Icon width={14} height={14} /></div>
            <div>
              <div className="title">{a.step_name} {a.decision?.toLowerCase()}</div>
              <div className="sub">{a.entity_type.replace('_', ' ')} #{a.entity_id} &middot; {formatRoleLabels(a.actor_role) || 'System'} &middot; {timeAgo(a.created_at)}</div>
            </div>
          </div>
        )
      })}
    </div>
  )
}

function ResolutionActivityGrid({ items }: { items: NonNullable<DashboardAttentionOut['resolution_activity']> }) {
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)
  const pageSize = 6
  const filtered = useMemo(() => {
    const needle = search.trim().toLowerCase()
    return needle ? items.filter((item) => item.resolver_name.toLowerCase().includes(needle)) : items
  }, [items, search])
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize))
  useEffect(() => { setPage(1) }, [search, items])
  const visible = filtered.slice((page - 1) * pageSize, page * pageSize)
  return <div className="dashboard-defect-resolvers">
    <div className="dashboard-defect-resolvers-head"><div><strong>Resolution activity</strong><span>Attributed to the user who submitted the latest audited Resolved action.</span></div><label><span>Find contributor</span><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by name…" /></label></div>
    <div>{visible.map((item) => <article key={item.resolver_id}><strong>{item.resolver_name}</strong><dl><div><dt>Resolved</dt><dd>{item.resolved_defects}</dd></div><div><dt>Reopened defects</dt><dd>{item.reopened_defects}</dd></div><div><dt>Reopen events</dt><dd>{item.reopen_events}</dd></div></dl></article>)}</div>
    <footer><span>{filtered.length ? `${(page - 1) * pageSize + 1}–${Math.min(page * pageSize, filtered.length)} of ${filtered.length}` : 'No contributors match'}</span><div><button disabled={page === 1} onClick={() => setPage((value) => Math.max(1, value - 1))}>← Previous</button><button disabled={page === pages || !filtered.length} onClick={() => setPage((value) => Math.min(pages, value + 1))}>Next →</button></div></footer>
  </div>
}

// Reported directly: "lots of api calling, sometime same api calling
// multiple time". This tab used to separately fetch requests/
// functionalRequests/sastRequests/dastRequests/performanceRequests (full
// row lists, up to 5 x page_size=100) just to derive 4 numbers and a
// Functional-lifecycle breakdown client-side -- that's exactly what
// DSH-001..004's consolidated GET /api/dashboard/summary now replaces (see
// its own fetch below). The full row lists are still fetched once at the
// Dashboard level and shared across tab switches, but only MyRequestsTab
// needs them now (genuine row browsing, out of scope for this endpoint).
function CommandCentre({ range }: { range: RaisedRange }) {
  const navigate = useRequestNavigation()
  const [proj, setProj] = useState<ProjectWiseOut | null>(null)
  const [threeW, setThreeW] = useState<ThreeWOut | null>(null)
  const [activity, setActivity] = useState<ApprovalActionOut[]>([])
  const [summary, setSummary] = useState<DashboardSummaryOut | null>(null)
  const [sectionErrors, setSectionErrors] = useState<Record<string, unknown>>({})
  const [activityLoading, setActivityLoading] = useState(true)
  const [retry, setRetry] = useState(0)
  const [govTab, setGovTab] = useState('Overview')
  // Reported directly: "Dashboard is too much of details and tracker." The
  // 3W governance card below is the densest thing on the default landing
  // tab -- a tabbed chart/donut/filter-toolbar/table tracker -- so it now
  // starts collapsed, showing only the card's own KPI strip (4 numbers) plus
  // a toggle, instead of dumping the full tracker in front of every visitor
  // by default. Nothing removed, just deferred behind one click.
  const [govExpanded, setGovExpanded] = useState(false)
  const [teamFilter, setTeamFilter] = useState('')
  const [priorityFilter, setPriorityFilter] = useState('')
  const [ageingFilter, setAgeingFilter] = useState('')
  const [governanceSearch, setGovernanceSearch] = useState('')
  const [attentionMetric, setAttentionMetric] = useState<DashboardAttentionMetric | null>(null)
  const [attentionDetail, setAttentionDetail] = useState<DashboardAttentionOut | null>(null)
  const [attentionLoading, setAttentionLoading] = useState(false)
  const [attentionError, setAttentionError] = useState<unknown>(null)

  const attentionRequest = useRef(0)

  async function loadAttention(metric: DashboardAttentionMetric, page: number, pageSize: number, search = '') {
    const request = ++attentionRequest.current
    setAttentionError(null)
    setAttentionLoading(true)
    try {
      const query = new URLSearchParams(rangeQuery(range).replace(/^\?/, ''))
      query.set('page', String(page))
      query.set('page_size', String(pageSize))
      if (search) query.set('search', search)
      const result = await api.get<DashboardAttentionOut>(`/api/dashboard/attention/${metric}?${query.toString()}`)
      if (request === attentionRequest.current) setAttentionDetail(result)
    } catch (err) {
      if (request === attentionRequest.current) setAttentionError(err)
    } finally {
      if (request === attentionRequest.current) setAttentionLoading(false)
    }
  }

  async function openAttention(metric: DashboardAttentionMetric) {
    setAttentionMetric(metric)
    setAttentionDetail(null)
    await loadAttention(metric, 1, 5)
  }

  useEffect(() => {
    let cancelled = false
    const query = rangeQuery(range)
    setSectionErrors({})
    setProj(null); setThreeW(null); setSummary(null); setActivity([]); setActivityLoading(true)
    const load = <T,>(key: string, path: string, publish: (value: T) => void) => async () => {
      if (cancelled) return
      try {
        const result = await api.get<T>(path)
        if (!cancelled) publish(result)
      } catch (error) {
        if (!cancelled) setSectionErrors(previous => ({ ...previous, [key]: error }))
      } finally {
        if (!cancelled && key === 'activity') setActivityLoading(false)
      }
    }
    void runIndependentLoads([
      load('projects', `/api/dashboard/project-wise${query}`, setProj),
      load('summary', `/api/dashboard/summary${query}`, setSummary),
      load('governance', `/api/dashboard/3w${query}`, setThreeW),
      load('activity', `/api/dashboard/recent-activity${query}${query ? '&' : '?'}limit=5`, setActivity),
    ])
    return () => { cancelled = true }
  }, [range, retry])

  const teams = useMemo(() => threeW ? Object.keys(threeW.team_wise_distribution) : [], [threeW])
  const priorities = useMemo(() => threeW
    ? Array.from(new Set(threeW.items.map((i) => i.priority).filter((p): p is string => !!p)))
    : [], [threeW])
  const visibleItems = useMemo<ThreeWItem[]>(() => {
    if (!threeW) return []
    const query = governanceSearch.trim().toLowerCase()
    return (threeW?.items || []).filter((i) => (
      (!teamFilter || i.responsible_team === teamFilter)
      && (!priorityFilter || i.priority === priorityFilter)
      && (!ageingFilter || i.ageing_bucket === ageingFilter)
      && (!query || [i.project_id, i.application_name, i.department, i.pending_stage, i.pending_with, i.owner, i.source]
        .some((value) => String(value || '').toLowerCase().includes(query)))
    ))
  }, [threeW, teamFilter, priorityFilter, ageingFilter, governanceSearch])

  // Everything below this point that's keyed off a raise/created timestamp
  // -- narrowed to whatever window RaisedRangeFilter above has selected (see
  // its own comment for why the other 3 At-a-Glance cards aren't included).
  const filteredActivity = useMemo(
    () => activity.filter((a) => isWithinRaisedRange(a.created_at, range)).slice(0, 5),
    [activity, range]
  )

  const sectionPlaceholder = (key: string, label: string) => <div role="status">
    {sectionErrors[key] ? <><strong>{label} unavailable</strong><ErrorText error={sectionErrors[key]} /><button className="btn btn-sm" onClick={() => setRetry(value => value + 1)}>Retry dashboard</button></> : <p>Loading {label.toLowerCase()}…</p>}
  </div>

  const m = proj?.metrics
  const slaWithin = (threeW?.items || []).filter((i) => i.ageing_days <= 7).length
  const slaNear = (threeW?.items || []).filter((i) => i.ageing_days > 7 && i.ageing_days <= 15).length
  const slaBreached = (threeW?.items || []).filter((i) => i.ageing_days > 15).length
  const highRiskPending = (threeW?.items || []).filter((i) => ['Critical', 'High'].includes(i.priority || '')).length
  // DSH-001..004 -- nearingRelease/criticalPending/activeRequestsCount below
  // all now come straight from the summary endpoint (see its own docstring
  // for exact query definitions) instead of being derived here from full
  // request-row collections.
  const criticalPending = summary?.critical_pending_count
  const activeRequestsCount = summary?.active_requests_count

  const attentionColumns: TableColumn<ThreeWItem>[] = [
    { key: 'project_id', header: 'Project' },
    { key: 'department', header: 'Department', render: (r) => r.department || '—' },
    { key: 'pending_stage', header: 'Pending At' },
    { key: 'pending_with', header: 'Pending With' },
    { key: 'owner', header: 'Owner', render: (r) => r.owner || '—' },
    { key: 'ageing_days', header: 'Since', render: (r) => <span className={`ageing-pill ${r.ageing_days > 15 ? 'breached' : r.ageing_days > 7 ? 'near' : 'within'}`}>{r.ageing_days}d</span> },
    { key: 'ageing_bucket', header: 'Ageing bucket' },
    { key: 'priority', header: 'Priority', render: (r) => r.priority ? <Badge status={r.priority} /> : '—' },
  ]

  const drilldownColumns: TableColumn<DashboardAttentionRow>[] = attentionMetric === 'defects'
    ? [
        { key: 'defect_id', header: 'Defect ID' },
        { key: 'request_id', header: 'Request ID', render: (r) => r.request_id || '—' },
        { key: 'project_id', header: 'Project ID', render: (r) => <span className="dashboard-trace-list">{r.project_ids?.length ? r.project_ids.map((key) => <small key={key}>{key}</small>) : '—'}</span> },
        { key: 'cycle_id', header: 'Cycle ID', render: (r) => <span className="dashboard-trace-list">{r.cycle_ids?.length ? r.cycle_ids.map((key) => <small key={key}>{key}</small>) : '—'}</span> },
        { key: 'test_case_id', header: 'Testcase IDs', render: (r) => <span className="dashboard-trace-list">{r.test_case_ids?.length ? r.test_case_ids.map((key) => <small key={key}>{key}</small>) : '—'}</span> },
        { key: 'application_name', header: 'Application' },
        { key: 'status', header: 'Status', render: (r) => <WorkflowStatusBadge record={r} status={r.status} /> },
        { key: 'severity', header: 'Severity', render: (r) => <Badge status={r.severity || ''} /> },
        { key: 'resolver_name', header: 'Resolved by', render: (r) => r.resolver_name || 'Not resolved' },
        { key: 'reopen_count', header: 'Reopens', render: (r) => r.reopen_count || 0 },
        { key: 'updated_at', header: 'Last updated', render: (r) => r.updated_at ? timeAgo(r.updated_at) : '—' },
      ]
    : attentionMetric === 'security-findings'
    ? [
        { key: 'type', header: 'Scan type' },
        { key: 'request_id', header: 'Request ID' },
        { key: 'application_name', header: 'Application' },
        { key: 'department', header: 'Department', render: (r) => r.department || '—' },
        { key: 'critical', header: 'Critical', render: (r) => r.critical || 0 },
        { key: 'high', header: 'High', render: (r) => r.high || 0 },
        { key: 'medium', header: 'Medium', render: (r) => r.medium || 0 },
        { key: 'low', header: 'Low', render: (r) => r.low || 0 },
        { key: 'value', header: 'Findings', render: (r) => <strong>{r.value || 0}</strong> },
        { key: 'updated_at', header: 'Latest scan', render: (r) => r.updated_at ? timeAgo(r.updated_at) : '—' },
      ]
    : attentionMetric === 'pending-decisions'
    ? [
        { key: 'type', header: 'Request type' },
        { key: 'request_id', header: 'Request ID' },
        { key: 'application_name', header: 'Application' },
        { key: 'department', header: 'Department', render: (r) => r.department || '—' },
        { key: 'status', header: 'Decision stage', render: (r) => <WorkflowStatusBadge record={r} status={r.status} /> },
        { key: 'pending_with', header: 'Waiting on' },
        { key: 'updated_at', header: 'Waiting since', render: (r) => r.updated_at ? timeAgo(r.updated_at) : '—' },
      ]
    : [
        { key: 'type', header: 'Request type' },
        { key: 'request_id', header: 'Request ID' },
        { key: 'application_name', header: 'Application' },
        { key: 'department', header: 'Department', render: (r) => r.department || '—' },
        { key: 'status', header: 'Current stage', render: (r) => <WorkflowStatusBadge record={r} status={r.status} /> },
        { key: 'created_at', header: 'Raised', render: (r) => r.created_at ? timeAgo(r.created_at) : '—' },
        { key: 'updated_at', header: 'Last updated', render: (r) => r.updated_at ? timeAgo(r.updated_at) : '—' },
      ]

  return (
    <div className="dashboard-command-centre">
      <div className="dashboard-section-head">
        <div>
          <span>Live portfolio</span>
          <h3>What needs attention</h3>
          <p>Select any card to see the exact records behind its total and open the relevant request.</p>
        </div>
      </div>
      <div className="grid dashboard-metric-grid dashboard-metric-grid-five">
        {m ? <><StatCard icon={IconGrid} iconClass="blue" tag="Distinct CR / EPIC" value={m.active_projects} label="Active CRs / EPICs"
                  hint="Distinct CR/EPICs with at least one active Functional QA request."
                  footline="Source: active Functional QA requests"
                  loading={attentionLoading && attentionMetric === 'active-projects'}
                  onOpen={() => openAttention('active-projects')} />
        <StatCard icon={IconWarning} iconClass="red" tag="Latest scans" value={m.sast_findings + m.dast_findings} label="Open security findings"
                  hint="Unresolved findings in the latest Fortify scan for every SAST and DAST request."
                  footline={`${m.sast_findings} SAST · ${m.dast_findings} DAST findings open`}
                  segments={[{ label: 'SAST', value: m.sast_findings, color: '#dc2626' }, { label: 'DAST', value: m.dast_findings, color: '#f97316' }]}
                  loading={attentionLoading && attentionMetric === 'security-findings'}
                  onOpen={() => openAttention('security-findings')} />
        <StatCard icon={IconApprove} iconClass="amber" tag={criticalPending ? `${criticalPending} critical` : 'Approval queue'} value={m.pending_approvals} label="Waiting for a decision"
                  hint="Functional, SAST, DAST, or Suppression records waiting at a decision step."
                  footline="Grouped across all decision workflows in your visible scope"
                  loading={attentionLoading && attentionMetric === 'pending-decisions'}
                  onOpen={() => openAttention('pending-decisions')} /></> : sectionPlaceholder('projects', 'Portfolio metrics')}
        {summary ? <><StatCard icon={IconWorkflow} iconClass="purple" tag="Child requests" value={activeRequestsCount} label="Active child requests"
                  hint="Still-open Functional, SAST, DAST, and Performance requests raised within the selected period."
                  footline={`${summary.child_requests_total} total child request${summary.child_requests_total === 1 ? '' : 's'} in the selected range`}
                  loading={attentionLoading && attentionMetric === 'active-requests'}
                  onOpen={() => openAttention('active-requests')} />
        <StatCard icon={IconCheckCircle} iconClass="blue" tag={`${summary.defects_resolved} resolved`} value={summary.defects_total} label="Defects"
                  hint="Governed defects reported within the selected period, with resolver and execution traceability."
                  footline={`${summary.defects_open} open · ${summary.defect_reopen_events} reopen event${summary.defect_reopen_events === 1 ? '' : 's'}`}
                  loading={attentionLoading && attentionMetric === 'defects'}
                  onOpen={() => openAttention('defects')} /></> : sectionPlaceholder('summary', 'Request summary')}
      </div>

      {attentionMetric && (
        <Modal
          title={attentionDetail?.title || 'Consolidated dashboard data'}
          onClose={() => { attentionRequest.current++; setAttentionMetric(null); setAttentionDetail(null); setAttentionError(null); setAttentionLoading(false) }}
          variant={attentionMetric === 'active-projects' ? 'dialog' : 'drawer'}
          fitContent={attentionMetric === 'active-projects'}
          preventBackdropClose
          wide
        >
          {attentionLoading && !attentionDetail && <p className="muted">Loading the source records behind this total…</p>}
          <ErrorText error={attentionError} />
          {attentionDetail && (attentionMetric === 'active-projects' ? (
            <ActiveProjectsBrowser data={attentionDetail} loading={attentionLoading}
              onLoad={(page, pageSize, search) => loadAttention('active-projects', page, pageSize, search)}
              onOpen={(route) => navigate(route)} formatUpdated={timeAgo} />
          ) : (
            <>
              <div className="dashboard-drilldown-summary">
                <div><strong>{attentionDetail.total}</strong><span>{attentionDetail.unit}</span></div>
                <p>{attentionDetail.description}</p>
              </div>
              <p className="muted small dashboard-drilldown-help">
                Five records are shown per page by default. Use the page-size control or column filters to review the data, then select a row to open its source request.
              </p>
              {attentionMetric === 'defects' && !!attentionDetail.resolution_activity?.length && <ResolutionActivityGrid items={attentionDetail.resolution_activity} />}
              {attentionMetric === 'defects' ? <DefectsBrowser
                data={attentionDetail} loading={attentionLoading}
                onLoad={(page, pageSize, search) => loadAttention('defects', page, pageSize, search)}
                onOpen={(route) => navigate(route)} formatUpdated={timeAgo}
              /> : <Table
                rowKey="key"
                columns={drilldownColumns}
                rows={attentionDetail.rows}
                server={{
                  page: attentionDetail.page,
                  pageSize: attentionDetail.page_size,
                  total: attentionDetail.total_rows,
                  totalPages: attentionDetail.total_pages,
                  hasNext: attentionDetail.has_next,
                  hasPrevious: attentionDetail.has_previous,
                  loading: attentionLoading,
                  onPageChange: (page) => loadAttention(attentionMetric, page, attentionDetail.page_size),
                  onPageSizeChange: (pageSize) => loadAttention(attentionMetric, 1, pageSize),
                }}
                onRowClick={(row) => { if (row.route) navigate(row.route) }}
              />}
            </>
          ))}
        </Modal>
      )}

      {threeW ? <Card
        style={{ marginTop: 18 }}
        title="3W project governance"
        subtitle="What is pending, where it is pending, and since when."
        right={(
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {govExpanded && (
              <div className="pill-tabs">
                {['Overview', 'Projects', 'Ageing'].map((t) => (
                  <button key={t} className={govTab === t ? 'active' : ''} onClick={() => setGovTab(t)}>{t}</button>
                ))}
              </div>
            )}
            <button type="button" className="btn btn-sm" onClick={() => setGovExpanded((v) => !v)}>
              {govExpanded ? 'Hide details' : 'Show details'}
            </button>
          </div>
        )}
      >
        <div className="governance-kpis">
          <div><small>Total pending</small><strong>{threeW.total_pending}</strong><span>Across all workflows</span></div>
          <div><small>SLA breached</small><strong className={slaBreached ? 'danger' : ''}>{slaBreached}</strong><span>Pending over 15 days</span></div>
          <div><small>Critical / high</small><strong className={highRiskPending ? 'warning' : ''}>{highRiskPending}</strong><span>Priority items requiring focus</span></div>
          <div><small>Owning teams</small><strong>{teams.length}</strong><span>Teams with pending work</span></div>
        </div>
        {!govExpanded && (
          <p className="muted small" style={{ margin: '10px 0 0' }}>
            {threeW.total_pending} pending item{threeW.total_pending !== 1 ? 's' : ''} across {teams.length} team{teams.length !== 1 ? 's' : ''} --
            click "Show details" for the breakdown, ageing, and full list.
          </p>
        )}
        {govExpanded && govTab === 'Overview' && (
          <>
            <div className="grid grid-2 governance-chart-grid" style={{ marginTop: 12 }}>
              <div className="subpanel">
                <div className="subpanel-title">Pending by Team</div>
                <BarChart data={threeW.team_wise_distribution} />
                <div style={{ display: 'flex', gap: 16, marginTop: 14, fontSize: 13.5 }}>
                  <span><span className="dot" style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: '#2563eb', marginRight: 5 }} />Within SLA {slaWithin}</span>
                  <span><span className="dot" style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: '#d97706', marginRight: 5 }} />Near SLA {slaNear}</span>
                  <span><span className="dot" style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: '#dc2626', marginRight: 5 }} />Breached {slaBreached}</span>
                </div>
                <p className="muted small" style={{ marginTop: 8 }}>
                  SLA bands: 0-7 days = within SLA, 8-15 = near SLA, 16+ = breached (based on days since last update).
                </p>
              </div>
              <div className="subpanel">
                <div className="subpanel-title">Ageing Distribution</div>
                <Donut data={threeW.ageing_bucket_distribution} />
              </div>
            </div>

            <div className="subpanel" style={{ marginTop: 16 }}>
              <div className="toolbar governance-toolbar" style={{ marginBottom: 10 }}>
                <div>
                  <div className="subpanel-title" style={{ marginBottom: 2 }}>Projects Requiring Attention</div>
                  <p className="muted small" style={{ margin: 0 }}>{visibleItems.length} of {threeW.total_pending} items · oldest first</p>
                </div>
                <div className="spacer" />
                <ClearableSearchInput className="governance-search" value={governanceSearch} onChange={(e) => setGovernanceSearch(e.target.value)} onClear={() => setGovernanceSearch('')} clearLabel="Clear pending item search" wrapperClassName="governance-search-wrap" placeholder="Search project, application, owner…" aria-label="Search pending items" />
                <SearchableSelect
                  value={teamFilter}
                  onChange={setTeamFilter}
                  style={{ minWidth: 160 }}
                  options={[{ value: '', label: 'All teams' }, ...teams.map((t) => ({ value: t, label: t }))]}
                />
                <select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)}>
                  <option value="">All priorities</option>
                  {priorities.map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
                <select value={ageingFilter} onChange={(e) => setAgeingFilter(e.target.value)}>
                  <option value="">All ageing</option>
                  {Object.keys(threeW.ageing_bucket_distribution).map((bucket) => <option key={bucket} value={bucket}>{bucket}</option>)}
                </select>
                <button className="btn btn-sm" onClick={() => downloadCsv('projects_requiring_attention.csv', visibleItems, [
                  { key: 'project_id', header: 'Project' }, { key: 'department', header: 'Department' },
                  { key: 'pending_stage', header: 'Pending At' },
                  { key: 'pending_with', header: 'Pending With' },
                  { key: 'owner', header: 'Owner' }, { key: 'ageing_days', header: 'Ageing (days)' }, { key: 'priority', header: 'Priority' },
                ])}>Export CSV</button>
              </div>
              {/* Used to cap at 8 rows with a "View all" link out to the
                  Projects tab -- the Table itself now paginates (5/page,
                  see components/Common.tsx), so every row is reachable
                  right here and that link is no longer needed. */}
              <Table rowKey="project_id" columns={attentionColumns} rows={visibleItems} />
            </div>
          </>
        )}

        {govExpanded && govTab === 'Projects' && (
          <div style={{ marginTop: 12 }}>
            <div className="governance-filter-strip">
              <ClearableSearchInput value={governanceSearch} onChange={(e) => setGovernanceSearch(e.target.value)} onClear={() => setGovernanceSearch('')} clearLabel="Clear project search" wrapperClassName="search-grow" placeholder="Search project, application, owner…" />
              <SearchableSelect
                value={teamFilter}
                onChange={setTeamFilter}
                style={{ minWidth: 160 }}
                options={[{ value: '', label: 'All teams' }, ...teams.map((t) => ({ value: t, label: t }))]}
              />
              <select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)}><option value="">All priorities</option>{priorities.map((p) => <option key={p}>{p}</option>)}</select>
              <span>{visibleItems.length} result{visibleItems.length !== 1 ? 's' : ''}</span>
            </div>
            <Table rowKey="project_id" columns={[
              { key: 'project_id', header: 'Project' },
              { key: 'application_name', header: 'Application' },
              { key: 'department', header: 'Department', render: (r) => r.department || '—' },
              { key: 'pending_stage', header: 'Pending At' },
              { key: 'responsible_team', header: 'Team', render: (r) => r.responsible_team || r.department || '—' },
              { key: 'owner', header: 'Owner', render: (r) => r.owner || '—' },
              { key: 'ageing_days', header: 'Ageing', render: (r) => <span className={`ageing-pill ${r.ageing_days > 15 ? 'breached' : r.ageing_days > 7 ? 'near' : 'within'}`}>{r.ageing_days}d</span> },
              { key: 'priority', header: 'Priority', render: (r) => r.priority ? <Badge status={r.priority} /> : '—' },
            ]} rows={visibleItems} />
          </div>
        )}

        {govExpanded && govTab === 'Ageing' && (
          <div className="subpanel" style={{ marginTop: 12 }}>
            <p className="muted small" style={{ marginTop: -6, marginBottom: 10 }}>
              All {threeW.total_pending} open item{threeW.total_pending !== 1 ? 's' : ''} (Functional, SAST, DAST, Performance & Suppression,
              excluding Drafts and Closed/Cancelled), grouped by days since last update.
            </p>
            <Donut data={threeW.ageing_bucket_distribution} size={160} />
          </div>
        )}
      </Card> : sectionPlaceholder('governance', 'Project governance')}

      <div className="dashboard-section-head dashboard-lower-head"><div><span>Delivery flow</span><h3>Lifecycle and activity</h3></div></div>
      <div className="grid grid-2 dashboard-lower-grid">
        <Card
          title="QA Lifecycle Health"
          subtitle="Functional requests by current workflow stage"
        >
          {summary ? <LifecycleStepper statusCounts={summary.functional_status_counts} /> : sectionPlaceholder('summary', 'Lifecycle health')}
        </Card>
        <Card title="Recent Activity" subtitle="Activity within the selected reporting period">
          {activityLoading || sectionErrors.activity ? sectionPlaceholder('activity', 'Recent activity') : <RecentActivity items={filteredActivity} />}
        </Card>
      </div>
    </div>
  )
}

function SecurityTab({ range }: { range: RaisedRange }) {
  const navigate = useRequestNavigation()
  const [sast, setSast] = useState<SecuritySastDashboard | null>(null)
  const [dast, setDast] = useState<SecurityDastDashboard | null>(null)
  const [error, setError] = useState<unknown>(null)
  const [selection, setSelection] = useState<{ kind: 'sast' | 'dast'; metric: SecurityInsightMetric; value: string } | null>(null)
  const [detail, setDetail] = useState<SecurityInsightDetail | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [detailError, setDetailError] = useState<unknown>(null)
  const detailRequest = useRef(0)

  function closeDetails() {
    detailRequest.current++
    setSelection(null)
    setDetail(null)
    setDetailError(null)
    setDetailLoading(false)
  }

  async function loadDetails(target: NonNullable<typeof selection>, page = 1, pageSize = 5) {
    const request = ++detailRequest.current
    setDetailLoading(true)
    setDetailError(null)
    try {
      const query = new URLSearchParams(rangeQuery(range).replace(/^\?/, ''))
      query.set('metric', target.metric)
      if (target.value) query.set('value', target.value)
      query.set('page', String(page))
      query.set('page_size', String(pageSize))
      const result = await api.get<SecurityInsightDetail>(`/api/dashboard/security/${target.kind}/details?${query}`)
      if (request === detailRequest.current) setDetail(result)
    } catch (err) {
      if (request === detailRequest.current) setDetailError(err)
    } finally {
      if (request === detailRequest.current) setDetailLoading(false)
    }
  }

  function openDetails(kind: 'sast' | 'dast', metric: SecurityInsightMetric, value = '') {
    const target = { kind, metric, value }
    setSelection(target)
    setDetail(null)
    void loadDetails(target)
  }

  useEffect(() => {
    let cancelled = false
    closeDetails()
    setError(null)
    setSast(null)
    setDast(null)
    const query = rangeQuery(range)
    Promise.all([api.get<SecuritySastDashboard>(`/api/dashboard/security/sast${query}`), api.get<SecurityDastDashboard>(`/api/dashboard/security/dast${query}`)])
      .then(([s, d]) => { if (!cancelled) { setSast(s); setDast(d) } })
      .catch((err) => { if (!cancelled) setError(err) })
    return () => { cancelled = true; detailRequest.current++ }
  }, [range])

  const columns: TableColumn<SecurityInsightDetail['rows'][number]>[] = [
    { key: 'request_id', header: 'Request ID' },
    { key: 'application_name', header: 'Application' },
    ...(selection?.kind === 'dast' ? [{ key: 'application_url', header: 'Application URL' }] : []),
    { key: 'department', header: 'Department', render: (row) => row.department || '—' },
    { key: 'status', header: 'Current stage', render: (row) => <WorkflowStatusBadge record={row} status={row.status} /> },
    ...(['vulnerabilities', 'severity', 'remediation'].includes(selection?.metric || '')
      ? [{ key: 'value', header: selection?.metric === 'severity' ? `${selection.value} findings` : 'Open findings' }] : []),
    { key: 'updated_at', header: 'Updated', render: (row) => row.updated_at ? timeAgo(row.updated_at) : '—' },
  ]

  if (error) return <ErrorText error={error} />
  if (!sast || !dast) return <DashboardLoadingSkeleton variant="insights" />
  return (
    <div>
      <div className="section-title">SAST</div>
      <div className="grid grid-3">
        <MetricCard label="SAST Requests Raised" value={sast.total_requests} hint="SAST requests in any status within the selected period and your visible scope."
          onClick={() => openDetails('sast', 'requests')} />
        <MetricCard label="Applications Scanned" value={sast.applications_scanned} hint="Distinct applications whose SAST request has reached Report Ready or Closed."
          onClick={() => openDetails('sast', 'applications')} />
        <MetricCard label="Open Vulnerabilities" value={sast.open_vulnerabilities} hint="Open findings in each request’s latest imported Fortify scan."
          onClick={() => openDetails('sast', 'vulnerabilities')} />
      </div>
      <div className="section-title" style={{ marginTop: 16 }}>DAST</div>
      <div className="grid grid-2">
        <MetricCard label="DAST Requests Raised" value={dast.total_requests} hint="DAST requests in any status within the selected period and your visible scope."
          onClick={() => openDetails('dast', 'requests')} />
        <MetricCard label="Scan Coverage (Scanned Applications)" value={dast.scan_coverage}
          hint="Distinct application URLs whose DAST request has reached Report Ready or Closed."
          onClick={() => openDetails('dast', 'applications')} />
      </div>
      <p className="muted small">Select a card or a non-zero chart bar to view its source records.</p>
      <div className="grid grid-2" style={{ marginTop: 16 }}>
        <Card title="SAST Severity Distribution"><BarChart data={sast.severity_distribution} onBarClick={(severity) => openDetails('sast', 'severity', severity)} /></Card>
        <Card title="DAST Vulnerability Trends"><BarChart data={dast.vulnerability_trends} onBarClick={(severity) => openDetails('dast', 'severity', severity)} /></Card>
      </div>
      <div className="grid grid-2" style={{ marginTop: 16 }}>
        <Card title="SAST Remediation Status" subtitle="Resolved only when every repository has a current, validated clear result"><BarChart data={sast.remediation_status} onBarClick={(status) => openDetails('sast', 'remediation', status)} /></Card>
        <Card title="DAST Compliance Status" subtitle="Requests by workflow and compliance state"><BarChart data={dast.compliance_status} onBarClick={(status) => openDetails('dast', 'compliance', status)} /></Card>
      </div>
      {selection && <Modal key={detail?.total_rows ? 'records' : 'summary'}
        title={detail?.title || 'Security analytics details'} onClose={closeDetails}
        variant={detail?.total_rows ? 'drawer' : 'dialog'} compact={!detail?.total_rows} wide={!!detail?.total_rows}>
        {detailLoading && !detail && <p role="status">Loading source records…</p>}
        <ErrorText error={detailError} />
        {!!detailError && <button className="btn" onClick={() => void loadDetails(selection, detail?.page || 1, detail?.page_size || 5)}>Retry</button>}
        {detail && (detail.total_rows === 0 ? <div className="security-insight-empty" role="status">
          <div className="security-insight-empty-count"><strong>{detail.total}</strong><span>{detail.unit}</span></div>
          <h4>No matching records</h4>
          <p>There are no records for this metric in the selected period and your visible scope.</p>
          <p className="muted small">{detail.description}</p>
          <button type="button" className="btn btn-primary" onClick={closeDetails}>Close</button>
        </div> : <>
          <div className="ap-overview"><div><strong>{detail.total}</strong><span>{detail.unit}</span></div><p>{detail.description}</p></div>
          <Table
            rowKey="key" columns={columns} rows={detail.rows}
            onRowClick={(row) => { if (row.route) navigate(row.route) }}
            server={{ page: detail.page, pageSize: detail.page_size, total: detail.total_rows,
              totalPages: detail.total_pages, hasNext: detail.has_next, hasPrevious: detail.has_previous,
              loading: detailLoading, onPageChange: (page) => loadDetails(selection, page, detail.page_size),
              onPageSizeChange: (pageSize) => loadDetails(selection, 1, pageSize),
            }} />
        </>)}
      </Modal>}
    </div>
  )
}

function SuppressionTab({ range }: { range: RaisedRange }) {
  const navigate = useRequestNavigation()
  const [data, setData] = useState<SuppressionDashboard | null>(null)
  const [error, setError] = useState<unknown>(null)
  const [severity, setSeverity] = useState<FortifySuppressedSeverity | null>(null)
  const [detail, setDetail] = useState<FortifySuppressionDetailOut | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [detailError, setDetailError] = useState<unknown>(null)
  const detailRequest = useRef(0)
  useEffect(() => {
    let active = true
    detailRequest.current++
    setData(null); setError(null)
    setSeverity(null); setDetail(null); setDetailError(null); setDetailLoading(false)
    api.get<SuppressionDashboard>(`/api/dashboard/suppression${rangeQuery(range)}`)
      .then((result) => { if (active) { setData(result); setError(null) } })
      .catch((failure) => { if (active) setError(failure) })
    return () => { active = false; detailRequest.current++ }
  }, [range])

  async function loadDetails(selectedSeverity: FortifySuppressedSeverity, page: number, pageSize: number) {
    const request = ++detailRequest.current
    setDetailLoading(true)
    setDetailError(null)
    try {
      const query = new URLSearchParams(rangeQuery(range).replace(/^\?/, ''))
      query.set('severity', selectedSeverity)
      query.set('page', String(page))
      query.set('page_size', String(pageSize))
      const result = await api.get<FortifySuppressionDetailOut>(`/api/dashboard/suppression/fortify-details?${query.toString()}`)
      if (request === detailRequest.current) {
        setDetail(result)
        setDetailError(null)
      }
    } catch (err) {
      if (request === detailRequest.current) setDetailError(err)
    } finally {
      if (request === detailRequest.current) setDetailLoading(false)
    }
  }

  function closeDetails() {
    detailRequest.current++
    setSeverity(null); setDetail(null); setDetailError(null); setDetailLoading(false)
  }

  function openDetails(key: string) {
    if (!['Critical', 'High', 'Medium', 'Low'].includes(key)) return
    const selectedSeverity = key as FortifySuppressedSeverity
    setSeverity(selectedSeverity)
    setDetail(null)
    void loadDetails(selectedSeverity, 1, 5)
  }

  const detailColumns: TableColumn<FortifySuppressionDetailRow>[] = [
    { key: 'type', header: 'Scan type' },
    { key: 'request_id', header: 'Request ID' },
    { key: 'application_name', header: 'Application' },
    { key: 'application_version', header: 'Version' },
    { key: 'department', header: 'Department', render: (row) => row.department || '—' },
    { key: 'suppressed_count', header: severity || 'Suppressed', render: (row) => <strong>{row.suppressed_count}</strong> },
    { key: 'suppressed_total', header: 'All suppressed' },
    { key: 'imported_at', header: 'Latest import', render: (row) => row.imported_at ? formatDateTimeIST(row.imported_at) : '—' },
  ]

  if (error) return <ErrorText error={error} />
  if (!data) return <DashboardLoadingSkeleton variant="insights" />
  return (
    <div>
      <div className="grid grid-2">
        <MetricCard
          label="Open QualityOps Suppression Requests"
          value={data.open_qualityops_suppression_requests}
          hint="QualityOps approval requests not yet Done, Rejected, or otherwise closed out."
        />
        <MetricCard
          label="Fortify Suppressed Findings"
          value={data.fortify_suppressed_findings}
          hint="Suppressed findings in the latest Fortify SSC Security Auditor View for in-scope SAST and DAST requests."
        />
      </div>
      <div className="grid grid-2" style={{ marginTop: 16 }}>
        <Card title="Fortify Suppressed Findings by Severity" subtitle="Latest SSC snapshot · Critical, High, Medium, and Low">
          <BarChart data={data.fortify_suppressed_severity_distribution} onBarClick={openDetails} />
          <p className="muted small" style={{ marginBottom: 0 }}>Select a non-zero severity to view application-wise details.</p>
        </Card>
        <Card title="QualityOps Suppression Status" subtitle="Approval requests by workflow state">
          <BarChart data={data.status_breakdown} />
        </Card>
      </div>
      {severity && (
        <Modal
          title={detail?.title || `Fortify Suppressed ${severity} Findings`}
          onClose={closeDetails}
          wide
        >
          {detailLoading && <p className="muted">Loading application details…</p>}
          <ErrorText error={detailError} />
          {detail && (
            <>
              <div className="dashboard-drilldown-summary">
                <div><strong>{detail.total}</strong><span>{detail.unit}</span></div>
                <p>{detail.description}</p>
              </div>
              <Table
                rowKey="key"
                columns={detailColumns}
                rows={detail.rows}
                server={{
                  page: detail.page,
                  pageSize: detail.page_size,
                  total: detail.total_rows,
                  totalPages: detail.total_pages,
                  hasNext: detail.has_next,
                  hasPrevious: detail.has_previous,
                  loading: detailLoading,
                  onPageChange: (page) => loadDetails(severity, page, detail.page_size),
                  onPageSizeChange: (pageSize) => loadDetails(severity, 1, pageSize),
                }}
                onRowClick={(row) => navigate(row.route)}
              />
            </>
          )}
        </Modal>
      )}
    </div>
  )
}

function ThreeWTab({ range }: { range: RaisedRange }) {
  const [data, setData] = useState<ThreeWOut | null>(null)
  const [error, setError] = useState<unknown>(null)
  const [detail, setDetail] = useState<ThreeWDetailOut | null>(null)

  const detailRequestId = useRef(0)
  const [detailError, setDetailError] = useState<unknown>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  useEffect(() => {
    let active = true
    detailRequestId.current++
    setData(null); setError(null)
    setDetail(null); setDetailError(null); setDetailLoading(false)
    api.get<ThreeWOut>(`/api/dashboard/3w${rangeQuery(range)}`)
      .then((result) => { if (active) { setData(result); setError(null) } })
      .catch((failure) => { if (active) setError(failure) })
    return () => { active = false; detailRequestId.current++ }
  }, [range])

  async function openProject(projectId: string, source: string) {
    const requestId = ++detailRequestId.current
    setDetail(null); setDetailError(null); setDetailLoading(true)
    try {
      const result = await api.get<ThreeWDetailOut>(`/api/dashboard/3w/${encodeURIComponent(projectId)}?source=${encodeURIComponent(source)}`)
      if (requestId === detailRequestId.current) setDetail(result)
    } catch (err) { if (requestId === detailRequestId.current) setDetailError(err) }
    finally { if (requestId === detailRequestId.current) setDetailLoading(false) }
  }

  if (error) return <ErrorText error={error} />
  if (!data) return <DashboardLoadingSkeleton variant="insights" />

  return (
    <div>
      <p className="muted small">
        "Know What Is Pending, Where It Is Pending, and Since When" — real-time visibility into pending QA
        documents, approvals, reviews and sign-offs in the selected workspace. Click a Project ID to drill into its
        lifecycle.
      </p>
      <div className="grid grid-4" style={{ marginBottom: 16 }}>
        <MetricCard label="Total Pending Items" value={data.total_pending}
                    hint="Open QA, SAST, DAST & Suppression requests -- excludes Drafts and anything already Closed/Cancelled." />
      </div>
      <div className="grid grid-3" style={{ marginBottom: 16 }}>
        <Card title="Team-wise Distribution"><BarChart data={data.team_wise_distribution} /></Card>
        <Card title="Ageing Buckets"><BarChart data={data.ageing_bucket_distribution} /></Card>
        <Card title="Priority Distribution"><BarChart data={data.priority_distribution} /></Card>
      </div>
      <Card title="Pending Items">
        <Table
          rowKey="project_id"
          onRowClick={(r) => openProject(r.project_id, r.source)}
          columns={[
            { key: 'project_id', header: 'Project / Request ID' },
            { key: 'application_name', header: 'Application' },
            { key: 'department', header: 'Department', render: (r) => r.department || '—' },
            { key: 'pending_stage', header: 'Pending Stage' },
            { key: 'responsible_team', header: 'Responsible Team' },
            { key: 'owner', header: 'Owner', render: (r) => r.owner || '—' },
            { key: 'ageing_days', header: 'Ageing', render: (r) => <span className={`ageing-pill ${r.ageing_days > 15 ? 'breached' : r.ageing_days > 7 ? 'near' : 'within'}`}>{r.ageing_days}d</span> },
            { key: 'priority', header: 'Priority', render: (r) => r.priority ? <Badge status={r.priority} /> : '—' },
            { key: 'source', header: 'Source' },
          ]}
          rows={data.items}
        />
      </Card>
      {detailLoading && <p role="status">Loading lifecycle…</p>}
      {!!detailError && <ErrorText error={detailError} />}
      {detail && (
        <Card title={`Lifecycle — ${detail.project_id || ''}`}>
          {detail.detail ? <p className="muted">{detail.detail}</p> : (
            <>
              <p><strong>Application:</strong> {detail.application_name} &nbsp; <strong>Status:</strong> <WorkflowStatusBadge record={detail} status={detail.status} /> &nbsp; <strong>Ageing:</strong> {detail.ageing_days} days</p>
              <div className="section-title">Lifecycle / Audit Trail</div>
              <Table rowKey="at" columns={[
                { key: 'step', header: 'Step' },
                { key: 'decision', header: 'Decision' },
                { key: 'actor_role', header: 'Role', render: (r) => formatRoleLabels(r.actor_role) || '—' },
                { key: 'at', header: 'When', render: (r) => formatDateTimeIST(r.at) },
              ]} rows={detail.lifecycle} />
              <div className="section-title">Readiness Checklist</div>
              <ul className="small">
                {detail.readiness_checklist.map((c, i) => (
                  <li key={i}>{c.complete ? '✅' : '⬜️'} {c.item} — {c.owner}</li>
                ))}
              </ul>
            </>
          )}
        </Card>
      )}
    </div>
  )
}

// Own dedicated tab (not a card mixed into Dashboard) so the main
// dashboard shows the active workspace's data, and this personal/
// department-scoped view is a deliberate, separate destination instead of
// something narrowing the default landing view.
//
// The table is backed by one dedicated, paginated dashboard endpoint. Oracle
// applies the user's scope and IST reporting period to each request type
// before the union, so the browser never has to load or filter five large
// request lists locally.
function MyRequestsTab({ range }: { range: RaisedRange }) {
  const navigate = useRequestNavigation()
  const { user } = useAuth()
  const [reqScope, setReqScope] = useState<'mine' | 'department'>('mine')
  const [requestPage, setRequestPage] = useState<DashboardRequestsPage | null>(null)
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(25)
  // The Dashboard feed uses server keyset pagination, not an ever-growing
  // OFFSET scan.  Table only exposes Previous/Next navigation, so retaining
  // the cursor used for each visited page gives users normal back navigation
  // without putting the database back through a global sort.
  const [pageCursors, setPageCursors] = useState<Record<number, string | null>>({ 1: null })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<unknown>(null)
  // 2026-08 "one user can be on multiple departments" CR -- "My department"
  // now means the UNION across every department this user belongs to, not
  // just their primary one.
  const myDepartments = user?.departments && user.departments.length
    ? user.departments : (user?.department ? [user.department] : [])

  // A reporting-period change can reduce the result set.  Always return to
  // the first server page so a previously valid later page never presents as
  // a misleading empty state.
  useEffect(() => {
    setPage(1)
    setPageCursors({ 1: null })
  }, [range.preset, range.from, range.to])

  useEffect(() => {
    if (!user?.id) return
    let cancelled = false
    setLoading(true)
    setError(null)
    const query = new URLSearchParams(rangeQuery(range).replace(/^\?/, ''))
    query.set('scope', reqScope)
    query.set('page', String(page))
    query.set('page_size', String(pageSize))
    const cursor = pageCursors[page]
    if (cursor) query.set('cursor', cursor)
    api.get<DashboardRequestsPage>(`/api/dashboard/requests?${query.toString()}`)
      .then((result) => { if (!cancelled) setRequestPage(result) })
      .catch((loadError) => { if (!cancelled) setError(loadError) })
      .finally(() => { if (!cancelled) setLoading(false) })
    return () => { cancelled = true }
  }, [user?.id, reqScope, page, pageSize, pageCursors, range.preset, range.from, range.to])

  function changeRequestPage(nextPage: number) {
    if (nextPage > page) {
      const nextCursor = requestPage?.next_cursor
      if (!nextCursor) return
      setPageCursors((current) => ({ ...current, [nextPage]: nextCursor }))
    }
    setPage(nextPage)
  }

  const scopedRequests = requestPage?.items || []

  if (error) return <ErrorText error={error} />
  if (!requestPage && loading) return <DashboardLoadingSkeleton variant="requests" />

  return (
    <div>
      <Card
        right={(
          <div className="pill-tabs">
            <button className={reqScope === 'mine' ? 'active' : ''} onClick={() => { setReqScope('mine'); setPage(1); setPageCursors({ 1: null }) }}>
              My Requests{reqScope === 'mine' && requestPage ? ` (${requestPage.total})` : ''}
            </button>
            <button className={reqScope === 'department' ? 'active' : ''} onClick={() => { setReqScope('department'); setPage(1); setPageCursors({ 1: null }) }}>
              {myDepartments.length ? myDepartments.join(', ') : 'My Department'}{reqScope === 'department' && requestPage ? ` (${requestPage.total})` : ''}
            </button>
          </div>
        )}
      >
        <div className="grid grid-3">
          <StatCard icon={IconGrid} iconClass="blue" value={requestPage?.total || 0} label="Main requests" />
          <StatCard icon={IconWorkflow} iconClass="purple" value={requestPage?.active_total || 0} label="Active / in progress" />
          <StatCard icon={IconCheckCircle} iconClass="amber" value={requestPage?.terminal_total || 0} label="Closed / cancelled" />
        </div>

        <p className="muted small">Each main QA request is counted once. Expand its child requests to view testing workflows. Standalone requests are counted separately. Raised requests remain active until all linked testing workflows are closed or cancelled.</p>
        <div style={{ marginTop: 18 }}>
          <Table
            rowKey="uid"
            onRowClick={(r) => navigate(`${TYPE_TO_PATH[r.type] || '/qa-requests'}?openId=${r.id}`)}
            columns={[
              { key: 'type', header: 'Type' },
              { key: 'request_id', header: 'Main request / child requests', render: (r) => <div>
                <strong>{r.request_id}</strong>
                {!!r.children?.length && <details onClick={event => event.stopPropagation()} style={{ marginTop: 8 }}>
                  <summary style={{ cursor: 'pointer' }}>{r.children.length} child request{r.children.length === 1 ? '' : 's'}</summary>
                  <div style={{ display: 'grid', gap: 10, marginTop: 10 }}>{r.children.map(child => <div key={`${child.type}-${child.id}`}>
                    <button type="button" className="btn btn-sm" onClick={() => navigate(`${TYPE_TO_PATH[child.type]}?openId=${child.id}`)}>{child.type} · {child.request_id}</button>
                    <div style={{ marginTop: 4 }}><WorkflowStatusBadge record={r} status={child.status} /></div>
                  </div>)}</div>
                </details>}
              </div> },
              { key: 'application_name', header: 'Application' },
              {
                key: 'change_description',
                header: 'Change Description',
                render: (r) => (
                  <span className="truncate-cell" title={r.change_description || ''}>
                    {r.change_description || '—'}
                  </span>
                ),
                filterValue: (r) => r.change_description || '',
              },
              { key: 'department', header: 'Department', render: (r) => r.department || '—' },
              { key: 'status', header: 'Status', render: (r) => <WorkflowStatusBadge record={r} status={r.status} /> },
              { key: 'created_at', header: 'Raised', render: (r) => timeAgo(r.created_at) },
            ]}
            rows={scopedRequests}
            server={{
              page: requestPage?.page || page,
              pageSize: requestPage?.page_size || pageSize,
              total: requestPage?.total || 0,
              totalPages: requestPage?.total_pages || 1,
              hasNext: requestPage?.has_next || false,
              hasPrevious: requestPage?.has_previous || false,
              onPageChange: changeRequestPage,
              onPageSizeChange: (nextPageSize) => { setPageSize(nextPageSize); setPage(1); setPageCursors({ 1: null }) },
              loading,
            }}
          />
          {!loading && scopedRequests.length === 0 && (
            <p className="muted small" style={{ marginTop: 8 }}>
              {reqScope === 'mine' ? "You haven't raised any requests yet." : 'No requests found for your department yet.'}
            </p>
          )}
        </div>
      </Card>
    </div>
  )
}

interface TesterWorkloadRow extends TesterActivityRow {
  department: string
  role_label: string
  status_counts: Record<string, number>
  source_counts: Record<'Functional' | 'Performance' | 'SAST' | 'DAST', number>
  total_pending: number
  occupied_points: number
  occupancy_percent: number
  available_percent: number
  occupancy_band: 'Available' | 'Light' | 'Balanced' | 'High' | 'Full' | 'Overloaded'
  queued_count: number
  active_count: number
  waiting_count: number
  near_complete_count: number
  assignments: TesterAssignment[]
  testcases_draft: number
  recommendation_pending: number
  qa_lead_approval_pending: number
  testcases_approved: number
  projects_worked: number
  project_names: string[]
  current_execution_assignments: number
  last_activity?: string | null
}

interface TesterAssignment {
  request_id: string
  request_pk: number
  source: 'Functional' | 'Performance' | 'SAST' | 'DAST'
  application_name: string
  status: string
  updated_at: string
  is_current: boolean
}

interface TesterWorkloadOut {
  statuses: string[]
  rows: TesterWorkloadRow[]
  total_pending: number
  testers_with_pending: number
  capacity_points: number
  average_occupancy: number
  available_testers: number
  highly_occupied_testers: number
  overloaded_testers: number
  contribution_summary: TesterContributionSummary
}

interface TesterContributionSummary {
  active_contributors: number
  testcases_created: number
  testcases_draft: number
  recommendation_pending: number
  qa_lead_approval_pending: number
  testcases_approved: number
  defects_raised: number
  retests_performed: number
  executions_completed: number
  projects_covered: number
}

interface TesterContributionActivity {
  activity_id: string
  activity_type: 'Defect Raised' | 'Defect Retested' | 'Execution Attempt'
  record_key: string
  description: string
  status: string
  activity_at: string
  project_id?: number | null
  project_key?: string | null
  project_name?: string | null
  route: string
}

interface TesterCurrentAssignment {
  record_key: string
  cycle_key: string
  cycle_status: string
  execution_status: string
  assigned_at?: string | null
  project_id: number
  project_key: string
  project_name: string
  route: string
}

interface TesterContributionProject {
  project_id: number
  project_key: string
  project_name: string
  activity_types: string[]
  last_activity?: string | null
}

interface TesterContributionDetail {
  tester_id: number
  tester_name: string
  period: { date_from?: string | null; date_to?: string | null }
  activities: TesterContributionActivity[]
  current_assignments: TesterCurrentAssignment[]
  projects: TesterContributionProject[]
  detail_limit: number
}

type TesterContributionDetailView = 'Defects' | 'Retests' | 'Executions' | 'Projects' | 'Current Assignments'

// QA-team-only capacity view. Aggregation and permission
// enforcement both live on /api/dashboard/qa-tester-workload; the client
// gate below is for navigation clarity, not the sole security boundary.
function TesterOverviewTab({ range }: { range: RaisedRange }) {
  const navigate = useRequestNavigation()
  const [workload, setWorkload] = useState<TesterWorkloadOut | null>(null)
  const [error, setError] = useState<unknown>(null)
  const [view, setView] = useState<'contribution' | 'capacity'>('contribution')
  const [selectedCapacityTesterId, setSelectedCapacityTesterId] = useState<number | null>(null)
  const [contributionDetail, setContributionDetail] = useState<TesterContributionDetail | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [detailView, setDetailView] = useState<TesterContributionDetailView>('Defects')
  const [testerFilterId, setTesterFilterId] = useState('')
  const [departmentFilter, setDepartmentFilter] = useState('')
  const [projectFilter, setProjectFilter] = useState('')
  const [exportingContribution, setExportingContribution] = useState(false)
  const occupancyTrendQuery = useMemo(() => rangeQuery(range), [range])

  useEffect(() => {
    // Keep the previous dashboard visible while a custom period is being
    // entered; do not accidentally issue an unbounded all-time query when
    // only one of the two mandatory dates is present.
    if (range.preset === 'custom' && (!range.from || !range.to)) return
    let current = true
    setWorkload(null); setError(null)
    setContributionDetail(null)
    api.get<TesterWorkloadOut>(`/api/dashboard/qa-tester-workload${occupancyTrendQuery}`)
      .then(result => { if (current) setWorkload(result) })
      .catch(err => { if (current) setError(err) })
    return () => { current = false }
  }, [range, occupancyTrendQuery])

  if (range.preset === 'custom' && (!range.from || !range.to)) {
    return <p className="muted">Select both Dashboard custom dates to load QA tester reporting data.</p>
  }
  if (error) return <ErrorText error={error} />
  if (!workload) return <p className="muted">Loading QA tester workload…</p>

  async function openContribution(row: TesterWorkloadRow, target?: TesterContributionDetailView) {
    const resolvedTarget = target
      || (row.defects_raised ? 'Defects'
        : row.retests_performed ? 'Retests'
          : row.executions_completed ? 'Executions'
            : row.projects_worked ? 'Projects' : 'Current Assignments')
    setDetailView(resolvedTarget)
    setDetailLoading(true)
    setError(null)
    try {
      const query = rangeQuery(range)
      setContributionDetail(await api.get<TesterContributionDetail>(
        `/api/dashboard/qa-tester-contribution/${row.tester_id}${query}${query ? '&' : '?'}limit=200`,
      ))
    } catch (err) {
      setError(err)
    } finally {
      setDetailLoading(false)
    }
  }

  const capacityColumns: TableColumn<TesterWorkloadRow>[] = [
    {
      key: 'tester_name', header: 'QA Tester',
      render: (row) => <div className="tester-capacity-person"><strong>{row.tester_name}</strong><span>{row.role_label} · {row.department}</span></div>,
    },
    {
      key: 'occupancy_percent', header: 'Occupancy',
      render: (row) => (
        <div className={`tester-occupancy tester-occupancy-${row.occupancy_band.toLowerCase()}`}>
          <div><strong>{row.occupancy_percent}%</strong><span>{row.occupancy_band}</span></div>
          <div className="tester-occupancy-track"><i style={{ width: `${Math.min(100, row.occupancy_percent)}%` }} /></div>
          <small>{row.occupied_points} of {workload.capacity_points} capacity points</small>
        </div>
      ),
      filterValue: (row) => `${row.occupancy_percent} ${row.occupancy_band}`,
    },
    {
      key: 'total_pending', header: 'Assigned',
      render: (row) => <strong className={row.total_pending ? 'tester-workload-total' : 'muted'}>{row.total_pending}</strong>,
    },
    { key: 'active_count', header: 'Active Work', render: (row) => <span className={`tester-workload-count ${row.active_count ? 'has-work' : ''}`}>{row.active_count}</span> },
    { key: 'queued_count', header: 'Queued', render: (row) => <span className={`tester-workload-count ${row.queued_count ? 'has-work' : ''}`}>{row.queued_count}</span> },
    { key: 'waiting_count', header: 'Waiting / Blocked', render: (row) => <span className={`tester-workload-count ${row.waiting_count ? 'is-waiting' : ''}`}>{row.waiting_count}</span> },
    { key: 'near_complete_count', header: 'Near Complete', render: (row) => <span className={`tester-workload-count ${row.near_complete_count ? 'is-complete' : ''}`}>{row.near_complete_count}</span> },
    {
      key: 'work_mix', header: 'Work Mix',
      render: (row) => (
        <div className="tester-work-mix">
          <span>Functional <strong>{row.source_counts.Functional || 0}</strong></span>
          <span>Performance <strong>{row.source_counts.Performance || 0}</strong></span>
          <span>SAST <strong>{row.source_counts.SAST || 0}</strong></span>
          <span>DAST <strong>{row.source_counts.DAST || 0}</strong></span>
        </div>
      ),
      filterValue: (row) => `Functional ${row.source_counts.Functional || 0} Performance ${row.source_counts.Performance || 0} SAST ${row.source_counts.SAST || 0} DAST ${row.source_counts.DAST || 0}`,
    },
    {
      key: 'available_percent', header: 'Available Capacity',
      render: (row) => <strong className={row.available_percent > 0 ? 'tester-available-capacity' : 'tester-no-capacity'}>{row.available_percent}%</strong>,
    },
  ]

  const contributionColumns: TableColumn<TesterWorkloadRow>[] = [
    {
      key: 'tester_name', header: 'QA Tester',
      render: (row) => <div className="tester-capacity-person"><strong>{row.tester_name}</strong><span>{row.role_label} · {row.department}</span></div>,
    },
    { key: 'testcases_created', header: 'Test Cases Created', render: (row) => <strong>{row.testcases_created}</strong> },
    { key: 'testcases_draft', header: 'Draft Test Cases', render: (row) => <strong className={row.testcases_draft ? 'tester-draft-count' : 'muted'}>{row.testcases_draft}</strong> },
    { key: 'recommendation_pending', header: 'Recommendation Pending', render: (row) => <strong className={row.recommendation_pending ? 'tester-pending-count' : 'muted'}>{row.recommendation_pending}</strong> },
    { key: 'qa_lead_approval_pending', header: 'QA Lead Approval Pending', render: (row) => <strong className={row.qa_lead_approval_pending ? 'tester-pending-count is-qa-lead' : 'muted'}>{row.qa_lead_approval_pending}</strong> },
    { key: 'testcases_approved', header: 'Approved Test Cases', render: (row) => <strong className={row.testcases_approved ? 'tester-approved-count' : 'muted'}>{row.testcases_approved}</strong> },
    { key: 'defects_raised', header: 'Defects Raised', render: (row) => <button className="tester-metric-link danger" disabled={!row.defects_raised} onClick={(event) => { event.stopPropagation(); openContribution(row, 'Defects') }}>{row.defects_raised}</button> },
    { key: 'retests_performed', header: 'Defects Retested', render: (row) => <button className="tester-metric-link warning" disabled={!row.retests_performed} onClick={(event) => { event.stopPropagation(); openContribution(row, 'Retests') }}>{row.retests_performed}</button> },
    { key: 'executions_completed', header: 'Execution Attempts', render: (row) => <button className="tester-metric-link" disabled={!row.executions_completed} onClick={(event) => { event.stopPropagation(); openContribution(row, 'Executions') }}>{row.executions_completed}</button> },
    { key: 'projects_worked', header: 'Projects Worked On', render: (row) => <button className="tester-metric-link success" disabled={!row.projects_worked} title={row.project_names.join('\n')} onClick={(event) => { event.stopPropagation(); openContribution(row, 'Projects') }}>{row.projects_worked}</button>, filterValue: (row) => row.project_names.join(' ') },
    { key: 'current_execution_assignments', header: 'Current Assignments', render: (row) => <button className="tester-metric-link" disabled={!row.current_execution_assignments} onClick={(event) => { event.stopPropagation(); openContribution(row, 'Current Assignments') }}>{row.current_execution_assignments}</button> },
    { key: 'last_activity', header: 'Last Activity', render: (row) => row.last_activity ? formatDateTimeIST(row.last_activity) : <span className="muted">No activity in period</span> },
  ]

  const departments = Array.from(new Set(workload.rows.map((row) => row.department).filter((value) => value && value !== '—'))).sort()
  const projects = Array.from(new Set(workload.rows.flatMap((row) => row.project_names))).sort()
  const filteredRows = workload.rows.filter((row) => (
    (!testerFilterId || row.tester_id === Number(testerFilterId))
    && (!departmentFilter || row.department.includes(departmentFilter))
    && (!projectFilter || row.project_names.includes(projectFilter))
  ))
  const filteredSummary: TesterContributionSummary = {
    active_contributors: filteredRows.filter(hasRecordedTesterActivity).length,
    testcases_created: filteredRows.reduce((sum, row) => sum + row.testcases_created, 0),
    testcases_draft: filteredRows.reduce((sum, row) => sum + row.testcases_draft, 0),
    recommendation_pending: filteredRows.reduce((sum, row) => sum + row.recommendation_pending, 0),
    qa_lead_approval_pending: filteredRows.reduce((sum, row) => sum + row.qa_lead_approval_pending, 0),
    testcases_approved: filteredRows.reduce((sum, row) => sum + row.testcases_approved, 0),
    defects_raised: filteredRows.reduce((sum, row) => sum + row.defects_raised, 0),
    retests_performed: filteredRows.reduce((sum, row) => sum + row.retests_performed, 0),
    executions_completed: filteredRows.reduce((sum, row) => sum + row.executions_completed, 0),
    projects_covered: new Set(filteredRows.flatMap((row) => row.project_names)).size,
  }
  const projectCoverageChart = filteredRows.reduce<Record<string, number>>((result, row) => {
    row.project_names.forEach((project) => { result[project] = (result[project] || 0) + 1 })
    return result
  }, {})
  const bounds = rangeBounds(range)
  const periodLabel = `${bounds.start ? formatDateIST(bounds.start) : 'Beginning'} – ${bounds.end ? formatDateIST(bounds.end) : 'Today'} (IST)`

  function exportContribution() {
    downloadCsv('qa-contribution-and-coverage.csv', filteredRows.map((row) => ({
      tester: row.tester_name, department: row.department,
      test_cases_created: row.testcases_created,
      draft_test_cases: row.testcases_draft,
      recommendation_pending: row.recommendation_pending,
      qa_lead_approval_pending: row.qa_lead_approval_pending,
      approved_test_cases: row.testcases_approved,
      defects_raised: row.defects_raised,
      defects_retested: row.retests_performed, execution_attempts: row.executions_completed,
      projects_worked_on: row.projects_worked, project_names: row.project_names.join('; '),
      current_assignments: row.current_execution_assignments,
      last_activity: row.last_activity ? formatDateTimeIST(row.last_activity) : '',
      reporting_period: periodLabel,
    })), [
      { key: 'tester', header: 'QA Tester' }, { key: 'department', header: 'Department' },
      { key: 'test_cases_created', header: 'Test Cases Created' },
      { key: 'draft_test_cases', header: 'Draft Test Cases' },
      { key: 'recommendation_pending', header: 'Recommendation Pending' },
      { key: 'qa_lead_approval_pending', header: 'QA Lead Approval Pending' },
      { key: 'approved_test_cases', header: 'Approved Test Cases' },
      { key: 'defects_raised', header: 'Defects Raised' },
      { key: 'defects_retested', header: 'Defects Retested' }, { key: 'execution_attempts', header: 'Execution Attempts' },
      { key: 'projects_worked_on', header: 'Projects Worked On' }, { key: 'project_names', header: 'Project Names' },
      { key: 'current_assignments', header: 'Current Assignments' }, { key: 'last_activity', header: 'Last Activity' },
      { key: 'reporting_period', header: 'Reporting Period' },
    ])
  }

  async function exportContributionExcel() {
    setExportingContribution(true)
    setError(null)
    try {
      const { start, end } = rangeBounds(range)
      const params = new URLSearchParams()
      if (start) params.set('date_from', toIstApiDateTime(start))
      if (end) params.set('date_to', toIstApiDateTime(end))
      const selectedTester = workload?.rows.find((row) => row.tester_id === Number(testerFilterId))
      if (selectedTester) params.set('search', selectedTester.tester_name)
      if (departmentFilter) params.set('department', departmentFilter)
      if (projectFilter) params.set('project', projectFilter)
      await api.downloadFile(`/api/dashboard/qa-contribution-export?${params}`, 'qa-contribution-and-coverage.xlsx')
    } catch (err) {
      setError(err)
    } finally {
      setExportingContribution(false)
    }
  }

  return (
    <div className="tester-overview-tab">
      <div className="dashboard-section-head">
        <div><strong>QA Contribution & Coverage</strong><span>Evidence-based testcase, defect, retest, execution, project, and current-work tracking. Using the Dashboard reporting period: {periodLabel}.</span></div>
        <Badge status="QA_LEAD_ASSIGNED" label="QA team only" />
      </div>
      <div className="pill-tabs tester-overview-modes">
        <button className={view === 'contribution' ? 'active' : ''} onClick={() => setView('contribution')}>Contribution & Coverage</button>
        <button className={view === 'capacity' ? 'active' : ''} onClick={() => setView('capacity')}>Capacity & Occupancy</button>
      </div>
      {view === 'contribution' && <>
      <div className="tester-contribution-filters">
        <SearchableSelect
          value={testerFilterId}
          onChange={setTesterFilterId}
          placeholder="Search QA tester…"
          options={[
            { value: '', label: 'All QA testers' },
            ...workload.rows.map((row) => ({ value: String(row.tester_id), label: `${row.tester_name} · ${row.role_label} · ${row.department}` })),
          ]}
          style={{ minWidth: 280, flex: '1 1 320px' }}
        />
        <select value={departmentFilter} onChange={(event) => setDepartmentFilter(event.target.value)}><option value="">All departments</option>{departments.map((department) => <option key={department}>{department}</option>)}</select>
        <select value={projectFilter} onChange={(event) => setProjectFilter(event.target.value)}><option value="">All projects</option>{projects.map((project) => <option key={project}>{project}</option>)}</select>
        <button className="btn btn-sm btn-primary" disabled={exportingContribution} onClick={exportContributionExcel}>{exportingContribution ? 'Exporting…' : 'Export Excel'}</button>
        <button className="btn btn-sm" onClick={exportContribution}>Export CSV</button>
      </div>
      <div className="tester-workload-summary tester-contribution-summary">
        <div><small>Active QA contributors</small><strong>{filteredSummary.active_contributors}</strong><span>With recorded work in this period</span></div>
        <div><small>Test cases created</small><strong>{filteredSummary.testcases_created}</strong><span>Original testcase identities, not versions</span></div>
        <div><small>Draft test cases</small><strong className={filteredSummary.testcases_draft ? 'draft' : ''}>{filteredSummary.testcases_draft}</strong><span>Created but not submitted for recommendation</span></div>
        <div><small>Recommendation pending</small><strong className={filteredSummary.recommendation_pending ? 'warning' : ''}>{filteredSummary.recommendation_pending}</strong><span>Awaiting reviewer recommendation</span></div>
        <div><small>QA Lead approval pending</small><strong className={filteredSummary.qa_lead_approval_pending ? 'danger' : ''}>{filteredSummary.qa_lead_approval_pending}</strong><span>Recommended and awaiting final approval</span></div>
        <div><small>Approved test cases</small><strong className={filteredSummary.testcases_approved ? 'approved' : ''}>{filteredSummary.testcases_approved}</strong><span>Completed final QA approval</span></div>
        <div><small>Defects raised</small><strong>{filteredSummary.defects_raised}</strong><span>Governed defects reported</span></div>
        <div><small>Defects retested</small><strong>{filteredSummary.retests_performed}</strong><span>Distinct defects with a latest recorded retest in this period</span></div>
        <div><small>Execution attempts</small><strong>{filteredSummary.executions_completed}</strong><span>Retained testcase run attempts</span></div>
        <div><small>Projects covered</small><strong>{filteredSummary.projects_covered}</strong><span>Distinct projects with real QA activity</span></div>
      </div>
      <div className="grid grid-2 tester-contribution-charts">
        <Card title="Activity by tester"><TesterActivityChart rows={filteredRows} /></Card>
        <Card title="Project coverage by QA testers"><BarChart data={projectCoverageChart} /></Card>
      </div>
      <div className="tester-metric-definition" role="note"><strong>How these figures are counted</strong><span>A testcase is counted once from its original author record; versions do not increase the count. Draft, pending, and approved figures show the current workflow stage of testcases created in the selected period. Defects use the reporter. Defects retested uses each defect's latest recorded retest tester and date. Execution attempts include repeat runs. These activity types are counted separately. Projects require actual authoring, execution, defect, or retest activity. Use the linked defect, retest, and execution counts for record-level evidence.</span></div>
      <Card>
        <Table rowKey="tester_id" columns={contributionColumns} rows={filteredRows} onRowClick={(row) => openContribution(row)} />
      </Card>
      {detailLoading && <p className="muted">Loading tester contribution details…</p>}
      {contributionDetail && !detailLoading && <Card title={`${contributionDetail.tester_name} · Contribution evidence`} className="tester-contribution-detail">
        <div className="pill-tabs tester-detail-tabs">
          {(['Defects', 'Retests', 'Executions', 'Projects', 'Current Assignments'] as const).map((item) => <button key={item} className={detailView === item ? 'active' : ''} onClick={() => setDetailView(item)}>{item}</button>)}
        </div>
        {detailView === 'Projects' ? <Table rowKey="project_id" rows={contributionDetail.projects} onRowClick={(project) => navigate(`/test-repository?project=${project.project_id}`)} columns={[
          { key: 'project_key', header: 'Project', render: (project) => <strong>{project.project_key}</strong> },
          { key: 'project_name', header: 'Project Name' },
          { key: 'activity_types', header: 'Contribution Types', render: (project) => project.activity_types.join(', ') },
          { key: 'last_activity', header: 'Last Activity', render: (project) => project.last_activity ? formatDateTimeIST(project.last_activity) : '—' },
        ]} /> : detailView === 'Current Assignments' ? <Table rowKey="record_key" rows={contributionDetail.current_assignments} onRowClick={(item) => navigate(item.route)} columns={[
          { key: 'record_key', header: 'Test Case', render: (item) => <strong>{item.record_key}</strong> },
          { key: 'project_name', header: 'Project', render: (item) => `${item.project_key} — ${item.project_name}` },
          { key: 'cycle_key', header: 'Cycle' },
          { key: 'cycle_status', header: 'Cycle Status', render: (item) => <Badge status={item.cycle_status} /> },
          { key: 'execution_status', header: 'Latest Result', render: (item) => <Badge status={item.execution_status} /> },
          { key: 'assigned_at', header: 'Assigned', render: (item) => item.assigned_at ? formatDateTimeIST(item.assigned_at) : '—' },
        ]} /> : <Table rowKey="activity_id" rows={contributionDetail.activities.filter((item) => (detailView === 'Defects' && item.activity_type === 'Defect Raised') || (detailView === 'Retests' && item.activity_type === 'Defect Retested') || (detailView === 'Executions' && item.activity_type === 'Execution Attempt'))} onRowClick={(item) => navigate(item.route)} columns={[
          { key: 'activity_type', header: 'Activity' },
          { key: 'record_key', header: 'Record ID', render: (item) => <strong>{item.record_key}</strong> },
          { key: 'project_name', header: 'Project', render: (item) => item.project_name ? `${item.project_key} — ${item.project_name}` : 'Not linked to a Test Project' },
          { key: 'description', header: 'Details' },
          { key: 'status', header: 'Status', render: (item) => <WorkflowStatusBadge record={item} status={item.status} /> },
          { key: 'activity_at', header: 'Activity Date', render: (item) => formatDateTimeIST(item.activity_at) },
        ]} />}
        {!['Projects', 'Current Assignments'].includes(detailView) && <p className="muted small">Up to {contributionDetail.detail_limit} recent records are shown per activity category. Summary counts above always cover the complete selected period.</p>}
      </Card>}
      </>}
      {view === 'capacity' && <>
      <Card><TesterOccupancyTrend query={occupancyTrendQuery} periodLabel={periodLabel} selectedTesterId={selectedCapacityTesterId} onSelectTester={setSelectedCapacityTesterId} /></Card>
      <div className="dashboard-section-head"><div><strong>Current capacity &amp; occupancy</strong><span>Live assignments now. The trend above uses the selected reporting period.</span></div></div>
      <div className="tester-workload-summary">
        <div><small>Average team occupancy</small><strong>{workload.average_occupancy}%</strong><span>Across {workload.rows.length} active QA team members</span></div>
        <div><small>Available team members</small><strong>{workload.available_testers}</strong><span>Below 50% occupied</span></div>
        <div><small>Highly occupied</small><strong>{workload.highly_occupied_testers}</strong><span>80% occupied or higher</span></div>
        <div><small>Overloaded team members</small><strong className={workload.overloaded_testers ? 'danger' : ''}>{workload.overloaded_testers}</strong><span>Above planned capacity</span></div>
      </div>
      <div className="tester-capacity-note">
        <div><strong>How occupancy is calculated</strong>
        <span>{workload.capacity_points} points equal 100%. Functional Execution in Progress = 2.5 points; test design, Performance setup/script/load execution, and Security scanning = 1 point; configuration/retest/baseline = 0.75; queued or remediation work = 0.5; result analysis = 0.25; waiting for fix = 0; and near-complete work = 0.05–0.15. Shared Functional or Performance requests are divided between assigned testers.</span></div>
        <a className="btn btn-sm" href="/docs/qa-tester-occupancy-guide.pdf" target="_blank" rel="noreferrer">View calculation guide</a>
      </div>
      <Card>
        <Table
          rowKey="tester_id"
          columns={capacityColumns}
          rows={workload.rows}
          onRowClick={(row) => setSelectedCapacityTesterId((current) => current === row.tester_id ? null : row.tester_id)}
        />
        {workload.rows.length === 0 && (
          <p className="muted small" style={{ marginTop: 8 }}>No active QA testers are available.</p>
        )}
      </Card>
      {selectedCapacityTesterId && (() => {
        const tester = workload.rows.find((row) => row.tester_id === selectedCapacityTesterId)
        if (!tester) return null
        const pathBySource: Record<TesterAssignment['source'], string> = { Functional: '/functional-requests', Performance: '/performance', SAST: '/sast', DAST: '/dast' }
        return <Card title={`${tester.tester_name} · Request tracking`} className="tester-assignment-ledger">
          <div className="tester-ledger-summary"><span><strong>{tester.assignments.filter((item) => item.is_current).length}</strong> currently working</span><span><strong>{tester.assignments.filter((item) => !item.is_current).length}</strong> completed in selected period</span></div>
          <Table
            tableId="qa-tester-request-ledger"
            rowKey="request_id"
            rows={tester.assignments}
            onRowClick={(assignment) => navigate(`${pathBySource[assignment.source]}?openId=${assignment.request_pk}`)}
            columns={[
              { key: 'request_id', header: 'Request ID', render: (item) => <strong>{item.request_id}</strong> },
              { key: 'source', header: 'Request Type' },
              { key: 'application_name', header: 'Application' },
              { key: 'status', header: 'Status', render: (item) => <WorkflowStatusBadge record={item} status={item.status} /> },
              { key: 'work_state', header: 'Work State', render: (item) => <span className={item.is_current ? 'tester-ledger-current' : 'tester-ledger-complete'}>{item.is_current ? 'Currently working' : 'Completed'}</span> },
              { key: 'updated_at', header: 'Last Activity', render: (item) => formatDateTimeIST(item.updated_at) },
            ]}
          />
        </Card>
      })()}
      </>}
    </div>
  )
}

// Reported directly: the "My Requests" tab (renamed to just "Requests" --
// see below) should be hidden for these roles -- QA Engineer, QA Lead,
// Security Analyst, and the QA Executive Group (CHIEF_MANAGER_QA / AGM_QA,
// 2026-08 -- see constants.py::Role's own comment on the CHEIF_MANAGER_COE/
// AGM_COE consolidation) -- they work across every team's requests as part
// of their job, so a "requests I personally raised" view isn't relevant to
// them the way it is for a Requester/Business Analyst/SM/Department Head.
// Checked directly against `user.roles` (not the shared `hasRole` helper,
// which treats ADMIN as satisfying any role check) so an Admin who also
// happens to hold one of these roles still sees the tab, matching "Admin
// always sees everything" elsewhere in the app.
const REQUESTS_TAB_HIDDEN_ROLES = [
  'QA_ENGINEER', 'QA_LEAD', 'SECURITY_ANALYST', 'CHIEF_MANAGER_QA', 'AGM_QA',
  'VIEW_ONLY',
]

export default function Dashboard() {
  const { user } = useAuth()
  const [tab, setTab] = useState('command')
  const [insightTab, setInsightTab] = useState<'security' | 'suppression' | '3w'>('security')
  const [range, setRange] = useState<RaisedRange>(DEFAULT_RAISED_RANGE)
  // Remount dashboard data owners when account/workspace identity changes.
  // This also prevents a slower response started under a previous scope from
  // committing into the newly-selected scope's component state.
  const activeWorkspaceId = localStorage.getItem('active_workspace_id')
    || localStorage.getItem('qa_active_workspace_id')
    || String(user?.preferred_workspace_id || user?.preferred_qa_workspace_id || 'unscoped')
  const dashboardScopeKey = `${user?.id || 'anonymous'}:${activeWorkspaceId}`
  const activeWorkspace = (user?.workspace_access || user?.qa_workspace_access || [])
    .find((membership) => String(membership.workspace_id) === activeWorkspaceId)
  const activeWorkspaceName = activeWorkspace?.workspace_name || 'Selected workspace'

  const hideRequestsTab = !!user?.roles?.some((r) => REQUESTS_TAB_HIDDEN_ROLES.includes(r))
    && !user?.roles?.includes('ADMIN')
  // QA workload contains internal tester assignment information. This uses
  // a direct role check (not hasRole's Admin bypass): Admin-only accounts are
  // not QA team members and therefore must not see this restricted view.
  const showTesterOverviewTab = !!user?.roles?.some((role) => (
    ['QA_ENGINEER', 'QA_LEAD', 'SECURITY_ANALYST', 'CHIEF_MANAGER_QA', 'AGM_QA', 'VIEW_ONLY'].includes(role)
  ))
  const organisationWidePortfolio = !!user?.roles?.some((role) => ORGANISATION_WIDE_PORTFOLIO_ROLES.has(role))
    || !user?.departments?.length
  const portfolioScopeLabel = organisationWidePortfolio
    ? `${activeWorkspaceName} · All departments`
    : `${activeWorkspaceName} · ${user?.departments.join(', ') || 'No department assigned'}`

  const tabs = [
    { key: 'command', label: 'Dashboard' },
    ...(hideRequestsTab ? [] : [{ key: 'my-requests', label: 'Requests' }]),
    { key: 'insights', label: 'Portfolio Analytics' },
    ...(showTesterOverviewTab ? [{ key: 'tester-overview', label: 'QA Tester Overview' }] : []),
  ]

  return (
    <div className="dashboard-page">
      <div className="dashboard-page-header">
        <div>
          <p>Quality operations</p>
          <h1>Dashboard</h1>
          <span>Monitor delivery health, governance, security, and team performance.</span>
        </div>
        <div className="dashboard-header-status"><i /><span><strong>Systems operational</strong><small>Live portal data</small></span></div>
      </div>
      <div className="tester-period-filter" role="group" aria-label="Dashboard filters">
        <div><strong>Reporting period</strong><span>All dates use India Standard Time (IST). Dashboard metrics, activity, portfolio analytics, and requests use this created/raised-date range.</span></div>
        <div className="tester-period-presets">
          {([
            ['7d', 'Last 7 days'], ['30d', 'Last 30 days'], ['3m', 'Last 3 months'], ['6m', 'Last 6 months'], ['custom', 'Custom dates'],
          ] as Array<[RaisedRangePreset, string]>).map(([preset, label]) => (
            <button key={preset} type="button" className={range.preset === preset ? 'active' : ''}
                    onClick={() => setRange((current) => preset === 'custom'
                      ? {
                          preset,
                          from: current.from || toIstDateInputValue(new Date(Date.now() - 6 * 24 * 60 * 60 * 1000)),
                          to: current.to || toIstDateInputValue(new Date()),
                        }
                      : { ...current, preset })}>{label}</button>
          ))}
        </div>
        {range.preset === 'custom' && <div className="tester-custom-dates">
          <label><span>From *</span><input required type="date" value={range.from} max={range.to || undefined} onChange={(event) => setRange((current) => ({ ...current, from: event.target.value }))} /></label>
          <label><span>To *</span><input required type="date" value={range.to} min={range.from || undefined} onChange={(event) => setRange((current) => ({ ...current, to: event.target.value }))} /></label>
        </div>}
      </div>
      <div className="tabs dashboard-tabs">
        {tabs.map((t) => (
          <button key={t.key} className={tab === t.key ? 'active' : ''} onClick={() => setTab(t.key)}>{t.label}</button>
        ))}
      </div>
      {tab === 'command' && <CommandCentre key={`command:${dashboardScopeKey}`} range={range} />}
      {tab === 'my-requests' && !hideRequestsTab && <MyRequestsTab key={`requests:${dashboardScopeKey}`} range={range} />}
      {tab === 'insights' && (
        <div className="dashboard-insights">
          <div className="dashboard-insights-head">
            <div><span>Risk and workflow analytics</span><h2>Portfolio Analytics</h2><p>Review security trends, suppression decisions, and pending work across the QA portfolio.</p></div>
            <div className="pill-tabs dashboard-insight-tabs">
              <button className={insightTab === 'security' ? 'active' : ''} onClick={() => setInsightTab('security')}>Security</button>
              <button className={insightTab === 'suppression' ? 'active' : ''} onClick={() => setInsightTab('suppression')}>Suppression</button>
              <button className={insightTab === '3w' ? 'active' : ''} onClick={() => setInsightTab('3w')}>3W Pending</button>
            </div>
          </div>
          <div className="portfolio-scope-note" role="note">
            <div>
              <span>Data scope</span>
              <strong>{organisationWidePortfolio ? 'Workspace-wide portfolio' : 'Department portfolio'}</strong>
            </div>
            <p><b>{portfolioScopeLabel}</b> · Every total and drilldown follows this workspace plus the signed-in user&apos;s team access.</p>
          </div>
          {insightTab === 'security' && <SecurityTab key={`security:${dashboardScopeKey}`} range={range} />}
          {insightTab === 'suppression' && <SuppressionTab key={`suppression:${dashboardScopeKey}`} range={range} />}
          {insightTab === '3w' && <ThreeWTab key={`3w:${dashboardScopeKey}`} range={range} />}
        </div>
      )}
      {tab === 'tester-overview' && showTesterOverviewTab && <TesterOverviewTab key={`testers:${dashboardScopeKey}`} range={range} />}
    </div>
  )
}
