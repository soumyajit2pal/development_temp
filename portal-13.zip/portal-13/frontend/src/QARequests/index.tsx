import WorkflowStatusBadge from '../components/WorkflowStatusBadge'
import { useRequestNavigation, useViewerManagedDeepLinks } from '../hooks/useRequestNavigation'
import React, { useCallback, useEffect, useState } from "react";
import {useLocation} from "react-router-dom"
import { api, HttpError, subscribeToApiMutations } from "../api";
import { formatDateTimeIST } from "../time";
import {
  Card,
  ErrorText,
  PageHeader,
  Table,
} from "../components/Common";
import InfoModal from "../components/InfoModal";
import { QARequestListOut, QARequestOut, UserOption, QAWorkspaceOut } from "../types";
import { classificationSummary, userName } from "./format";
import { NewRequestModal } from "./NewRequestModal";
import { RequestDetail } from "./RequestDetail";
import CurrentStageStatus from "./CurrentStageStatus";
import { qaRequestCurrentStage, qaRequestStatusMutation } from "./currentStage";
import ClearableSearchInput from "../components/ClearableSearchInput";
import RaisedHistoryFilter from "../components/RaisedHistoryFilter";
import { IconPlus } from "../components/Icons";
import { QA_REQUEST_CREATOR_ROLES, hasRole } from "../constants";
import "./QARequests.css";
import "../components/PortalActionButton.css";
import { usePaginatedList } from "../hooks/usePaginatedList";
import { useAuth } from "../context/AuthContext";

type LinkedRequestKind = "Functional QA" | "SAST" | "DAST" | "Performance" | "Clearance";

interface LinkedRequestSearchResult {
  key: string;
  kind: LinkedRequestKind;
  path: string;
  request: QARequestListOut["linked_functional_requests"][number];
}

const LINKED_REQUEST_GROUPS: Array<{
  field: keyof Pick<QARequestListOut,
    "linked_functional_requests" |
    "linked_sast_requests" |
    "linked_dast_requests" |
    "linked_performance_requests" |
    "linked_signoffs"
  >;
  kind: LinkedRequestKind;
  path: string;
}> = [
  { field: "linked_functional_requests", kind: "Functional QA", path: "/functional-requests" },
  { field: "linked_sast_requests", kind: "SAST", path: "/sast" },
  { field: "linked_dast_requests", kind: "DAST", path: "/dast" },
  { field: "linked_performance_requests", kind: "Performance", path: "/performance" },
  { field: "linked_signoffs", kind: "Clearance", path: "/signoff" },
];

function linkedRequestsFor(row: QARequestListOut): LinkedRequestSearchResult[] {
  return LINKED_REQUEST_GROUPS.flatMap(({ field, kind, path }) =>
    (row[field] || []).map((request) => ({
      key: `${kind}-${request.id}`,
      kind,
      path,
      request,
    }))
  );
}

// The QA Requests list page -- the intake gateway. "Raise QA Request" opens
// the wizard (NewRequestModal); clicking a row opens the detail/edit view
// (RequestDetail). See ./buildSteps.ts, ./validation.ts and ./steps/* for how
// the wizard itself is put together.
export default function QARequests() {
  const viewerManagedDeepLinks = useViewerManagedDeepLinks();
  const { user } = useAuth();
  const location = useLocation();
  const navigate = useRequestNavigation();
  const searchParams = new URLSearchParams(location.search);
  const [users, setUsers] = useState<UserOption[]>([]);
  const [workspaces, setWorkspaces] = useState<QAWorkspaceOut[]>([]);
  const [assignedOnly, setAssignedOnly] = useState(false);
  const [raisedHistory, setRaisedHistory] = useState({ from: "", to: "" });
  const [search, setSearch] = useState(
    searchParams.get("search") || searchParams.get("application_name") || searchParams.get("cr_number") || ""
  );
  // Set only when arriving via a CR/EPIC-number global search (see
  // components/Layout.tsx's submitSearch) -- drives an exact-match filter
  // (GET /api/qa-requests?cr_number=...) instead of the free-text `search`
  // param's substring match, so CR-102 doesn't also pull in CR-1023/
  // CR-1024. Cleared as soon as the box is edited by hand, reverting to
  // ordinary free-text search.
  const [crNumber, setCrNumber] = useState(searchParams.get("cr_number") || "");
  const [showNew, setShowNew] = useState(false);
  // SRS 7.2 PAG-006 -- the list only ever holds the lightweight
  // QARequestListOut shape now; opening a request fetches the full
  // QARequestOut record fresh via GET /api/qa-requests/{id} before
  // RequestDetail (which needs every field) is shown. `openingId` drives a
  // small inline loading state on the row being opened while that fetch is
  // in flight.
  const [selected, setSelected] = useState<QARequestOut | null>(null);
  const [openingId, setOpeningId] = useState<number | null>(null);
  const [error, setError] = useState<unknown>(null);
  // Shown right after saving a brand-new request, as long as it's still sitting
  // in Draft (which it always is at this point -- creating a QA Request never
  // raises it) -- makes it explicit that nothing has actually been submitted
  // yet, since there's no separate "Draft saved" confirmation otherwise.
  const [draftNotice, setDraftNotice] = useState(false);

  const {
    items: requests, page, pageSize, total, totalPages, hasNext, hasPrevious,
    loading, setPage, setPageSize, reload,
  } = usePaginatedList<QARequestListOut>("/api/qa-requests", {
    // While an exact CR/EPIC-number filter is active, the free-text
    // substring `search` param is suppressed -- cr_number below already
    // narrows to exactly that CR, and combining both would just be
    // redundant (harmless, but pointless) until the user edits the box.
    search: crNumber ? undefined : search,
    extra: {
      assigned_to_me: assignedOnly ? "true" : undefined,
      cr_number: crNumber || undefined,
      raised_from: raisedHistory.from || undefined,
      raised_to: raisedHistory.to || undefined,
    },
  });

  useEffect(() => {
    api.get<UserOption[]>("/api/auth/user-options").then(setUsers).catch(setError);
    if (user?.roles.includes('ADMIN')) api.get<QAWorkspaceOut[]>('/api/workspaces').then(setWorkspaces).catch(setError);
  }, [user?.id]);

  // Keep statuses current without asking users to refresh the browser. A
  // successful mutation in this tab updates immediately; a conservative
  // visibility-aware poll also captures changes made by another approver,
  // browser, or API client. Hidden tabs do not poll.
  useEffect(() => {
    const refreshIfVisible = () => {
      if (!document.hidden) reload();
    };
    const unsubscribe = subscribeToApiMutations((event) => {
      // Child workflow and clearance actions also change the displayed stage.
      if (qaRequestStatusMutation(event.path)) {
        refreshIfVisible();
      }
    });
    const interval = window.setInterval(refreshIfVisible, 20_000);
    document.addEventListener("visibilitychange", refreshIfVisible);
    return () => {
      unsubscribe();
      window.clearInterval(interval);
      document.removeEventListener("visibilitychange", refreshIfVisible);
    };
  }, [reload]);

  useEffect(() => {
    // Reacts to location.state on every navigation to this route -- not just
    // on first mount -- so the topbar's "+ New QA request" button (which
    // navigates here with { state: { openNew: true } }) also works when the
    // user is already sitting on the QA Requests page (no remount happens
    // in that case, so a useState initializer alone would miss it).
    const state = location.state as { openNew?: boolean } | null;
    if (state?.openNew) {
      setShowNew(true);
      // Clear the nav state so refreshing/back/clicking the button again doesn't get stuck.
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location.state, location.pathname, navigate]);

  useEffect(() => {
    // Same "no remount on this route" issue as the openNew effect above --
    // the topbar search box (components/Layout.tsx) navigates to
    // `/qa-requests?search=...` from anywhere in the app, including while
    // already sitting on this page. `search`'s useState initializer only
    // reads the URL once, on first mount, so a second search typed into the
    // topbar while already here updated the URL but never reached this
    // page's `search` state -- the list just kept showing the previous (or
    // no) filter. Re-syncing on every `location.search` change fixes that.
    const params = new URLSearchParams(location.search);
    setSearch(params.get("search") || params.get("application_name") || params.get("cr_number") || "");
    setCrNumber(params.get("cr_number") || "");
  }, [location.search]);

  const openRequest = useCallback(async (idOrRow: number | QARequestListOut) => {
    const id = typeof idOrRow === "number" ? idOrRow : idOrRow.id;
    setOpeningId(id);
    try {
      const full = await api.get<QARequestOut>(`/api/qa-requests/${id}`);
      setSelected(full);
    } catch (err) {
      // The row may have changed visibility (for example a Draft was raised
      // or cancelled in another session) between the list response and this
      // click. Re-query the list instead of surfacing a misleading 403.
      if (err instanceof HttpError && (err.status === 403 || err.status === 404)) {
        setSelected(null);
        reload();
        return;
      }
      setError(err);
    } finally {
      setOpeningId(null);
    }
  }, [reload]);

  const handleUnavailable = useCallback(() => {
    setSelected(null);
    reload();
  }, [reload]);

  const handleChanged = useCallback((updated: QARequestOut) => {
    setSelected(updated);
    reload();
  }, [reload]);

  // Pending Approvals and other deep links can open the parent gateway's
  // drawer immediately instead of landing on its filtered list first.
  useEffect(() => {
    if (viewerManagedDeepLinks) return;
    const recordId = Number(new URLSearchParams(location.search).get("openId"));
    const openId = new URLSearchParams(location.search).get("open");
    if (Number.isInteger(recordId) && recordId > 0) {
      openRequest(recordId);
    } else if (openId) {
      const match = requests.find((request) => request.request_id === openId);
      if (!match) return;
      openRequest(match.id);
    } else {
      return;
    }
    const params = new URLSearchParams(location.search);
    params.delete("open");
    params.delete("openId");
    navigate(`${location.pathname}${params.toString() ? `?${params}` : ""}`, { replace: true });
  }, [requests, location.search, location.pathname, navigate, openRequest, viewerManagedDeepLinks]);

  function clearSearch() {
    setSearch("");
    setCrNumber("");
    const params = new URLSearchParams(location.search);
    params.delete("search");
    params.delete("application_name");
    params.delete("cr_number");
    const remaining = params.toString();
    navigate(`${location.pathname}${remaining ? `?${remaining}` : ""}`, { replace: true });
  }

  const linkedResultCount = requests.reduce(
    (count, request) => count + linkedRequestsFor(request).length,
    0
  );

  function openLinkedRequest(event: React.MouseEvent, linked: LinkedRequestSearchResult) {
    // The surrounding table row opens the parent QA Request. A linked chip
    // is a more specific destination, so keep that row handler from firing.
    event.stopPropagation();
    navigate(`${linked.path}?openId=${linked.request.id}`);
  }

  return (
    <div className="qa-requests-page">
      <ErrorText error={error} />
      <PageHeader
        eyebrow="Request management"
        title={crNumber ? `${crNumber} traceability` : "QA Requests"}
        count={total}
        subtitle={crNumber
          ? "Every visible QA gateway and linked workflow raised under this exact CR/EPIC number. Select a linked record to open it in its owning module."
          : "Create requests and track linked testing work."}
        actions={hasRole(user, ...QA_REQUEST_CREATOR_ROLES) ? (
          <button type="button" className="btn btn-primary portal-action-button" onClick={() => setShowNew(true)}>
            <IconPlus width={16} height={16} aria-hidden="true" /> New QA request
          </button>
        ) : undefined}
      />
      <div className={`toolbar qa-request-toolbar ${crNumber ? "is-traceability" : ""}`}>
        <div className="tabs qa-request-scope-tabs" style={{ margin: 0 }}>
          <button type="button" className={!assignedOnly ? "active" : ""} aria-pressed={!assignedOnly} onClick={() => setAssignedOnly(false)}>
            All requests
          </button>
          <button type="button" className={assignedOnly ? "active" : ""} aria-pressed={assignedOnly} onClick={() => setAssignedOnly(true)}>
            My drafts / delegated
          </button>
        </div>
        {!crNumber && (
          <ClearableSearchInput
            aria-label="Filter QA requests"
            placeholder="Filter by ID, application, CR or project…"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setCrNumber(""); }}
            onClear={clearSearch}
            clearLabel="Clear QA Request search"
            wrapperClassName="search-grow qa-request-local-search"
          />
        )}
        <RaisedHistoryFilter value={raisedHistory} onChange={setRaisedHistory} compact />
      </div>

      {crNumber && !loading && (
        <div className="cr-trace-summary" role="status" aria-live="polite">
          <div>
            <span>Exact CR/EPIC</span>
            <strong>{crNumber}</strong>
          </div>
          <div>
            <span>QA requests</span>
            <strong>{total}</strong>
          </div>
          <div>
            <span>Linked records on this page</span>
            <strong>{linkedResultCount}</strong>
          </div>
          <button type="button" className="cr-trace-clear" onClick={clearSearch}>
            Exit traceability
          </button>
        </div>
      )}

      <Card className="qa-request-register">
        <Table
          rowKey="id"
          onRowClick={(r) => openRequest(r)}
          server={{
            page, pageSize, total, totalPages, hasNext, hasPrevious,
            onPageChange: setPage, onPageSizeChange: setPageSize, loading,
          }}
          columns={[
            {
              key: "request_id",
              header: "Request ID",
              // Not assigned until raised (see backend's request_id column
              // comment) -- a still-Draft row shows a placeholder instead of
              // a blank cell.
              render: (r) => (openingId === r.id ? "Opening…" : (r.request_id || `Draft #${r.id}`)),
              filterValue: (r) => r.request_id || `Draft #${r.id}`,
            },
            { key: "application_name", header: "Application" },
            { key: "module_name", header: "Module", render: (r) => r.module_name || '—' },
            {
              key: "department",
              header: "Department Scope",
              render: (r) => r.department || '—',
              filterValue: (r) => r.department || '',
            },
            {
              key: "qa_workspace",
              header: "Workspace",
              render: (r) => {
                const needsRouting = !r.qa_workspace_id || ['PENDING', 'AMBIGUOUS', 'ROUTING_REQUIRED'].includes(r.workspace_routing_status);
                if (needsRouting && user?.roles.includes('ADMIN')) return <select
                  aria-label={`Move ${r.request_id || `Draft ${r.id}`} to workspace`}
                  defaultValue=""
                  onClick={(event) => event.stopPropagation()}
                  onChange={async (event) => {
                    event.stopPropagation();
                    if (!event.target.value) return;
                    try {
                      await api.patch(`/api/workspaces/requests/${r.id}/route`, { workspace_id: Number(event.target.value) });
                      reload();
                    } catch (err) { setError(err); }
                  }}
                ><option value="">Routing required…</option>{workspaces.filter((workspace) => workspace.is_active).map((workspace) => <option key={workspace.id} value={workspace.id}>{workspace.name}</option>)}</select>;
                return <span className={`badge ${needsRouting ? 'badge-yellow' : 'badge-blue'}`}>{r.qa_workspace_name || 'Routing required'}</span>;
              },
              filterValue: (r) => r.qa_workspace_name || r.workspace_routing_status,
            },
            {
              key: "cr_number",
              header: "CR Number/EPIC Number",
              // Reported directly: "why CR number is blank, though input is
              // provided" -- the backend's list schema was missing cr_number
              // entirely (fixed, see schemas.QARequestListOut), but this
              // also falls back to the legacy epic_number for older rows
              // that predate the consolidated field, same fallback
              // NewRequestModal.tsx already uses when reopening a Draft.
              render: (r) => r.cr_number || r.epic_number || "—",
              filterValue: (r) => r.cr_number || r.epic_number || "",
            },
            {
              key: "change_description",
              header: "Change Description",
              render: (r) => (
                <span className="truncate-cell" title={r.change_description || ""}>
                  {r.change_description || "—"}
                </span>
              ),
              filterValue: (r) => r.change_description || "",
            },
            ...(crNumber ? [{
              key: "linked_requests",
              header: "Linked Records",
              filterable: false,
              render: (r: QARequestListOut) => {
                const linked = linkedRequestsFor(r);
                if (linked.length === 0) return <span className="muted">None yet</span>;
                return (
                  <div className="cr-linked-records">
                    {linked.map((item) => (
                      <div
                        role="button" tabIndex={0}
                        onKeyDown={event => { if (event.target === event.currentTarget && (event.key === "Enter" || event.key === " ")) { event.preventDefault(); event.currentTarget.click() } }}
                        className="cr-linked-record"
                        key={item.key}
                        onClick={(event) => openLinkedRequest(event, item)}
                        title={`Open ${item.kind} request ${item.request.request_id}`}
                      >
                        <span>{item.kind}</span>
                        <strong>{item.request.request_id}</strong>
                        <WorkflowStatusBadge record={r} status={item.request.status} />
                      </div>
                    ))}
                  </div>
                );
              },
            }] : []),
            {
              key: "requester_id",
              header: "Requester",
              render: (r) => userName(users, r.requester_id) || "—",
              filterValue: (r) => userName(users, r.requester_id) || "",
            },
            {
              key: "assigned_to",
              header: "Assigned To",
              render: (r) => r.active_delegation?.assigned_to_name || "—",
              filterValue: (r) => r.active_delegation?.assigned_to_name || "",
            },
            {
              key: "priority",
              header: "Priority / Risk (per type)",
              render: (r) => (
                <span
                  className="truncate-cell"
                  title={classificationSummary(r)}
                >
                  {classificationSummary(r)}
                </span>
              ),
              filterValue: (r) => classificationSummary(r),
            },
            {
              key: "status",
              header: "Status",
              render: (r) => <CurrentStageStatus record={r} onOpenLinked={openLinkedRequest} />,
              filterValue: (r) => qaRequestCurrentStage(r).label,
            },
            {
              key: "pending_with",
              header: "Pending With",
              render: (r) => qaRequestCurrentStage(r).pendingWith,
              filterValue: (r) => qaRequestCurrentStage(r).pendingWith,
            },
            { key: "target_release_date", header: "Target Release" },
            {
              key: "created_at",
              header: "Created",
              render: (r) => formatDateTimeIST(r.created_at),
            },
            {
              key: "updated_at",
              header: "Updated",
              render: (r) => formatDateTimeIST(r.updated_at),
            },
          ]}
          rows={requests}
        />
      </Card>

      {showNew && (
        <NewRequestModal
          onClose={() => setShowNew(false)}
          onCreated={(created) => {
            // Land straight on the new request's detail view instead of
            // dropping the user back on the bare list.
            setShowNew(false);
            reload();
            setSelected(created);
            if (created.status === "DRAFT") setDraftNotice(true);
          }}
        />
      )}
      {selected && (
        <RequestDetail
          req={selected}
          users={users}
          onClose={() => setSelected(null)}
          onUnavailable={handleUnavailable}
          onChanged={handleChanged}
        />
      )}
      {draftNotice && (
        <InfoModal title="Saved as Draft" onClose={() => setDraftNotice(false)}>
          <p style={{ marginTop: -4 }}>
            Your QA Request has been saved as a <strong>Draft</strong> — it has{" "}
            <strong>not</strong> been raised yet.
          </p>
          <p className="muted small">
            Nothing happens on any Functional/SAST/DAST/Performance request
            until you submit it. Open this request any time and click "Submit /
            Raise" when you're ready.
          </p>
        </InfoModal>
      )}
    </div>
  );
}
