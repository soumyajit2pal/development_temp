import React from 'react'
import { Field } from '../../components/Common'
import { PRIORITIES, RISK_RATINGS, POST_SIT_ENVIRONMENTS } from '../../constants'
import { DraftChecklistEvidenceOut } from '../../types'
import { QARequestForm, SetField, blankDastComponent } from '../types'
import { EvidenceKind } from './ChecklistEvidencePicker'
import { ReadinessChecklistSection } from './ReadinessChecklistSection'
import SearchableSelect from '../../components/SearchableSelect'

interface Props {
  form: QARequestForm
  set: SetField
  // Once the linked DAST request already exists (created on an earlier
  // save), further edits happen on that request's own page instead.
  existingDast: boolean
  draftRequestId?: number
  evidenceFiles: (kind: EvidenceKind, itemIndex: number) => File[]
  setEvidenceFiles: (kind: EvidenceKind, itemIndex: number, files: File[]) => void
  savedEvidenceFor: (kind: EvidenceKind, itemIndex: number) => DraftChecklistEvidenceOut[]
  onEvidenceChanged: () => void
  focusEvidenceItem?: string
}

// Shown only while "DAST" is a selected request type -- fills in the
// auto-created DAST request's target details and its own Security
// Readiness checklist self-declaration, up front.
export function DastStep({ form, set, existingDast, draftRequestId, evidenceFiles, setEvidenceFiles, savedEvidenceFor, onEvidenceChanged, focusEvidenceItem }: Props) {
  function toggleChecked(item: string) {
    set(
      'dast_checked_items',
      form.dast_checked_items.includes(item)
        ? form.dast_checked_items.filter((x) => x !== item)
        : [...form.dast_checked_items, item],
    )
  }

  function setTarget<K extends keyof (typeof form.dast_components)[number]>(
    index: number,
    key: K,
    value: (typeof form.dast_components)[number][K],
  ) {
    set('dast_components', form.dast_components.map((row, rowIndex) => (
      rowIndex === index ? { ...row, [key]: value } : row
    )))
  }

  function addTarget() {
    set('dast_components', [...form.dast_components, blankDastComponent()])
  }

  function removeTarget(index: number) {
    if (form.dast_components.length <= 1) return
    set('dast_components', form.dast_components.filter((_, rowIndex) => rowIndex !== index))
  }

  return (
    <div className="security-request-step security-request-step-dast">
      <div className="security-step-intro">
        <span>DAST request configuration</span>
        <h3>Dynamic application security testing details</h3>
        <p>Define classification, reachable scan targets, authentication requirements, and readiness evidence.</p>
      </div>
      {existingDast ? (
        <div className="security-existing-request">
          <strong>DAST request already raised</strong>
          <span>Edit its configuration from DAST Requests. This intake step is now read-only.</span>
        </div>
      ) : (
        <>
          <section className="security-request-panel">
            <div className="security-panel-heading">
              <span className="security-panel-number">01</span>
              <div><h4>Classification</h4><p>Set the operational urgency and security risk independently for this DAST request.</p></div>
            </div>
            <div className="security-classification-grid">
              <Field label="Priority *">
                <SearchableSelect searchable={false} value={form.dast_priority} options={PRIORITIES} onChange={(value) => set('dast_priority', value)} />
              </Field>
              <Field label="Risk Category *">
                <SearchableSelect searchable={false} value={form.dast_risk_category} options={RISK_RATINGS} onChange={(value) => set('dast_risk_category', value)} />
              </Field>
            </div>
            <div className="security-context-note">
              <span>Target release date</span>
              <strong>{form.target_release_date || 'Not provided'}</strong>
              <small>Managed on the Application &amp; Change Details step.</small>
            </div>
          </section>

          <section className="security-request-panel">
            <div className="security-panel-heading security-panel-heading-with-action">
              <span className="security-panel-number">02</span>
              <div><h4>Application scan targets</h4><p>Add every reachable URL as its own target with environment and authentication details.</p></div>
              <button type="button" className="btn security-add-button" onClick={addTarget}>+ Add target</button>
            </div>
            <div className="security-target-list">
              {form.dast_components.map((target, index) => {
                const authYesId = `dast-target-auth-yes-${index}`
                const authNoId = `dast-target-auth-no-${index}`
                return (
                  <div className="security-target-card" key={index}>
                    <div className="security-target-card-head">
                      <span>Target {String(index + 1).padStart(2, '0')}</span>
                      {form.dast_components.length > 1 && (
                        <button type="button" className="security-remove-button" aria-label={`Remove target ${index + 1}`} onClick={() => removeTarget(index)}>Remove</button>
                      )}
                    </div>
                    <div className="security-dast-target-grid">
                      <label className="security-control security-control-application-url">
                        <span>Application URL *</span>
                        <input
                          required type="url" value={target.application_url}
                          placeholder="https://application.example.com"
                          onChange={(event) => setTarget(index, 'application_url', event.target.value)}
                        />
                      </label>
                      <div className="security-control security-control-environment">
                        <span>Environment *</span>
                        <SearchableSelect searchable={false} value={target.environment} options={POST_SIT_ENVIRONMENTS} onChange={(value) => setTarget(index, 'environment', value)} />
                      </div>
                      <div className="security-auth-control">
                        <span>Authentication Required?</span>
                        <div className="security-auth-options" role="radiogroup" aria-label={`Authentication required for target ${index + 1}`}>
                          <label htmlFor={authYesId} className={target.authentication_required ? 'selected' : ''}>
                            <input id={authYesId} type="radio" name={`dast-target-auth-${index}`} checked={target.authentication_required} onChange={() => setTarget(index, 'authentication_required', true)} />
                            <span><strong>Yes</strong><small>Sign-in required</small></span>
                          </label>
                          <label htmlFor={authNoId} className={!target.authentication_required ? 'selected' : ''}>
                            <input id={authNoId} type="radio" name={`dast-target-auth-${index}`} checked={!target.authentication_required} onChange={() => setTarget(index, 'authentication_required', false)} />
                            <span><strong>No</strong><small>No authentication</small></span>
                          </label>
                        </div>
                      </div>
                      {target.authentication_required && (
                        <label className="security-control security-control-credentials">
                          <span>Test Credentials *</span>
                          <input
                            required value={target.test_credentials}
                            placeholder="Provide a dedicated non-production test account"
                            onChange={(event) => setTarget(index, 'test_credentials', event.target.value)}
                          />
                          <small>Use credentials approved for security testing. Do not enter personal production credentials.</small>
                        </label>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </section>

          <ReadinessChecklistSection
            department={form.department}
            module="DAST" kind="dast" sectionNumber="03"
            heading="Security readiness self-declaration"
            description="Confirm what is already in place and attach supporting evidence beside the relevant criterion. The Security Analyst will verify every declaration independently."
            noticeLabel="Before SM approval"
            noticeText="Every mandatory criterion must be selected and have supporting evidence attached before the request can be raised."
            selectedItems={form.dast_checked_items} onToggle={toggleChecked}
            draftRequestId={draftRequestId} evidenceFiles={evidenceFiles} setEvidenceFiles={setEvidenceFiles}
            savedEvidenceFor={savedEvidenceFor} onEvidenceChanged={onEvidenceChanged}
            focusEvidenceItem={focusEvidenceItem}
          />
        </>
      )}
    </div>
  )
}
