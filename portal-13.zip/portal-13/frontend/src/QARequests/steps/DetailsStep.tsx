import React, { useEffect, useState } from "react";
import { api } from "../../api";
import { istToday } from "../../time";
import { ErrorText, Field, Modal } from "../../components/Common";
import SearchableSelect from "../../components/SearchableSelect";
import NewApplicationDisabledModal from "../../components/NewApplicationDisabledModal";
import RoleGroupLink from "../../components/RoleGroupLink";
import { IconUsers } from "../../components/Icons";
import { CHANGE_TYPES, DEPLOYMENT_ENVIRONMENTS, validTargetPromotionOptions } from "../../constants";
import { ApplicationMasterOut, ApplicationCreationPolicyOut } from "../../types";
import { QARequestForm, SetField } from "../types";
import { ModuleNameField } from "./ModuleNameField";
import { CHANGE_REFERENCE_REGEX, CHANGE_REFERENCE_MAX_LENGTH, CHANGE_REFERENCE_FORMAT_ERROR } from "../../changeReference";

// Sentinel dropdown value for "Other" -- never a real application name (all
// real names are always upper-cased, see backend routers/qa_requests.py::
// _resolve_application_name), so this can't collide with one.
const OTHER = "__OTHER__";

interface Props {
  form: QARequestForm;
  set: SetField;
  // 2026-08 "one user can be on multiple departments" CR, follow-up: the
  // requester's own department(s) only -- never the full org-wide list (that
  // stays enforced server-side too, see routers/qa_requests.py::
  // _resolve_requester_department).
  departmentOptions: string[];
  departmentLocked?: boolean;
}

interface BugFixSourceOption {
  request_id: string;
  functional_request_id: string;
  application_name: string;
  cr_number?: string | null;
  completed_at?: string | null;
}

// First wizard step -- the core "Application & Change Details" and
// "Release & Environment" fields, shared by every request type.
export function DetailsStep({ form, set, departmentOptions, departmentLocked = false }: Props) {
  // An already-Draft request's saved department might not be in the
  // requester's CURRENT department list any more (e.g. an Admin later
  // removed that department from their profile) -- keep it selectable
  // rather than silently dropping/blanking an already-valid saved value.
  const departmentSelectOptions = form.department && !departmentOptions.includes(form.department)
    ? [form.department, ...departmentOptions]
    : departmentOptions;
  const [crError, setCrError] = useState("");
  // Approved names only -- a brand-new name typed via "Other" doesn't show up
  // here until an Application Owner in the workspace approves it on the
  // master QA Request. Always includes "Other" as a standing option
  // regardless of what's been approved so far.
  const [approvedNames, setApprovedNames] = useState<ApplicationMasterOut[]>(
    []
  );
  const [approvedNamesLoaded, setApprovedNamesLoaded] = useState(false);
  const [showOther, setShowOther] = useState(false);
  const [showNewApplicationWarning, setShowNewApplicationWarning] = useState(false);
  const [applicationCreationEnabled, setApplicationCreationEnabled] = useState(false);
  const [checkingCreationPolicy, setCheckingCreationPolicy] = useState(false);
  const [showCreationDisabled, setShowCreationDisabled] = useState(false);
  const [creationPolicyError, setCreationPolicyError] = useState<unknown>(null);
  const [bugFixSources, setBugFixSources] = useState<BugFixSourceOption[]>([]);

  useEffect(() => {
    api
      .get<ApplicationMasterOut[]>("/api/application-names")
      .then(names => { setApprovedNames(names); setApprovedNamesLoaded(true); })
      .catch(() => {});
  }, []);

  useEffect(() => {
    let active = true;
    api.getFresh<ApplicationCreationPolicyOut>("/api/system-settings/application-creation")
      .then(policy => { if (active) setApplicationCreationEnabled(policy.enabled); })
      .catch(error => { if (active) setCreationPolicyError(error); });
    return () => { active = false; };
  }, []);

  async function creationAllowed() {
    setCheckingCreationPolicy(true); setCreationPolicyError(null);
    try {
      // Recheck at activation so an already-open wizard observes admin changes.
      const policy = await api.getFresh<ApplicationCreationPolicyOut>("/api/system-settings/application-creation");
      setApplicationCreationEnabled(policy.enabled);
      if (!policy.enabled) { setShowNewApplicationWarning(false); setShowCreationDisabled(true); }
      return policy.enabled;
    } catch (error) {
      setApplicationCreationEnabled(false); setCreationPolicyError(error);
      setShowNewApplicationWarning(false); setShowCreationDisabled(true);
      return false;
    } finally { setCheckingCreationPolicy(false); }
  }

  async function chooseOther() {
    if (await creationAllowed()) setShowNewApplicationWarning(true);
  }

  // Once the approved list has loaded, figure out whether the current value
  // (e.g. re-opening a Draft that already has a still-pending "Other" name,
  // or a name an SM has since rejected) is one of the approved options or
  // needs the "Other" textbox shown instead -- covers both "brand new,
  // nothing typed yet" and "editing an existing Draft" the same way.
  useEffect(() => {
    if (!approvedNamesLoaded || !form.application_name) return;
    const isApproved = approvedNames.some(
      (a) => a.name === form.application_name
    );
    setShowOther(!isApproved);
  }, [approvedNamesLoaded, approvedNames, form.application_name]);

  // A Bug Fix or Enhancement may point back to the completed Functional Testing
  // request where the original implementation was verified. The endpoint
  // already narrows candidates to this application and department, so the
  // shared searchable picker stays compact even when the portal has a large
  // request history.
  useEffect(() => {
    if (!["Bug Fix", "Enhancement"].includes(form.change_type) || !form.application_name || !form.department) {
      setBugFixSources([]);
      return;
    }
    let cancelled = false;
    const timer = window.setTimeout(() => {
      const params = new URLSearchParams({
        application_name: form.application_name,
        department: form.department,
      });
      api
        .get<BugFixSourceOption[]>(`/api/qa-requests/bug-fix-source-options?${params}`)
        .then((rows) => { if (!cancelled) setBugFixSources(rows); })
        .catch(() => { if (!cancelled) setBugFixSources([]); });
    }, 250);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [form.change_type, form.application_name, form.department]);

  return (
    <>
      {showCreationDisabled && <NewApplicationDisabledModal onClose={() => setShowCreationDisabled(false)} />}
      {showNewApplicationWarning && (
        <Modal
          title="New application name warning"
          onClose={() => setShowNewApplicationWarning(false)}
          variant="dialog"
          tone="warning"
          compact
          preventBackdropClose
        >
          <p>
            A new application name must comply with the <strong>BCP policy</strong>.
            If it does not meet the policy requirements, the{" "}
            <RoleGroupLink
              role="APPLICATION_OWNER"
              label="Application Owner"
              renderTrigger={(_count, onClick) => (
                <button
                  type="button"
                  className="application-owner-group-link"
                  onClick={onClick}
                  aria-label="View responsible Application Owners in this workspace"
                  aria-haspopup="dialog"
                  title="View the people responsible for application name approval"
                >
                  <IconUsers width={16} height={16} aria-hidden="true" />
                  <span className="application-owner-group-link-label">Application Owner</span>
                  <span className="application-owner-group-link-hint">View people</span>
                </button>
              )}
            />{" "}
            will reject the name.
          </p>
          <p>
            To make the approval process easier, please select an available application whenever possible.
          </p>
          <div className="modal-actions">
            <button
              type="button"
              className="btn btn-warning"
              onClick={() => {
                setShowNewApplicationWarning(false);
                if (showOther) {
                  setShowOther(false);
                  set("application_name", "");
                }
              }}
            >
              Choose available application
            </button>
            <button
              type="button"
              className="btn"
              disabled={checkingCreationPolicy}
              onClick={async () => {
                if (!(await creationAllowed())) return;
                setShowNewApplicationWarning(false);
                if (!showOther) set("application_name", "");
                setShowOther(true);
              }}
            >
              Continue with new name
            </button>
          </div>
        </Modal>
      )}
      <div className="form-section">
        <div className="form-section-title">
          Application &amp; Change Details
        </div>
        <div className="form-row">
          <Field label="Application Name *">
            {/* Searchable -- this list only grows over time as new
                applications get approved, so a plain <select> becomes hard
                to scan (the original motivating case for this component). */}
            <SearchableSelect
              value={showOther ? OTHER : form.application_name}
              placeholder="Select Application Name"
              disabled={checkingCreationPolicy}
              onChange={(v) => {
                if (v === OTHER) {
                  void chooseOther();
                } else {
                  setShowOther(false);
                  set("application_name", v);
                }
              }}
              options={[
                ...approvedNames.map((a) => ({ value: a.name, label: a.name })),
                { value: OTHER, label: "Other (new application)", disabled: !applicationCreationEnabled, onDisabledSelect: () => { void chooseOther(); } },
              ]}
            />
            <ErrorText error={creationPolicyError} />
            {showOther && (
              <>
                <input
                  required
                  placeholder="Type the new application name"
                  value={form.application_name}
                  onChange={(e) =>
                    set("application_name", e.target.value.toUpperCase())
                  }
                  style={{ marginTop: 6 }}
                />
                <p className="muted small" style={{ margin: "4px 0 0" }}>
                New names are automatically capitalized. After submission, any Application Owner in this workspace can approve the name, regardless of department. Linked requests are created after approval.
                </p>
              </>
            )}
          </Field>
          <ModuleNameField
            key={form.application_name}
            applicationName={form.application_name}
            value={form.module_name}
            onChange={(value) => set("module_name", value)}
          />
          <Field label="Application Owner *">
            <input
              required
              value={form.application_owner}
              onChange={(e) =>
                set("application_owner", e.target.value.toUpperCase())
              }
            />
          </Field>
          <Field label="Department *">
            <SearchableSelect
              value={form.department || ""}
              onChange={(v) => set("department", v)}
              options={departmentSelectOptions}
              placeholder="Select department..."
              disabled={departmentLocked}
            />
            <p className="muted small" style={{ margin: "4px 0 0" }}>
              {departmentLocked
                ? "Department is fixed while this request is delegated for input."
                : departmentSelectOptions.length > 1
                ? "Defaults to your primary department -- pick any department you're assigned to."
                : "Fixed to your registered department. Contact an Administrator to add more."}
            </p>
          </Field>
          <Field label="CR Number/EPIC Number *">
            <input
              required
              maxLength={CHANGE_REFERENCE_MAX_LENGTH}
              placeholder="e.g. IN-46, CR-1234 or EPIC-123456"
              value={form.cr_number}
              onChange={(e) => {
                set("cr_number", e.target.value.toUpperCase());
                // Clear as soon as they start correcting it -- otherwise the
                // stale message just sits there under the field, unrelated
                // to whatever they're currently typing, until the next blur.
                if (crError) setCrError("");
              }}
              onBlur={(e) => {
                if (e.target.value.trim() && !CHANGE_REFERENCE_REGEX.test(e.target.value.trim())) {
                  setCrError(CHANGE_REFERENCE_FORMAT_ERROR);
                } else {
                  setCrError("");
                }
              }}
            />
            {/* Plain inline text, not the shared ErrorText -- that component
                renders a full blocking dialog (Modal), which is right for a
                stopped save/submit action but was wrong here: tabbing through
                this field was invalid. */}
            {crError && (
              <p className="small" style={{ color: "var(--danger)", margin: "4px 0 0" }}>
                {crError}
              </p>
            )}
          </Field>

          <Field label="Change Type *">
            <SearchableSelect
              value={form.change_type}
              searchable={false}
              options={CHANGE_TYPES}
              onChange={(value) => {
                set("change_type", value);
                if (value !== "Bug Fix") {
                  set("business_defect_number", "");
                }
                if (!["Bug Fix", "Enhancement"].includes(value)) {
                  set("bug_fix_source_request_id", "");
                }
              }}
            />
          </Field>
          {form.change_type === "Bug Fix" && (
            <Field label="Defect Number (Raised By Business)">
              <input
                value={form.business_defect_number}
                maxLength={64}
                placeholder="Enter the defect number raised by business"
                onChange={(event) => set("business_defect_number", event.target.value)}
              />
            </Field>
          )}
          {["Bug Fix", "Enhancement"].includes(form.change_type) && (
            <Field label="Previous Completed Request ID (optional)">
              <SearchableSelect
                value={form.bug_fix_source_request_id}
                onChange={(value) => set("bug_fix_source_request_id", value)}
                placeholder="Select the original completed request..."
                options={[
                  { value: "", label: "No previous request" },
                  ...bugFixSources.map((source) => ({
                    value: source.request_id,
                    label: `${source.request_id} · ${source.functional_request_id}${source.cr_number ? ` · ${source.cr_number}` : ""}`,
                  })),
                ]}
              />
              <p className="muted small" style={{ margin: "4px 0 0" }}>
                Link this {form.change_type.toLowerCase()} to the earlier request whose Functional Testing was completed.
              </p>
            </Field>
          )}
          <Field label="Change Description *">
            <textarea
              required
              placeholder="Describe the change being requested"
              value={form.change_description}
              onChange={(e) => set("change_description", e.target.value)}
            />
          </Field>
          <Field label="Vendor / SI Partner">
            <input
              value={form.vendor_si_partner}
              maxLength={15}
              placeholder="Enter Vendor / SI Partner"
              onChange={(e) =>
                set("vendor_si_partner", e.target.value.toUpperCase())
              }
            />
          </Field>
          <Field label="Technology Stack *">
            <input
              required
              maxLength={30}
              placeholder="Enter Technology Stack"
              value={form.technology_stack}
              onChange={(e) =>
                set("technology_stack", e.target.value.toUpperCase())
              }
            />
          </Field>
        </div>
      </div>

      <div className="form-section">
        <div className="form-section-title">Release &amp; Environment</div>
        <div className="form-row">
          <Field label="Release Version">
            <input
              value={form.release_version}
              maxLength={10}
              placeholder="Enter release version"
              onChange={(e) => set("release_version", e.target.value)}
            />
          </Field>
          <Field label="Build Number">
            <input
              value={form.build_number}
              maxLength={10}
              placeholder="Enter Build Number"
              onChange={(e) => set("build_number", e.target.value)}
            />
          </Field>
          <Field label="Deployment Environment *">
            <SearchableSelect
              value={form.environment}
              searchable={false}
              options={DEPLOYMENT_ENVIRONMENTS}
              onChange={(nextEnv) => {
                set("environment", nextEnv);
                // Target Promotion Environment must always stay strictly
                // later than Deployment Environment in the SIT -> UAT ->
                // Pre-Production -> Production pipeline -- if the
                // already-picked target is no longer valid against the
                // newly-picked deployment environment (e.g. Deployment
                // flipped from SIT to Production while Target was still
                // UAT), snap it forward to the nearest valid stage instead
                // of silently leaving an invalid combination selected. Keeps
                // this dropdown's own "always a real, non-blank value"
                // invariant intact (see validation.ts's detailsStepError
                // comment) rather than falling back to an empty selection.
                const validTargets = validTargetPromotionOptions(nextEnv);
                if (!validTargets.includes(form.target_promotion_environment)) {
                  set("target_promotion_environment", validTargets[0] || "");
                }
              }}
            />
          </Field>
          {/* Reported directly: this dropdown could be left on its blank
              placeholder and Next/Submit still went through -- fixed in
              validation.ts's detailsStepError, which now actually blocks
              that. targetOptions/hasTargetOptions below still guard the
              "Production has nowhere later to promote to" edge case
              (validTargetPromotionOptions('Production') === []), even
              though Deployment Environment's own dropdown above no longer
              offers "Production" at all (see DEPLOYMENT_ENVIRONMENTS'
              own comment) -- this stays purely as a safety net for any
              pre-existing Draft saved with environment='Production' before
              that change, so reopening one doesn't show a required field
              with genuinely nothing to select. */}
          {(() => {
            const targetOptions = validTargetPromotionOptions(form.environment);
            const hasTargetOptions = targetOptions.length > 0;
            return (
              <Field
                label={`Target Promotion Environment${hasTargetOptions ? " *" : ""}`}
              >
                <SearchableSelect
                  value={form.target_promotion_environment}
                  disabled={!hasTargetOptions}
                  searchable={false}
                  onChange={(value) => set("target_promotion_environment", value)}
                  placeholder={hasTargetOptions
                    ? "Select Target Promotion Environment"
                    : "Not applicable -- Production is the final stage"}
                  options={targetOptions}
                />
              </Field>
            );
          })()}
          <Field label="Target Release Date">
            <input
              type="date"
              min={istToday()}
              value={form.target_release_date}
              onChange={(e) => set("target_release_date", e.target.value)}
            />
          </Field>
        </div>
      </div>
    </>
  );
}
