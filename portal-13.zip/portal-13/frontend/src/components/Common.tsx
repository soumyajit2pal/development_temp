import React, {
  ReactNode,
  useCallback,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
} from "react";
import { createPortal } from "react-dom";
import { formatDateTimeIST, toISTISOString } from "../time";

import {
  QA_STATUS_LABELS,
  SAST_DAST_STATUS_LABELS,
  SUPPRESSION_STATUS_LABELS,
  PERFORMANCE_STATUS_LABELS,
  canDeleteWorkflowDocument,
} from "../constants";
import { IconFolder, IconFilter, IconEdit, IconWarning } from "./Icons";
import MultiSelect from "./MultiSelect";
import { api, HttpError } from "../api";
import { useAuth } from "../context/AuthContext";
import type { RequestDocumentOut, ChecklistItemDocumentOut } from "../types";
import { isKeyboardActivationKey } from "../keyboard";
import { shouldActivateTableRow } from "../tableInteraction";

// Every status across every module (QA Request, SAST/DAST,
// Performance, Suppression, Sign-off) funnels through this one Badge, so its
// label lookup merges all of their *_STATUS_LABELS maps rather than just
// QA_STATUS_LABELS -- otherwise a SAST/DAST/Performance/
// Suppression status would render as its raw SNAKE_CASE value instead of a
// human label.
//
// SIGNOFF_STATUS_LABELS is deliberately NOT part of this merge. Reported
// bug: QASignOff reuses "SM_APPROVAL_PENDING"/"RETURNED_BY_SM"/"SM_REJECTED"
// as legacy internal status codes for its own QA-Lead-approval checkpoint
// (see constants.ts's own comment on SIGNOFF_STATUS_LABELS and
// routers/signoff.py) instead of a distinct set of strings -- but gives them
// Sign-off-specific labels ("QA Lead Approval Pending", "Returned by QA
// Lead", "Rejected by QA Lead"). Spreading that map in here last meant it
// silently overwrote the correct "SM Approval Pending"/"Returned by
// SM"/"Rejected by SM" entries for every OTHER module that also uses those
// same status codes (QA Request/Functional, SAST, DAST, Performance,
// Suppression) -- so a freshly-raised Functional Testing Request sitting at
// genuine SM_APPROVAL_PENDING rendered as "QA Lead Approval Pending"
// everywhere, since this is the one shared Badge every module's status
// renders through. Sign-off's own two Badge call sites (SignOff.tsx) pass an
// explicit `label={SIGNOFF_STATUS_LABELS[status] || status}` override
// instead, the same pattern Suppression.tsx/TestRepository.tsx already use
// for their own status vocabularies -- so this map only needs to cover
// status codes that mean the same thing everywhere they appear.
const ALL_STATUS_LABELS: Record<string, string> = {
  ...QA_STATUS_LABELS,
  ...SAST_DAST_STATUS_LABELS,
  ...SUPPRESSION_STATUS_LABELS,
  ...PERFORMANCE_STATUS_LABELS,
};

export function Badge({ status, label: labelOverride }: { status?: string | null; label?: ReactNode }) {
  // Colour families are semantic, not decorative: gray = neutral/closed,
  // blue = submitted/informational, purple = actively being worked
  // (planning/execution/scanning), teal = verification/sign-off checkpoints,
  // yellow = waiting on a person's decision, green = positive outcome,
  // red = rejected/blocked/defect. Spreading statuses across this wider
  // palette (rather than defaulting everything "in progress" to yellow)
  // makes list/table views easier to scan at a glance.
  const map: Record<string, string> = {
    // Legacy / other-module statuses
    Draft: "badge-gray",
    Completed: "badge-green",
    Returned: "badge-red",
    Cancelled: "badge-gray",
    Approved: "badge-green",
    Rejected: "badge-red",
    "Not a Defect Review": "badge-yellow",
    "Change Request Raised": "badge-blue",
    "Not a Defect": "badge-red",
    Passed: "badge-green",
    Failed: "badge-red",
    "In Progress": "badge-purple",
    Open: "badge-red",
    Closed: "badge-gray",
    Issued: "badge-green",
    Done: "badge-green",
    // Shared across QA Request / SAST-DAST / Performance / Suppression
    DRAFT: "badge-gray",
    SUBMITTED: "badge-blue",
    SM_APPROVAL_PENDING: "badge-yellow",
    RETURNED_BY_SM: "badge-red",
    SM_REJECTED: "badge-red",
    RETURNED_BY_REQUESTER: "badge-red",  // Legacy pre-immutable-revision QASignOff state.
    SUPERSEDED: "badge-gray",
    ISSUED_UNDER_REVIEW: "badge-yellow",
    VOIDED: "badge-gray",
    DEPARTMENT_HEAD_APPROVAL_PENDING: "badge-yellow",
    RETURNED_BY_DEPARTMENT_HEAD: "badge-red",
    DEPARTMENT_HEAD_REJECTED: "badge-red",
    CLOSED: "badge-green",
    CANCELLED: "badge-gray",
    REQUESTER_VERIFICATION: "badge-teal",
    SIGNOFF_PENDING: "badge-teal",
    SIGNED_OFF: "badge-green",
    // QA Request lifecycle
    QA_LEAD_ASSIGNED: "badge-blue",
    READINESS_VERIFICATION: "badge-teal",
    RETURNED_BY_QA_LEAD: "badge-red",
    QA_ACTIVITY_INITIATED: "badge-blue",
    PLANNING: "badge-purple",
    TESTER_ASSIGNED: "badge-blue",
    TEST_DESIGN: "badge-purple",
    EXECUTION_IN_PROGRESS: "badge-purple",
    DEFECT_RAISED: "badge-red",
    WAITING_FOR_FIX: "badge-red",
    RETESTING: "badge-purple",
    QA_COMPLETED: "badge-green",
    QA_SIGNOFF_PENDING: "badge-teal",
    QA_SIGNED_OFF: "badge-green",
    QA_CHANGE_REVIEW: "badge-yellow",
    // SAST/DAST lifecycle
    SECURITY_LEAD_ASSIGNED: "badge-blue",
    SECURITY_READINESS: "badge-teal",
    RETURNED_BY_SECURITY_LEAD: "badge-red",
    CONFIGURATION: "badge-purple",
    SCANNING: "badge-purple",
    FINDING_VALIDATION: "badge-teal",
    REMEDIATION: "badge-red",
    ASSIGNED_TO_REQUESTER: "badge-red",
    ASSIGNED_TO_LEAD: "badge-purple",
    RESCAN: "badge-purple",
    SECURITY_COMPLETE: "badge-green",
    REPORT_READY: "badge-green",
    // Performance Testing lifecycle
    READINESS: "badge-teal",
    FEASIBILITY: "badge-teal",
    SCRIPT_DEVELOPMENT: "badge-purple",
    ENVIRONMENT_SETUP: "badge-purple",
    BASELINE: "badge-purple",
    LOAD_TEST_EXECUTION: "badge-purple",
    RESULT_ANALYSIS: "badge-teal",
    DEFECT_FIX_RETEST: "badge-red",
    REPORT: "badge-teal",
    // Suppression lifecycle
    SECURITY_TEAM_VERIFICATION: "badge-teal",
    // Test Management: Test Case lifecycle + Test Execution result (see
    // constants.ts TEST_CASE_STATUSES/TEST_EXECUTION_STATUSES) -- "Pass"/
    // "Fail" here are deliberately distinct keys from the legacy "Passed"/
    // "Failed" above (different modules, different exact wording). "Active"/
    // "Deprecated"/"Not Started" are kept for any not-yet-refreshed cached
    // data from before the current versioned workflow vocabularies.
    Active: "badge-green",
    Deprecated: "badge-gray",
    "Not Executed": "badge-gray",
    Pass: "badge-green",
    Fail: "badge-red",
    Blocked: "badge-yellow",
    NA: "badge-gray",
    "Retest Passed": "badge-blue",
    "Not Started": "badge-gray",
    // 2026-08 "Test Approval Workflow" revamp -- TestCaseVersion/TestCase
    // status (constants.ts TEST_CASE_STATUSES, 7 values: Draft/In Review/
    // Review Completed/Returned/Approved/Rejected/Archived). "Returned" and
    // "Rejected" are already covered by the shared "Legacy / other-module
    // statuses" entries above (badge-red each) -- not repeated here.
    "In Review": "badge-yellow",
    "Review Completed": "badge-yellow",
    Archived: "badge-gray",
    // 2026-08 revamp -- TestCycle status (constants.ts TEST_CYCLE_STATUSES:
    // Draft/Ready/In Progress/Blocked/Completed).
    Ready: "badge-blue",
  };
  const label = labelOverride ?? ((status && ALL_STATUS_LABELS[status]) || status || "");
  return (
    <span className={`badge ${(status && map[status]) || "badge-gray"}`}>
      {label}
    </span>
  );
}

export function EmptyState({
  title = "No data available",
  description = "There are no records to display yet.",
  action,
  compact = false,
  className = "",
}: {
  title?: ReactNode;
  description?: ReactNode;
  action?: ReactNode;
  compact?: boolean;
  className?: string;
}) {
  return (
    <div className={`common-empty-state${compact ? " compact" : ""}${className ? ` ${className}` : ""}`} role="status">
      <span className="common-empty-state-icon" aria-hidden="true"><IconFolder width={26} height={26} /></span>
      <strong>{title}</strong>
      {description && <span>{description}</span>}
      {action && <div className="common-empty-state-action">{action}</div>}
    </div>
  );
}

// Reported directly: while an Application Name is still sitting with the
// Application Owner -- the FIRST of the two approval tiers, see
// ApplicationNameBanner -- a Functional/SAST/DAST/Performance request's own
// `status` is already SM_APPROVAL_PENDING under the hood (every linked child
// is born straight at that status the moment its gateway is raised;
// approving/rejecting the name only ever moves the NAME along a tier, never
// the request's own status -- see ApplicationNameBanner.tsx's docstring).
// Showing "SM Approval Pending" at that point is misleading: there is
// nothing for the SM to do yet, and the backend's own sm_decision endpoint
// (routers/functional.py/sast_dast.py/performance.py) actively refuses an
// Approve while application_master_status isn't APPROVED yet, so the SM
// really can't act until the Application Owner clears their own tier first.
// This only overrides what's DISPLAYED, via Badge's `label` prop -- nothing
// that gates SM/Department Head actions reads this, they all still key off
// the real `status` value untouched. Pass to every <Badge status={...} />
// for a request that carries `application_master_status`.
export function applicationNameAwareStatusLabel(
  status?: string | null,
  applicationMasterStatus?: string | null
): string | undefined {
  if (status === "SM_APPROVAL_PENDING" && applicationMasterStatus === "PENDING_APP_OWNER") {
    return "Application Owner Approval Pending";
  }
  return undefined;
}

// 2026-08 "SAST/DAST Request Workflow Requirement" doc -- the flowchart's
// "Suppression Approval Pending" node has no status value of its own; it's
// treated here as a display-only overlay on top of the real WAITING_FOR_FIX
// status (same pattern as applicationNameAwareStatusLabel just above), active
// while a non-terminal Suppression / False Positive request is linked. This
// only changes what's DISPLAYED via Badge's `label` prop -- every gate that
// actually reads `status` (canInitiateSuppression, canMarkFixed, etc.) still
// keys off the real WAITING_FOR_FIX value untouched. Pass to every
// <Badge status={...} /> for a SAST/DAST request alongside
// applicationNameAwareStatusLabel (mutually exclusive statuses, so callers
// can just take whichever one returns a value).
export function suppressionAwareStatusLabel(
  status?: string | null,
  hasOpenSuppression?: boolean
): string | undefined {
  if (status === "WAITING_FOR_FIX" && hasOpenSuppression) {
    return "Suppression Approval Pending";
  }
  return undefined;
}

interface PageHeaderProps {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  count?: number;
  actions?: ReactNode;
  children?: ReactNode;
}

// Consistent "title + description + primary actions" header used at the top
// of every page, replacing the old ad hoc <div className="toolbar"> + bare
// <Card title="X (N)"> pairing that varied slightly page to page.
export function PageHeader({
  title,
  eyebrow = "Quality workspace",
  subtitle,
  count,
  actions,
  children,
}: PageHeaderProps) {
  return (
    <div className="page-header">
      <div className="titles">
        <span className="page-eyebrow">{eyebrow}</span>
        <h2>
          {title}
          {typeof count === "number" && (
            <span className="count-pill">{count}</span>
          )}
        </h2>
        {subtitle && <p>{subtitle}</p>}
        {children}
      </div>
      {actions && <div className="actions">{actions}</div>}
    </div>
  );
}

interface CardProps {
  title?: ReactNode;
  subtitle?: ReactNode;
  children?: ReactNode;
  right?: ReactNode;
  style?: React.CSSProperties;
  className?: string;
}

export function InfoTooltip({ content, label = "More information" }: { content: ReactNode; label?: string }) {
  return (
    <span className="stat-card-info shared-info-tooltip">
      <button type="button" aria-label={label}>i</button>
      <span className="stat-card-tooltip" role="tooltip">{content}</span>
    </span>
  );
}

export function Card({ title, subtitle, children, right, style, className }: CardProps) {
  return (
    <div className={`card${className ? ` ${className}` : ""}`} style={style}>
      {(title || subtitle || right) && (
        <div className="card-head">
          <div>
            {title && <h3>{title}</h3>}
          </div>
          <div className="card-head-actions">
            {subtitle && <InfoTooltip content={subtitle} label={`About ${typeof title === "string" ? title : "this section"}`} />}
            {right}
          </div>
        </div>
      )}
      {children}
    </div>
  );
}

export function MetricCard({
  label,
  value,
  hint,
  onClick,
}: {
  label: ReactNode;
  value: ReactNode;
  // One plain-English line explaining exactly what's being counted --
  // reported directly: several dashboard numbers (e.g. "Total Pending
  // Items", which is the same count as the Dashboard's Ageing
  // Distribution donut) had no visible explanation of their scope, so
  // people had to ask what they meant instead of reading it on screen.
  // Available through the shared information control so metric cards keep
  // the same compact behaviour throughout the application.
  hint?: ReactNode;
  onClick?: () => void;
}) {
  return (
    <div className={`metric-card${onClick ? ' metric-card-clickable' : ''}`}>
      {hint && <InfoTooltip content={hint} label={`About ${typeof label === "string" ? label : "this metric"}`} />}
      <div className="value">{value ?? 0}</div>
      <div className="label">{label}</div>
      {onClick && <>
        <span className="metric-card-view" aria-hidden="true">View details <span>→</span></span>
        <button type="button" className="metric-card-hit-area" onClick={onClick}
          aria-label={`View ${typeof label === 'string' ? label : 'metric'} details`}
          title={`View ${typeof label === 'string' ? label : 'metric'} details`} />
      </>}
    </div>
  );
}

export function BarChart({
  data,
  onBarClick,
}: {
  data?: Record<string, number> | null;
  onBarClick?: (key: string, value: number) => void;
}) {
  const entries = Object.entries(data || {}).filter(([k]) => k);
  const max = Math.max(1, ...entries.map(([, v]) => v));
  if (entries.length === 0) return <EmptyState compact title="No chart data available" description="Data will appear here when matching records are available." />;
  return (
    <div className="bar-chart">
      {entries.map(([k, v]) => {
        const clickable = !!onBarClick && v > 0;
        const Row = clickable ? "button" : "div";
        return (
        <Row
          className={`bar-row${clickable ? " bar-row-clickable" : ""}`}
          key={k}
          {...(clickable ? {
            type: "button" as const,
            onClick: () => onBarClick(k, v),
            title: `View application details for ${k.replace(/_/g, " ")}`,
          } : {})}
        >
          <span
            className="bar-label"
            title={k.replace(/_/g, " ")}
          >
            {k.includes("_")
              ? k.toLowerCase().split("_").map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ")
              : k}
          </span>
          <div className="bar-track">
            <div
              className="bar-fill"
              style={{ width: `${(v / max) * 100}%` }}
            />
          </div>
          <span className="bar-value">{v}</span>
        </Row>
      )})}
    </div>
  );
}

export function WarningNotice({ title = "Warning", children, className = "", compact = false, active = true, role = "status", id, style }: {
  title?: ReactNode;
  children?: ReactNode;
  className?: string;
  compact?: boolean;
  active?: boolean;
  role?: "alert" | "status" | "note";
  id?: string;
  style?: React.CSSProperties;
}) {
  if (!active) return <div className={className} role={role} id={id} style={style}>{children}</div>;
  return (
    <div className={`warning-notice${compact ? " warning-notice-compact" : ""} ${className}`} role={role} id={id} style={style}>
      <span className="warning-notice-icon" aria-hidden="true"><IconWarning /></span>
      <div className="warning-notice-body">
        <strong className="warning-notice-title">{title}</strong>
        <div className="warning-notice-content">{children}</div>
      </div>
    </div>
  );
}

interface ModalProps {
  title: ReactNode;
  onClose: () => void;
  children?: ReactNode;
  wide?: boolean;
  // Content-sized dialog for short forms and confirmations. This keeps a
  // one- or two-field task from inheriting the spacious record-detail size.
  compact?: boolean;
  // Wide lists can grow with their contents without filling the viewport.
  fitContent?: boolean;
  // 'drawer' (default): right-side slide-over -- gives most record detail
  // views (SAST/DAST, Suppression, Sign-off, Admin forms, etc.) room to
  // breathe and keeps the surrounding page visible/in context, matching the
  // panel pattern used by most modern SaaS dashboards.
  // 'dialog': centered on screen -- used for longer multi-step forms (the
  // QA Request wizard) where a narrow side-anchored panel cramps a step's
  // worth of fields/checklist content; a centered box gives it more usable
  // width without needing to be as tall as the viewport.
  variant?: "drawer" | "dialog";
  // When true, clicking the backdrop (the dimmed area outside the panel)
  // does nothing instead of closing the modal -- only the panel's own
  // explicit "Close"/"Cancel" button (or whatever the caller renders) can
  // close it. Use this for anything holding typed-but-not-yet-saved data
  // (e.g. the QA Request wizard), where an accidental outside click
  // shouldn't be able to silently throw away everything filled in so far.
  // A brief shake on the panel gives feedback that the click did register,
  // rather than the modal just feeling unresponsive.
  preventBackdropClose?: boolean;
  // Prevent an explicit header close while a non-interruptible operation is
  // running. The disabled control makes the lock visible and accessible.
  closeDisabled?: boolean;
  tone?: "warning" | "danger";
}

export function Modal({
  title,
  onClose,
  children,
  wide,
  compact,
  fitContent,
  variant = "drawer",
  preventBackdropClose,
  closeDisabled,
  tone,
}: ModalProps) {
  const [shake, setShake] = useState(false);
  const titleId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeStateRef = useRef({ onClose, closeDisabled, preventBackdropClose, variant });
  closeStateRef.current = { onClose, closeDisabled, preventBackdropClose, variant };
  // Record drawers open in the spacious centered view by default. Users can
  // restore the compact right-side drawer with the header toggle.
  const [expanded, setExpanded] = useState(variant === "drawer");

  useEffect(() => {
    const previouslyFocused = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const frame = window.requestAnimationFrame(() => {
      const first = dialogRef.current?.querySelector<HTMLElement>(
        "button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex]:not([tabindex='-1'])",
      );
      (first || dialogRef.current)?.focus();
    });
    function onKeyDown(event: KeyboardEvent) {
      const dialog = dialogRef.current;
      if (!dialog) return;
      // A native modal (search or assignment confirmation) owns focus while
      // open. Do not move keyboard focus into the underlying record drawer.
      if (document.querySelector("dialog[open][aria-modal='true']")) return;
      const openDialogs = document.querySelectorAll<HTMLElement>("[role='dialog'][aria-modal='true']");
      if (openDialogs[openDialogs.length - 1] !== dialog) return;
      if (event.key === "Escape") {
        const state = closeStateRef.current;
        if (state.closeDisabled || state.preventBackdropClose) return;
        event.preventDefault();
        event.stopPropagation();
        state.onClose();
        if (state.variant === "drawer" && new URLSearchParams(window.location.search).get("fromPending") === "1") {
          window.history.back();
        }
        return;
      }
      if (event.key !== "Tab") return;
      const focusable = Array.from(dialog.querySelectorAll<HTMLElement>(
        "button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[tabindex]:not([tabindex='-1'])",
      )).filter((element) => element.getAttribute("aria-hidden") !== "true");
      if (!focusable.length) { event.preventDefault(); dialog.focus(); return; }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
    document.addEventListener("keydown", onKeyDown, true);
    return () => {
      window.cancelAnimationFrame(frame);
      document.removeEventListener("keydown", onKeyDown, true);
      previouslyFocused?.focus();
    };
  }, []);

  function handleExplicitClose() {
    if (closeDisabled) return;
    onClose();
    // Pending Approvals opens a child module only as a host for its detail
    // drawer. Closing that drawer should return to the queue, not strand the
    // user on the module list and force another sidebar click.
    if (variant === "drawer" && new URLSearchParams(window.location.search).get("fromPending") === "1") {
      window.history.back();
    }
  }

  function handleBackdropClick(event: React.MouseEvent) {
    // Portals retain React event bubbling; never activate the underlying row.
    event.stopPropagation();
    // Drawers hold record details and forms, so an outside click must never
    // dismiss them. They stay open until the user deliberately uses Close.
    // Centered dialogs retain their existing opt-in backdrop behaviour.
    if (variant === "dialog" && !preventBackdropClose && !closeDisabled) {
      onClose();
      return;
    }
    setShake(true);
    setTimeout(() => setShake(false), 320);
  }

  const heading = tone ? (
    <div className="modal-tone-heading">
      <span className="modal-tone-icon" aria-hidden="true"><IconWarning /></span>
      <div><span className="modal-tone-label">{tone === "warning" ? "Warning" : "Destructive action"}</span><h3 id={titleId}>{title}</h3></div>
    </div>
  ) : <h3 id={titleId}>{title}</h3>;

  // Mount outside cards/tables: transformed or clipped ancestors otherwise
  // constrain fixed overlays to the card instead of the viewport.
  if (variant === "dialog") {
    return createPortal(
      <div
        className="modal-overlay modal-overlay-center"
        onClick={handleBackdropClick}
      >
        <div
          ref={dialogRef}
          role="dialog"
          aria-modal="true"
          aria-labelledby={titleId}
          tabIndex={-1}
          className={`dialog ${tone ? `modal-tone-${tone}` : ""} ${wide ? "dialog-wide" : ""} ${compact ? "dialog-compact" : ""} ${fitContent ? "dialog-fit-content" : ""} ${
            shake ? "modal-shake" : ""
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="drawer-header">
            {heading}
            <button
              type="button"
              className="modal-close-btn"
              onClick={handleExplicitClose}
              aria-label={closeDisabled ? "Close unavailable while upload is in progress" : "Close"}
              title={closeDisabled ? "Upload in progress" : "Close"}
              disabled={closeDisabled}
            >
              ×
            </button>
          </div>
          <div className="drawer-body">{children}</div>
        </div>
      </div>,
      document.body
    );
  }
  return createPortal(
    <div
      className={`modal-overlay ${expanded ? "modal-overlay-expanded" : ""}`}
      onClick={handleBackdropClick}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        className={`drawer ${tone ? `modal-tone-${tone}` : ""} ${wide ? "drawer-wide" : ""} ${expanded ? "drawer-expanded" : ""} ${
          shake ? "modal-shake" : ""
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="drawer-header">
          {heading}
          <div className="drawer-header-actions">
            <button
              type="button"
              className="modal-close-btn drawer-expand-btn"
              onClick={() => setExpanded((value) => !value)}
              aria-label={expanded ? "Restore drawer" : "Expand drawer"}
              title={expanded ? "Restore drawer" : "Expand drawer"}
            >
              {expanded ? (
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3v6H3M15 21v-6h6M3 9l6-6M21 15l-6 6" /></svg>
              ) : (
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H3v5M16 21h5v-5M3 8l6-5M21 16l-6 5" /></svg>
              )}
            </button>
            <button
              type="button"
              className="modal-close-btn"
              onClick={handleExplicitClose}
              aria-label={closeDisabled ? "Close unavailable while an operation is in progress" : "Close"}
              title={closeDisabled ? "Operation in progress" : "Close"}
              disabled={closeDisabled}
            >
              ×
            </button>
          </div>
        </div>
        <div className="drawer-body">{children}</div>
      </div>
    </div>,
    document.body
  );
}

export interface ElectronicSignature {
  signer: string;
  signedAt: string;
  signatureId: string;
  statement: string;
  style: SignatureStyle;
}

export type SignatureStyle = "professional" | "classic" | "handwritten";

const SIGNATURE_STYLE_OPTIONS: Array<{
  value: SignatureStyle;
  label: string;
  description: string;
}> = [
  { value: "professional", label: "Professional", description: "Clean and formal" },
  { value: "classic", label: "Classic", description: "Traditional serif" },
  { value: "handwritten", label: "Handwritten", description: "Personal script" },
];

// Deliberate electronic-signature ceremony for approval checkpoints. The
// identity is locked to the authenticated account; the user must open the
// dialog, review the signature intent and explicitly consent. The approval
// API then writes the real actor and authoritative server timestamp to the
// append-only ApprovalAction log. This is an auditable in-app e-signature,
// not a PKI/USB-token certificate signature.
export function SignField({
  userName,
  onSignedChange,
  disabled = false,
}: {
  userName?: string;
  onSignedChange: (signature: ElectronicSignature | null) => void;
  disabled?: boolean;
}) {
  const [signature, setSignature] = useState<ElectronicSignature | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [consented, setConsented] = useState(false);
  const [signatureStyle, setSignatureStyle] = useState<SignatureStyle>("professional");
  const signed = !!signature;

  useEffect(() => {
    setSignature(null);
    setConsented(false);
    onSignedChange(null);
  }, [userName]); // eslint-disable-line react-hooks/exhaustive-deps

  function applySignature() {
    if (!userName || !consented) return;
    if (!globalThis.crypto?.randomUUID) {
      throw new Error("A secure browser random-number generator is required for electronic signatures");
    }
    const applied: ElectronicSignature = {
      signer: userName,
      signedAt: toISTISOString(),
      signatureId: `ESIG-${globalThis.crypto.randomUUID().toUpperCase()}`,
      statement: "I confirm my identity and intend this electronic signature to authorize the approval decision.",
      style: signatureStyle,
    };
    setSignature(applied);
    onSignedChange(applied);
    setDialogOpen(false);
  }

  return (
    <div className={`workflow-sign-step${signed ? " signed" : ""}`}>
      <span className="workflow-step-number">1</span>
      <span className="workflow-sign-copy">
        <small>STEP 1 · IDENTITY VERIFICATION</small>
        <strong>{signed ? `Signed by ${signature.signer}` : userName || "Unknown user"}</strong>
        <em>
          {signed ? (
            <>
              <span>{formatDateTimeIST(signature.signedAt)}</span>
              <code title={signature.signatureId}>{signature.signatureId}</code>
            </>
          ) : "Confirm your authenticated identity before an approval can be submitted."}
        </em>
      </span>
      <span className={`workflow-step-status${signed ? " complete" : " required"}`}>
        {signed ? "Complete" : "Required"}
      </span>
      <button
        type="button"
        className={`btn btn-sm esign-trigger${signed ? " signed" : ""}`}
        disabled={disabled || !userName}
        onClick={() => { setConsented(false); setDialogOpen(true); }}
      >
        {signed ? <><span className="esign-trigger-check" aria-hidden="true">✓</span><span>Review signature</span></> : <><IconEdit /><span>Verify &amp; sign</span></>}
      </button>
      {dialogOpen && (
        <Modal title="Apply electronic signature" onClose={() => setDialogOpen(false)} variant="dialog" preventBackdropClose>
          <div className="esign-dialog">
            <div className="esign-security-note"><span>✓</span><div><strong>Authenticated identity</strong><small>Your signature is locked to the currently signed-in account and will be recorded with the approval audit entry.</small></div></div>
            <div className="esign-preview" aria-label={`Electronic signature preview for ${userName}`}>
              <small>SIGNATURE PREVIEW</small>
              <strong className={`signature-style-${signatureStyle}`}>{userName}</strong>
              <span>QualityOps electronic approval</span>
            </div>
            <fieldset className="esign-style-picker">
              <legend>Choose signature style</legend>
              <div className="esign-style-options">
                {SIGNATURE_STYLE_OPTIONS.map((option) => (
                  <label key={option.value} className={signatureStyle === option.value ? "selected" : ""}>
                    <input
                      type="radio"
                      name="signature-style"
                      value={option.value}
                      checked={signatureStyle === option.value}
                      onChange={() => setSignatureStyle(option.value)}
                    />
                    <span className={`esign-style-sample signature-style-${option.value}`}>{userName}</span>
                    <strong>{option.label}</strong>
                    <small>{option.description}</small>
                  </label>
                ))}
              </div>
            </fieldset>
            <dl className="esign-details"><div><dt>Signer</dt><dd>{userName}</dd></div><div><dt>Purpose</dt><dd>Authorize this workflow approval</dd></div><div><dt>Audit evidence</dt><dd>Account, role, server timestamp, decision and signature reference</dd></div></dl>
            <label className="esign-consent"><input type="checkbox" checked={consented} onChange={(event) => setConsented(event.target.checked)} /><span><strong>I agree to sign electronically.</strong><small>I confirm my identity and intend this signature to authorize the approval decision.</small></span></label>
            <div className="modal-actions esign-actions"><button type="button" className="btn btn-sm" onClick={() => setDialogOpen(false)}>Cancel</button><button type="button" className="btn btn-success btn-sm" disabled={!consented} onClick={applySignature}>Apply signature</button></div>
          </div>
        </Modal>
      )}
    </div>
  );
}

// Carries the signature evidence into the existing append-only workflow log.
// ApprovalAction.actor_id and created_at remain the authoritative identity
// and server time; these fields preserve the user's ceremony and intent.
export function withSignature(
  comments: string,
  signature: ElectronicSignature | null
): string {
  if (!signature) return comments;
  const base = (comments || "").trim();
  return `${base ? base + " " : ""}[Electronic signature | Signer: ${signature.signer} | Applied: ${signature.signedAt} | Signature ID: ${signature.signatureId} | Style: ${signature.style} | Intent: ${signature.statement}]`;
}

interface ApprovalDecisionButtonsProps {
  // Name pre-filled into the Sign field -- normally the acting user's own name.
  userName?: string;
  // Whatever's in the page's "Comments (optional)" box; gets the signature
  // appended before being sent with the Approve action (Return/Reject are
  // sent as typed, unsigned).
  comments: string;
  busy: boolean;
  onApprove: (signedComments: string) => void;
  onReturn: (comments: string, requiredTestingTypes: string[]) => void;
  additionalTestingOptions?: string[];
  onReject: (comments: string) => void;
  approveLabel?: string;
  returnLabel?: string;
  rejectLabel?: string;
  // For steps that need something picked before Approve makes sense (e.g.
  // Department Head assigning a QA Lead / Security Lead) -- rendered in its
  // own labeled row above the Sign field, and Approve also stays disabled
  // until `extraReady`. extraControlLabel is the caption shown next to it
  // (e.g. "Assign QA Lead") -- without one it just renders unlabeled.
  extraControl?: ReactNode;
  extraControlLabel?: string;
  extraReady?: boolean;
  // Set while this request's Application Name is still not APPROVED (i.e.
  // PENDING_APP_OWNER, PENDING_SM, or REJECTED -- see
  // ApplicationNameBanner/application_master_status)
  // -- disables both Sign and Approve (Return/Reject stay usable, since an
  // approver should still be able to bounce a request back over an
  // unapproved name rather than being stuck unable to act on it at all).
  // signBlockedMessage is shown next to the buttons while blocked.
  signBlocked?: boolean;
  signBlockedMessage?: string;
}

// The one-stop replacement for the "Sign, Approve, Return to Requester,
// Reject" button group that used to be copy-pasted (with the Sign button
// added by hand into all six of them) across every SM/Department Head
// decision step: Functional, SAST, DAST, Performance,
// Suppression. Changing how approvals work now means editing this one
// component instead of six near-identical blocks of JSX.
export function ApprovalDecisionButtons({
  userName,
  comments,
  busy,
  onApprove,
  onReturn,
  onReject,
  additionalTestingOptions = [],
  approveLabel = "Approve",
  returnLabel = "Return to Requester",
  rejectLabel = "Reject",
  extraControl,
  extraControlLabel,
  extraReady = true,
  signBlocked = false,
  signBlockedMessage,
}: ApprovalDecisionButtonsProps) {
  const [signature, setSignature] = useState<ElectronicSignature | null>(null);
  // Whether an assignment (QA Lead/Security Lead/Engineer) is still needed
  // before this decision can be confirmed -- see assignModalOpen below. An
  // inline row for this (tried first) sat directly above Sign/Approve/
  // Return/Reject inside the same flex-wrap row, and its search popover
  // (position: fixed) visually overlapped those buttons and the Comments box
  // beneath them, since opening it doesn't push that content down -- reported
  // directly, twice, with screenshots. A modal sidesteps the problem
  // entirely: it's a dedicated overlay with its own stacking context, so
  // there's nothing underneath for its popover to collide with.
  const [pendingDecision, setPendingDecision] = useState<"approve" | "return" | "reject" | null>(null);
  const [actionNote, setActionNote] = useState(comments);
  const [requiredTestingTypes, setRequiredTestingTypes] = useState<string[]>([]);

  const [activeTestingTypes, setActiveTestingTypes] = useState<Set<string> | null>(null);
  useEffect(() => {
    if (!additionalTestingOptions.length) return;
    let mounted = true;
    api.get<{ request_type: string; is_active: boolean }[]>('/api/request-type-config')
      .then((rows) => { if (mounted) setActiveTestingTypes(new Set(rows.filter((row) => row.is_active).map((row) => row.request_type))); })
      .catch(() => { if (mounted) setActiveTestingTypes(new Set()); });
    return () => { mounted = false; };
  }, [additionalTestingOptions.join(',')]);
  const availableTestingOptions = additionalTestingOptions.filter((type) => activeTestingTypes?.has(type));
  const invalidTestingSelection = requiredTestingTypes.some((type) => !availableTestingOptions.includes(type));
  const decisionBlocked = busy
    || (pendingDecision === "approve" && (!signature || signBlocked || !extraReady))
    || (pendingDecision === "return" && invalidTestingSelection);

  function handleApproveClick() {
    setActionNote(comments);
    setPendingDecision("approve");
  }

  function openDecision(decision: "return" | "reject") {
    setRequiredTestingTypes([]);
    setActionNote(comments);
    setPendingDecision(decision);
  }

  function confirmDecision() {
    if (decisionBlocked) return;
    if ((pendingDecision === "return" || pendingDecision === "reject") && !actionNote.trim()) return;
    if (pendingDecision === "approve") onApprove(withSignature(actionNote, signature));
    if (pendingDecision === "return") onReturn(actionNote.trim(), requiredTestingTypes);
    if (pendingDecision === "reject") onReject(actionNote.trim());
    setPendingDecision(null);
  }

  return (
    <>
      <div className="workflow-decision-flow">
        <SignField userName={userName} onSignedChange={setSignature} disabled={busy || signBlocked} />
        <div className="workflow-decision-step">
          <div className="workflow-decision-heading">
            <span className="workflow-step-number">2</span>
            <span className="workflow-sign-copy">
              <small>STEP 2 · WORKFLOW OUTCOME</small>
              <strong>Select the next action</strong>
              <em>Review the consequence of each choice before continuing.</em>
            </span>
            <span className={`workflow-step-status${signature ? " ready" : " waiting"}`}>
              {signature ? "Ready" : "Complete step 1"}
            </span>
          </div>
          <div className={`workflow-decision-readiness${signature ? " ready" : " waiting"}`}>
            <span>{signature ? "✓" : "i"}</span>
            <p>
              <strong>{signature ? "Identity verified" : "Approval requires a signature"}</strong>
              <small>{signature ? "Approval is enabled. Return and Reject remain available without a signature." : "Verify and sign above to enable Approve. You can still Return or Reject without signing."}</small>
            </p>
          </div>
          <div className="workflow-decision-options">
            <button type="button" className="workflow-decision-card approve" disabled={busy || !signature || signBlocked} onClick={handleApproveClick} title={!signature ? "Verify and sign first to enable approval" : "Accept and move to the next stage"}>
              <span className="workflow-decision-icon">✓</span><span>{approveLabel}</span>
            </button>
            <button type="button" className="workflow-decision-card return" disabled={busy} onClick={() => openDecision("return")} title="Send back for corrections and resubmission">
              <span className="workflow-decision-icon">↩</span><span>{returnLabel}</span>
            </button>
            <button type="button" className="workflow-decision-card reject" disabled={busy} onClick={() => openDecision("reject")} title="Stop and close this approval path">
              <span className="workflow-decision-icon">×</span><span>{rejectLabel}</span>
            </button>
          </div>
        </div>
        {signBlocked && signBlockedMessage && <div className="workflow-blocked-message"><b>Approval unavailable</b><span>{signBlockedMessage}</span></div>}
      </div>
      {pendingDecision && (
        <Modal
          title={`Confirm ${pendingDecision === "approve" ? approveLabel : pendingDecision === "return" ? returnLabel : rejectLabel}`}
          onClose={() => setPendingDecision(null)}
          variant="dialog"
          preventBackdropClose
          closeDisabled={busy}
        >
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div className={`workflow-confirm-banner ${pendingDecision}`}>
              <span>{pendingDecision === "approve" ? "✓" : pendingDecision === "return" ? "↩" : "×"}</span>
              <div><strong>{pendingDecision === "approve" ? approveLabel : pendingDecision === "return" ? returnLabel : rejectLabel}</strong><small>{pendingDecision === "approve" ? "The request will proceed to its next workflow stage." : pendingDecision === "return" ? "The requester can correct the details and submit again." : "This approval path will be stopped."}</small></div>
            </div>
            {pendingDecision === "reject" && (
              <p className="workflow-reject-guidance" role="note">
                <strong>
                  {additionalTestingOptions.length > 0
                    ? "If the requester needs to edit details or add another testing type, choose Return to Requester. Reject closes the current approval path."
                    : "If the requester needs to edit details, choose Return to Requester. Reject closes the current approval path."}
                </strong>
              </p>
            )}
            {pendingDecision === "approve" && extraControl && <div>
              {extraControlLabel && (
                <label
                  style={{
                    display: "block",
                    fontSize: 12.5,
                    fontWeight: 600,
                    color: "var(--navy)",
                    marginBottom: 6,
                  }}
                >
                  {extraControlLabel}
                </label>
              )}
              {extraControl}
            </div>}
            {pendingDecision === "approve" && !extraReady && (
              <div style={{ fontSize: 12.5, color: "var(--muted)" }}>
                Select someone above before confirming {approveLabel.toLowerCase()}.
              </div>
            )}
            {pendingDecision === "return" && availableTestingOptions.length > 0 && <fieldset className="scope-options">
              <legend>Additional testing required (optional)</legend>
              <p className="muted small">Selected types must be raised under the same QA request before resubmission.</p>
              {availableTestingOptions.map((type) => <label key={type}>
                <input type="checkbox" disabled={busy} checked={requiredTestingTypes.includes(type)} onChange={(event) =>
                  setRequiredTestingTypes((current) => event.target.checked ? [...current, type] : current.filter((value) => value !== type))} /> {type}
              </label>)}
            </fieldset>}
            {pendingDecision === "return" && invalidTestingSelection && <p role="alert" className="workflow-blocked-message">
              Testing choices have changed. Cancel and reopen Return to Requester to review the available types.
            </p>}
            <label className="workflow-note-field">
              <span>Remarks <em>{pendingDecision === "approve" ? "Optional" : "Required"}</em></span>
              <textarea
                value={actionNote}
                onChange={(event) => setActionNote(event.target.value)}
                rows={4}
                required={pendingDecision !== "approve"}
                disabled={busy}
                placeholder={pendingDecision === "approve" ? "Add context for this decision, or continue without remarks…" : `Explain why this request is being ${pendingDecision === "return" ? "returned" : "rejected"}…`}
              />
              <small>{pendingDecision === "approve" ? "If entered, the remarks will be saved in workflow history." : "Remarks are required and will be saved in workflow history."}</small>
            </label>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button
                type="button"
                className="btn btn-sm"
                onClick={() => setPendingDecision(null)}
                disabled={busy}
              >
                Cancel
              </button>
              <button
                type="button"
                className={`btn btn-sm ${pendingDecision === "reject" ? "btn-danger" : pendingDecision === "approve" ? "btn-success" : "btn-primary"}`}
                disabled={decisionBlocked || (pendingDecision !== "approve" && !actionNote.trim())}
                onClick={confirmDecision}
              >
                Confirm {pendingDecision === "approve" ? approveLabel : pendingDecision === "return" ? returnLabel : rejectLabel}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
}

export interface WorkflowDecisionOption {
  key: string;
  label: string;
  description: string;
  tone?: "approve" | "return" | "reject";
  icon?: string;
  disabled?: boolean;
  onClick: () => void;
}

// Shared visual treatment for workflow decisions that do not require the
// identity-signature step (analysis outcomes, requester acceptance, test
// case review, security verification, etc.).
export function WorkflowDecisionPanel({
  title = "Choose a decision",
  description = "Select one outcome for this workflow stage.",
  options,
  busy = false,
}: {
  title?: string;
  description?: string;
  options: WorkflowDecisionOption[];
  busy?: boolean;
}) {
  return <div className="workflow-decision-step workflow-decision-standalone">
    <div className="workflow-decision-heading">
      <span className="workflow-step-number">1</span>
      <span className="workflow-sign-copy"><small>WORKFLOW DECISION</small><strong>{title}</strong><em>{description}</em></span>
    </div>
    <div className="workflow-decision-options">
      {options.map((option) => <button key={option.key} type="button" className={`workflow-decision-card ${option.tone || "return"}`} disabled={busy || option.disabled} onClick={option.onClick} title={option.description}>
        <span className="workflow-decision-icon">{option.icon || (option.tone === "approve" ? "✓" : option.tone === "reject" ? "×" : "↩")}</span>
        <span>{option.label}</span>
      </button>)}
    </div>
  </div>;
}

export function Field({
  label,
  children,
}: {
  label: ReactNode;
  children?: ReactNode;
}) {
  return (
    <div className="form-field">
      <label>{label}</label>
      {children}
    </div>
  );
}

// Read-only field grouping for request detail "Overview" tabs. Replaces the
// old pattern of one long flat <div className="grid grid-2"> holding every
// field (status, priority, department, CR number, environment, people...)
// with no visual grouping at all -- splitting a detail screen into a handful
// of small, labeled clusters (Application & Change / Classification /
// Environment & Release / People) reads far more clearly than one wall of
// 12-15 facts. Reuses the same .detail-section/.detail-section-title
// classes across every module's detail page for a consistent look.
export function DetailSection({
  title,
  children,
  columns = 2,
}: {
  title?: ReactNode;
  children?: ReactNode;
  columns?: 1 | 2 | 3;
}) {
  return (
    <div className="detail-section">
      {title && <div className="detail-section-title">{title}</div>}
      <div className={`grid grid-${columns}`}>{children}</div>
    </div>
  );
}

// Caller is responsible for its own "—" fallback (e.g. `{req.x || '—'}`),
// same convention already used everywhere else in this codebase -- kept
// dumb here rather than guessing what counts as "empty" for every caller.
export function DetailField({
  label,
  children,
}: {
  label: ReactNode;
  children?: ReactNode;
}) {
  return (
    <div className="detail-field">
      <div className="label">{label}</div>
      <div className="value">{children}</div>
    </div>
  );
}

export interface RepeatableGroupField {
  key: string;
  label: string;
  placeholder?: string;
}
export type RepeatableGroupRow = Record<string, string>;

function blankGroupRow(fields: RepeatableGroupField[]): RepeatableGroupRow {
  return Object.fromEntries(fields.map((f) => [f.key, ""]));
}

// A whole set of fields that repeats together as one unit (e.g. a project
// with several repositories, each with its own branch, commit ID, tech stack
// and build number). One row = one full set of inputs; the single "+" (on
// the last row) adds a new, entirely blank row; "x" removes a row. Never
// down to zero rows, so there's always at least one row to fill in.
export function RepeatableGroupInput({
  fields,
  rows,
  onChange,
  required,
}: {
  fields: RepeatableGroupField[];
  rows: RepeatableGroupRow[];
  onChange: (rows: RepeatableGroupRow[]) => void;
  required?: boolean;
}) {
  const data = rows.length > 0 ? rows : [blankGroupRow(fields)];
  function setAt(i: number, key: string, v: string) {
    onChange(data.map((r, idx) => (idx === i ? { ...r, [key]: v } : r)));
  }
  function addRow() {
    onChange([...data, blankGroupRow(fields)]);
  }
  function removeRow(i: number) {
    onChange(
      data.length > 1
        ? data.filter((_, idx) => idx !== i)
        : [blankGroupRow(fields)]
    );
  }
  return (
    <div>
      {data.map((row, i) => (
        <div
          key={i}
          style={{
            display: "flex",
            gap: 6,
            marginBottom: i < data.length - 1 ? 8 : 0,
            alignItems: "center",
          }}
        >
          {fields.map((f) => (
            <input
              key={f.key}
              required={required && i === 0}
              placeholder={f.placeholder || f.label}
              value={row[f.key] || ""}
              onChange={(e) => setAt(i, f.key, e.target.value)}
              style={{ flex: 1, minWidth: 0 }}
            />
          ))}
          {data.length > 1 && (
            <button
              type="button"
              className="btn btn-sm"
              onClick={() => removeRow(i)}
            >
              &times;
            </button>
          )}
          {i === data.length - 1 && (
            <button type="button" className="btn btn-sm" onClick={addRow}>
              +
            </button>
          )}
        </div>
      ))}
    </div>
  );
}

// Like RepeatableGroupInput, but for a row of mixed field types (selects,
// checkboxes, conditionally-shown fields) that a single `fields` config
// can't express -- the caller supplies its own row JSX via renderRow, and
// this just handles the add/remove/"always at least one row" mechanics
// around it (single "+" on the last row, "x" to remove a row).
export function RepeatableRows<T>({
  rows,
  blankRow,
  onChange,
  renderRow,
}: {
  rows: T[];
  blankRow: () => T;
  onChange: (rows: T[]) => void;
  renderRow: (
    row: T,
    setField: <K extends keyof T>(key: K, value: T[K]) => void,
    index: number
  ) => ReactNode;
}) {
  const data = rows.length > 0 ? rows : [blankRow()];
  function addRow() {
    onChange([...data, blankRow()]);
  }
  function removeRow(i: number) {
    onChange(
      data.length > 1 ? data.filter((_, idx) => idx !== i) : [blankRow()]
    );
  }
  return (
    <div>
      {data.map((row, i) => {
        function setField<K extends keyof T>(key: K, value: T[K]) {
          onChange(
            data.map((r, idx) => (idx === i ? { ...r, [key]: value } : r))
          );
        }
        return (
          <div
            key={i}
            style={{
              display: "flex",
              gap: 6,
              marginBottom: i < data.length - 1 ? 10 : 0,
              alignItems: "flex-start",
            }}
          >
            <div style={{ flex: 1, display: "flex", gap: 6, flexWrap: "wrap" }}>
              {renderRow(row, setField, i)}
            </div>
            {data.length > 1 && (
              <button
                type="button"
                className="btn btn-sm"
                onClick={() => removeRow(i)}
              >
                &times;
              </button>
            )}
            {i === data.length - 1 && (
              <button type="button" className="btn btn-sm" onClick={addRow}>
                +
              </button>
            )}
          </div>
        );
      })}
    </div>
  );
}

function correctiveGuidance(message: string): string {
  const normalized = message.toLowerCase();
  if (normalized.includes("http 502") || normalized.includes("http 503") || normalized.includes("http 504")
    || normalized.includes("temporarily unavailable") || normalized.includes("could not connect"))
    return "Wait a moment and try again. If the service remains unavailable, contact the portal administrator and provide the technical reference shown above, if available.";
  if (normalized.includes("too long to respond") || normalized.includes("http 408") || normalized.includes("timeout"))
    return "The operation may be under heavy load. Wait briefly, refresh the page, and try again. Avoid submitting the same data repeatedly.";
  // Re-execution validation can mention both "requires" and "Recycle Bin".
  // Keep this before the broad required-field branch so the dialog gives the
  // recovery action instead of incorrectly asking the user to fill a field.
  if (normalized.includes("recycle bin"))
    return "Restore the listed testcase(s) from the Recycle Bin, refresh the current record, and try the action again. Existing execution history remains unchanged.";
  if (normalized.includes("checklist") || normalized.includes("readiness"))
    return "Review the readiness checklist, complete every item identified in the reason, and try the action again.";
  if (normalized.includes("required") || normalized.includes("cannot be blank") || normalized.includes("choose") || normalized.includes("select"))
    return "Complete the required information described above, verify the entered values, and try again.";
  if (normalized.includes("not found") || normalized.includes("404"))
    return "The record may have changed or been removed. Close this message, refresh the page, and select the record again.";
  if (normalized.includes("permission") || normalized.includes("permitted") || normalized.includes("role") || normalized.includes("403"))
    return "Your account does not have the required access for this action. Contact the portal administrator or the responsible workflow owner.";
  if (normalized.includes("inactive"))
    return "Reactivate the related project or record before attempting this action again.";
  if (normalized.includes("already") || normalized.includes("current status") || normalized.includes("must be in"))
    return "Refresh the record and confirm its latest workflow status before retrying the action.";
  if (normalized.includes("excel") || normalized.includes("workbook") || normalized.includes("import") || normalized.includes("file"))
    return "Correct the file or data described in the reason, then upload it again. Previously successful records are unaffected.";
  return "Review the reason, correct the data or workflow condition, and try again. If the problem continues, contact the portal administrator.";
}

export function ErrorText({ error, title = "Action could not be completed", guidance }: {
  error?: unknown;
  title?: string;
  guidance?: ReactNode;
}) {
  const [visible, setVisible] = useState(Boolean(error));
  useEffect(() => setVisible(Boolean(error)), [error]);
  if (!error || !visible) return null;
  const message = error instanceof Error ? error.message : String(error);
  const httpError = error instanceof HttpError ? error : null;
  // Request IDs also accompany expected validation and workflow responses.
  // Surface diagnostic details only for service, network, or timeout failures.
  const systemFailure = httpError !== null &&
    (httpError.status >= 500 || httpError.status === 0 || httpError.status === 408);
  const reasonParts = ["Reason"];
  if (httpError?.cause) reasonParts.push(httpError.cause);
  if (systemFailure && httpError.status) reasonParts.push(`HTTP ${httpError.status}`);
  const correctiveAction = httpError?.guidance ||
    (systemFailure ? correctiveGuidance(message) : guidance || correctiveGuidance(message));
  return (
    <Modal title={title} onClose={() => setVisible(false)} variant="dialog" preventBackdropClose>
      <div className="action-error-dialog" role="alert">
        <div className="action-error-dialog-icon">!</div>
        <div>
          <strong>The requested action was stopped</strong>
          <span>{reasonParts.join(" · ")}</span>
          <p>{message}</p>
          {httpError?.code && <small className="action-error-reference">Diagnostic code: {httpError.code}</small>}
          {systemFailure && httpError.reference && <small className="action-error-reference">Technical reference: {httpError.reference}</small>}
        </div>
      </div>
      <div className="action-error-guidance">
        <strong>What to do</strong>
        <p>{correctiveAction}</p>
      </div>
      <button type="button" className="btn btn-primary" onClick={() => setVisible(false)}>Close</button>
    </Modal>
  );
}

// One readiness-pass failure dialog for every request module. Keeping the
// title and corrective guidance here prevents Functional, SAST, DAST and
// Performance from drifting back to different inline/disabled behaviours.
export function ReadinessPassError({ error }: { error?: unknown }) {
  return (
    <ErrorText
      error={error}
      title="Readiness cannot be passed"
      guidance="Review the Readiness Checklist, complete the listed verification items, and then try “Readiness Passed” again."
    />
  );
}

export interface TableColumn<T> {
  key: string;
  header: ReactNode;
  render?: (row: T) => ReactNode;
  // Set false to hide the filter box for this column entirely -- for
  // action-only columns (a lone "Download" button, icons with no text) where
  // a text filter wouldn't match anything meaningful. Every other column gets
  // one automatically.
  filterable?: boolean;
  // The plain text a typed filter is matched against for this column.
  // Defaults to String(row[key]) which works fine for columns that render
  // their own raw field, but must be supplied explicitly wherever `render`
  // displays something derived from the row rather than the field at `key`
  // itself (a user-ID column showing a looked-up name, a linked-object column
  // showing a badge, a findings array shown as a count, etc.) -- otherwise
  // the filter would silently compare against the wrong underlying value.
  filterValue?: (row: T) => string;
}

// SRS 7.2 (PAG-001..010) -- when a list is server-paginated (see
// hooks/usePaginatedList.ts), `rows` holds only the CURRENT page's items,
// not the whole dataset, so Table can no longer do its own client-side
// filtering/slicing over `rows` -- there's nothing left in the browser to
// filter beyond what the server already sent. Passing this prop switches
// Table into that mode. Column filters remain available so the filtering
// experience is consistent throughout the application; because `rows` is
// the current API page, those value filters refine the current page while
// each module's search/status/department controls continue to query the full
// dataset. The footer makes that scope explicit whenever a filter is active.
export interface TableServerPagination {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrevious: boolean;
  onPageChange: (page: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  loading?: boolean;
}

interface TableProps<T> {
  columns: TableColumn<T>[];
  rows: T[];
  rowKey: keyof T;
  onRowClick?: (row: T) => void;
  // Every Table paginates -- 5 rows per page by default, everywhere in the
  // app, per the "everywhere in project table, list add pagination, show 5
  // items only per page" requirement. Left as an overridable prop (rather
  // than a hardcoded constant) purely as an escape hatch for some future
  // call site that genuinely needs a different page size, not because any
  // current one does. Ignored when `server` is set -- `server.pageSize`
  // governs instead.
  pageSize?: number;
  // Optional stable identifier for pages containing multiple similar tables.
  // When omitted, the route and column keys form the preference key.
  tableId?: string;
  // Reset client-side pagination when an external search or tab changes.
  // The table cannot infer this from rows.length when two searches happen
  // to return the same number of records.
  resetKey?: unknown;
  showColumnControls?: boolean;
  // See TableServerPagination above. Omitted (the default): Table behaves
  // exactly as before, filtering/paginating `rows` entirely client-side.
  server?: TableServerPagination;
  // Reports the rows actually rendered in <tbody>, after the Table's own
  // column filters and client-side pagination. Bulk-selection owners use
  // this instead of the raw `rows` prop so "Select all visible" cannot
  // accidentally include rows hidden by a column filter.
  onVisibleRowsChange?: (rows: T[]) => void;
}

const SERVER_PAGE_SIZE_OPTIONS = [5, 10, 25, 50, 100];

function statusColumnSecond<T>(columns: TableColumn<T>[]): TableColumn<T>[] {
  let statusIndex = columns.findIndex((column) => column.key === "status");
  if (statusIndex < 0) {
    statusIndex = columns.findIndex((column) =>
      /(?:^|_)status$/.test(column.key) ||
      (typeof column.header === "string" && /\bstatus\b/i.test(column.header))
    );
  }
  if (statusIndex < 0 || statusIndex === 1 || columns.length < 2) return columns;
  const ordered = columns.filter((_, index) => index !== statusIndex);
  ordered.splice(1, 0, columns[statusIndex]);
  return ordered;
}

export function Table<T extends Record<string, any>>({
  columns,
  rows,
  rowKey,
  onRowClick,
  pageSize = 5,
  tableId,
  resetKey,
  showColumnControls = true,
  server,
  onVisibleRowsChange,
}: TableProps<T>) {
  // Each column can hold several exact values. Different columns are still
  // combined with AND, while values selected inside one column use OR.
  const [filters, setFilters] = useState<Record<string, string[]>>({});
  const [page, setPage] = useState(1);
  // Which column's filter popover is currently open -- at most one at a
  // time, closed by clicking its icon again, pressing Escape, or clicking
  // anywhere outside the popover (see the document listener below). Having a
  // values selected in a column's filter and the popover being closed are
  // independent: closing the popover doesn't clear that column's filter, it
  // just hides the input (the icon itself gets a filled/active style so it's
  // still obvious a filter is applied).
  const [openFilterKey, setOpenFilterKey] = useState<string | null>(null);
  // Screen coordinates for the currently-open popover, captured from the
  // filter icon's own bounding box at click time. The popover itself is
  // rendered with position:fixed at these coordinates -- rather than
  // position:absolute nested inside the <th> -- specifically so it isn't
  // clipped by .table-wrap's overflow-x:auto/overflow-y:hidden scroll box
  // and always paints in front of every table row underneath it instead of
  // visually overlapping/blending into the first row's cell text.
  const [popoverPos, setPopoverPos] = useState<{
    top: number;
    left: number;
    width: number;
  } | null>(null);
  const popoverRef = useRef<HTMLDivElement>(null);
  const columnsPanelRef = useRef<HTMLDivElement>(null);
  const columnsTriggerRef = useRef<HTMLDivElement>(null);
  const [columnsOpen, setColumnsOpen] = useState(false);
  const [columnsPanelPosition, setColumnsPanelPosition] = useState({ top: 0, right: 12 });
  // Only columns deliberately configured by each screen belong in its table.
  // Raw API response fields are intentionally not auto-discovered: doing so
  // exposed internal IDs/metadata and made everyday tables unnecessarily wide.
  const availableColumns = useMemo(() => statusColumnSecond(columns), [columns]);
  const preferenceKey = useMemo(() => {
    const route = typeof window === "undefined" ? "table" : window.location.pathname;
    return `qap-visible-columns:v2:${tableId || `${route}:${columns.map((c) => c.key).join("|")}`}`;
  }, [columns, tableId]);
  const [hiddenColumnKeys, setHiddenColumnKeys] = useState<string[]>([]);
  const [hasColumnPreference, setHasColumnPreference] = useState(false);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(preferenceKey);
      const parsed = saved ? JSON.parse(saved) : [];
      setHiddenColumnKeys(Array.isArray(parsed) ? parsed.filter((key) => typeof key === "string") : []);
      setHasColumnPreference(saved !== null);
    } catch {
      setHiddenColumnKeys([]);
      setHasColumnPreference(false);
    }
  }, [preferenceKey]);

  const visibleColumns = useMemo(() => {
    const available = new Set(availableColumns.map((column) => column.key));
    // With no saved choice, show the screen's curated default column set.
    const defaultHidden: string[] = [];
    const hidden = new Set(
      (hasColumnPreference ? hiddenColumnKeys : defaultHidden).filter((key) => available.has(key))
    );
    const selected = availableColumns.filter((column) => !hidden.has(column.key));
    // Keep Status second even when the first column has been hidden.
    return selected.length > 0 ? statusColumnSecond(selected) : availableColumns.slice(0, 1);
  }, [availableColumns, hasColumnPreference, hiddenColumnKeys]);

  function setColumnVisible(key: string, visible: boolean) {
    setHiddenColumnKeys((current) => {
      const defaultHidden: string[] = [];
      const startingHidden = hasColumnPreference ? current : defaultHidden;
      const next = visible
        ? startingHidden.filter((item) => item !== key)
        : Array.from(new Set([...startingHidden, key]));
      // A useful table must always retain at least one visible column.
      if (availableColumns.every((column) => next.includes(column.key))) return current;
      try {
        window.localStorage.setItem(preferenceKey, JSON.stringify(next));
      } catch {
        // Storage can be unavailable in private/restricted browser contexts.
      }
      setHasColumnPreference(true);
      if (!visible) {
        setFilters((existing) => {
          const updated = { ...existing };
          delete updated[key];
          return updated;
        });
        setOpenFilterKey((open) => (open === key ? null : open));
      }
      return next;
    });
  }

  function showAllColumns() {
    setHiddenColumnKeys([]);
    setHasColumnPreference(true);
    try {
      window.localStorage.setItem(preferenceKey, "[]");
    } catch {
      // See storage note above.
    }
  }

  useEffect(() => {
    if (!columnsOpen) return;
    function closeColumns(e: MouseEvent) {
      const target = e.target as Node;
      if (
        !columnsPanelRef.current?.contains(target) &&
        !columnsTriggerRef.current?.contains(target)
      )
        setColumnsOpen(false);
    }
    function closeOnEscape(e: KeyboardEvent) {
      if (e.key === "Escape") setColumnsOpen(false);
    }
    document.addEventListener("mousedown", closeColumns);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("mousedown", closeColumns);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, [columnsOpen]);

  function toggleColumnsPanel() {
    if (!columnsOpen && columnsTriggerRef.current) {
      const rect = columnsTriggerRef.current.getBoundingClientRect();
      setColumnsPanelPosition({
        top: Math.min(rect.bottom + 6, window.innerHeight - 180),
        right: Math.max(12, window.innerWidth - rect.right),
      });
    }
    setColumnsOpen((open) => !open);
  }

  useEffect(() => {
    if (!openFilterKey) return;
    function onDocMouseDown(e: MouseEvent) {
      if (popoverRef.current && !popoverRef.current.contains(e.target as Node))
        setOpenFilterKey(null);
    }
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") setOpenFilterKey(null);
    }
    function onScroll(e: Event) {
      // The searchable value picker has its own scrollable suggestion list.
      // Window receives that non-bubbling scroll through this capture-phase
      // listener, but scrolling within the active filter must not dismiss the
      // filter itself. External page/table scrolling can still close it so a
      // fixed-position popover is never left detached from its column icon.
      const target = e.target;
      if (target instanceof Node && popoverRef.current?.contains(target)) return;
      setOpenFilterKey(null);
    }
    function onResize() {
      setOpenFilterKey(null);
    }
    document.addEventListener("mousedown", onDocMouseDown);
    document.addEventListener("keydown", onKeyDown);
    // Closing on scroll/resize (rather than tracking + repositioning) keeps
    // this simple -- a filter popover doesn't need to survive the page
    // moving underneath it.
    window.addEventListener("scroll", onScroll, true);
    window.addEventListener("resize", onResize);
    return () => {
      document.removeEventListener("mousedown", onDocMouseDown);
      document.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("scroll", onScroll, true);
      window.removeEventListener("resize", onResize);
    };
  }, [openFilterKey]);

  function toggleFilter(key: string, e: React.MouseEvent<HTMLButtonElement>) {
    e.stopPropagation();
    if (openFilterKey === key) {
      setOpenFilterKey(null);
      return;
    }
    const rect = e.currentTarget.getBoundingClientRect();
    const viewportGap = 10;
    const popoverGap = 6;
    const width = Math.min(300, window.innerWidth - viewportGap * 2);
    const estimatedHeight = 280;
    const left = Math.min(
      Math.max(viewportGap, rect.left),
      window.innerWidth - width - viewportGap
    );
    const opensAbove = rect.bottom + popoverGap + estimatedHeight > window.innerHeight - viewportGap;
    const top = opensAbove
      ? Math.max(viewportGap, rect.top - estimatedHeight - popoverGap)
      : rect.bottom + popoverGap;
    setPopoverPos({ top, left, width });
    setOpenFilterKey(key);
  }

  function textFor(col: TableColumn<T>, row: T): string {
    if (col.filterValue) return col.filterValue(row);
    const v = (row as any)[col.key];
    if (v === null || v === undefined) return "";
    if (typeof v === "object") {
      try {
        return JSON.stringify(v);
      } catch {
        return String(v);
      }
    }
    return String(v);
  }

  const activeFilters = Object.entries(filters).filter(([, values]) => values.length > 0);

  const filteredRows = useMemo(() => {
    if (activeFilters.length === 0) return rows;
    return rows.filter((row) =>
      activeFilters.every(([key, values]) => {
        const col = availableColumns.find((c) => c.key === key);
        if (!col) return true;
        const rowValue = textFor(col, row).trim().toLowerCase();
        return values.some((value) => rowValue === value.trim().toLowerCase());
      })
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, filters, availableColumns, server]);

  // Reset to page 1 whenever the filtered set changes shape (a new filter
  // typed, or the underlying row count changes, e.g. fresh data loaded) --
  // otherwise narrowing a filter while sitting on page 3 could strand you on
  // a now-empty page instead of showing the first (most relevant) matches.
  // Keyed on rows.length rather than `rows` itself -- several call sites
  // pass a freshly-computed array (e.g. `rows={items.slice(0, 8)}`) on every
  // render, and resetting on identity rather than content would snap back
  // to page 1 on any unrelated parent re-render, not just an actual data
  // change. Not relevant in server mode -- the caller (usePaginatedList)
  // already resets its own `page` state when a filter changes.
  useEffect(() => {
    if (server) return;
    setPage(1);
  }, [filters, rows.length, resetKey, server]);

  const totalPages = server ? Math.max(1, server.totalPages) : Math.max(1, Math.ceil(filteredRows.length / pageSize));
  // Clamp separately from the reset above -- covers the case where `page`
  // was already >1 and filteredRows.length shrinks for a reason that didn't
  // go through the filters/rows reset (e.g. pageSize itself changing).
  const currentPage = server ? server.page : Math.min(page, totalPages);
  const effectivePageSize = server ? server.pageSize : pageSize;
  const pagedRows = useMemo(
    () =>
      server ? filteredRows : filteredRows.slice((currentPage - 1) * pageSize, currentPage * pageSize),
    [server, rows, filteredRows, currentPage, pageSize]
  );

  useEffect(() => {
    onVisibleRowsChange?.(pagedRows);
  }, [pagedRows, onVisibleRowsChange]);

  function clearFilters() {
    setFilters({});
    setOpenFilterKey(null);
  }

  function columnLabel(column: TableColumn<T>): string {
    if (typeof column.header === "string" && column.header.trim()) return column.header;
    return column.key.replace(/[_-]+/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
  }

  const recordCount = server ? server.total : rows.length;
  const visibleRecordCount = server ? filteredRows.length : filteredRows.length;

  return (
    <div className="table-shell">
      <div className="table-toolbar">
        <div className="table-record-summary" aria-live="polite">
          <span className="table-record-dot" aria-hidden="true" />
          <strong>{recordCount.toLocaleString()} record{recordCount === 1 ? "" : "s"}</strong>
          {activeFilters.length > 0 && <span>{visibleRecordCount.toLocaleString()} matching current filters</span>}
        </div>
        {showColumnControls && <div className="table-column-controls" ref={columnsTriggerRef}>
          <button
            type="button"
            className="table-columns-trigger"
            onClick={toggleColumnsPanel}
            aria-expanded={columnsOpen}
          >
            Columns <span>{visibleColumns.length}/{availableColumns.length}</span>
          </button>
        </div>}
        {showColumnControls && columnsOpen && createPortal(
          <div
            className="table-columns-panel"
            ref={columnsPanelRef}
            style={{
              top: columnsPanelPosition.top,
              right: columnsPanelPosition.right,
              bottom: 12,
            }}
          >
            <div className="table-columns-heading">
              <div>
                <strong>Choose visible columns</strong>
                <small>Saved only for your view</small>
              </div>
              <button type="button" onClick={showAllColumns} disabled={visibleColumns.length === availableColumns.length}>
                Show all
              </button>
            </div>
            <div className="table-columns-list">
              {availableColumns.map((column) => {
                const visible = visibleColumns.some((item) => item.key === column.key);
                const lastVisible = visible && visibleColumns.length === 1;
                return (
                  <label key={column.key} title={lastVisible ? "At least one column must remain visible" : undefined}>
                    <input
                      type="checkbox"
                      checked={visible}
                      disabled={lastVisible}
                      onChange={(event) => setColumnVisible(column.key, event.target.checked)}
                    />
                    <span>{typeof column.header === "string" ? column.header : column.key}</span>
                  </label>
                );
              })}
            </div>
          </div>,
          document.body
        )}
      </div>
      <div className="table-wrap" role="region" aria-label="Data table" tabIndex={0}>
      <table className="data-table">
        <thead>
          <tr>
            {visibleColumns.map((c) => (
              <th key={c.key} data-column={c.key} scope="col">
                <div className="th-cell">
                  <span>{c.header}</span>
                  {c.filterable !== false && (
                    <button
                      type="button"
                      className={`th-filter-btn ${
                        filters[c.key]?.length ? "active" : ""
                      }`}
                      title={`Filter ${columnLabel(c)}`}
                      aria-label={`Filter ${columnLabel(c)}`}
                      onClick={(e) => toggleFilter(c.key, e)}
                    >
                      <IconFilter width={12} height={12} />
                    </button>
                  )}
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {filteredRows.length === 0 && (
            <tr>
              <td colSpan={visibleColumns.length}>
                <EmptyState
                  compact
                  title={rows.length === 0 ? "No records available" : "No matching records"}
                  description={rows.length === 0
                    ? "There is no data to display yet."
                    : "No rows match the selected column filters."}
                  action={activeFilters.length > 0 ? (
                    <button
                      type="button"
                      className="btn btn-sm"
                      onClick={clearFilters}
                    >
                      Clear filters
                    </button>
                  ) : undefined}
                />
              </td>
            </tr>
          )}
          {pagedRows.map((row) => (
            <tr
              key={String(row[rowKey])}
              onClick={onRowClick ? (event) => {
                const target = event.target as Element;
                if (!shouldActivateTableRow(target, event.currentTarget)) return;
                onRowClick(row);
              } : undefined}
              onKeyDown={onRowClick ? (event) => {
                if (event.target === event.currentTarget && isKeyboardActivationKey(event.key)) {
                  event.preventDefault();
                  onRowClick(row);
                }
              } : undefined}
              role={onRowClick ? "button" : undefined}
              tabIndex={onRowClick ? 0 : undefined}
              aria-label={onRowClick ? `Open record ${String(row[rowKey])}` : undefined}
              className={onRowClick ? "row-clickable" : undefined}
            >
              {visibleColumns.map((c) => (
              <td key={c.key} data-column={c.key} data-label={columnLabel(c)}>
                  {c.render ? c.render(row) : textFor(c, row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {server
        ? (server.total > 0 && (server.totalPages > 1 || server.onPageSizeChange)) && (
          <div className="table-footer">
            <div className="table-footer-filters">
              {server.loading && <span>Loading…</span>}
              {!server.loading && activeFilters.length > 0 && (
                <>
                  <span>Showing {filteredRows.length} of {rows.length} rows on this page</span>
                  <button type="button" onClick={clearFilters}>Clear filters</button>
                </>
              )}
            </div>
            <div className="table-pagination">
              <span>
                {(server.page - 1) * server.pageSize + 1}–
                {Math.min(server.page * server.pageSize, server.total)} of{" "}
                {server.total}
              </span>
              {server.onPageSizeChange && (
                <select
                  className="table-page-size"
                  value={server.pageSize}
                  onChange={(e) => server.onPageSizeChange!(Number(e.target.value))}
                  aria-label="Rows per page"
                >
                  {SERVER_PAGE_SIZE_OPTIONS.map((size) => (
                    <option key={size} value={size}>{size} / page</option>
                  ))}
                </select>
              )}
              <button
                type="button"
                disabled={!server.hasPrevious || server.loading}
                onClick={() => server.onPageChange(server.page - 1)}
              >
                ‹ Prev
              </button>
              <span>
                Page {server.page} of {server.totalPages}
              </span>
              <button
                type="button"
                disabled={!server.hasNext || server.loading}
                onClick={() => server.onPageChange(server.page + 1)}
              >
                Next ›
              </button>
            </div>
          </div>
        )
        : filteredRows.length > 0 &&
          (activeFilters.length > 0 || totalPages > 1) && (
          <div className="table-footer">
            <div className="table-footer-filters">
              {activeFilters.length > 0 && (
                <>
                  <span>
                    Showing {filteredRows.length} of {rows.length} rows
                  </span>
                  <button type="button" onClick={clearFilters}>
                    Clear filters
                  </button>
                </>
              )}
            </div>
            {totalPages > 1 && (
              <div className="table-pagination">
                <span>
                  {(currentPage - 1) * effectivePageSize + 1}–
                  {Math.min(currentPage * effectivePageSize, filteredRows.length)} of{" "}
                  {filteredRows.length}
                </span>
                <button
                  type="button"
                  disabled={currentPage <= 1}
                  onClick={() => setPage(currentPage - 1)}
                >
                  ‹ Prev
                </button>
                <span>
                  Page {currentPage} of {totalPages}
                </span>
                <button
                  type="button"
                  disabled={currentPage >= totalPages}
                  onClick={() => setPage(currentPage + 1)}
                >
                  Next ›
                </button>
              </div>
            )}
          </div>
        )}
      {openFilterKey &&
        popoverPos &&
        (() => {
          const col = availableColumns.find((c) => c.key === openFilterKey);
          if (!col) return null;
          const values = Array.from(
            new Set(rows.map((row) => textFor(col, row).trim()).filter(Boolean))
          ).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
          return (
            <div
              className="th-filter-popover th-filter-popover-multi"
              ref={popoverRef}
              style={{ top: popoverPos.top, left: popoverPos.left, width: popoverPos.width }}
              onClick={(e) => e.stopPropagation()}
            >
              <MultiSelect
                inline
                value={filters[col.key] || []}
                onChange={(value) => setFilters((f) => ({ ...f, [col.key]: value }))}
                placeholder="All values"
                itemName="value"
                options={values}
              />
            </div>
          );
        })()}
      </div>
    </div>
  );
}

// Shared "Documents" tab body -- multiple supporting files uploaded any time
// after a request has been raised. Used by every module EXCEPT the Gateway
// QA Request, which has its own bespoke Documents tab/upload flow in
// QARequests.tsx predating this (documents collected during the wizard
// itself, not just after raising). `apiBase` is that module's own request
// router prefix, e.g. "/api/functional-requests" -- this component always
// talks to `${apiBase}/${reqId}/documents[...]`, matching the endpoints
// added in each router (see backend/app/documents.py).
export function RequestDocuments({
  apiBase,
  reqId,
  canManage = true,
}: {
  apiBase: string;
  reqId: number;
  // Reported directly: "uploading document should be non editable if not
  // assigned, or in other person's bucket. only the assigned person can
  // update" -- this Documents tab used to render its Upload form (and every
  // row's Delete button, beyond the existing uploaded-by-me/admin check) to
  // any viewer regardless of whether the backend's own _can_upload_documents
  // would actually accept the upload, matching the same gap
  // ChecklistEvidence had before it gained its own `canManage`. Defaults to
  // `true` so any not-yet-updated call site keeps its old behavior.
  canManage?: boolean;
}) {
  const { user } = useAuth();
  const [documents, setDocuments] = useState<RequestDocumentOut[]>([]);
  const [files, setFiles] = useState<File[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [pendingDelete, setPendingDelete] = useState<RequestDocumentOut | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      setDocuments(
        await api.get<RequestDocumentOut[]>(`${apiBase}/${reqId}/documents`)
      );
    } catch (err) {
      setError(err);
    }
  }, [apiBase, reqId]);

  useEffect(() => {
    load();
  }, [load]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (files.length === 0) return;
    setBusy(true);
    setError(null);
    try {
      await api.uploadFiles(`${apiBase}/${reqId}/documents`, files);
      setFiles([]);
      load();
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    setDeleteBusy(true);
    setError(null);
    try {
      await api.del(`${apiBase}/${reqId}/documents/${pendingDelete.id}`);
      setPendingDelete(null);
      load();
    } catch (err) {
      setPendingDelete(null);
      setError(err);
    } finally {
      setDeleteBusy(false);
    }
  }

  return (
    <div>
      <ErrorText error={error} />
      <Table
        rowKey="id"
        columns={[
          { key: "file_name", header: "File" },
          {
            key: "file_size",
            header: "Size",
            render: (d) =>
              d.file_size ? `${(d.file_size / 1024).toFixed(1)} KB` : "—",
          },
          {
            key: "uploaded_at",
            header: "Uploaded",
            render: (d) => formatDateTimeIST(d.uploaded_at),
          },
          {
            key: "actions",
            header: "",
            filterable: false,
            render: (d) => (
              <span style={{ display: "inline-flex", gap: 6 }}>
                <button
                  className="btn btn-sm"
                  onClick={() =>
                    api.downloadFile(
                      `${apiBase}/${reqId}/documents/${d.id}/download`,
                      d.file_name
                    )
                  }
                >
                  Download
                </button>
                {canDeleteWorkflowDocument(user, d.uploaded_by_id, canManage) && (
                  <button
                    className="btn btn-sm btn-danger"
                    onClick={() => setPendingDelete(d)}
                  >
                    Delete
                  </button>
                )}
              </span>
            ),
          },
        ]}
        rows={documents}
      />
      {canManage ? (
      <form onSubmit={submit} style={{ marginTop: 14 }}>
        <div
          style={{
            display: "flex",
            gap: 8,
            alignItems: "center",
            flexWrap: "wrap",
          }}
        >
          <input
            type="file"
            multiple
            onChange={(e) =>
              setFiles((prev) => [...prev, ...Array.from(e.target.files || [])])
            }
          />
          <button className="btn btn-sm" disabled={busy || files.length === 0}>
            {busy ? "Uploading..." : "Upload"}
          </button>
        </div>
        {files.length > 0 && (
          <ul
            style={{
              listStyle: "none",
              margin: "8px 0 0",
              padding: 0,
              display: "flex",
              flexDirection: "column",
              gap: 4,
            }}
          >
            {files.map((f, idx) => (
              <li
                key={`${f.name}-${idx}`}
                style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5 }}
              >
                <span>{f.name}</span>
                <button
                  type="button"
                  className="btn btn-sm"
                  disabled={busy}
                  onClick={() =>
                    setFiles((prev) => prev.filter((_, i) => i !== idx))
                  }
                  aria-label={`Remove ${f.name}`}
                >
                  ✕
                </button>
              </li>
            ))}
          </ul>
        )}
      </form>
      ) : (
        <p className="muted small" style={{ marginTop: 14 }} title="Only whoever this request is currently assigned to can upload documents">
          Only the current assignee can upload documents at this stage.
        </p>
      )}
      {pendingDelete && (
        <Modal
          title="Delete document?"
          onClose={() => setPendingDelete(null)}
          variant="dialog"
          preventBackdropClose
        >
          <div style={{ fontSize: 13.5 }}>
            Delete <strong>{pendingDelete.file_name}</strong>? This cannot be undone.
          </div>
          <div style={{ display: "flex", gap: 10, marginTop: 18 }}>
            <button
              type="button"
              className="btn btn-danger"
              disabled={deleteBusy}
              onClick={confirmDelete}
            >
              {deleteBusy ? "Deleting..." : "Delete"}
            </button>
            <button
              type="button"
              className="btn"
              disabled={deleteBusy}
              onClick={() => setPendingDelete(null)}
            >
              Cancel
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// Batched fetch of every checklist item's evidence documents for one
// raised (post-Draft) Functional/SAST/DAST/Performance request -- reported
// directly via server logs showing one GET .../checklist/{item_id}/documents
// per checklist item (e.g. 8 parallel calls for one Functional request with
// 8 items) because every <ChecklistEvidence/> instance used to fetch its
// own. One call per page instead: GET .../checklist/documents returns every
// item's documents in one flat list tagged with item_id (see
// ChecklistItemDocumentOut), regrouped here into per-item buckets. Same
// pattern already used for the pre-raise wizard's ChecklistEvidencePicker
// (see QARequests/steps/ChecklistEvidencePicker.tsx + NewRequestModal.tsx).
export function useChecklistDocuments(apiBase: string, reqId: number | undefined) {
  const [documentsByItem, setDocumentsByItem] = useState<Record<number, RequestDocumentOut[]>>({});

  const reload = useCallback(async () => {
    if (!reqId) {
      setDocumentsByItem({});
      return;
    }
    try {
      const rows = await api.get<ChecklistItemDocumentOut[]>(`${apiBase}/${reqId}/checklist/documents`);
      const grouped: Record<number, RequestDocumentOut[]> = {};
      for (const row of rows) {
        (grouped[row.item_id] || (grouped[row.item_id] = [])).push(row);
      }
      setDocumentsByItem(grouped);
    } catch {
      // Swallow -- a failed batched fetch just leaves every item's count at
      // 0; each ChecklistEvidence instance's own upload/delete still
      // surfaces its own errors independently.
    }
  }, [apiBase, reqId]);

  useEffect(() => {
    reload();
  }, [reload]);

  return { documentsByItem, reload };
}

// Shared building block for one already-uploaded evidence document's row --
// a download button (filename, ellipsised) plus an optional delete "×"
// button. Used by both ChecklistEvidence below (post-raise, backed by a
// real per-item documents endpoint) and the pre-raise wizard's own
// ChecklistEvidencePicker (QARequests/steps/ChecklistEvidencePicker.tsx) --
// reported directly: "checklist UI still not uniformed like QA request
// checklist UI, Edit UI, why duplicate code, make consistent UI." The two
// components' underlying data still differs too much to merge outright
// (this one talks to a real REST endpoint; the wizard's operates on a
// draft's local File[] state until the whole form is saved), but the
// per-saved-file row markup was identical in both and is now defined once.
export function ChecklistEvidenceFileRow({
  fileName,
  onDownload,
  onDelete,
}: {
  fileName: string;
  onDownload: () => void;
  onDelete?: () => void;
}) {
  return (
    <div className="checklist-evidence-file">
      <button
        type="button"
        className="btn btn-sm"
        style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}
        title={`Download ${fileName}`}
        onClick={onDownload}
      >
        {fileName}
      </button>
      {onDelete && (
        <button type="button" className="btn btn-sm btn-danger" aria-label={`Delete ${fileName}`} onClick={onDelete}>×</button>
      )}
    </div>
  );
}

// One visual/interaction shell for supporting evidence everywhere. The
// gateway wizard keeps new files locally until Draft save, while raised
// request modules upload immediately, but that storage difference must not
// produce two different controls for users.
export function SupportingEvidenceControl({
  canAttach = true,
  attachDisabled = false,
  attachBusy = false,
  onAttach,
  totalFiles,
  required = false,
  mandatory = false,
  children,
}: {
  canAttach?: boolean;
  attachDisabled?: boolean;
  attachBusy?: boolean;
  onAttach: () => void;
  totalFiles: number;
  required?: boolean;
  mandatory?: boolean;
  children?: ReactNode;
}) {
  return (
    <>
      <div className="checklist-evidence-actions">
        {canAttach ? (
          <button
            type="button"
            className="btn btn-sm"
            disabled={attachBusy || attachDisabled}
            title={attachDisabled ? "Tick this item as checked before attaching evidence for it" : undefined}
            onClick={onAttach}
          >
            {attachBusy ? "Uploading…" : "Attach evidence"}
          </button>
        ) : (
          <span className="muted small" title="Evidence is locked after Department Head approval">Evidence locked</span>
        )}
        {totalFiles > 0 && <span className="badge badge-blue">{totalFiles} file{totalFiles !== 1 ? "s" : ""}</span>}
        {mandatory && totalFiles === 0 ? (
          <span className="badge badge-red" title="Evidence is required before this request can be raised.">
            Evidence required
          </span>
        ) : required && totalFiles === 0 ? (
          <span className="badge badge-gray" title="Evidence is recommended for selected checklist items.">
            Evidence recommended
          </span>
        ) : null}
      </div>
      {totalFiles > 0 && <div className="checklist-evidence-files">{children}</div>}
    </>
  );
}

// Shared delete-confirmation dialog for one evidence document -- same
// markup/behavior in both ChecklistEvidence and ChecklistEvidencePicker,
// just an optional trailing phrase on the body copy (e.g. "from this
// checklist item").
export function ChecklistEvidenceDeleteModal({
  fileName,
  itemLabel,
  busy,
  onConfirm,
  onCancel,
}: {
  fileName: string;
  itemLabel?: string;
  busy: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <Modal title="Delete checklist evidence?" onClose={onCancel} variant="dialog" compact tone="danger" preventBackdropClose>
      <p>Delete <strong>{fileName}</strong>{itemLabel ? ` ${itemLabel}` : ""}? This cannot be undone.</p>
      <div className="modal-actions">
        <button type="button" className="btn btn-danger" disabled={busy} onClick={onConfirm}>
          {busy ? "Deleting…" : "Delete"}
        </button>
        <button type="button" className="btn" disabled={busy} onClick={onCancel}>Cancel</button>
      </div>
    </Modal>
  );
}

// Compact evidence uploader rendered beside one readiness-checklist item.
// Evidence uses checklist-specific endpoints, so it stays associated with
// this row instead of being mixed into the request's general Documents tab.
export function ChecklistEvidence({
  apiBase,
  reqId,
  itemId,
  canManage = true,
  required = false,
  onCountChange,
  documents,
  onReload,
  checked = true,
}: {
  apiBase: string;
  reqId: number;
  itemId: number;
  canManage?: boolean;
  // Whether this item is one that needs at least one evidence document --
  // i.e. it's mandatory, or the requester has self-declared it checked (see
  // backend documents.py::require_checklist_evidence for the matching
  // server-side rule). Purely a front-end hint here; the backend is the
  // actual enforcement point at Submit/Resubmit and QA Lead verify-time.
  required?: boolean;
  // Reports the current evidence-document count back up to the parent so it
  // can (for example) disable a "verify" checkbox until evidence exists,
  // mirroring the backend's verify-time gate.
  onCountChange?: (count: number) => void;
  // This item's own slice of the parent's batched fetch (see
  // useChecklistDocuments above) -- no longer fetched by this component
  // itself, so N items on one page cost one request, not N.
  documents: RequestDocumentOut[];
  // Re-runs that same batched fetch -- called after this instance uploads or
  // deletes evidence, so every other instance on the page (and this one)
  // picks up the change too.
  onReload: () => Promise<void> | void;
  // Whether this checklist item's own checkbox is currently ticked --
  // reported directly, matching the pre-raise wizard's
  // ChecklistEvidencePicker (see that component's own `checked` prop):
  // attaching evidence for an item that isn't declared "in place" yet
  // doesn't make sense, so new evidence can't be attached until it's
  // checked. Already-saved evidence (e.g. attached while checked, then the
  // box got unticked again) stays visible/deletable regardless -- only
  // adding NEW evidence is blocked. Defaults to true so every pre-existing
  // call site that hasn't been updated to pass it keeps working exactly as
  // before (never blocked on this).
  checked?: boolean;
}) {
  const { user } = useAuth();
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [pendingDelete, setPendingDelete] = useState<RequestDocumentOut | null>(null);

  const endpoint = `${apiBase}/${reqId}/checklist/${itemId}/documents`;

  useEffect(() => {
    onCountChange?.(documents.length);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [documents.length]);

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    setError(null);
    try {
      await api.uploadFiles(endpoint, files);
      await onReload();
    } catch (err) {
      setError(err);
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  async function deleteDocument() {
    if (!pendingDelete) return;
    setBusy(true);
    setError(null);
    try {
      await api.del(`${endpoint}/${pendingDelete.id}`);
      setPendingDelete(null);
      await onReload();
    } catch (err) {
      // Never leave the confirmation and error dialogs mounted together.
      // The error dialog becomes the single active layer.
      setPendingDelete(null);
      setError(err);
    } finally {
      setBusy(false);
    }
  }

  return (
    // Plain 230/200px box by default (matches every existing call site);
    // inside the wizard-style .security-checklist-row grid table (see the 4
    // modules' edit-mode checklists in Functional/SAST/DAST/Performance.tsx,
    // and QARequests/steps/ReadinessChecklistSection.tsx's own
    // .checklist-evidence-picker, same idea) a scoped override in index.css
    // instead stretches/centers this to match that row's "Supporting
    // evidence" column exactly -- reported directly: "On edit details it
    // should be like while creating the request."
    <div className="checklist-evidence-cell supporting-evidence-control">
      {/* Same checklist-evidence-actions/-files/-file classes
          ChecklistEvidencePicker.tsx uses (index.css) instead of inline
          styles -- reported directly: "Font style and all should be same as
          qa request readiness checklist." A base rule keeps this row
          centered (matching every existing call site, e.g. the read-only
          Checklist tab, unchanged); the .security-checklist-row-scoped
          override below matches the wizard's own left-aligned, smaller
          button/badge sizing exactly, same as
          ChecklistEvidencePicker gets from .security-request-step. */}
      <input
        ref={inputRef}
        type="file"
        multiple
        hidden
        onChange={(e) => upload(e.target.files)}
      />
      <SupportingEvidenceControl
        canAttach={canManage}
        attachDisabled={!checked}
        attachBusy={busy}
        onAttach={() => inputRef.current?.click()}
        totalFiles={documents.length}
        required={required}
      >
          {documents.map((document) => (
            <ChecklistEvidenceFileRow
              key={document.id}
              fileName={document.file_name}
              onDownload={() => api.downloadFile(`${endpoint}/${document.id}/download`, document.file_name)}
              onDelete={
                canDeleteWorkflowDocument(user, document.uploaded_by_id, canManage)
                  ? () => setPendingDelete(document)
                  : undefined
              }
            />
          ))}
      </SupportingEvidenceControl>
      <ErrorText error={error} />
      {pendingDelete && (
        <ChecklistEvidenceDeleteModal
          fileName={pendingDelete.file_name}
          busy={busy}
          onConfirm={deleteDocument}
          onCancel={() => setPendingDelete(null)}
        />
      )}
    </div>
  );
}
