import React, { useEffect, useRef, useState } from 'react'
import { IconSearch, IconStar } from './Icons'
import { computePanelPos, PanelPos } from './panelPosition'
import ClearableSearchInput from './ClearableSearchInput'
import { isKeyboardActivationKey } from '../keyboard'

export interface SearchableSelectOption {
  value: string
  label: string
  disabled?: boolean
  onDisabledSelect?: () => void
}

interface SearchableSelectProps {
  value: string
  onChange: (value: string) => void
  ariaLabel?: string
  // Either a flat list of strings (value and label are the same -- e.g.
  // Department) or {value, label} pairs for anything id-keyed (e.g. a
  // Test Project/Folder picker, where the option's real value is a numeric
  // id but the label shown/searched is its name) or that needs a sentinel
  // entry alongside real rows (e.g. "-- Top level --" / "No change" at
  // value ''/'unchanged', same as a plain <option value="..."> would be).
  options: string[] | SearchableSelectOption[]
  placeholder?: string
  disabled?: boolean
  // Short, fixed enums should use the same portal dropdown panel without a
  // redundant search input. Growing lists keep search enabled by default.
  searchable?: boolean
  // Open and focus the suggestion panel as soon as the control mounts. This
  // is used by the shared Table column-filter popover: clicking the filter
  // icon should take the user directly to searchable suggestions rather than
  // requiring a second click on another dropdown trigger.
  autoOpen?: boolean
  // Optional favorite controls for large, frequently-used option sets.
  // Favorites are displayed first while the caller owns persistence.
  favoriteValues?: ReadonlySet<string>
  favoriteGroupLabel?: string
  optionsGroupLabel?: string
  searchPlaceholder?: string
  // Passed through to the root wrapper -- e.g. a toolbar dropdown that
  // isn't already inside a width-constraining Field wrapper (native
  // <select>s in the same spot would otherwise just size to content too,
  // but this component's trigger is `width: 100%` of its own wrapper, which
  // has no intrinsic width of its own in a plain flex row).
  style?: React.CSSProperties
}

function normalize(options: string[] | SearchableSelectOption[]): SearchableSelectOption[] {
  return options.map((o) => (typeof o === 'string' ? { value: o, label: o } : o))
}

// Single-select dropdown with an inline search box for filtering long,
// growing option lists (Application Name, Department, Test Project/Folder
// pickers, etc.) -- reusable anywhere a plain <select> would otherwise need
// dozens of <option>s that only get harder to scan as more get added.
// Short, fixed-size enums (Priority, Risk, Status, Environment and the like)
// use `searchable={false}` so they keep this same visual and interaction
// pattern without displaying an unnecessary search field.
export default function SearchableSelect({ value, onChange, options, ariaLabel, placeholder, disabled, searchable = true, autoOpen = false, favoriteValues, favoriteGroupLabel = 'Favorites', optionsGroupLabel = 'All options', searchPlaceholder = 'Search...', style }: SearchableSelectProps) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [panelPos, setPanelPos] = useState<PanelPos>({ top: 0, bottom: 'auto', left: 0, width: 0 })
  const rootRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setOpen(false)
        setQuery('')
      }
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [])

  useEffect(() => {
    if (open && searchable) inputRef.current?.focus()
  }, [open, searchable])

  useEffect(() => {
    if (!autoOpen || disabled) return
    // Wait until the mounted trigger has a measurable viewport rectangle.
    const frame = window.requestAnimationFrame(() => {
      const rect = triggerRef.current?.getBoundingClientRect()
      if (rect) setPanelPos(computePanelPos(rect))
      setOpen(true)
    })
    return () => window.cancelAnimationFrame(frame)
  }, [autoOpen, disabled])

  // Reported bug: position:fixed (see toggleOpen below) is only computed
  // once, at the moment the panel opens -- so scrolling the page (or any
  // scrollable ancestor) afterward leaves the panel stranded at its
  // original on-screen spot while the trigger itself moves out from under
  // it, instead of following along. Recompute the same rect on every
  // scroll/resize while the panel is open so it stays glued to its trigger.
  // `{ capture: true }` on the scroll listener is required to catch
  // scrolling of a nested scrollable ancestor (e.g. `.table-wrap`) too --
  // scroll events don't bubble, but they do fire during the capture phase.
  useEffect(() => {
    if (!open) return
    function reposition() {
      const rect = triggerRef.current?.getBoundingClientRect()
      if (rect) setPanelPos(computePanelPos(rect))
    }
    window.addEventListener('scroll', reposition, true)
    window.addEventListener('resize', reposition)
    return () => {
      window.removeEventListener('scroll', reposition, true)
      window.removeEventListener('resize', reposition)
    }
  }, [open])

  const opts = normalize(options)
  const current = opts.find((o) => o.value === value)
  const filtered = searchable
    ? opts.filter((o) => o.label.toLowerCase().includes(query.toLowerCase()))
    : opts
  const hasFavoriteGrouping = favoriteValues !== undefined
  const favoriteOptions = hasFavoriteGrouping
    ? filtered.filter((option) => favoriteValues?.has(option.value))
    : []
  const regularOptions = hasFavoriteGrouping
    ? filtered.filter((option) => !favoriteValues?.has(option.value))
    : filtered

  function select(opt: SearchableSelectOption) {
    if (opt.disabled) opt.onDisabledSelect?.()
    else onChange(opt.value)
    setOpen(false)
    setQuery('')
  }

  function renderOption(opt: SearchableSelectOption) {
    const active = opt.value === value
    const favorite = Boolean(favoriteValues?.has(opt.value))
    return (
      <div
        key={opt.value}
        className={`searchable-select-option ${active ? 'active' : ''} ${opt.disabled ? 'disabled' : ''}`}
        role="option"
        aria-selected={active}
        aria-disabled={opt.disabled || undefined}
        tabIndex={0}
        onClick={() => select(opt)}
        onKeyDown={(event) => {
          if (isKeyboardActivationKey(event.key)) { event.preventDefault(); select(opt) }
          if (event.key === 'Escape') { setOpen(false); triggerRef.current?.focus() }
        }}
      >
        <span className="searchable-select-option-content">
          {favorite && <IconStar className="searchable-select-option-star" aria-hidden="true" />}
          <span>{opt.label}</span>
        </span>
      </div>
    )
  }

  // Reported bug: when this control sits inside a scroll container that
  // clips overflow (e.g. the Admin Users table's own `.table-wrap`, which is
  // `overflow-y: hidden` so its rounded corners stay crisp -- see
  // index.css), the panel's normal `position: absolute` (nested under this
  // trigger) got visually cut off at the container's own edge, hiding most
  // of the option list. Fixed the same way `.th-filter-popover` already
  // solves this identical problem for the table's own column-filter
  // popovers (see index.css's comment there): compute the trigger's own
  // on-screen position via getBoundingClientRect() at open-time and render
  // the panel with `position: fixed` at those exact coordinates instead --
  // that escapes every ancestor's overflow clipping entirely, regardless of
  // where this control is used.
  function toggleOpen() {
    if (open) { setOpen(false); return }
    const rect = triggerRef.current?.getBoundingClientRect()
    if (rect) setPanelPos(computePanelPos(rect))
    setOpen(true)
  }

  return (
    <div className="searchable-select" ref={rootRef} style={style}>
      <button
        ref={triggerRef}
        type="button"
        className="searchable-select-trigger"
        aria-label={ariaLabel || placeholder || 'Select option'}
        aria-expanded={open}
        title={current?.label}
        disabled={disabled}
        onClick={toggleOpen}
      >
        <span className={`searchable-select-trigger-value ${current ? '' : 'muted'}`}>
          {current && favoriteValues?.has(current.value) && <IconStar className="searchable-select-trigger-star" aria-hidden="true" />}
          <span>{current ? current.label : (placeholder || 'Select...')}</span>
        </span>
        <span className="caret">&#9662;</span>
      </button>
      {open && (
        <div
          className="searchable-select-panel searchable-select-panel-fixed"
          style={{ top: panelPos.top, bottom: panelPos.bottom, left: panelPos.left, width: panelPos.width }}
        >
          {searchable && (
            <div className="searchable-select-search">
              <IconSearch width={13} height={13} />
              <ClearableSearchInput
                ref={inputRef}
                placeholder={searchPlaceholder}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onClear={() => setQuery('')}
                clearLabel="Clear option search"
              />
            </div>
          )}
          <div className="searchable-select-list" role="listbox" aria-label={ariaLabel || placeholder || 'Options'}>
            {filtered.length === 0 && <div className="searchable-select-empty">No matches</div>}
            {favoriteOptions.length > 0 && <div className="searchable-select-group-label" role="presentation">{favoriteGroupLabel}</div>}
            {favoriteOptions.map(renderOption)}
            {regularOptions.length > 0 && hasFavoriteGrouping && <div className="searchable-select-group-label" role="presentation">{optionsGroupLabel}</div>}
            {regularOptions.map(renderOption)}
          </div>
        </div>
      )}
    </div>
  )
}
