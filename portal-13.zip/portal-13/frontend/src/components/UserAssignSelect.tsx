import React from 'react'
import UserPicker, { PickerUser } from './UserPicker'

interface UserAssignSelectProps {
  value: string
  onChange: (value: string) => void
  users: PickerUser[]
  placeholder: string
  disabled?: boolean
  style?: React.CSSProperties
  showRoles?: boolean
  showUserId?: boolean
  variant?: 'default' | 'coordinator'
  clearable?: boolean
  clearLabel?: string
  ariaLabel?: string
}

/** Single-value adapter for the shared UserPicker. */
export default function UserAssignSelect(props: UserAssignSelectProps) {
  return <UserPicker {...props} showRoles={props.showRoles ?? true} onChange={(value) => props.onChange(value as string)} />
}
