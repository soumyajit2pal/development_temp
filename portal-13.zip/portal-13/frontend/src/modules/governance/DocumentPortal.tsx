import React, {
  ChangeEvent,
  DragEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { api } from "../../api";
import { Card, ErrorText, Modal, PageHeader, WarningNotice } from "../../components/Common";
import ConfirmModal from "../../components/ConfirmModal";
import InfoModal from "../../components/InfoModal";
import { IconContract, IconExpand } from "../../components/Icons";
import { useAuth } from "../../context/AuthContext";
import AppVersion from "../../components/AppVersion";
import { createLatestRequestGate } from "../../latestRequest";
import { formatDateTimeIST } from "../../time";

type Sort = "name" | "type" | "size" | "modified";
type Item = {
  name: string;
  path: string;
  is_folder: boolean;
  size: number;
  modified_at: string;
  extension: string;
};
type Folder = Pick<Item, "name" | "path">;
type Browse = {
  path: string;
  items: Item[];
  folders: Folder[];
  breadcrumbs: { name: string; path: string }[];
  stats: { folders: number; files: number; used: number; free: number } | null;
  upload_capacity: number;
  workspace_name: string;
  storage_limit_bytes: number | null;
  family_storage_limit_bytes: number | null;
  family_storage_used_bytes: number;
  parent_storage_limit_bytes: number | null;
  repository_path: string;
};
type UploadState = "ready" | "uploading" | "success" | "error";
type Upload = {
  id: string;
  file: File;
  relativePath: string;
  loaded: number;
  state: UploadState;
  message?: string;
};

const CONTRIBUTOR_ROLES = [
  "ADMIN",
  "DOCUMENT_PORTAL_CONTRIBUTOR",
  "DOCUMENT_PORTAL_MANAGER",
];
const MANAGER_ROLE = "DOCUMENT_PORTAL_MANAGER";
const bytes = (value: number) => {
  if (!Number.isFinite(value) || value < 0) return "—";
  if (value === 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const index = Math.min(
    Math.floor(Math.log(value) / Math.log(1024)),
    units.length - 1,
  );
  return `${(value / 1024 ** index).toFixed(index ? 1 : 0)} ${units[index]}`;
};
const itemName = (value: string) =>
  value.split("/").filter(Boolean).pop() || "Document Portal";
const parent = (value: string) => {
  const parts = value.split("/").filter(Boolean);
  parts.pop();
  return parts.join("/");
};
const timestamp = formatDateTimeIST;

function FolderTree({
  folders,
  active,
  expanded,
  toggle,
  open,
}: {
  folders: Folder[];
  active: string;
  expanded: Set<string>;
  toggle: (path: string) => void;
  open: (path: string) => void;
}) {
  const [isClosed, setIsClosed] = useState(false);
  const tree = useMemo(
    () =>
      folders.reduce<Record<string, Folder[]>>((out, folder) => {
        (out[parent(folder.path)] ||= []).push(folder);
        return out;
      }, {}),
    [folders],
  );
  Object.values(tree).forEach((items) =>
    items.sort((a, b) => a.name.localeCompare(b.name)),
  );
  const branch = (path: string, depth: number): React.ReactNode =>
    (tree[path] || []).map((folder) => {
      const children = tree[folder.path] || [];
      const isOpen =
        expanded.has(folder.path) ||
        active === folder.path ||
        active.startsWith(`${folder.path}/`);
      return (
        <React.Fragment key={folder.path}>
          <div
            className={`document-tree-row ${active === folder.path ? "active" : ""}`}
            style={{ paddingLeft: 10 + depth * 16 }}
          >
            {children.length ? (
              <button
                className="document-tree-toggle"
                type="button"
                onClick={() => toggle(folder.path)}
                aria-label={`${isOpen ? "Collapse" : "Expand"} ${folder.name}`}
              >
                {isOpen ? "⌄" : "›"}
              </button>
            ) : (
              <span className="document-tree-spacer" />
            )}
            <button type="button" onClick={() => open(folder.path)}>
              <span>▰</span>
              {folder.name}
            </button>
          </div>
          {children.length > 0 && isOpen
            ? branch(folder.path, depth + 1)
            : null}
        </React.Fragment>
      );
    });
  if (isClosed)
    return (
      <aside className="document-tree collapsed">
        <button
          className="document-tree-reopen"
          type="button"
          onClick={() => setIsClosed(false)}
          aria-label="Open folder structure"
          title="Open folder structure"
        >
          ☰
        </button>
      </aside>
    );
  return (
    <aside className="document-tree">
      <header>
        <div>
          <small>Repository</small>
          <strong>Folder structure</strong>
        </div>
        <div className="document-tree-head-actions">
          <span>{folders.length} folders</span>
          <button
            className="document-tree-close"
            type="button"
            onClick={() => setIsClosed(true)}
            aria-label="Close folder structure"
            title="Close folder structure"
          >
            ×
          </button>
        </div>
      </header>
      <div className={`document-tree-row root ${!active ? "active" : ""}`}>
        <button
          className="document-tree-toggle"
          type="button"
          onClick={() => toggle("")}
          aria-label="Toggle root folders"
        >
          {expanded.has("") ? "⌄" : "›"}
        </button>
        <button type="button" onClick={() => open("")}>
          <span>⌂</span>Document Portal
        </button>
      </div>
      {expanded.has("") && branch("", 0)}
      {!folders.length && (
        <p className="document-tree-empty">No folders yet.</p>
      )}
    </aside>
  );
}

function DocumentGovernanceGuide() {
  return (
    <div className="document-guide">
      <div className="document-guide-intro">
        <span aria-hidden="true">✓</span>
        <div>
          <strong>Keep document data clean and audit-ready</strong>
          <p>
            Create one top-level folder for each change request, then place
            every artefact in the correct category.
          </p>
        </div>
      </div>
      <div className="document-guide-structure">
        <small>Recommended folder structure</small>
        <div className="document-guide-root">
          <span aria-hidden="true">▰</span>
          <div>
            <strong>CR-NUMBER</strong>
            <small>For example: CR-12345</small>
          </div>
        </div>
        <div className="document-guide-branches">
          <code>Execution Evidence</code>
          <code>Test Cases</code>
          <code>TCS Sign-off Certificates</code>
          <code>Etc.</code>
        </div>
      </div>
      <ul className="document-guide-rules">
        <li>Do not upload files directly at the repository root.</li>
        <li>Use clear file names containing a date or version.</li>
        <li>Avoid duplicate, temporary, and draft files.</li>
      </ul>
    </div>
  );
}

function DocumentFullscreenCredit() {
  return (
    <footer className="document-fullscreen-credit">
      <span>Developed by</span>
      <strong>Soumyajit Pal</strong>
      <span>·</span>
      <span>Quality Assurance Department - IT</span>
      <span>·</span>
      <span>© 2026 All rights reserved.</span>
      <AppVersion />
    </footer>
  );
}

export default function DocumentPortal() {
  const { user } = useAuth();
  const canContribute = !!user?.roles.some((role) =>
    CONTRIBUTOR_ROLES.includes(role),
  );
  const canDelete = !!user?.roles.includes(MANAGER_ROLE);
  const [data, setData] = useState<Browse | null>(null);
  const [path, setPath] = useState("");
  const [sort, setSort] = useState<Sort>("name");
  const [order, setOrder] = useState<"asc" | "desc">("asc");
  const [query, setQuery] = useState("");
  const [searchItems, setSearchItems] = useState<Item[] | null>(null);
  const [searchTruncated, setSearchTruncated] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [expanded, setExpanded] = useState<Set<string>>(new Set([""]));
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState("");
  const contentRequests = useRef(createLatestRequestGate()).current;
  const [downloadStatus, setDownloadStatus] = useState("");
  const [dialog, setDialog] = useState<
    "folder" | "upload" | "rename" | "move" | null
  >(null);
  const [activeItem, setActiveItem] = useState<Item | null>(null);
  const [pendingDelete, setPendingDelete] = useState<Item[] | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [folderName, setFolderName] = useState("");
  const [newName, setNewName] = useState("");
  const [destination, setDestination] = useState("");
  const [duplicate, setDuplicate] = useState<"keep" | "replace" | "cancel">(
    "keep",
  );
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [uploadSummary, setUploadSummary] = useState<{
    success: number;
    failed: number;
  } | null>(null);
  const [confirmUpload, setConfirmUpload] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<unknown>(null);
  const [showFolderGuide, setShowFolderGuide] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(true);
  const fileInput = useRef<HTMLInputElement>(null);
  const folderInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    folderInput.current?.setAttribute("webkitdirectory", "");
    folderInput.current?.setAttribute("directory", "");
  }, [dialog]);
  useEffect(() => {
    if (!isUploading) return;
    const lockedUrl = window.location.href;
    const guardId = `document-upload-${Date.now()}`;
    const guardState = {
      ...(window.history.state || {}),
      documentPortalUploadGuard: guardId,
    };
    const warnBeforeLeaving = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };
    const blockHistoryNavigation = () => {
      // A same-URL sentinel means Back first lands on the entry immediately
      // beneath this one, without leaving the route. Re-install it so Back
      // and Forward remain unavailable until the batch finishes.
      window.history.pushState(guardState, "", lockedUrl);
    };
    const blockAppNavigation = (event: MouseEvent) => {
      const target = event.target;
      if (target instanceof Element && target.closest("a[href]")) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    };
    const blockRefreshShortcut = (event: KeyboardEvent) => {
      const refreshKey = event.key === "F5" ||
        ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "r");
      if (refreshKey) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    };

    window.history.pushState(guardState, "", lockedUrl);
    window.addEventListener("beforeunload", warnBeforeLeaving);
    window.addEventListener("popstate", blockHistoryNavigation);
    document.addEventListener("click", blockAppNavigation, true);
    document.addEventListener("keydown", blockRefreshShortcut, true);
    return () => {
      window.removeEventListener("beforeunload", warnBeforeLeaving);
      window.removeEventListener("popstate", blockHistoryNavigation);
      document.removeEventListener("click", blockAppNavigation, true);
      document.removeEventListener("keydown", blockRefreshShortcut, true);
      // Remove the same-URL sentinel after the upload completes so it does
      // not add a redundant Back step to the user's later navigation.
      if (window.history.state?.documentPortalUploadGuard === guardId) {
        window.history.back();
      }
    };
  }, [isUploading]);
  useEffect(() => {
    if (!isFullscreen) return;
    const wasScrollLocked = document.body.classList.contains("qap-scroll-locked");
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !dialog && !showFolderGuide)
        setIsFullscreen(false);
    };
    document.body.classList.add("qap-scroll-locked");
    window.addEventListener("keydown", closeOnEscape);
    return () => {
      if (!wasScrollLocked) document.body.classList.remove("qap-scroll-locked");
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [isFullscreen, dialog, showFolderGuide]);
  const load = useCallback(
    async (
      nextPath = path,
      nextSort = sort,
      nextOrder = order,
      showGlobalActivity = true,
    ) => {
      const generation = contentRequests.begin();
      setBusy("Loading documents…");
      setError(null);
      try {
        const requestPath = `/api/document-portal?${new URLSearchParams({ path: nextPath, sort: nextSort, order: nextOrder })}`;
        const response = showGlobalActivity
          ? await api.get<Browse>(requestPath)
          : await api.getWithoutActivity<Browse>(requestPath);
        if (contentRequests.isCurrent(generation)) {
          setData(response);
          setPath(response.path);
          setSelected(new Set());
        }
      } catch (caught) {
        if (contentRequests.isCurrent(generation)) setError(caught);
      } finally {
        if (contentRequests.isCurrent(generation)) setBusy("");
      }
    },
    [path, sort, order, contentRequests],
  );
  useEffect(() => {
    void load("", sort, order);
  }, []);
  useEffect(() => {
    setExpanded((current) => {
      const next = new Set(current);
      next.add("");
      const pieces = path.split("/").filter(Boolean);
      for (let i = 1; i <= pieces.length; i += 1)
        next.add(pieces.slice(0, i).join("/"));
      return next;
    });
  }, [path]);
  const openFolder = async (nextPath: string) => {
    setSearchItems(null);
    setSearchTruncated(false);
    setQuery("");
    await load(nextPath);
  };
  const toggleTree = (nextPath: string) =>
    setExpanded((current) => {
      const next = new Set(current);
      next.has(nextPath) ? next.delete(nextPath) : next.add(nextPath);
      return next;
    });
  const closeDialog = () => {
    if (isUploading) return;
    setConfirmUpload(false);
    setDialog(null);
    setActiveItem(null);
    setFolderName("");
    setNewName("");
    setDestination("");
    setUploads([]);
    setUploadSummary(null);
    setUploadError(null);
  };

  async function search(event?: React.FormEvent) {
    event?.preventDefault();
    if (!query.trim()) {
      contentRequests.invalidate();
      setSearchItems(null);
      return;
    }
    const generation = contentRequests.begin();
    setBusy("Searching documents…");
    setError(null);
    setSelected(new Set());
    try {
      const response = await api.get<{ items: Item[]; truncated?: boolean }>(
        `/api/document-portal/search?q=${encodeURIComponent(query)}`,
      );
      if (contentRequests.isCurrent(generation)) {
        setSearchItems(response.items);
        setSearchTruncated(!!response.truncated);
      }
    } catch (caught) {
      if (contentRequests.isCurrent(generation)) setError(caught);
    } finally {
      if (contentRequests.isCurrent(generation)) setBusy("");
    }
  }
  async function createFolder() {
    if (!folderName.trim()) return;
    setBusy("Creating folder…");
    try {
      await api.post("/api/document-portal/folders", {
        path,
        name: folderName,
      });
      closeDialog();
      await load(path);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy("");
    }
  }
  const addFiles = (files: File[], paths?: string[]) => {
    setUploadSummary(null);
    setUploadError(null);
    setUploads((current) => [
      ...current,
      ...files.map((file, index) => ({
        id: `${Date.now()}-${current.length + index}-${file.name}`,
        file,
        relativePath:
          paths?.[index] ||
          (file as File & { webkitRelativePath?: string }).webkitRelativePath ||
          file.name,
        loaded: 0,
        state: "ready" as const,
      })),
    ]);
  };
  const removeUpload = (id: string) => {
    setUploadSummary(null);
    setUploadError(null);
    setUploads((current) =>
      current.filter(
        (upload) =>
          upload.id !== id ||
          upload.state === "uploading" ||
          upload.state === "success",
      ),
    );
  };
  async function addDropped(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    const entries = Array.from(event.dataTransfer.items || [])
      .map((item) => (item as any).webkitGetAsEntry?.())
      .filter(Boolean);
    if (!entries.length) {
      addFiles(Array.from(event.dataTransfer.files));
      return;
    }
    const walk = async (
      entry: any,
      prefix = "",
    ): Promise<{ file: File; path: string }[]> => {
      if (entry.isFile)
        return new Promise((resolve, reject) =>
          entry.file(
            (file: File) => resolve([{ file, path: `${prefix}${file.name}` }]),
            reject,
          ),
        );
      if (!entry.isDirectory) return [];
      const reader = entry.createReader();
      const children: any[] = [];
      for (;;) {
        const batch: any[] = await new Promise((resolve, reject) =>
          reader.readEntries(resolve, reject),
        );
        if (!batch.length) break;
        children.push(...batch);
      }
      return (
        await Promise.all(
          children.map((child) => walk(child, `${prefix}${entry.name}/`)),
        )
      ).flat();
    };
    try {
      const values = (
        await Promise.all(entries.map((entry) => walk(entry)))
      ).flat();
      addFiles(
        values.map((value) => value.file),
        values.map((value) => value.path),
      );
    } catch {
      setError(
        new Error(
          "Some dropped files could not be read. Use the file or folder picker instead.",
        ),
      );
    }
  }
  async function uploadDocuments() {
    const queue = uploads.filter((upload) => upload.state !== "success");
    if (!queue.length || isUploading) return;
    const requestedBytes = queue.reduce(
      (total, upload) => total + upload.file.size,
      0,
    );
    if (!data || requestedBytes > data.upload_capacity) {
      setUploadError(
        new Error(
          `The selected content requires ${bytes(requestedBytes)}, but only ${bytes(data?.upload_capacity || 0)} is available for uploads. Remove files or free repository storage, then try again.`,
        ),
      );
      return;
    }
    setUploadError(null);
    try {
      await api.postWithoutActivity(
        `/api/document-portal/upload/validate?path=${encodeURIComponent(path)}`,
        { total_size: requestedBytes, file_count: queue.length },
      );
    } catch (caught) {
      setUploadError(caught);
      return;
    }

    setIsUploading(true);
    let success = 0;
    let failed = 0;
    const outcomes = new Map<
      string,
      { state: "success" | "error"; message: string }
    >();
    try {
      for (const upload of queue) {
        setUploads((current) =>
          current.map((row) =>
            row.id === upload.id
              ? { ...row, state: "uploading", message: "Uploading…", loaded: 0 }
              : row,
          ),
        );
        try {
          await api.uploadFormWithProgress(
            "/api/document-portal/upload",
            {
              path,
              relative_path: upload.relativePath,
              duplicate,
              file: upload.file,
            },
            (loaded, total) =>
              setUploads((current) =>
                current.map((row) =>
                  row.id === upload.id
                    ? {
                        ...row,
                        loaded: total
                          ? Math.round((loaded / total) * row.file.size)
                          : loaded,
                      }
                    : row,
                ),
              ),
          );
          success += 1;
          outcomes.set(upload.id, { state: "success", message: "Uploaded" });
          setUploads((current) =>
            current.map((row) =>
              row.id === upload.id
                ? {
                    ...row,
                    state: "success",
                    message: "Uploaded",
                    loaded: row.file.size,
                  }
                : row,
            ),
          );
        } catch (caught) {
          failed += 1;
          const failureMessage =
            caught instanceof Error ? caught.message : "Upload failed";
          outcomes.set(upload.id, {
            state: "error",
            message: failureMessage,
          });
          setUploads((current) =>
            current.map((row) =>
              row.id === upload.id
                ? {
                    ...row,
                    state: "error",
                    message: failureMessage,
                    // xhr upload progress can reach 100% before the server
                    // rejects the file. A failed row must not retain that
                    // transfer percentage as if it had been accepted.
                    loaded: 0,
                  }
                : row,
            ),
          );
        }
      }
      // Keep the modal's upload status as the only progress UI while the
      // refreshed repository contents are fetched after the batch.
      if (success) await load(path, sort, order, false);
      // Final reconciliation keeps the visible row state and the summary in
      // lockstep even when several quick XHR callbacks were React-batched.
      setUploads((current) =>
        current.map((row) => {
          const outcome = outcomes.get(row.id);
          return outcome
            ? {
                ...row,
                state: outcome.state,
                message: outcome.message,
                loaded: outcome.state === "success" ? row.file.size : 0,
              }
            : row;
        }),
      );
      setUploadSummary({ success, failed });
    } finally {
      setIsUploading(false);
    }
  }
  async function rename() {
    if (!activeItem || !newName.trim()) return;
    setBusy("Renaming document…");
    try {
      await api.post("/api/document-portal/items/rename", {
        path: activeItem.path,
        name: newName,
      });
      closeDialog();
      await load(path);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy("");
    }
  }
  async function move() {
    if (!activeItem) return;
    setBusy("Moving document…");
    try {
      await api.post("/api/document-portal/items/move", {
        path: activeItem.path,
        destination,
      });
      closeDialog();
      await load(path);
    } catch (caught) {
      setError(caught);
    } finally {
      setBusy("");
    }
  }
  async function deleteItem() {
    if (!pendingDelete) return;
    setDeleteBusy(true);
    setError(null);
    try {
      const result = await api.post<{ deleted: string[]; failed: string[] }>(
        "/api/document-portal/delete-selection",
        { current_path: path, paths: pendingDelete.map((item) => item.path) },
      );
      setPendingDelete(null);
      await load(path);
      if (result.failed.length) {
        setError(new Error(`Deleted ${result.deleted.length} item(s). Could not delete: ${result.failed.join(", ")}. Refresh and try again.`));
      }
    } catch (caught) {
      setError(caught);
    } finally {
      setDeleteBusy(false);
    }
  }
  async function download(url: string, filename: string) {
    setDownloadStatus("Preparing your download…");
    setError(null);
    try {
      await api.downloadFile(url, filename);
      setDownloadStatus(
        "Download started. Continue in your browser downloads if it does not open automatically.",
      );
    } catch (caught) {
      setError(caught);
      setDownloadStatus("");
    }
  }

  const visible = searchItems ?? data?.items ?? [];
  const isSearching = searchItems !== null;
  const allSelected = visible.length > 0 && selected.size === visible.length;
  const uploadTotal = uploads.reduce((sum, item) => sum + item.file.size, 0);
  const uploadLoaded = uploads.reduce((sum, item) => {
    if (item.state === "success") return sum + item.file.size;
    if (item.state === "uploading")
      return sum + Math.min(item.loaded, item.file.size);
    return sum;
  }, 0);
  const uploadPercent = uploadTotal
    ? Math.round((uploadLoaded / uploadTotal) * 100)
    : 0;
  const pendingUploadTotal = uploads
    .filter((upload) => upload.state !== "success")
    .reduce((sum, upload) => sum + upload.file.size, 0);
  const uploadExceedsCapacity = !!data && pendingUploadTotal > data.upload_capacity;
  const toggleSelect = (value: string) =>
    setSelected((current) => {
      const next = new Set(current);
      next.has(value) ? next.delete(value) : next.add(value);
      return next;
    });
  const selectAll = () =>
    setSelected(
      allSelected ? new Set() : new Set(visible.map((item) => item.path)),
    );
  const downloadOne = (item: Item) =>
    void download(
      item.is_folder
        ? `/api/document-portal/zip?path=${encodeURIComponent(item.path)}`
        : `/api/document-portal/download?path=${encodeURIComponent(item.path)}`,
      item.is_folder ? `${item.name}.zip` : item.name,
    );
  const downloadSelection = async () => {
    setDownloadStatus("Preparing selected items…");
    try {
      await api.downloadPost(
        "/api/document-portal/download-selection",
        { current_path: path, paths: [...selected] },
        selected.size === 1
          ? itemName([...selected][0])
          : `${itemName(path)}-selection.zip`,
      );
      setDownloadStatus(
        "Download started. Continue in your browser downloads if it does not open automatically.",
      );
    } catch (caught) {
      setError(caught);
      setDownloadStatus("");
    }
  };

  return (
    <div className="document-portal-page document-explorer-page">
      <PageHeader
        eyebrow="Workspace documents"
        title="Document Portal"
        subtitle="Files and folders in your active workspace. All timestamps use India Standard Time (IST)."
        actions={
          canContribute && data?.storage_limit_bytes != null ? (
            <>
              <button className="btn" onClick={() => setDialog("folder")}>
                New folder
              </button>
              <button
                className="btn btn-primary"
                onClick={() => setDialog("upload")}
              >
                Upload files
              </button>
            </>
          ) : undefined
        }
      />
      {data && data.storage_limit_bytes == null && <WarningNotice className="alert alert-warning" role="status">An administrator must set the Document Portal storage limit for {data.workspace_name} before files can be uploaded.</WarningNotice>}
      {data && data.storage_limit_bytes != null && data.family_storage_limit_bytes == null && <WarningNotice className="alert alert-warning" role="status">An administrator must set the parent workspace storage limit before files can be uploaded here.</WarningNotice>}
      <Card
        className={`document-portal-card${isFullscreen ? " document-portal-fullscreen" : ""}`}
      >
        <div className="document-mount">
          {isFullscreen && (
            <div className="document-fullscreen-brand" aria-label="QualityOps — Bank of Maharashtra">
              <img
                className="document-fullscreen-brand-logo"
                src="/qualityops-logo.png"
                alt=""
                aria-hidden="true"
              />
              <div>
                <b>
                  Quality<span>Ops</span>
                </b>
                <img
                  src="/bank-of-maharashtra-wordmark.png"
                  alt="Bank of Maharashtra"
                />
              </div>
            </div>
          )}
          <span className="document-library-icon">⌂</span>
          <strong>Mounted repository</strong>
          <code>{data?.repository_path || "Loading…"}</code>
          <button
            type="button"
            className="document-fullscreen-toggle"
            onClick={() => setIsFullscreen((current) => !current)}
            aria-label={
              isFullscreen
                ? "Exit full screen document library"
                : "Open document library full screen"
            }
            title={isFullscreen ? "Exit full screen (Esc)" : "Open full screen"}
          >
            {isFullscreen ? (
              <IconContract aria-hidden="true" />
            ) : (
              <IconExpand aria-hidden="true" />
            )}
            <span>{isFullscreen ? "Exit full screen" : "Full screen"}</span>
          </button>
          <span>{canDelete ? "Manager deletion enabled" : "Deletion restricted to Document Portal Managers"}</span>
        </div>
        <form
          className="document-portal-toolbar"
          onSubmit={(event) => void search(event)}
        >
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search documents and folders"
          />
          <button className="btn" type="submit">
            Search
          </button>
          {query && (
            <button
              className="btn"
              type="button"
              onClick={() => {
                setQuery("");
                setSearchItems(null);
                setSearchTruncated(false);
              }}
            >
              Clear
            </button>
          )}
          {!isSearching && (
            <>
              <label>
                Sort{" "}
                <select
                  value={`${sort}:${order}`}
                  onChange={(event) => {
                    const [nextSort, nextOrder] = event.target.value.split(
                      ":",
                    ) as [Sort, "asc" | "desc"];
                    setSort(nextSort);
                    setOrder(nextOrder);
                    void load(path, nextSort, nextOrder);
                  }}
                >
                  <option value="name:asc">Name A–Z</option>
                  <option value="name:desc">Name Z–A</option>
                  <option value="type:asc">Type</option>
                  <option value="size:asc">Size, smallest</option>
                  <option value="size:desc">Size, largest</option>
                  <option value="modified:desc">Recently modified</option>
                  <option value="modified:asc">Oldest modified</option>
                </select>
              </label>
              <button
                className="btn"
                type="button"
                onClick={() =>
                  void download(
                    `/api/document-portal/zip?path=${encodeURIComponent(path)}`,
                    `${itemName(path)}.zip`,
                  )
                }
              >
                Download ZIP
              </button>
            </>
          )}
          {selected.size > 0 && (
            <button
              className="btn btn-primary"
              type="button"
              onClick={() => void downloadSelection()}
            >
              Download selected ({selected.size})
            </button>
          )}
          {!isSearching && canDelete && selected.size > 0 && (
            <button
              className="btn btn-danger"
              type="button"
              disabled={deleteBusy}
              onClick={() => setPendingDelete(visible.filter((item) => selected.has(item.path)))}
            >
              Delete selected ({selected.size})
            </button>
          )}
        </form>
        {!isSearching && (!isFullscreen || !!path) && (
          <div className="document-breadcrumbs">
            {data?.breadcrumbs.map((crumb, index) => (
              <React.Fragment key={crumb.path || "home"}>
                {index > 0 && <span>/</span>}
                <button
                  type="button"
                  onClick={() => void openFolder(crumb.path)}
                >
                  {crumb.name}
                </button>
              </React.Fragment>
            ))}
          </div>
        )}
        {error ? <ErrorText error={error} /> : null}
        {busy && <p className="document-portal-status">{busy}</p>}
        {downloadStatus && (
          <div className="document-download-status">
            <strong>{downloadStatus}</strong>
            <span>
              Keep this page open while the browser receives the file.
            </span>
          </div>
        )}
        {!isSearching && data?.stats && (
          <div className="document-stats">
            <span>
              <strong>{data.stats.folders}</strong> folders
            </span>
            <span>
              <strong>{data.stats.files}</strong> files
            </span>
            <span>
              <strong>{bytes(data.stats.used)}</strong> used
            </span>
            {data.parent_storage_limit_bytes != null && <span>
              <strong>{bytes(data.family_storage_used_bytes)}</strong> used across parent and child workspaces of {bytes(data.parent_storage_limit_bytes)}
            </span>}
            {data.parent_storage_limit_bytes == null && data.family_storage_used_bytes !== data.stats.used && <span>
              <strong>{bytes(data.family_storage_used_bytes)}</strong> used across this workspace and its children
            </span>}
            <span>
              <strong>{bytes(data.stats.free)}</strong> available of {data.storage_limit_bytes == null ? 'limit not set' : bytes(data.storage_limit_bytes)}
            </span>
          </div>
        )}
        <div className="document-explorer-layout">
          <FolderTree
            folders={data?.folders || []}
            active={path}
            expanded={expanded}
            toggle={toggleTree}
            open={(nextPath) => void openFolder(nextPath)}
          />
          <section className="document-explorer-main">
            <header className="document-contents-head">
              <div>
                <small>{isSearching ? "Search" : "Contents"}</small>
                <h2>
                  {isSearching
                    ? `Results for “${query}”`
                    : path
                      ? itemName(path)
                      : "Document Portal"}
                </h2>
                <p>
                  {isSearching
                    ? `${visible.length}${searchTruncated ? "+" : ""} matching items`
                    : `${visible.filter((item) => item.is_folder).length} folders · ${visible.filter((item) => !item.is_folder).length} files`}
                </p>
              </div>
              <div className="document-contents-actions">
                <button
                  className="btn btn-small document-guide-button"
                  type="button"
                  onClick={() => setShowFolderGuide(true)}
                >
                  <span aria-hidden="true">ⓘ</span>
                  Folder guide
                </button>
                {!isSearching && (
                  <button
                    className="btn btn-small"
                    type="button"
                    onClick={() => void load(path)}
                  >
                    Refresh
                  </button>
                )}
              </div>
            </header>
            <div className="document-table-wrap">
              <table className="document-table">
                <thead>
                  <tr>
                    <th>
                      {!isSearching && (
                        <input
                          type="checkbox"
                          checked={allSelected}
                          onChange={selectAll}
                          aria-label="Select all"
                        />
                      )}
                    </th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Size</th>
                    <th>Modified (IST)</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((item) => (
                    <tr key={item.path}>
                      <td>
                        {!isSearching && (
                          <input
                            type="checkbox"
                            checked={selected.has(item.path)}
                            onChange={() => toggleSelect(item.path)}
                            aria-label={`Select ${item.name}`}
                          />
                        )}
                      </td>
                      <td>
                        <button
                          className="document-item-name"
                          type="button"
                          onClick={() =>
                            item.is_folder
                              ? void openFolder(item.path)
                              : downloadOne(item)
                          }
                        >
                          <span>{item.is_folder ? "▰" : "▤"}</span>
                          {item.name}
                        </button>
                        <small>{item.path}</small>
                      </td>
                      <td>
                        <span className="document-type-pill">
                          {item.extension}
                        </span>
                      </td>
                      <td>{item.is_folder ? "—" : bytes(item.size)}</td>
                      <td>{timestamp(item.modified_at)}</td>
                      <td className="document-actions">
                        {!item.is_folder && (
                          <button
                            type="button"
                            className="btn btn-small"
                            onClick={() => downloadOne(item)}
                          >
                            Download
                          </button>
                        )}
                        {!isSearching && canContribute && (
                          <>
                            <button
                              type="button"
                              className="btn btn-small"
                              onClick={() => {
                                setActiveItem(item);
                                setNewName(item.name);
                                setDialog("rename");
                              }}
                            >
                              Rename
                            </button>
                            <button
                              type="button"
                              className="btn btn-small"
                              onClick={() => {
                                setActiveItem(item);
                                setDestination("");
                                setDialog("move");
                              }}
                            >
                              Move
                            </button>
                          </>
                        )}
                        {!isSearching && canDelete && (
                          <button
                            type="button"
                            className="btn btn-small btn-danger"
                            onClick={() => setPendingDelete([item])}
                          >
                            Delete
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                  {!visible.length && (
                    <tr>
                      <td colSpan={6} className="document-empty">
                        {isSearching
                          ? "No documents or folders match this search."
                          : "This folder is empty. Create a folder or upload files to get started."}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </div>
        {isFullscreen && <DocumentFullscreenCredit />}
      </Card>
      {showFolderGuide && (
        <InfoModal
          title="Folder convention & data hygiene"
          onClose={() => setShowFolderGuide(false)}
        >
          <DocumentGovernanceGuide />
        </InfoModal>
      )}
      {dialog === "folder" && (
        <Modal title="New folder" onClose={closeDialog} variant="dialog">
          <div className="document-dialog">
            <label>
              Folder name
              <input
                autoFocus
                value={folderName}
                onChange={(event) => setFolderName(event.target.value)}
              />
            </label>
            <div className="modal-actions">
              <button className="btn" onClick={closeDialog}>
                Cancel
              </button>
              <button
                className="btn btn-primary"
                disabled={!folderName.trim() || !!busy}
                onClick={() => void createFolder()}
              >
                Create folder
              </button>
            </div>
          </div>
        </Modal>
      )}
      {dialog === "upload" && (
        <Modal
          title="Upload files or a folder"
          onClose={closeDialog}
          variant="dialog"
          wide
          preventBackdropClose={isUploading}
          closeDisabled={isUploading}
        >
          <div className="document-dialog">
            {isUploading && (
              <div className="document-upload-active" role="status" aria-live="assertive">
                <span className="document-upload-spinner" aria-hidden="true" />
                <div>
                  <strong>Upload in progress — please wait</strong>
                  <span>Do not close or refresh this page until every file has finished uploading.</span>
                </div>
              </div>
            )}
            <p className="muted">
              Drag files or folders here, or choose them below. Folder hierarchy
              is preserved. The complete selection is checked against available
              repository storage before uploading begins.
            </p>
            <div
              className={`document-drop-zone${isUploading ? " disabled" : ""}`}
              onDragOver={(event) => {
                event.preventDefault();
                if (isUploading) event.dataTransfer.dropEffect = "none";
              }}
              onDrop={(event) => {
                event.preventDefault();
                if (!isUploading) void addDropped(event);
              }}
              onClick={() => !isUploading && fileInput.current?.click()}
              role="button"
              tabIndex={0}
              aria-disabled={isUploading}
            >
              <strong>⇧ Drop files or folders here</strong>
              <span>or select from your device</span>
            </div>
            <div className="document-upload-source">
              <label className="btn">
                Choose files
                <input
                  ref={fileInput}
                  type="file"
                  multiple
                  hidden
                  disabled={isUploading}
                  onChange={(event: ChangeEvent<HTMLInputElement>) => {
                    addFiles(Array.from(event.target.files || []));
                    event.currentTarget.value = "";
                  }}
                />
              </label>
              <label className="btn">
                Choose folder
                <input
                  ref={folderInput}
                  type="file"
                  multiple
                  hidden
                  disabled={isUploading}
                  onChange={(event: ChangeEvent<HTMLInputElement>) => {
                    addFiles(Array.from(event.target.files || []));
                    event.currentTarget.value = "";
                  }}
                />
              </label>
              <label>
                Duplicates{" "}
                <select
                  value={duplicate}
                  disabled={isUploading}
                  onChange={(event) =>
                    setDuplicate(event.target.value as typeof duplicate)
                  }
                >
                  <option value="keep">Keep both (add number)</option>
                  <option value="replace">Replace existing</option>
                  <option value="cancel">Skip and report duplicate</option>
                </select>
              </label>
            </div>
            {uploads.length > 0 && (
              <>
                <div className={`document-upload-capacity${uploadExceedsCapacity ? " error" : ""}`}>
                  <span>Selected content <strong>{bytes(pendingUploadTotal)}</strong></span>
                  <span>Available for upload <strong>{bytes(data?.upload_capacity || 0)}</strong></span>
                </div>
                {uploadExceedsCapacity && (
                  <p className="document-upload-capacity-message" role="alert">
                    The selected content is larger than the available repository storage. Remove files or free storage before uploading.
                  </p>
                )}
                <div className="document-upload-progress">
                  <div>
                    <strong>
                      {uploadSummary
                        ? uploadSummary.failed
                          ? "Upload result"
                          : "Upload completed"
                        : "Upload progress"}
                    </strong>
                    <span>
                      {uploadPercent}% · {bytes(uploadLoaded)} of{" "}
                      {bytes(uploadTotal)}
                    </span>
                  </div>
                  <progress value={uploadPercent} max="100" />
                  {uploadSummary?.failed ? (
                    <small className="document-upload-progress-note">
                      The percentage includes only files accepted by the server; failed files are not counted as uploaded.
                    </small>
                  ) : null}
                </div>
                <div className="document-upload-list">
                  {uploads.map((upload) => (
                    <div
                      className={`document-upload-row ${upload.state}`}
                      key={upload.id}
                    >
                      <span>
                        {upload.state === "success"
                          ? "✓"
                          : upload.state === "error"
                            ? "!"
                            : upload.state === "uploading"
                              ? "↑"
                              : "•"}
                      </span>
                      <div>
                        <strong>{upload.relativePath}</strong>
                        <small>
                          {upload.message ||
                            `${bytes(upload.file.size)} · Ready`}
                        </small>
                        <progress
                          value={
                            upload.file.size
                              ? Math.round(
                                  (upload.loaded / upload.file.size) * 100,
                                )
                              : 0
                          }
                          max="100"
                        />
                      </div>
                      <button
                        type="button"
                        className="document-upload-remove"
                        disabled={
                          upload.state === "uploading" ||
                          upload.state === "success"
                        }
                        onClick={() => removeUpload(upload.id)}
                        aria-label={`Remove ${upload.relativePath} from upload queue`}
                        title={
                          upload.state === "uploading"
                            ? "This file is currently uploading"
                            : upload.state === "success"
                              ? "This file has already been uploaded"
                              : "Remove from upload queue"
                        }
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              </>
            )}
            {uploadSummary && (
              <div
                className={`document-upload-summary ${uploadSummary.failed ? "partial" : "success"}`}
              >
                <strong>
                  {uploadSummary.failed
                    ? "Upload completed with issues"
                    : "Upload completed"}
                </strong>
                <span>
                  {uploadSummary.success} uploaded · {uploadSummary.failed}{" "}
                  failed
                </span>
              </div>
            )}
            {uploadError ? <ErrorText error={uploadError} title="Upload cannot start" /> : null}
            <div className="modal-actions">
              <button className="btn" disabled={isUploading} onClick={closeDialog}>
                {isUploading ? "Uploading…" : "Cancel"}
              </button>
              <button
                className="btn btn-primary"
                disabled={
                  isUploading ||
                  uploadExceedsCapacity ||
                  !uploads.some(
                    (upload) =>
                      upload.state === "ready" || upload.state === "error",
                  )
                }
                onClick={() => setConfirmUpload(true)}
              >
                Upload queued files
              </button>
            </div>
          </div>
        </Modal>
      )}
      {confirmUpload && (
        <ConfirmModal
          title={`Upload ${uploads.filter((upload) => upload.state !== "success").length} ${uploads.filter((upload) => upload.state !== "success").length === 1 ? "file" : "files"}?`}
          message={
            <div className="document-upload-confirmation">
              <p>
                The selected files will be uploaded to <strong>{path || "Document Portal"}</strong>.
              </p>
              <dl>
                <div>
                  <dt>Files</dt>
                  <dd>{uploads.filter((upload) => upload.state !== "success").length}</dd>
                </div>
                <div>
                  <dt>Total size</dt>
                  <dd>{bytes(uploads.filter((upload) => upload.state !== "success").reduce((total, upload) => total + upload.file.size, 0))}</dd>
                </div>
                <div>
                  <dt>Available</dt>
                  <dd>{bytes(data?.upload_capacity || 0)}</dd>
                </div>
                <div>
                  <dt>Duplicates</dt>
                  <dd>{duplicate === "keep" ? "Keep both" : duplicate === "replace" ? "Replace existing" : "Skip duplicate"}</dd>
                </div>
              </dl>
            </div>
          }
          confirmLabel="Upload files"
          cancelLabel="Review selection"
          onConfirm={() => {
            setConfirmUpload(false);
            void uploadDocuments();
          }}
          onCancel={() => setConfirmUpload(false)}
        />
      )}
      {dialog === "rename" && activeItem && (
        <Modal
          title={`Rename “${activeItem.name}”`}
          onClose={closeDialog}
          variant="dialog"
        >
          <div className="document-dialog">
            <label>
              New name
              <input
                autoFocus
                value={newName}
                onChange={(event) => setNewName(event.target.value)}
              />
            </label>
            <div className="modal-actions">
              <button className="btn" onClick={closeDialog}>
                Cancel
              </button>
              <button
                className="btn btn-primary"
                disabled={!newName.trim() || !!busy}
                onClick={() => void rename()}
              >
                Rename
              </button>
            </div>
          </div>
        </Modal>
      )}
      {dialog === "move" && activeItem && (
        <Modal
          title={`Move “${activeItem.name}”`}
          onClose={closeDialog}
          variant="dialog"
        >
          <div className="document-dialog">
            <label>
              Destination folder
              <select
                value={destination}
                onChange={(event) => setDestination(event.target.value)}
              >
                <option value="">Document Portal (root)</option>
                {data?.folders
                  .filter(
                    (folder) =>
                      folder.path !== activeItem.path &&
                      !folder.path.startsWith(`${activeItem.path}/`),
                  )
                  .map((folder) => (
                    <option key={folder.path} value={folder.path}>
                      {folder.path}
                    </option>
                  ))}
              </select>
            </label>
            <div className="modal-actions">
              <button className="btn" onClick={closeDialog}>
                Cancel
              </button>
              <button
                className="btn btn-primary"
                disabled={!!busy}
                onClick={() => void move()}
              >
                Move item
              </button>
            </div>
          </div>
        </Modal>
      )}
      {pendingDelete && (
        <ConfirmModal
          title={pendingDelete.length === 1 ? `Delete “${pendingDelete[0].name}”?` : `Delete ${pendingDelete.length} selected items?`}
          message={
            `Selected items: ${pendingDelete.map((item) => item.name).join(", ")}. These files and folders, including all documents and subfolders inside selected folders, will be permanently deleted.`
          }
          confirmLabel="Delete"
          cancelLabel="Cancel"
          busy={deleteBusy}
          destructive
          onConfirm={() => void deleteItem()}
          onCancel={() => {
            if (!deleteBusy) setPendingDelete(null);
          }}
        />
      )}
    </div>
  );
}
