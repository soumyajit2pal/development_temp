import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { useInternalNavigate } from '../../hooks/useRequestNavigation'
import { api } from '../../api'
import { useAuth } from '../../context/AuthContext'
import { Table, TableColumn, ErrorText, PageHeader, Badge } from '../../components/Common'
import SearchableSelect from '../../components/SearchableSelect'
import { TEST_EXECUTION_STATUSES, executionStatusGate, hasRetestEligibleHistory } from '../../constants'
import { MyExecutionOut, TestProjectOut, TestCycleOut, TestExecutionOut, TestRunDefectOut, PageOut, DefectListOut, TestExecutionRunOut } from '../../types'

// SRS EXE-002 -- the backend returns the signed-in user's actionable queue
// in one joined, permission-scoped query. Reuses the shared Table component
// purely for its built-in 5-per-page pagination/filtering.
interface MyExecutionRow {
  id: number
  execution: TestExecutionOut
  project: TestProjectOut
  cycle: TestCycleOut
}

// A compact, self-contained version of Test Execution's own inline "Run"
// quick-action (that component isn't exported -- see TestExecution.tsx's
// InlineExecutionActions -- so this mirrors its status-button + optimistic
// concurrency behavior rather than reaching across module boundaries for a
// component that was written to be page-local).
function QuickResultActions({ execution, onChanged, onError }: {
  execution: TestExecutionOut
  onChanged: (execution: TestExecutionOut) => void
  onError: (error: unknown) => void
}) {
  const [open, setOpen] = useState(false)
  const [result, setResult] = useState('')
  const [busy, setBusy] = useState(false)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const [position, setPosition] = useState<{ top: number; left: number; width: number } | null>(null)

  function togglePanel() {
    if (open) { setOpen(false); return }
    const rect = triggerRef.current?.getBoundingClientRect()
    if (!rect) return
    const gap = 8
    const viewportGap = 12
    const width = Math.min(330, window.innerWidth - viewportGap * 2)
    const estimatedHeight = 265
    setPosition({
      left: Math.min(Math.max(viewportGap, rect.right - width), window.innerWidth - width - viewportGap),
      top: window.innerHeight - rect.bottom >= estimatedHeight + gap ? rect.bottom + gap : Math.max(viewportGap, rect.top - estimatedHeight - gap),
      width,
    })
    setOpen(true)
  }

  useEffect(() => {
    if (!open) return
    function closeOutside(event: MouseEvent) {
      const target = event.target as Node
      if (!panelRef.current?.contains(target) && !triggerRef.current?.contains(target)) setOpen(false)
    }
    function closeOnMove() { setOpen(false) }
    function closeOnEscape(event: KeyboardEvent) { if (event.key === 'Escape') setOpen(false) }
    document.addEventListener('mousedown', closeOutside)
    document.addEventListener('keydown', closeOnEscape)
    window.addEventListener('resize', closeOnMove)
    window.addEventListener('scroll', closeOnMove, true)
    return () => {
      document.removeEventListener('mousedown', closeOutside)
      document.removeEventListener('keydown', closeOnEscape)
      window.removeEventListener('resize', closeOnMove)
      window.removeEventListener('scroll', closeOnMove, true)
    }
  }, [open])

  async function saveResult() {
    if (!result) return
    setBusy(true)
    try {
      const saved = await api.patch<TestExecutionOut>(`/api/test-execution/executions/${execution.id}`, {
        status: result, actual_result: null, test_run_artifacts: null, defect_id: null,
        // SRS EXE-007 -- reject the save (409) if someone else already
        // recorded a newer attempt on this exact slot since this row loaded.
        expected_run_version: execution.run_version,
      })
      onChanged(saved)
      setResult('')
      setOpen(false)
    } catch (error) { onError(error) } finally { setBusy(false) }
  }

  return (
    <div className="tm-inline-run" onClick={(event) => event.stopPropagation()}>
      <button ref={triggerRef} type="button" className="tm-play-button" disabled={busy} onClick={togglePanel}>
        <span>▶</span> Run
      </button>
      {open && position && createPortal(
        <div ref={panelRef} className="tm-inline-run-panel portaled" style={position} onClick={(event) => event.stopPropagation()}>
          <div className="tm-inline-run-head"><span><small>Quick execution</small><strong>Record result</strong></span><b>Attempt #{(execution.run_count || 0) + 1}</b></div>
          <div className="tm-inline-result-options">
            {TEST_EXECUTION_STATUSES.filter((status) =>
              status !== 'Not Executed'
              && (status !== 'Retest Passed' || hasRetestEligibleHistory(execution.runs, execution.status))
            ).map((status) => {
              const blocked = executionStatusGate(execution.linked_defects, execution.runs, status, undefined, execution.status, execution.id)
              const tone = status.toLowerCase().replace(/\s+/g, '-')
              return <button type="button" key={status} className={`${result === status ? 'selected ' : ''}result-${tone}`} disabled={!!blocked} title={blocked || undefined} onClick={() => setResult(status)}><i />{status}</button>
            })}
          </div>
          {result && executionStatusGate(execution.linked_defects, execution.runs, result, undefined, execution.status, execution.id) && (
            <small className="tm-inline-defect-gate-note">{executionStatusGate(execution.linked_defects, execution.runs, result, undefined, execution.status, execution.id)}</small>
          )}
          <div className="tm-inline-run-actions">
            <span>{result ? `${result} selected` : 'Select one result'}</span>
            <button type="button" className="btn btn-sm" onClick={() => { setResult(''); setOpen(false) }}>Cancel</button>
            <button type="button" className="btn btn-sm btn-primary" disabled={!result || busy} onClick={saveResult}>{busy ? 'Saving…' : 'Save attempt'}</button>
          </div>
        </div>, document.body
      )}
    </div>
  )
}

// A lightweight defect-link affordance for the latest Fail/Blocked attempt,
// mirroring InlineExecutionActions' own "Link defect" behavior -- lets a
// runner attach a defect key right from this cross-project queue instead of
// having to open the full Test Execution cycle just for that.
function QuickDefectLink({ execution, onChanged, onError }: {
  execution: TestExecutionOut
  onChanged: (execution: TestExecutionOut) => void
  onError: (error: unknown) => void
}) {
  const latestRun = execution.runs?.[execution.runs.length - 1]
  const [open, setOpen] = useState(false)
  const [linkMode, setLinkMode] = useState<'internal' | 'external' | null>(null)
  const [internalDefects, setInternalDefects] = useState<DefectListOut[]>([])
  const [internalDefectId, setInternalDefectId] = useState('')
  const [loadingInternal, setLoadingInternal] = useState(false)
  const [defectKey, setDefectKey] = useState('')
  const [defectUrl, setDefectUrl] = useState('')
  const [busy, setBusy] = useState(false)
  const [defectSearch, setDefectSearch] = useState('')
  const [defectPage, setDefectPage] = useState(1)
  const [defectHasNext, setDefectHasNext] = useState(false)
  const [defectLoadError, setDefectLoadError] = useState<unknown>(null)
  const [defectRetry, setDefectRetry] = useState(0)
  useEffect(() => {
    if (!open || linkMode !== 'internal') return
    let active = true
    setLoadingInternal(true)
    setDefectLoadError(null)
    setInternalDefects([])
    const timer = window.setTimeout(() => {
      const qs = new URLSearchParams({ page_size: '25', page: String(defectPage), search: defectSearch })
      ;['New', 'Triaged', 'Assigned', 'In Progress', 'Resolved', 'Retest', 'Reopened', 'Deferred', 'Not a Defect Review'].forEach(status => qs.append('status', status))
      api.get<PageOut<DefectListOut>>(`/api/defects?${qs}`)
        .then(result => { if (active) { setInternalDefects(result.items); setDefectHasNext(result.has_next) } })
        .catch(error => { if (active) setDefectLoadError(error) })
        .finally(() => { if (active) setLoadingInternal(false) })
    }, 250)
    return () => { active = false; window.clearTimeout(timer) }
  }, [linkMode, open, defectSearch, defectPage, defectRetry])

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!latestRun || !defectKey.trim()) return
    setBusy(true)
    try {
      const defect = await api.post<TestRunDefectOut>(`/api/test-execution/executions/${execution.id}/runs/${latestRun.id}/defects`, {
        defect_key: defectKey.trim(), defect_url: defectUrl.trim() || null, defect_status: 'Open',
      })
      onChanged({ ...execution, runs: (execution.runs || []).map((run) => run.id === latestRun.id ? { ...run, defects: [...(run.defects || []), defect] } : run) })
      setDefectKey(''); setDefectUrl(''); setOpen(false)
    } catch (error) { onError(error) } finally { setBusy(false) }
  }

  async function submitInternal(e: React.FormEvent) {
    e.preventDefault()
    if (!internalDefectId) return
    setBusy(true)
    try {
      await api.post(`/api/defects/${internalDefectId}/link-execution`, { execution_id: execution.id })
      const runs = await api.get<TestExecutionRunOut[]>(`/api/test-execution/executions/${execution.id}/runs`)
      onChanged({ ...execution, runs })
      setInternalDefectId(''); setLinkMode(null); setOpen(false)
    } catch (error) { onError(error) } finally { setBusy(false) }
  }

  // A second, separate defect can't be linked to an attempt that already
  // has one -- see TestExecution.tsx's matching latestCanLinkDefect comment
  // for the full reasoning; enforced backend-side regardless.
  if (!latestRun || !['Fail', 'Blocked'].includes(latestRun.status) || latestRun.defects?.length) return null

  return (
    <div className="tm-inline-run" onClick={(event) => event.stopPropagation()}>
      <button type="button" className="tm-link-last-defect" onClick={() => { setOpen((v) => !v); setLinkMode(null) }}>Link defect</button>
      {open && (
        <div className="tm-inline-defect-panel">
          <strong>Link to latest {latestRun.status.toLowerCase()} run</strong><small>Attempt #{latestRun.attempt_no} only</small>
          {!linkMode && <div className="tm-inline-defect-source"><button type="button" onClick={() => setLinkMode('internal')}><strong>Internal defect</strong><small>Existing governed defect</small></button><button type="button" onClick={() => setLinkMode('external')}><strong>External reference</strong><small>Managed in another system</small></button></div>}
          {linkMode === 'internal' && <form onSubmit={submitInternal}>
            <input aria-label="Search internal defects" placeholder="Search all open defects by ID or title…" value={defectSearch} onChange={event => { setDefectSearch(event.target.value); setDefectPage(1); setInternalDefectId('') }} />
            <ErrorText error={defectLoadError} />
            {!!defectLoadError && <button type="button" onClick={() => setDefectRetry(value => value + 1)}>Retry</button>}
            <SearchableSelect value={internalDefectId} onChange={setInternalDefectId} placeholder={loadingInternal ? 'Loading defects…' : 'Select an open internal defect…'} disabled={loadingInternal} options={internalDefects.map((defect) => ({ value: String(defect.id), label: `${defect.defect_key} · ${defect.title} · ${defect.status}` }))} />
            <div className="tm-inline-run-actions">
              <button type="button" disabled={loadingInternal || defectPage === 1} onClick={() => { setDefectPage(page => page - 1); setInternalDefectId('') }}>Previous</button>
              <span>Page {defectPage}</span>
              <button type="button" disabled={loadingInternal || !!defectLoadError || !defectHasNext} onClick={() => { setDefectPage(page => page + 1); setInternalDefectId('') }}>Next</button>
            </div>
            <div className="tm-inline-run-actions"><button type="button" className="btn btn-sm" onClick={() => setLinkMode(null)}>Back</button><button className="btn btn-sm btn-primary" disabled={busy || loadingInternal || !internalDefectId}>{busy ? 'Linking…' : 'Link internal'}</button></div>
          </form>}
          {linkMode === 'external' && <form onSubmit={submit}>
            <input required value={defectKey} onChange={(e) => setDefectKey(e.target.value)} placeholder="External defect reference" />
            <input type="url" value={defectUrl} onChange={(e) => setDefectUrl(e.target.value)} placeholder="External defect URL (optional)" />
            <div className="tm-inline-run-actions"><button type="button" className="btn btn-sm" onClick={() => setLinkMode(null)}>Back</button><button className="btn btn-sm btn-primary" disabled={busy}>{busy ? 'Linking…' : 'Link external'}</button></div>
          </form>}
          <button type="button" className="link-btn" onClick={() => setOpen(false)}>Cancel</button>
        </div>
      )}
    </div>
  )
}

export default function MyExecutions() {
  const navigate = useInternalNavigate()
  const { user } = useAuth()
  const [rows, setRows] = useState<MyExecutionRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<unknown>(null)
  const [hideCompleted, setHideCompleted] = useState(true)

  const load = useCallback(async () => {
    if (!user) return
    setLoading(true)
    setError(null)
    try {
      const assignments = await api.get<MyExecutionOut[]>('/api/test-execution/my-executions')
      setRows(assignments.map(({ execution, project, cycle }) => ({ id: execution.id, execution, project, cycle })))
    } catch (err) { setError(err) } finally { setLoading(false) }
  }, [user])
  useEffect(() => { load() }, [load])

  function updateExecution(updated: TestExecutionOut) {
    setRows((prev) => prev.map((row) => row.execution.id === updated.id ? { ...row, execution: updated } : row))
  }

  const visibleRows = useMemo(() => (
    hideCompleted ? rows.filter((row) => !['Pass', 'NA', 'Retest Passed'].includes(row.execution.status)) : rows
  ), [rows, hideCompleted])

  const notExecutedCount = rows.filter((row) => row.execution.status === 'Not Executed').length
  const failedCount = rows.filter((row) => ['Fail', 'Blocked'].includes(row.execution.status)).length
  const completedCount = rows.filter((row) => ['Pass', 'NA', 'Retest Passed'].includes(row.execution.status)).length

  const columns: TableColumn<MyExecutionRow>[] = [
    { key: 'project', header: 'Project', render: (row) => <span className="my-execution-context"><strong>{row.project.project_key}</strong><small>{row.project.name}</small></span>, filterValue: (row) => `${row.project.project_key} ${row.project.name}` },
    { key: 'cycle', header: 'Cycle', render: (row) => (
        <span className="my-execution-context"><strong>{row.cycle.cycle_key}</strong><small>{row.cycle.name}</small><Badge status={row.cycle.status} /></span>
      ), filterValue: (row) => `${row.cycle.cycle_key} ${row.cycle.name} ${row.cycle.status}` },
    { key: 'test_case', header: 'Test Case', render: (row) => (
        row.execution.test_case ? <span className="my-execution-context"><strong>{row.execution.test_case.test_case_key}</strong><small>{row.execution.test_case.test_scenario || row.execution.test_case.description || 'Scenario not provided'}</small></span> : <strong>#{row.execution.test_case_id}</strong>
      ), filterValue: (row) => `${row.execution.test_case?.test_case_key || ''} ${row.execution.test_case?.test_scenario || ''}` },
    { key: 'pinned_version_label', header: 'Version', render: (row) => row.execution.pinned_version_label || '—', filterable: false },
    { key: 'status', header: 'Result', render: (row) => (
        <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Badge status={row.execution.status} />
          {row.execution.is_pinned_stale && <span className="muted small" title="A newer approved version exists">stale</span>}
        </span>
      ), filterValue: (row) => row.execution.status },
    { key: 'actions', header: '', filterable: false, render: (row) => (
        <div className="my-execution-actions">
          {row.cycle.workspace_writable ? <><QuickResultActions execution={row.execution} onChanged={updateExecution} onError={setError} />
          <QuickDefectLink execution={row.execution} onChanged={updateExecution} onError={setError} /></> : <span className="badge badge-gray">{row.cycle.origin_workspace_name || 'Other workspace'} · Read-only</span>}
          <button type="button" className="btn btn-sm" onClick={(e) => { e.stopPropagation(); navigate(`/test-execution?project=${row.project.id}&cycle=${row.cycle.id}`) }}>Open cycle</button>
        </div>
      ) },
  ]

  return (
    <div className="tm-page my-executions-page">
      <ErrorText error={error} />
      <PageHeader
        eyebrow="Test Case Management · Design · Organize · Execute · Trace"
        title="My Executions" count={visibleRows.length}
        subtitle="Test cases assigned to you for execution, across every project you have access to."
      />
      <section className="my-execution-overview">
        <div><span>Assigned</span><strong>{rows.length}</strong><small>Across active cycles</small></div>
        <div className="ready"><span>Ready to run</span><strong>{notExecutedCount}</strong><small>Not executed</small></div>
        <div className={failedCount ? 'attention' : ''}><span>Needs attention</span><strong>{failedCount}</strong><small>Failed or blocked</small></div>
        <div className="complete"><span>Completed</span><strong>{completedCount}</strong><small>Pass, NA or retest passed</small></div>
      </section>
      <section className="my-execution-register">
        <header>
          <div><span>Personal work queue</span><h3>Assigned test cases</h3><p>{visibleRows.length} actionable item{visibleRows.length !== 1 ? 's' : ''} in this view</p></div>
          <label className="my-execution-completed-toggle">
            <input type="checkbox" checked={hideCompleted} onChange={(e) => setHideCompleted(e.target.checked)} />
            <span><strong>Focus mode</strong><small>Hide completed results</small></span>
          </label>
        </header>
        {loading ? <div className="my-execution-loading">Loading your assignments…</div> : (
          <Table columns={columns} rows={visibleRows} rowKey="id" tableId="my-executions" />
        )}
        {!loading && visibleRows.length === 0 && (
          <div className="tm-empty">
            <strong>Nothing to execute right now</strong>
            <span>{rows.length === 0 ? 'No test cases are currently assigned to you across your projects.' : 'Everything currently assigned to you is already Pass, NA, or Retest Passed.'}</span>
          </div>
        )}
      </section>
    </div>
  )
}
