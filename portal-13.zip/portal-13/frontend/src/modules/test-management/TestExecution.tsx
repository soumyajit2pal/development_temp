import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { useSearchParams } from 'react-router-dom'
import { useInternalNavigate } from '../../hooks/useRequestNavigation'
import { api, mapWithConcurrency, waitForJob } from '../../api'
import { formatDateTimeIST } from '../../time'
import { useAuth } from '../../context/AuthContext'
import { Table, Modal, Field, ErrorText, PageHeader, Badge, WarningNotice } from '../../components/Common'
import SearchableSelect from '../../components/SearchableSelect'
import ProjectSelect from '../../components/ProjectSelect'
import { ENVIRONMENTS, defectBlocksExecution, activeExternalExecutionDefects, hasWorkflowRole as hasRole, hasWorkspaceRole, hasRetestEligibleHistory, isSelectableUser, QA_STATUS_LABELS, TEST_CASE_PRIORITIES, TEST_EXECUTION_STATUSES, TEST_CYCLE_LOCKED_STATUSES, executionStatusGate, selectionActionLabel } from '../../constants'
import { TestProjectOut, TestCaseOut, TestCycleOut, TestExecutionOut, TestExecutionSummaryOut, TestExecutionRunOut, TestRunDefectOut, ApprovalActionOut, RequestDocumentOut, UserOption, PageOut, LinkedRequestRef, TestProjectMyAccessOut, DefectListOut, TestCycleFolderOut, TestCycleFolderAccessOut, TestCycleFolderListOut, DepartmentOut } from '../../types'
import ConfirmModal from '../../components/ConfirmModal'
import JiraActivity, { AuthenticatedMarkdown } from '../../components/JiraActivity'
import JiraRichTextField from '../../components/JiraRichTextField'
import UserAssignSelect from '../../components/UserAssignSelect'
import LinkedDefects from '../../components/LinkedDefects'
import { usePaginatedList } from '../../hooks/usePaginatedList'
import { IconFolder, IconGrid, IconInbox, IconLock, IconPlus, IconTrash, IconWorkflow } from '../../components/Icons'
import { defectEvidenceError, DEFECT_EVIDENCE_EXTENSIONS } from '../../defectEvidence'
import ExternalDefectStatusModal from './ExternalDefectStatusModal'
import { resolvePreferredProjectId } from '../../projectPreferences'
import { lazyModule } from '../../lazyModule'
import ModuleBoundary from '../../components/ModuleBoundary'
import { cycleCompletionRequestGate, REQUIRED_LINKED_REQUEST_COMPLETION_STATUS } from '../../cycleCompletion'
import { canChangeCycleOwner, canUnlinkExecutionDefect, executionRemovalEligibility } from '../../executionPermissions'

// Test Execution module -- Test Cycles under a selected Test Project, each
// holding one result row (Pass/Fail/Blocked/NA/Retest Passed) per test case
// added to it. Execution requires an explicit QA role and project access.
const CAN_EXEC_ROLES = ['QA_ENGINEER', 'QA_LEAD', 'CHIEF_MANAGER_QA', 'AGM_QA']
// 2026-08 -- reported directly: "'Remove from cycle' should be available
// only for QA lead ... Same for Test Cycle ... Administration can supersede
// everything." Matches backend deps.py's can_manage_execution_governance
// role set exactly (QA_LEAD/CHIEF_MANAGER_QA/AGM_QA) -- deliberately
// narrower than CAN_EXEC_ROLES above, which also includes plain QA_ENGINEER
// (who may execute but may not remove a governed testcase or delete a
// cycle).
const QA_LEAD_GROUP_ROLES = ['QA_LEAD', 'CHIEF_MANAGER_QA', 'AGM_QA']
// Reported directly: "Create Test Cycle Folder, in which I can give access
// department based or user level, same behaviour like project has. Under
// this folder create test cycle." Sentinel for the sidebar's "Unfiled"
// pseudo-folder, same convention as TestRepository.tsx's own UNFILED.
const CYCLE_UNFILED = '__unfiled__'

// Keep Defect Management in its existing lazy bundle. The completion review
// loads the full detail only when someone explicitly opens a defect row.
const EmbeddedDefectDetail = lazyModule(() => import('./Defects')
  .then((module) => ({ default: module.EmbeddedDefectDetail })), { displayName: 'EmbeddedDefectDetail' })

function CycleModal({ project, requests, users, folders, defaultFolderId, editing, onClose, onSaved }: {
  project: TestProjectOut
  requests: LinkedRequestRef[]
  users: UserOption[]
  // Reported directly: "Create Test Cycle Folder ... Under this folder
  // create test cycle." '' means Unfiled -- same convention as
  // TestRepository.tsx's own folder picker.
  folders: TestCycleFolderOut[]
  defaultFolderId: number | ''
  editing?: TestCycleOut | null
  onClose: () => void
  onSaved: (c: TestCycleOut) => void
}) {
  const [ownerCandidates, setOwnerCandidates] = useState<UserOption[]>([])
  const [ownersLoading, setOwnersLoading] = useState(true)
  const [ownersError, setOwnersError] = useState<unknown>(null)
  useEffect(() => {
    let active = true
    setOwnersLoading(true); setOwnerCandidates([]); setOwnersError(null)
    api.get<UserOption[]>(`/api/test-execution/projects/${project.id}/cycle-owner-candidates${editing ? `?cycle_id=${editing.id}` : ''}`)
      .then(items => { if (active) setOwnerCandidates(items) })
      .catch(error => { if (active) setOwnersError(error) })
      .finally(() => { if (active) setOwnersLoading(false) })
    return () => { active = false }
  }, [project.id, editing?.id])
  const [name, setName] = useState(editing?.name || '')
  const [description, setDescription] = useState(editing?.description || '')
  const [folderId, setFolderId] = useState<number | ''>(editing ? (editing.folder_id ?? '') : defaultFolderId)
  const [startDate, setStartDate] = useState(editing?.start_date || '')
  const [endDate, setEndDate] = useState(editing?.end_date || '')
  const [linkedRequest, setLinkedRequest] = useState(editing?.linked_request_type === 'Functional' && editing.linked_request_id ? `Functional:${editing.linked_request_id}` : '')
  // SRS CYC-001 "type, dates, owner, environment and build".
  const [cycleType, setCycleType] = useState(editing?.cycle_type || '')
  const [environment, setEnvironment] = useState(editing?.environment || '')
  const [build, setBuild] = useState(editing?.build || '')
  const [ownerId, setOwnerId] = useState<number | ''>(editing?.owner_id ?? '')
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)
  const { user } = useAuth()
  // 2026-08 Reassignment Requirement -- changing an already-set cycle owner
  // is a reassignment: only the current owner or a workspace QA Executive
  // may pick a different one, and a reason becomes mandatory.
  // Setting an owner for the first time (creating a cycle, or editing one
  // that never had an owner) stays open to anyone who can edit the cycle at
  // all -- same broad gate this whole modal already runs under.
  const hasExistingOwner = !!editing?.owner_id
  const previousOwner = users.find(candidate => candidate.id === editing?.owner_id)
  const canChangeOwner = canChangeCycleOwner(user, editing?.owner_id, previousOwner?.departments || (previousOwner?.department ? [previousOwner.department] : []))
  const requestLinkLocked = !!editing?.linked_request_key && editing.linked_request_change_allowed === false
  const isOwnerReassignment = hasExistingOwner && (ownerId || null) !== editing?.owner_id
  const [ownerReassignReason, setOwnerReassignReason] = useState('')

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!name.trim()) { setError(new Error('Cycle name cannot be blank')); return }
    if (!environment.trim() || !build.trim()) { setError(new Error('Environment and Build are required')); return }
    if (!startDate || !endDate) { setError(new Error('Start date and end date are required')); return }
    if (startDate > endDate) { setError(new Error('Start date cannot be after end date')); return }
    if (isOwnerReassignment && !ownerReassignReason.trim()) { setError(new Error('A reassignment reason is required to change the cycle owner')); return }
    setBusy(true); setError(null)
    try {
      const payload = {
        name: name.trim(), description: description || null,
        start_date: startDate, end_date: endDate,
        ...(linkedRequest
          ? { linked_request_type: 'Functional', linked_request_id: Number(linkedRequest.split(':')[1]) }
          : editing ? { linked_request_type: null, linked_request_id: null } : {}),
        cycle_type: cycleType || null,
        environment: environment.trim(), build: build.trim(),
        owner_id: ownerId || null,
        folder_id: folderId || null,
        ...(isOwnerReassignment ? { reason: ownerReassignReason.trim() } : {}),
      }
      const saved = editing
        ? await api.patch<TestCycleOut>(`/api/test-execution/cycles/${editing.id}`, payload)
        : await api.post<TestCycleOut>(`/api/test-execution/projects/${project.id}/cycles`, payload)
      onSaved(saved)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  return (
    <Modal title={editing ? `Edit ${editing.cycle_key}` : 'New Test Cycle'} onClose={onClose}>
      <form onSubmit={submit}>
        <Field label="Test Project">
          <input
            value={`${project.project_key} — ${project.name}`}
            disabled
            aria-label="Selected Test Project"
          />
          <small className="muted">This cycle belongs to this Test Project and the project cannot be changed here.</small>
        </Field>
        <Field label="Cycle Name *">
          <input required value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Description">
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
        <Field label="Folder">
          <SearchableSelect
            value={folderId === '' ? '' : String(folderId)}
            onChange={(v) => setFolderId(v ? Number(v) : '')}
            placeholder="-- Unfiled --"
            options={[{ value: '', label: '-- Unfiled --' }, ...folders.map((f) => ({
              value: String(f.id),
              label: f.access_grants.length ? `${f.name} (restricted)` : f.name,
            }))]}
          />
        </Field>
        <div className="grid grid-2">
          <Field label="Cycle Type">
            <input value={cycleType} onChange={(e) => setCycleType(e.target.value)} placeholder="Smoke, Functional, Regression, Retest…" />
          </Field>
          <Field label="Environment *">
            <select required value={environment} onChange={(e) => setEnvironment(e.target.value)}>
              <option value="">-- Select environment --</option>
              {/* Keep a pre-existing legacy value selectable while editing,
                  but all new choices come from the shared system list. */}
              {environment && !ENVIRONMENTS.includes(environment) && (
                <option value={environment}>{environment} (Legacy)</option>
              )}
              {ENVIRONMENTS.map((value) => (
                <option key={value} value={value}>{value}</option>
              ))}
            </select>
          </Field>
          <Field label="Build *">
            <input required value={build} onChange={(e) => setBuild(e.target.value)} placeholder="e.g. 2026.08.1" />
          </Field>
          <Field label="Owner">
            {canChangeOwner ? (
              <UserAssignSelect
                value={ownerId === '' ? '' : String(ownerId)}
                onChange={(v) => setOwnerId(v ? Number(v) : '')}
                placeholder="-- Unassigned --"
                users={ownerCandidates}
                clearable
                clearLabel="-- Unassigned --"
              />
            ) : (
              <input value={editing?.owner_name || 'Unassigned'} disabled title="Only the current owner, a QA Executive in this workspace, or an Administrator can reassign the cycle owner" />
            )}
          </Field>
        </div>
        {isOwnerReassignment && (
          <Field label="Owner reassignment reason *">
            <input className="reassign-reason-input" value={ownerReassignReason} onChange={(e) => setOwnerReassignReason(e.target.value)} placeholder="Required when changing an already-assigned owner…" />
          </Field>
        )}
        <Field label="Functional QA Request (optional)">
          <SearchableSelect disabled={requestLinkLocked} value={linkedRequest} onChange={setLinkedRequest} placeholder="Select a Functional QA Request…" options={[
            { value: '', label: 'No request (Standalone)' },
            ...requests.map((request) => (
              { value: `Functional:${request.id}`, label: `${request.request_id} — ${project.name}` }
            )),
          ]} />
          <small className="muted">{requestLinkLocked
            ? 'Functional execution has started, so this request link is locked.'
            : requests.length
              ? 'Leave blank for a standalone Test Cycle. A Functional request can be linked later.'
              : `No Functional QA Request for ${project.name} exists in this workspace. You can create a standalone cycle or raise a matching request first.`}</small>
        </Field>
        <div className="grid grid-2">
          <Field label="Start Date *">
            <input type="date" required value={startDate} max={endDate || undefined} onChange={(e) => setStartDate(e.target.value)} />
          </Field>
          <Field label="End Date *">
            <input type="date" required value={endDate} min={startDate || undefined} onChange={(e) => setEndDate(e.target.value)} />
          </Field>
        </div>
        <ErrorText error={error} />
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <ErrorText error={ownersError} /><button className="btn btn-primary" disabled={busy || ownersLoading || !!ownersError || (isOwnerReassignment && !ownerReassignReason.trim())}>{busy ? 'Saving…' : editing ? 'Save Changes' : 'Create Cycle'}</button>
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
        </div>
      </form>
    </Modal>
  )
}

// Reported directly: "Create Test Cycle Folder, in which I can give access
// department based or user level, same behaviour like project has." Flat --
// no nesting, no rename-with-reparent complexity (see
// ORACLE_MIGRATION_2026-07.md section 147) -- just a name.
function NewCycleFolderModal({ projectId, editing, onClose, onSaved }: {
  projectId: number
  editing?: TestCycleFolderOut | null
  onClose: () => void
  onSaved: (f: TestCycleFolderOut) => void
}) {
  const [name, setName] = useState(editing?.name || '')
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!name.trim()) { setError(new Error('Folder name cannot be blank')); return }
    setBusy(true); setError(null)
    try {
      const saved = editing
        ? await api.patch<TestCycleFolderOut>(`/api/test-execution/cycle-folders/${editing.id}`, { name: name.trim() })
        : await api.post<TestCycleFolderOut>(`/api/test-execution/projects/${projectId}/cycle-folders`, { name: name.trim() })
      onSaved(saved)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  return (
    <Modal title={editing ? 'Rename Folder' : 'New Test Cycle Folder'} onClose={onClose}>
      <form onSubmit={submit}>
        <Field label="Folder Name *">
          <input autoFocus required value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <ErrorText error={error} />
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : editing ? 'Save' : 'Create Folder'}</button>
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
        </div>
      </form>
    </Modal>
  )
}

// Reported directly: "give access department based or user level, same
// behaviour like project has." Deliberately the OPPOSITE of Test Projects'
// own ManageViewAccessModal (which only ever WIDENS a project's visibility)
// -- adding even one grant here RESTRICTS this folder's cycles to just the
// department(s)/user(s) listed (plus the project owner, this folder's own
// creator, and the QA Lead Group/Admin, who bypass every governance gate in
// this module already) -- see backend models.TestCycleFolder's own
// docstring. Gated the same as folder deletion (QA Lead Group/Admin only).
function CycleFolderAccessModal({ folder, departments, onClose, onChanged }: {
  folder: TestCycleFolderOut
  departments: DepartmentOut[]
  onClose: () => void
  onChanged: (grants: TestCycleFolderAccessOut[]) => void
}) {
  const [grants, setGrants] = useState<TestCycleFolderAccessOut[]>(folder.access_grants)
  const [allUsers, setAllUsers] = useState<UserOption[]>([])
  const [loaded, setLoaded] = useState(false)
  const [grantType, setGrantType] = useState<'department' | 'user'>('department')
  const [department, setDepartment] = useState('')
  const [userId, setUserId] = useState('')
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    api.get<UserOption[]>('/api/auth/user-options').then((u) => { setAllUsers(u); setLoaded(true) }).catch((err) => { setError(err); setLoaded(true) })
  }, [])

  function report(next: TestCycleFolderAccessOut[]) {
    setGrants(next)
    onChanged(next)
  }

  async function addGrant(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    if (grantType === 'department' && !department) { setError(new Error('Select a department')); return }
    if (grantType === 'user' && !userId) { setError(new Error('Select a user')); return }
    setBusy(true)
    try {
      const created = await api.post<TestCycleFolderAccessOut>(`/api/test-execution/cycle-folders/${folder.id}/access`, {
        department: grantType === 'department' ? department : null,
        user_id: grantType === 'user' ? Number(userId) : null,
      })
      report([...grants, created])
      setDepartment(''); setUserId('')
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  async function removeGrant(grant: TestCycleFolderAccessOut) {
    setBusy(true)
    setError(null)
    try {
      await api.del(`/api/test-execution/cycle-folders/${folder.id}/access/${grant.id}`)
      report(grants.filter((g) => g.id !== grant.id))
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  const grantedDepartments = new Set(grants.filter((g) => g.department).map((g) => g.department))
  const grantedUserIds = new Set(grants.filter((g) => g.user_id != null).map((g) => g.user_id))
  const departmentOptions = departments.filter((d) => !grantedDepartments.has(d.name))
  const userOptions = allUsers.filter((u) => isSelectableUser(u) && !grantedUserIds.has(u.id))

  return (
    <Modal title={`Folder access — ${folder.name}`} onClose={onClose}>
      <p className="muted small">
        {grants.length === 0
          ? 'No access restriction yet -- this folder is visible to anyone who can already execute in this project, same as an Unfiled cycle.'
          : 'This folder is RESTRICTED -- only the department(s)/user(s) below (plus the project owner, this folder\'s creator, and the QA Lead Group/Admin) can see its test cycles.'}
      </p>
      {!loaded ? <p className="muted">Loading...</p> : (
        <div className="tm-view-access-list">
          {grants.map((grant) => (
            <div key={grant.id} className="tm-view-access-row">
              <span>
                {grant.department ? <><strong>{grant.department}</strong> <small className="muted">(department)</small></> : (
                  <><strong>{grant.user_name || `User #${grant.user_id}`}</strong> <small className="muted">(user)</small></>
                )}
              </span>
              <button type="button" className="btn btn-sm btn-danger" disabled={busy} onClick={() => removeGrant(grant)}>Remove</button>
            </div>
          ))}
        </div>
      )}
      <form onSubmit={addGrant} style={{ marginTop: 14 }}>
        <div className="pill-tabs" style={{ marginBottom: 10 }}>
          <button type="button" className={grantType === 'department' ? 'active' : ''} onClick={() => setGrantType('department')}>Department</button>
          <button type="button" className={grantType === 'user' ? 'active' : ''} onClick={() => setGrantType('user')}>Particular user</button>
        </div>
        {grantType === 'department' ? (
          <Field label="Department">
            <SearchableSelect value={department} onChange={setDepartment} placeholder="Select department…" options={departmentOptions.map((d) => ({ value: d.name, label: d.name }))} />
          </Field>
        ) : (
          <Field label="User">
            <UserAssignSelect value={userId} onChange={setUserId} placeholder="Select user…" users={userOptions} />
          </Field>
        )}
        <ErrorText error={error} />
        <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Granting...' : 'Grant access'}</button>
          <button type="button" className="btn" onClick={onClose}>Close</button>
        </div>
      </form>
    </Modal>
  )
}

// 2026-08 -- reported directly: "once test cycle completed, then test cycle
// is locked to edit. that is okay, but give option to link QA request." A
// narrower sibling of CycleModal -- just the one field, so it can stay
// reachable on an otherwise-frozen Completed cycle without exposing (or
// silently no-op'ing) every other field CycleModal carries. Submits a PATCH
// containing ONLY linked_request_type/linked_request_id -- the backend's own
// update_cycle allows exactly that shape through even once a cycle is
// Completed, still rejecting anything broader.
function LinkCycleRequestModal({ cycle, project, requests, onClose, onSaved }: {
  cycle: TestCycleOut
  project: TestProjectOut
  requests: LinkedRequestRef[]
  onClose: () => void
  onSaved: (c: TestCycleOut) => void
}) {
  const [linkedRequest, setLinkedRequest] = useState(cycle.linked_request_type === 'Functional' && cycle.linked_request_id ? `Functional:${cycle.linked_request_id}` : '')
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!linkedRequest) { setError(new Error('Select a Functional QA Request')); return }
    setBusy(true); setError(null)
    try {
      const saved = await api.patch<TestCycleOut>(`/api/test-execution/cycles/${cycle.id}`, {
        linked_request_type: 'Functional',
        linked_request_id: Number(linkedRequest.split(':')[1]),
      })
      onSaved(saved)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  return (
    <Modal title={`Link QA Request — ${cycle.cycle_key}`} onClose={onClose}>
      <form onSubmit={submit}>
        <p className="muted small">{cycle.cycle_key} is Completed and otherwise read-only. Its Functional QA Request can be replaced here for traceability and reporting.</p>
        <Field label="Functional QA Request *">
          <SearchableSelect value={linkedRequest} onChange={setLinkedRequest} placeholder="Select a Functional QA Request…" options={requests.map((request) =>
            ({ value: `Functional:${request.id}`, label: `${request.request_id} — ${project.name}` })
          )} />
          <small className="muted">{requests.length
            ? 'Required. Select the Functional QA Request executed by this cycle.'
            : `No Functional QA Request for ${project.name} exists in this workspace.`}</small>
        </Field>
        <ErrorText error={error} />
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <button className="btn btn-primary" disabled={busy || !linkedRequest}>{busy ? 'Saving…' : 'Save Link'}</button>
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
        </div>
      </form>
    </Modal>
  )
}

function QALeadGroupUnlinkRequestModal({ cycle, onClose, onSaved }: {
  cycle: TestCycleOut
  onClose: () => void
  onSaved: (c: TestCycleOut) => void
}) {
  const [reason, setReason] = useState('')
  const [impactConfirmed, setImpactConfirmed] = useState(false)
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)
  const normalizedReason = reason.trim()
  const canSubmit = normalizedReason.length >= 10 && impactConfirmed && !busy
  const isGovernedRetestCancellation = cycle.reexecution_of_cycle_id != null

  async function unlink() {
    if (!canSubmit) return
    setBusy(true); setError(null)
    try {
      const saved = await api.post<TestCycleOut>(`/api/test-execution/cycles/${cycle.id}/request-link/qa-lead-group-unlink`, {
        reason: normalizedReason,
        impact_confirmed: true,
      })
      onSaved(saved)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  return (
    <Modal title={`QA Lead Group unlink — ${cycle.cycle_key}`} onClose={onClose} closeDisabled={busy} variant="dialog" preventBackdropClose>
      <div className="tm-bulk-confirm">
        <div className="action-error-dialog" role="alert">
          <div className="action-error-dialog-icon">!</div>
          <div>
            <strong>Break-glass workflow action</strong>
            <span>Functional Request {cycle.linked_request_key}</span>
            {isGovernedRetestCancellation
              ? <p>This performs a governed re-test cancellation. It removes the Functional Request association, clears this cycle&apos;s re-execution lineage, and may return the Functional Request from Execution in Progress to QA Change Review. The detached Test Cycle remains available for audit. Both records receive a QA Lead Group audit entry.</p>
              : <p>This removes only the Functional Request association. The Test Cycle and its execution attempts, results, linked defects, and evidence remain unchanged. Both records receive a QA Lead Group audit entry.</p>}
          </div>
        </div>
        <p className="muted small">{isGovernedRetestCancellation
          ? 'Use this only to cancel an untouched, incorrectly created clearance re-test cycle. A cycle with recorded work cannot be detached; its evidence must be preserved through the governed workflow.'
          : 'Use this only to recover an incorrect association after execution has started. The Functional Request cannot complete QA until the correct execution evidence is linked again.'}</p>
        <Field label="Override reason *">
          <textarea
            autoFocus
            maxLength={2000}
            value={reason}
            onChange={(event) => setReason(event.target.value)}
            placeholder="Explain why the current request link is incorrect and what will be linked instead…"
          />
          <small className="muted">At least 10 characters. This explanation is permanent audit history.</small>
        </Field>
        <label className="workflow-regression-check">
          <input type="checkbox" checked={impactConfirmed} disabled={busy} onChange={(event) => setImpactConfirmed(event.target.checked)} />
          <span>{isGovernedRetestCancellation
            ? 'I confirm this will cancel the governed re-test association, clear its lineage, may restore the Functional Request to QA Change Review, and retain the detached Test Cycle for audit.'
            : 'I confirm that only the request association will be removed, all execution evidence will be retained, and the correct request must be linked before QA completion.'}</span>
        </label>
        <ErrorText error={error} />
        <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
          <button type="button" className="btn btn-danger" disabled={!canSubmit} onClick={unlink}>{busy ? 'Unlinking…' : 'Unlink with QA Lead override'}</button>
          <button type="button" className="btn" disabled={busy} onClick={onClose}>Keep current link</button>
        </div>
      </div>
    </Modal>
  )
}

function CycleStatusControl({ cycle, executionTotal, executedCount, failedCount, blockedCount, onChanged, onError }: {
  cycle: TestCycleOut
  executionTotal: number
  executedCount: number
  failedCount: number
  blockedCount: number
  onChanged: (c: TestCycleOut) => void
  onError: (err: unknown) => void
}) {
  const { user } = useAuth()
  const [busy, setBusy] = useState(false)
  const [showBlock, setShowBlock] = useState(false)
  const [showComplete, setShowComplete] = useState(false)
  const [conditionalCompletion, setConditionalCompletion] = useState(false)
  const [blockingReason, setBlockingReason] = useState('')
  const [remarks, setRemarks] = useState('')
  const [dialogError, setDialogError] = useState<unknown>(null)
  const [completionDefects, setCompletionDefects] = useState<DefectListOut[]>([])
  const [loadingCompletion, setLoadingCompletion] = useState(false)
  const [completionFilter, setCompletionFilter] = useState<'all' | 'blocker' | 'target'>('all')
  const [completionPage, setCompletionPage] = useState(1)
  const [selectedCompletionDefect, setSelectedCompletionDefect] = useState<string | null>(null)
  const requestCompletionGate = cycleCompletionRequestGate(cycle)
  const linkedRequestCompletionBlocked = !requestCompletionGate.allowed
  const requiredRequestStatusLabel = QA_STATUS_LABELS[REQUIRED_LINKED_REQUEST_COMPLETION_STATUS] || 'Execution In Progress'
  const linkedRequestStatusLabel = requestCompletionGate.currentStatus
    ? QA_STATUS_LABELS[requestCompletionGate.currentStatus] || requestCompletionGate.currentStatus
    : 'Status unavailable'
  const linkedRequestIdentity = cycle.linked_request_key || `Linked QA Request #${cycle.linked_request_id}`
  const linkedRequestCompletionReason = linkedRequestCompletionBlocked
    ? `${linkedRequestIdentity} is currently ${linkedRequestStatusLabel}. Test Cycle completion requires the linked request to be ${requiredRequestStatusLabel}.`
    : ''
  const linkedRequestGateDescriptionId = `cycle-${cycle.id}-linked-request-completion-gate`

  useEffect(() => {
    if (!showComplete) return
    let active = true
    setLoadingCompletion(true); setDialogError(null)
    setCompletionDefects([]); setSelectedCompletionDefect(null)
    setCompletionFilter('all'); setCompletionPage(1)
    // Completion rules must evaluate the complete defect set even when the
    // cycle grows beyond one server page. The table below paginates locally
    // after every server page has been collected.
    async function loadAllCompletionDefects() {
      const defects = await api.getAll<DefectListOut>(`/api/defects?cycle_id=${cycle.id}`)
      if (active) {
        setCompletionDefects(defects)
        setDialogError(null)
      }
    }
    loadAllCompletionDefects()
      .catch((error) => { if (active) setDialogError(error) })
      .finally(() => { if (active) setLoadingCompletion(false) })
    return () => { active = false }
  }, [showComplete, cycle.id])

  async function transition(status: string, reason = '', transitionRemarks = '') {
    // This is an explanatory UI guard only. The PATCH endpoint remains the
    // authoritative authorization and rechecks the request under its lock.
    if (status === 'Completed' && linkedRequestCompletionBlocked) {
      const completionError = new Error(linkedRequestCompletionReason)
      if (showComplete) setDialogError(completionError)
      else onError(completionError)
      return
    }
    setBusy(true); setDialogError(null)
    try {
      const saved = await api.patch<TestCycleOut>(`/api/test-execution/cycles/${cycle.id}`, {
        status,
        blocking_reason: reason || null,
        remarks: transitionRemarks || null,
        conditional_clearance: status === 'Completed' && conditionalCompletion,
      })
      onChanged(saved)
      setShowBlock(false); setShowComplete(false)
      setBlockingReason(''); setRemarks('')
    } catch (err) {
      if (showBlock || showComplete) setDialogError(err)
      else onError(err)
    } finally { setBusy(false) }
  }

  const actions = cycle.status === 'Draft'
    ? [{ label: 'Mark as Ready', status: 'Ready' }]
    : cycle.status === 'Ready'
      ? [{ label: 'Start Execution', status: 'In Progress' }]
      : cycle.status === 'In Progress'
        ? [{ label: 'Block Execution', status: 'Blocked' }, { label: 'Complete Execution', status: 'Completed' }]
        : cycle.status === 'Blocked'
          ? [{ label: 'Resume Execution', status: 'In Progress' }]
          : []
  const unresolvedStatuses = new Set(['New', 'Triaged', 'Assigned', 'In Progress', 'Resolved', 'Retest', 'Reopened', 'Not a Defect Review', 'Ready for QA', 'QA Testing', 'Business Acceptance', 'Ready for Release', 'Production Verification'])
  // Verification coverage is environment-scoped. Builds stay on each
  // verification record as audit evidence, but a different recorded build
  // must not make otherwise valid environment coverage disappear.
  const verifiedForCycleContext = (defect: DefectListOut) => !!defect.verified_builds?.some(v =>
    v.environment === cycle.environment)
  const severeBlockers = completionDefects.filter((defect) => ['Critical', 'High'].includes(defect.severity) && (unresolvedStatuses.has(defect.status) || (defect.modern_workflow && defect.status === 'Closed' && defect.resolution_type === 'Fixed')) && !verifiedForCycleContext(defect))
  const residualDefects = completionDefects.filter((defect) => ['Medium', 'Low'].includes(defect.severity) && (unresolvedStatuses.has(defect.status) || (defect.modern_workflow && defect.status === 'Closed' && defect.resolution_type === 'Fixed')) && !verifiedForCycleContext(defect))
  const canCompleteWithResidualRisk = hasRole(user, ...QA_LEAD_GROUP_ROLES)
  const notExecutedCount = Math.max(0, executionTotal - executedCount)
  const severitySummary = ['Critical', 'High', 'Medium', 'Low'].map((severity) => ({ severity, count: completionDefects.filter((defect) => defect.severity === severity).length }))
  const targetReleaseMissing = completionDefects.filter((defect) =>
    !defect.target_release && (
      (['Medium', 'Low'].includes(defect.severity) && (unresolvedStatuses.has(defect.status) || (defect.modern_workflow && defect.status === 'Closed' && defect.resolution_type === 'Fixed')) && !verifiedForCycleContext(defect)) || defect.status === 'Deferred'
    ))
  const completionBlockers = new Set(severeBlockers.map((defect) => defect.id))
  const missingTargetDefects = new Set(targetReleaseMissing.map((defect) => defect.id))
  const filteredCompletionDefects = completionDefects.filter((defect) =>
    completionFilter === 'all'
      ? true
      : completionFilter === 'blocker'
        ? completionBlockers.has(defect.id)
        : missingTargetDefects.has(defect.id))
  const completionPageSize = 5
  const completionTotalPages = Math.max(1, Math.ceil(filteredCompletionDefects.length / completionPageSize))
  const safeCompletionPage = Math.min(completionPage, completionTotalPages)
  const visibleCompletionDefects = filteredCompletionDefects.slice((safeCompletionPage - 1) * completionPageSize, safeCompletionPage * completionPageSize)
  const firstVisibleDefect = filteredCompletionDefects.length ? (safeCompletionPage - 1) * completionPageSize + 1 : 0
  const lastVisibleDefect = Math.min(safeCompletionPage * completionPageSize, filteredCompletionDefects.length)
  const hasCompletionBlockers = linkedRequestCompletionBlocked || (conditionalCompletion
    ? executedCount === 0 || !canCompleteWithResidualRisk
    : failedCount > 0 || blockedCount > 0 || notExecutedCount > 0 || severeBlockers.length > 0)
    || targetReleaseMissing.length > 0 || (residualDefects.length > 0 && !canCompleteWithResidualRisk)
  const needsResidualJustification = (conditionalCompletion || residualDefects.length > 0) && canCompleteWithResidualRisk && !remarks.trim()
  const completionState = hasCompletionBlockers ? 'blocked' : needsResidualJustification ? 'pending' : 'ready'

  function setDefectFilter(filter: 'all' | 'blocker' | 'target') {
    setCompletionFilter(filter)
    setCompletionPage(1)
  }

  function requiredDefectAction(defect: DefectListOut) {
    if (completionBlockers.has(defect.id)) return conditionalCompletion ? 'Document condition and mitigation in the clearance certificate' : 'Resolve, reject, defer, or close'
    if (missingTargetDefects.has(defect.id)) return 'Set Target Release or resolve'
    if (residualDefects.some((item) => item.id === defect.id)) return 'QA Lead Group residual-risk review'
    return 'No action required'
  }

  function defectExecutionImpact(defect: DefectListOut) {
    const byExecution = new Map<number, { testCase: string; status: string }>()
    if (defect.execution_id) {
      byExecution.set(defect.execution_id, {
        testCase: defect.test_case_key || 'Unknown testcase',
        status: defect.execution_status || 'Not Executed',
      })
    }
    for (const link of defect.execution_links || []) {
      byExecution.set(link.execution_id, {
        testCase: link.test_case_key || 'Unknown testcase',
        status: link.status || 'Not Executed',
      })
    }
    const impacts = Array.from(byExecution.values())
    const resultCounts = impacts.reduce<Record<string, number>>((counts, impact) => {
      counts[impact.status] = (counts[impact.status] || 0) + 1
      return counts
    }, {})
    return {
      count: impacts.length,
      summary: Object.entries(resultCounts).map(([status, count]) => `${count} ${status}`).join(' · ') || 'No execution linked',
      details: impacts.map((impact) => `${impact.testCase}: ${impact.status}`).join('\n'),
    }
  }

  return (
    <>
      <div className="tm-cycle-status-actions" aria-label={`Available actions for ${cycle.status} cycle`}>
        <Badge status={cycle.status} />
        {actions.map((action) => (
          <button
            key={action.status}
            type="button"
            className={`btn btn-sm ${action.status === 'Completed' ? 'btn-primary' : ''}`}
            disabled={busy || (action.status === 'Completed' && linkedRequestCompletionBlocked)}
            aria-describedby={action.status === 'Completed' && linkedRequestCompletionBlocked ? linkedRequestGateDescriptionId : undefined}
            title={action.status === 'Completed' && linkedRequestCompletionBlocked ? linkedRequestCompletionReason : undefined}
            onClick={() => {
              if (action.status === 'Blocked') setShowBlock(true)
              else if (action.status === 'Completed') { setConditionalCompletion(false); setShowComplete(true) }
              else transition(action.status)
            }}
          >
            {busy ? 'Updating…' : action.label}
          </button>
        ))}
        {cycle.status === 'In Progress' && canCompleteWithResidualRisk && <button type="button" className="btn btn-sm" disabled={busy || linkedRequestCompletionBlocked} aria-describedby={linkedRequestCompletionBlocked ? linkedRequestGateDescriptionId : undefined} title={linkedRequestCompletionBlocked ? linkedRequestCompletionReason : undefined} onClick={() => { setConditionalCompletion(true); setShowComplete(true) }}>Complete for Conditional Clearance</button>}
        {cycle.status === 'In Progress' && linkedRequestCompletionBlocked && <small id={linkedRequestGateDescriptionId} className="tm-cycle-completion-request-block" role="status">{linkedRequestCompletionReason}</small>}
        {cycle.status === 'Ready' && cycle.linked_request_key && (
          <small className="muted">Start execution on {cycle.linked_request_key} first. The linked request must be Execution In Progress before this cycle can start.</small>
        )}
      </div>
      {showBlock && (
        <Modal title={`Block ${cycle.cycle_key}?`} onClose={() => setShowBlock(false)} closeDisabled={busy} variant="dialog" preventBackdropClose>
          <form onSubmit={(event) => {
            event.preventDefault()
            if (!blockingReason.trim()) { setDialogError(new Error('A blocking reason is required')); return }
            transition('Blocked', blockingReason.trim(), remarks.trim())
          }}>
            <Field label="Blocking Reason *">
              <textarea required rows={3} value={blockingReason} onChange={(event) => setBlockingReason(event.target.value)} placeholder="Describe the issue or dependency stopping execution." />
            </Field>
            <Field label="Remarks (optional)">
              <textarea rows={2} value={remarks} onChange={(event) => setRemarks(event.target.value)} />
            </Field>
            <ErrorText error={dialogError} />
            <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
              <button className="btn btn-primary" disabled={busy || !blockingReason.trim()}>{busy ? 'Blocking…' : 'Block Execution'}</button>
              <button type="button" className="btn" disabled={busy} onClick={() => setShowBlock(false)}>Cancel</button>
            </div>
          </form>
        </Modal>
      )}
      {showComplete && !selectedCompletionDefect && (
        <Modal title={conditionalCompletion ? `Conditional completion of ${cycle.cycle_key}` : `Review before completing ${cycle.cycle_key}`} onClose={() => setShowComplete(false)} closeDisabled={busy} variant="dialog" preventBackdropClose wide>
          <div className="tm-cycle-completion-review">
            {conditionalCompletion && <p>Complete this cycle with recorded exceptions for Conditional Clearance review. A QA Lead must record the reason below. At least one test result and all required defect Target Releases are needed. Completion freezes the cycle; the clearance certificate still needs conditions, residual-risk remarks, mitigation, and both approvals. Responsible owner and target date on the certificate are optional.</p>}
            {loadingCompletion ? <p className="muted">Loading defect validation…</p> : <>
              <section className={`tm-completion-state ${completionState}`}>
                <span aria-hidden="true">{completionState === 'ready' ? '✓' : '!'}</span>
                <div>
                  <strong>{hasCompletionBlockers ? 'This cycle is not ready to complete' : needsResidualJustification ? 'Residual-risk approval details required' : 'This cycle satisfies the completion checks'}</strong>
                  <p>
                    {linkedRequestCompletionBlocked
                      ? linkedRequestCompletionReason
                      : conditionalCompletion
                      ? executedCount === 0 ? 'Record at least one test result before conditional completion.'
                        : targetReleaseMissing.length > 0 ? `Add Target Releases to ${targetReleaseMissing.length} residual defect(s).`
                        : 'Review the failed, blocked, and unexecuted tests and open defects, then record why conditional review is appropriate.'
                      : failedCount > 0 || blockedCount > 0
                      ? `${failedCount} failed and ${blockedCount} blocked testcase(s) must be resolved and retested before completion.`
                      : notExecutedCount > 0
                      ? `Record results for ${notExecutedCount} remaining testcase(s).`
                      : severeBlockers.length > 0
                        ? `Resolve ${severeBlockers.length} open Critical/High defect(s) before completion.`
                        : targetReleaseMissing.length > 0
                          ? `Add Target Releases to ${targetReleaseMissing.length} residual defect(s).`
                          : residualDefects.length > 0 && !canCompleteWithResidualRisk
                            ? 'A QA Lead Group member must review the residual risk and complete this cycle.'
                            : residualDefects.length > 0
                              ? 'Add the residual-risk justification, then complete the cycle.'
                              : 'Review the details below before completing. Completion is final.'}
                  </p>
                </div>
              </section>
              <div className="tm-cycle-defect-counts">
                {severitySummary.map((item) => <div key={item.severity} data-severity={item.severity.toLowerCase()}><small>{item.severity}</small><strong>{item.count}</strong><span>{conditionalCompletion ? 'Requires conditional review when open' : ['Critical', 'High'].includes(item.severity) ? 'Blocks completion when open' : 'Residual risk when open'}</span></div>)}
              </div>
              <section className="tm-completion-readiness" aria-label="Completion readiness">
                {requestCompletionGate.linked && <div className={linkedRequestCompletionBlocked ? 'failed' : 'passed'}><i>{linkedRequestCompletionBlocked ? '×' : '✓'}</i><span><strong>Linked QA Request</strong><small>{linkedRequestIdentity} · Current: {linkedRequestStatusLabel} · Required: {requiredRequestStatusLabel}</small></span></div>}
                <div className={notExecutedCount || failedCount || blockedCount ? 'failed' : 'passed'}><i>{notExecutedCount || failedCount || blockedCount ? '×' : '✓'}</i><span><strong>Execution results</strong><small>{executedCount} of {executionTotal} recorded · {failedCount} failed · {blockedCount} blocked</small></span></div>
                <div className={severeBlockers.length ? 'failed' : 'passed'}><i>{severeBlockers.length ? '×' : '✓'}</i><span><strong>Critical/High defect gate</strong><small>{severeBlockers.length ? `${severeBlockers.length} open Critical/High defect(s)` : 'No open Critical/High defects'}</small></span></div>
                <div className={targetReleaseMissing.length ? 'failed' : 'passed'}><i>{targetReleaseMissing.length ? '×' : '✓'}</i><span><strong>Target Releases</strong><small>{targetReleaseMissing.length ? `${targetReleaseMissing.length} missing` : 'All required releases set'}</small></span></div>
              </section>

              <section className="tm-completion-defects">
                <header>
                  <div><h4>Linked defects</h4><p>Each defect is counted once. Execution impact shows every testcase result affected by that defect.</p></div>
                  <div className="tm-completion-filters" role="group" aria-label="Defect filters">
                    <button type="button" className={completionFilter === 'all' ? 'active' : ''} onClick={() => setDefectFilter('all')}>All <b>{completionDefects.length}</b></button>
                    <button type="button" className={completionFilter === 'blocker' ? 'active' : ''} onClick={() => setDefectFilter('blocker')}>Critical/High <b>{severeBlockers.length}</b></button>
                    <button type="button" className={completionFilter === 'target' ? 'active' : ''} onClick={() => setDefectFilter('target')}>Missing target <b>{targetReleaseMissing.length}</b></button>
                  </div>
                </header>
                <div className="tm-completion-table-wrap">
                  <table>
                    <thead><tr><th>Defect</th><th>Defect status</th><th>Severity</th><th>Execution impact</th><th>Target Release</th><th>Required action</th><th><span className="sr-only">Open</span></th></tr></thead>
                    <tbody>
                      {visibleCompletionDefects.map((defect) => {
                        const impact = defectExecutionImpact(defect)
                        return <tr key={defect.id}>
                          <td><strong>{defect.defect_key}</strong><small>{defect.title}</small></td>
                          <td><Badge status={defect.status} /></td>
                          <td><span className={`defect-severity ${defect.severity.toLowerCase()}`}>{defect.severity}</span></td>
                          <td className="tm-execution-impact" title={impact.details}><strong>{impact.count} testcase{impact.count === 1 ? '' : 's'}</strong><small>{impact.summary}</small></td>
                          <td className={!defect.target_release && missingTargetDefects.has(defect.id) ? 'missing' : ''}>{defect.target_release || (missingTargetDefects.has(defect.id) ? 'Not set' : '—')}</td>
                          <td>{requiredDefectAction(defect)}</td>
                          <td><button type="button" className="link-btn" onClick={() => setSelectedCompletionDefect(defect.defect_key)}>Open</button></td>
                        </tr>
                      })}
                      {!visibleCompletionDefects.length && <tr><td colSpan={7} className="tm-completion-empty">No defects match this filter.</td></tr>}
                    </tbody>
                  </table>
                  <footer>
                    <span>Showing {firstVisibleDefect}–{lastVisibleDefect} of {filteredCompletionDefects.length} defects</span>
                    <div><button type="button" disabled={safeCompletionPage <= 1} onClick={() => setCompletionPage((page) => Math.max(1, page - 1))}>‹ Previous</button><span>Page {safeCompletionPage} of {completionTotalPages}</span><button type="button" disabled={safeCompletionPage >= completionTotalPages} onClick={() => setCompletionPage((page) => Math.min(completionTotalPages, page + 1))}>Next ›</button></div>
                  </footer>
                </div>
              </section>
            </>}
            {(residualDefects.length === 0 || canCompleteWithResidualRisk) && (
              <Field label={conditionalCompletion ? 'Conditional Completion Reason *' : residualDefects.length ? 'Residual Risk Justification *' : 'Completion Remarks (optional)'}>
                <textarea rows={3} maxLength={5000} required={conditionalCompletion || residualDefects.length > 0} value={remarks} onChange={(event) => setRemarks(event.target.value)} placeholder={conditionalCompletion ? 'Explain why testing is being completed with these exceptions and why Conditional Clearance review is appropriate.' : residualDefects.length ? 'Explain why completion is accepted with the remaining Medium/Low defects.' : 'Record any completion remarks.'} />
              </Field>
            )}
            <ErrorText error={dialogError} />
            <div className="tm-completion-actions">
              <span>Completion becomes available only after every prerequisite passes.</span>
              <div>
              <button type="button" className="btn" disabled={busy} onClick={() => setShowComplete(false)}>Close</button>
              <button
                type="button"
                className="btn btn-primary"
                disabled={busy || loadingCompletion || Boolean(dialogError) || hasCompletionBlockers || needsResidualJustification}
                onClick={() => transition('Completed', '', remarks.trim())}
              >
                {busy ? 'Completing…' : conditionalCompletion ? 'Complete for Conditional Clearance' : 'Complete cycle'}
              </button>
              </div>
            </div>
          </div>
        </Modal>
      )}
      {selectedCompletionDefect && (
        <ModuleBoundary
          key={selectedCompletionDefect}
          moduleName="Defect details"
          recoveryModal={{ title: `Unable to open ${selectedCompletionDefect}`, onClose: () => setSelectedCompletionDefect(null) }}
        >
          <React.Suspense fallback={
            <Modal title={`Opening ${selectedCompletionDefect}`} onClose={() => setSelectedCompletionDefect(null)} wide>
              <div className="tm-empty"><strong>Loading defect details…</strong><span>The cycle completion review will remain available behind this dialog.</span></div>
            </Modal>
          }>
            <EmbeddedDefectDetail defectKey={selectedCompletionDefect} onClose={() => setSelectedCompletionDefect(null)} />
          </React.Suspense>
        </ModuleBoundary>
      )}
    </>
  )
}

interface TestCaseCandidate {
  id: number
  test_case_key: string
  test_scenario?: string | null
  test_type?: string | null
  priority?: string | null
  module_name?: string | null
  version: string
  created_at: string
  created_by_id?: number | null
  created_by_name?: string | null
}

interface TestCaseCandidateAuthor { id: number; name: string }

interface TestCaseCandidatePage {
  items: TestCaseCandidate[]
  total: number
  next_cursor?: number | null
  has_more: boolean
}

function AddCasesModal({ cycleId, canAssign, requiresScopeChangeReason, runnerCandidates, onClose, onAdded }: {
  cycleId: number
  canAssign: boolean
  requiresScopeChangeReason: boolean
  runnerCandidates: UserOption[]
  onClose: () => void
  onAdded: (createdCount: number) => void
}) {
  const pageSize = 25
  const [candidatePage, setCandidatePage] = useState<TestCaseCandidatePage>({ items: [], total: 0, has_more: false })
  const [candidateLoading, setCandidateLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const [priority, setPriority] = useState('')
  const [createdById, setCreatedById] = useState('')
  const [authors, setAuthors] = useState<TestCaseCandidateAuthor[]>([])
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest')
  // Each entry is the cursor used to load that page. Keeping the small
  // history client-side gives Previous/Next navigation without OFFSET.
  const filterKey = JSON.stringify([cycleId, debouncedSearch, priority, createdById, sortOrder])
  const [pagination, setPagination] = useState<{ key: string; cursors: Array<number | null> }>({ key: filterKey, cursors: [null] })
  // A cursor only belongs to the exact query that produced it.
  const cursorStack = pagination.key === filterKey ? pagination.cursors : [null]
  const setCursorStack = (update: React.SetStateAction<Array<number | null>>) => {
    setPagination(current => {
      const cursors = current.key === filterKey ? current.cursors : [null]
      return { key: filterKey, cursors: typeof update === 'function' ? update(cursors) : update }
    })
  }
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [selectAllMatching, setSelectAllMatching] = useState(false)
  const [excluded, setExcluded] = useState<Set<number>>(new Set())
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)
  const [assignedTo, setAssignedTo] = useState('')
  const [scopeChangeReason, setScopeChangeReason] = useState('')
  const submittingRef = useRef(false)
  const requestRef = useRef(0)
  const jobController = useRef<AbortController | null>(null)

  useEffect(() => () => {
    jobController.current?.abort()
  }, [])

  useEffect(() => {
    const timer = window.setTimeout(() => setDebouncedSearch(search.trim()), 250)
    return () => window.clearTimeout(timer)
  }, [search])

  useEffect(() => {
    let active = true
    api.get<TestCaseCandidateAuthor[]>(`/api/test-execution/cycles/${cycleId}/candidate-authors`)
      .then(rows => { if (active) setAuthors(rows) })
      .catch(err => { if (active) setError(err) })
    return () => { active = false }
  }, [cycleId])

  useEffect(() => {
    setCursorStack([null])
    setSelectAllMatching(false)
    setSelected(new Set())
    setExcluded(new Set())
  }, [debouncedSearch, priority, createdById])

  // Sorting changes presentation only, so keep explicit selections while
  // restarting cursor pagination from the beginning of the new order.
  useEffect(() => { setCursorStack([null]) }, [sortOrder])

  const cursor = cursorStack[cursorStack.length - 1]
  const pageNumber = cursorStack.length
  useEffect(() => {
    const requestId = ++requestRef.current
    const qs = new URLSearchParams({ page_size: String(pageSize) })
    if (cursor != null) qs.set('cursor', String(cursor))
    if (debouncedSearch) qs.set('search', debouncedSearch)
    if (priority) qs.set('priority', priority)
    if (createdById) qs.set('created_by_id', createdById)
    qs.set('sort_order', sortOrder)
    setCandidateLoading(true)
    api.get<TestCaseCandidatePage>(`/api/test-execution/cycles/${cycleId}/candidate-test-cases?${qs.toString()}`)
      .then((result) => { if (requestId === requestRef.current) { setCandidatePage(result); setError(null) } })
      .catch((err) => { if (requestId === requestRef.current) setError(err) })
      .finally(() => { if (requestId === requestRef.current) setCandidateLoading(false) })
    return () => { if (requestId === requestRef.current) ++requestRef.current }
  }, [cycleId, cursor, debouncedSearch, priority, createdById, sortOrder])

  const candidates = candidatePage.items
  const selectedCount = selectAllMatching ? Math.max(0, candidatePage.total - excluded.size) : selected.size

  function toggle(id: number) {
    if (busy) return
    if (selectAllMatching) {
      setExcluded((prev) => {
        const next = new Set(prev)
        if (next.has(id)) next.delete(id); else next.add(id)
        return next
      })
      return
    }
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id); else next.add(id)
      return next
    })
  }

  const isSelected = (id: number) => selectAllMatching ? !excluded.has(id) : selected.has(id)
  const allCandidatesSelected = candidates.length > 0 && candidates.every((testCase) => isSelected(testCase.id))

  function toggleAllCandidates() {
    if (busy) return
    setSelected((current) => {
      if (selectAllMatching) {
        setExcluded((previous) => {
          const nextExcluded = new Set(previous)
          if (allCandidatesSelected) candidates.forEach((testCase) => nextExcluded.add(testCase.id))
          else candidates.forEach((testCase) => nextExcluded.delete(testCase.id))
          return nextExcluded
        })
        return current
      }
      const next = new Set(current)
      if (allCandidatesSelected) candidates.forEach((testCase) => next.delete(testCase.id))
      else candidates.forEach((testCase) => next.add(testCase.id))
      return next
    })
  }

  function selectEveryMatchingCase() {
    setSelectAllMatching(true)
    setSelected(new Set())
    setExcluded(new Set())
  }

  function clearSelection() {
    setSelectAllMatching(false)
    setSelected(new Set())
    setExcluded(new Set())
  }

  async function submit() {
    // State updates are asynchronous, so a fast double-click can enter this
    // function twice before `busy` rerenders the button. The ref is an
    // immediate submission lock; the visible modal overlay below explains
    // the ongoing work and prevents every other interaction.
    if (submittingRef.current) return
    if (selectedCount === 0) { setError(new Error('Pick at least one test case')); return }
    const normalizedScopeChangeReason = scopeChangeReason.trim()
    if (requiresScopeChangeReason && normalizedScopeChangeReason.length < 10) {
      setError(new Error('Enter a scope expansion reason of at least 10 characters.'))
      return
    }
    submittingRef.current = true
    setBusy(true); setError(null)
    try {
      let result = await api.post<{ created_count: number; skipped_count: number; job_id?: string | null; status?: string | null }>(`/api/test-execution/cycles/${cycleId}/executions/from-selection`, {
        selection_mode: selectAllMatching ? 'all_matching' : 'ids',
        test_case_ids: selectAllMatching ? [] : Array.from(selected),
        excluded_ids: selectAllMatching ? Array.from(excluded) : [],
        search: debouncedSearch || null,
        priority: priority || null,
        created_by_id: createdById ? Number(createdById) : null,
        assigned_to_id: assignedTo ? Number(assignedTo) : null,
        reason: requiresScopeChangeReason ? normalizedScopeChangeReason : null,
      }, 180_000)
      if (result.job_id && result.status !== 'COMPLETED') {
        const controller = new AbortController()
        jobController.current?.abort()
        jobController.current = controller
        const job = await waitForJob<{ created_count: number; skipped_count: number }>(result.job_id, { signal: controller.signal })
        result = { ...result, ...job.result, status: job.status }
      }
      onAdded(result.created_count)
    } catch (err) {
      if (!(err instanceof Error && err.name === 'AbortError')) setError(err)
    } finally {
      jobController.current = null
      submittingRef.current = false
      setBusy(false)
    }
  }

  return (
    <Modal title="Add Test Cases to Cycle" onClose={() => { if (!busy) onClose() }} closeDisabled={busy} wide>
      <div className="tm-add-cases-modal" aria-busy={busy}>
      {busy && (
        <div className="tm-add-cases-loading-overlay" role="status" aria-live="assertive">
          <div className="tm-add-cases-loading-card">
            <span className="tm-add-cases-loading-spinner" aria-hidden="true" />
            <strong>Adding {selectedCount.toLocaleString()} testcase{selectedCount !== 1 ? 's' : ''} to this cycle</strong>
            <span>Validating approved versions and creating execution records. Large selections may take a moment.</span>
            <small>Please keep this window open.</small>
          </div>
        </div>
      )}
      {requiresScopeChangeReason && (
        <div className="info-banner" role="note">
          <strong>Execution has started.</strong>
          <span>Adding approved testcases expands the governed scope. Existing attempts and evidence stay unchanged, and every new testcase starts as Not Executed.</span>
          <Field label="Scope expansion reason (required)">
            <textarea
              rows={3}
              maxLength={2000}
              value={scopeChangeReason}
              onChange={(event) => setScopeChangeReason(event.target.value)}
              placeholder="Explain why these testcases are being added after execution started"
              disabled={busy}
              required
            />
          </Field>
          <small>This reason will be retained in the cycle activity. Any pending QA Clearance snapshot must be refreshed before approval.</small>
        </div>
      )}
      {canAssign && <div className="tm-add-cases-runner"><div><strong>Assign selected testcases</strong><span>Optional—assign all selected cases to one runner now, then reassign individual rows later.</span></div><UserAssignSelect value={assignedTo} onChange={setAssignedTo} users={runnerCandidates} placeholder="Leave unassigned…" disabled={busy} /></div>}
      <div className="tm-add-cases-discovery">
        <Field label="Find approved testcases">
          <input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Test Case ID, scenario, module or type…" disabled={busy} />
        </Field>
        <Field label="Priority">
          <select value={priority} onChange={(event) => setPriority(event.target.value)} disabled={busy}><option value="">All priorities</option>{TEST_CASE_PRIORITIES.map((value) => <option key={value}>{value}</option>)}</select>
        </Field>
        <Field label="Created By">
          <select value={createdById} onChange={(event) => setCreatedById(event.target.value)} disabled={busy}><option value="">All creators</option>{authors.map(author => <option key={author.id} value={author.id}>{author.name}</option>)}</select>
        </Field>
        <Field label="Sort By">
          <select value={sortOrder} onChange={(event) => setSortOrder(event.target.value as 'newest' | 'oldest')} disabled={busy}><option value="newest">Recently added first</option><option value="oldest">Oldest added first</option></select>
        </Field>
      </div>
      <div className="tm-add-cases-discovery-note"><span>Newest testcases are shown first by default. Date means when the testcase was created or imported into the portal.</span>{(search || priority || createdById || sortOrder !== 'newest') && <button type="button" className="link-btn" disabled={busy} onClick={() => { setSearch(''); setPriority(''); setCreatedById(''); setSortOrder('newest') }}>Reset filters</button>}</div>
      {candidateLoading ? (
        <p className="muted small">Loading approved testcases…</p>
      ) : candidates.length === 0 ? (
        <p className="muted small">{search || priority || createdById ? 'No approved testcases match these filters. Change or reset the filters to see other available cases.' : 'There are no approved testcases available to add. Approve pending testcases in the Test Repository first.'}</p>
      ) : (
        <>
          <div className="tm-add-cases-selection-bar">
            <div>
              <strong>{selectedCount ? `${selectedCount.toLocaleString()} testcase${selectedCount !== 1 ? 's' : ''} selected` : 'Select testcases to add'}</strong>
              <span>{candidatePage.total.toLocaleString()} approved testcase{candidatePage.total !== 1 ? 's' : ''} available</span>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              {!selectAllMatching && <button type="button" className="btn btn-sm" onClick={selectEveryMatchingCase} disabled={busy}>Select all matching ({candidatePage.total.toLocaleString()})</button>}
              {selectedCount > 0 && <button type="button" className="btn btn-sm" onClick={clearSelection} disabled={busy}>Clear selection</button>}
            </div>
          </div>
          <Table<TestCaseCandidate>
            tableId="add-testcases-to-cycle"
            rowKey="id"
            rows={candidates}
            onRowClick={(testCase) => toggle(testCase.id)}
            columns={[
              {
                key: 'selection',
                header: <input type="checkbox" aria-label="Select all eligible testcases" checked={allCandidatesSelected} disabled={busy} onChange={toggleAllCandidates} onClick={(event) => event.stopPropagation()} />,
                filterable: false,
                render: (testCase) => <input type="checkbox" aria-label={`Select ${testCase.test_case_key}`} checked={isSelected(testCase.id)} disabled={busy} onChange={() => toggle(testCase.id)} onClick={(event) => event.stopPropagation()} />,
              },
              { key: 'test_case_key', header: 'Test Case ID' },
              { key: 'test_scenario', header: 'Scenario', render: (testCase) => testCase.test_scenario || '—' },
              { key: 'test_type', header: 'Type', render: (testCase) => testCase.test_type || '—' },
              { key: 'priority', header: 'Priority', render: (testCase) => testCase.priority || '—' },
              { key: 'module_name', header: 'Module', render: (testCase) => testCase.module_name || '—' },
              { key: 'created_by_name', header: 'Created By', render: (testCase) => testCase.created_by_name || 'Unknown creator', filterValue: (testCase) => testCase.created_by_name || '' },
              { key: 'created_at', header: 'Upload / Created Date', render: (testCase) => formatDateTimeIST(testCase.created_at), filterValue: (testCase) => formatDateTimeIST(testCase.created_at) },
              { key: 'version', header: 'Version' },
            ]}
            server={{
              page: pageNumber,
              pageSize,
              total: candidatePage.total,
              totalPages: Math.max(1, Math.ceil(candidatePage.total / pageSize)),
              hasNext: candidatePage.has_more,
              hasPrevious: cursorStack.length > 1,
              loading: candidateLoading,
              onPageChange: (nextPage) => {
                if (nextPage > pageNumber && candidatePage.next_cursor != null) setCursorStack((current) => [...current, candidatePage.next_cursor!])
                if (nextPage < pageNumber) setCursorStack((current) => current.slice(0, -1))
              },
            }}
          />
        </>
      )}
      <ErrorText error={error} />
      <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
        <button className="btn btn-primary" disabled={busy || selectedCount === 0 || (requiresScopeChangeReason && scopeChangeReason.trim().length < 10)} onClick={submit}>
          {busy ? 'Adding…' : `Add Selected (${selectedCount.toLocaleString()})`}
        </button>
        <button type="button" className="btn" disabled={busy} onClick={onClose}>Cancel</button>
      </div>
      </div>
    </Modal>
  )
}

function TestCaseDetail({ label, value, wide = false, children }: {
  label: string
  value?: React.ReactNode
  wide?: boolean
  children?: React.ReactNode
}) {
  return (
    <div className={`tm-case-detail ${wide ? 'tm-case-detail-wide' : ''}`}>
      <small>{label}</small>
      <div>{children ?? value ?? '—'}</div>
    </div>
  )
}

function InlineExecutionActions({ execution, canExecute, executionContextError, onChanged, onLinkExisting, onError }: {
  execution: TestExecutionOut
  canExecute: boolean
  executionContextError?: string
  onChanged: (execution: TestExecutionOut) => void
  onLinkExisting: (execution: TestExecutionOut) => void
  onError: (error: unknown) => void
}) {
  const navigate = useInternalNavigate()
  const [open, setOpen] = useState(false)
  const [result, setResult] = useState('')
  const [busy, setBusy] = useState(false)
  const [linkingDefect, setLinkingDefect] = useState(false)
  const [defectKey, setDefectKey] = useState('')
  const [defectUrl, setDefectUrl] = useState('')
  const runButtonRef = useRef<HTMLButtonElement>(null)
  const runPanelRef = useRef<HTMLDivElement>(null)
  const [runPanelPosition, setRunPanelPosition] = useState<{ top: number; left: number; width: number } | null>(null)
  const latestRun = execution.runs?.[execution.runs.length - 1]
  // All distinct findings from the same attempt remain attached to that attempt.
  const latestCanLinkDefect = !!latestRun && ['Fail', 'Blocked'].includes(latestRun.status)

  function toggleRunPanel() {
    if (open) { setOpen(false); return }
    const rect = runButtonRef.current?.getBoundingClientRect()
    if (!rect) return
    const gap = 8
    const viewportGap = 12
    const width = Math.min(330, window.innerWidth - viewportGap * 2)
    const estimatedHeight = 265
    const left = Math.min(Math.max(viewportGap, rect.right - width), window.innerWidth - width - viewportGap)
    const top = window.innerHeight - rect.bottom >= estimatedHeight + gap
      ? rect.bottom + gap
      : Math.max(viewportGap, rect.top - estimatedHeight - gap)
    setRunPanelPosition({ top, left, width })
    setLinkingDefect(false)
    setOpen(true)
  }

  useEffect(() => {
    if (!open) return
    function closeOutside(event: MouseEvent) {
      const target = event.target as Node
      if (!runPanelRef.current?.contains(target) && !runButtonRef.current?.contains(target)) setOpen(false)
    }
    function closeOnMove() { setOpen(false) }
    function closeOnEscape(event: KeyboardEvent) { if (event.key === 'Escape') setOpen(false) }
    document.addEventListener('mousedown', closeOutside)
    document.addEventListener('keydown', closeOnEscape)
    window.addEventListener('resize', closeOnMove)
    window.addEventListener('scroll', closeOnMove, true)
    return () => {
      document.removeEventListener('mousedown', closeOutside)
      document.removeEventListener('keydown', closeOnEscape)
      window.removeEventListener('resize', closeOnMove)
      window.removeEventListener('scroll', closeOnMove, true)
    }
  }, [open])

  async function saveResult() {
    if (!result || !canExecute || executionContextError) return
    setBusy(true)
    try {
      const saved = await api.patch<TestExecutionOut>(`/api/test-execution/executions/${execution.id}`, {
        status: result, actual_result: null, test_run_artifacts: null, defect_id: null,
        // SRS EXE-007 optimistic concurrency -- lets the backend detect and
        // reject a save if someone else already recorded a newer attempt on
        // this exact slot since this row was last loaded into the table.
        expected_run_version: execution.run_version,
      })
      onChanged(saved)
      setResult('')
      setOpen(false)
    } catch (error) { setOpen(false); onError(error) } finally { setBusy(false) }
  }

  async function linkDefect(event: React.FormEvent) {
    event.preventDefault()
    if (!latestRun || !defectKey.trim()) return
    setBusy(true)
    try {
      const defect = await api.post<TestRunDefectOut>(`/api/test-execution/executions/${execution.id}/runs/${latestRun.id}/defects`, {
        defect_key: defectKey.trim(), defect_url: defectUrl.trim() || null, defect_status: 'Open',
      })
      onChanged({ ...execution, runs: (execution.runs || []).map((run) => run.id === latestRun.id ? { ...run, defects: [...(run.defects || []), defect] } : run) })
      setDefectKey(''); setDefectUrl(''); setLinkingDefect(false)
    } catch (error) { onError(error) } finally { setBusy(false) }
  }

  return (
    <div className="tm-inline-run" onClick={(event) => event.stopPropagation()}>
      <button ref={runButtonRef} type="button" className="tm-play-button" disabled={!canExecute || busy} title={executionContextError || (canExecute ? 'Record a result without opening the testcase' : 'Only the assigned runner can execute this testcase')} onClick={toggleRunPanel}><span>▶</span> Run</button>
      {latestCanLinkDefect && canExecute && <button type="button" className="tm-link-last-defect tm-governed-defect" onClick={() => navigate(`/defects?execution=${execution.id}`)}>Raise defect</button>}
      {latestCanLinkDefect && canExecute && <button type="button" className="tm-link-last-defect" onClick={() => onLinkExisting(execution)}>Link existing</button>}
      {latestCanLinkDefect && canExecute && <button type="button" className="tm-link-last-defect" onClick={() => { setLinkingDefect((value) => !value); setOpen(false) }}>Link external</button>}
      {open && runPanelPosition && createPortal(<div ref={runPanelRef} className="tm-inline-run-panel portaled" style={runPanelPosition} onClick={(event) => event.stopPropagation()}>
        <div className="tm-inline-run-head"><span><small>Quick execution</small><strong>Record result</strong></span><b>Attempt #{(execution.run_count || 0) + 1}</b></div>
        <div className="tm-inline-result-options">{TEST_EXECUTION_STATUSES.filter((status) =>
          status !== 'Not Executed' && (status !== 'Retest Passed' || hasRetestEligibleHistory(execution.runs, execution.status))
        ).map((status) => {
          const blocked = executionStatusGate(execution.linked_defects, execution.runs, status, undefined, execution.status, execution.id)
          const tone = status.toLowerCase().replace(/\s+/g, '-')
          return <button type="button" key={status} className={`${result === status ? 'selected ' : ''}result-${tone}`} disabled={!!blocked} title={blocked || undefined} onClick={() => setResult(status)}><i />{status}</button>
        })}</div>
        {result && executionStatusGate(execution.linked_defects, execution.runs, result, undefined, execution.status, execution.id) && (
          <small className="tm-inline-defect-gate-note">{executionStatusGate(execution.linked_defects, execution.runs, result, undefined, execution.status, execution.id)}</small>
        )}
        <div className="tm-inline-run-actions"><span>{result ? `${result} selected` : 'Select one result'}</span><button type="button" className="btn btn-sm" onClick={() => { setResult(''); setOpen(false) }}>Cancel</button><button type="button" className="btn btn-sm btn-primary" disabled={!result || busy || !canExecute || !!executionContextError} onClick={saveResult}>{busy ? 'Saving…' : 'Save attempt'}</button></div>
      </div>, document.body)}
      {linkingDefect && latestRun && <form className="tm-inline-defect-panel" onSubmit={linkDefect}>
        <strong>Link to latest {latestRun.status.toLowerCase()} run</strong><small>Attempt #{latestRun.attempt_no} only</small>
        <input required value={defectKey} onChange={(event) => setDefectKey(event.target.value)} placeholder="External defect reference" />
        <input type="url" value={defectUrl} onChange={(event) => setDefectUrl(event.target.value)} placeholder="Defect URL (optional)" />
        <div className="tm-inline-run-actions"><button type="button" className="btn btn-sm" onClick={() => setLinkingDefect(false)}>Cancel</button><button className="btn btn-sm btn-danger" disabled={busy}>{busy ? 'Linking…' : 'Link external'}</button></div>
      </form>}
    </div>
  )
}

function LinkExistingDefectModal({ execution, onClose, onLinked }: {
  execution: TestExecutionOut; onClose: () => void; onLinked: () => void
}) {
  const [defects, setDefects] = useState<DefectListOut[]>([])
  const [defectId, setDefectId] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<unknown>(null)
  useEffect(() => {
    // Reported directly: this used to send `queue=unlinked` (execution_id
    // IS NULL), so a governed defect already primary-linked to a DIFFERENT
    // execution never showed up here at all -- "instead of [unlinked
    // only], show linked defect as well." Dropped the queue filter; the
    // explicit non-terminal status list alone now reproduces "every open
    // governed defect", linked or not. Picking an already-linked one adds
    // this execution as an ADDITIONAL trace (see routers/defects.py's
    // _link_additional_execution) without moving its original link.
    // Load every page so an older governed defect does not disappear merely
    // because more than 100 open records exist. Triaged is actionable and
    // must be included as well.
    const openStatuses = ['New', 'Triaged', 'Assigned', 'In Progress', 'Resolved', 'Retest', 'Reopened', 'Not a Defect Review', 'Ready for QA', 'QA Testing', 'Business Acceptance', 'Ready for Release', 'Production Verification', 'Deferred']
    const qs = new URLSearchParams({ page_size: '100' })
    openStatuses.forEach((s) => qs.append('status', s))
    let active = true
    async function loadCandidates() {
      const candidates = await api.getAll<DefectListOut>(`/api/defects?${qs.toString()}`)
      if (active) {
        const latestRun = execution.runs?.[execution.runs.length - 1]
        const alreadyLinked = new Set((latestRun?.defects || [])
          .filter(link => link.defect_url?.startsWith('/defects')).map(link => link.defect_key))
        setDefects(candidates.filter(defect => !alreadyLinked.has(defect.defect_key)))
        setError(null)
      }
    }
    loadCandidates().catch((reason) => { if (active) setError(reason) })
    return () => { active = false }
  }, [execution.id, execution.runs])
  async function submit(event: React.FormEvent) {
    event.preventDefault()
    if (!defectId) return
    setBusy(true); setError(null)
    try {
      await api.post(`/api/defects/${defectId}/link-execution`, { execution_id: execution.id })
      onLinked()
    } catch (err) { setError(err); setBusy(false) }
  }
  return <Modal title="Link existing defect" onClose={onClose} closeDisabled={busy} variant="dialog" preventBackdropClose wide>
    <form onSubmit={submit}>
      <div className="defect-trace-banner"><strong>{execution.test_case?.test_case_key} · {execution.status}</strong><span>Select a previously opened governed defect. This execution's Cycle, Test Case, and latest attempt will be linked automatically. A defect already linked elsewhere is added as an additional trace, without disturbing its original link.</span></div>
      <Field label="Governed Defect *"><SearchableSelect value={defectId} onChange={setDefectId} placeholder="Select open defect…" options={defects.map((defect) => ({ value: String(defect.id), label: `${defect.defect_key} · ${defect.title} · ${defect.qa_request_key || 'QA Request'}${defect.execution_id ? ` · already linked to ${defect.cycle_key || 'a cycle'} / ${defect.test_case_key || 'a test case'}` : ''}` }))} /></Field>
      {!defects.length && <p className="muted small">No open defects are available. Use Open Defect in Defect Management first.</p>}
      <ErrorText error={error} title="Defect could not be linked" />
      <div className="modal-actions"><button className="btn btn-primary" disabled={busy || !defectId}>{busy ? 'Linking…' : 'Link Defect'}</button><button type="button" className="btn" onClick={onClose}>Cancel</button></div>
    </form>
  </Modal>
}

// Generic evidence gallery. `basePath` points at either the legacy
// "current attempt" result-images endpoint or a specific historical
// attempt's `/runs/{run_id}/images` endpoint -- both expose the same
// list/download/delete shape, so one component covers both.
function ImageGallery({ basePath, readOnly, emptyText }: { basePath: string; readOnly: boolean; emptyText?: string }) {
  const { user } = useAuth()
  const [documents, setDocuments] = useState<RequestDocumentOut[]>([])
  const [urls, setUrls] = useState<Record<number, string>>({})
  const [error, setError] = useState<unknown>(null)

  useEffect(() => {
    let active = true
    const createdUrls: string[] = []
    async function load() {
      try {
        const docs = await api.get<RequestDocumentOut[]>(basePath)
        if (!active) return
        setDocuments(docs)
        const loaded = await mapWithConcurrency(docs, 3, async (document) => {
          const blob = await api.getBlob(`${basePath}/${document.id}/download`)
          const url = URL.createObjectURL(blob)
          createdUrls.push(url)
          return [document.id, url] as const
        })
        if (active) setUrls(Object.fromEntries(loaded))
      } catch (err) { if (active) setError(err) }
    }
    load()
    return () => { active = false; createdUrls.forEach((url) => URL.revokeObjectURL(url)) }
  }, [basePath])

  async function remove(document: RequestDocumentOut) {
    try {
      setError(null)
      await api.del(`${basePath}/${document.id}`)
      if (urls[document.id]) URL.revokeObjectURL(urls[document.id])
      setDocuments((current) => current.filter((item) => item.id !== document.id))
      setUrls((current) => { const next = { ...current }; delete next[document.id]; return next })
    } catch (err) { setError(err) }
  }

  if (documents.length === 0 && !error) return emptyText ? <p className="muted small">{emptyText}</p> : null
  return (
    <div className="execution-result-images">
      <div className="execution-result-images-title">Screenshots <span>{documents.length}</span></div>
      <div className="jira-comment-attachments">
        {documents.map((document) => urls[document.id] && (
          <div className="execution-result-image" key={document.id}>
            <button type="button" className="jira-comment-image" title={`Open ${document.file_name}`} onClick={() => window.open(urls[document.id], '_blank', 'noopener,noreferrer')}>
              <img src={urls[document.id]} alt={document.file_name} /><span>{document.file_name}</span>
            </button>
            {!readOnly && document.uploaded_by_id === user?.id && <button type="button" className="execution-result-image-remove" title="Delete screenshot" onClick={() => remove(document)}>×</button>}
          </div>
        ))}
      </div>
      <ErrorText error={error} title="Screenshot action failed" />
    </div>
  )
}

// Every save records a brand new, immutable attempt rather than overwriting
// the last one -- so a Fail logged with evidence stays on the record even
// after a later run comes back Pass. This lists every attempt (newest
// first), each expandable to its own actual result and its own screenshots.
function DefectLinks({ executionId, run, readOnly, canUnlinkDefects, canUpdateExternalDefects, onChanged, onExecutionChanged }: {
  executionId: number
  run: TestExecutionRunOut
  readOnly: boolean
  canUnlinkDefects: boolean
  canUpdateExternalDefects: boolean
  onChanged: (defects: TestRunDefectOut[]) => void
  onExecutionChanged: (execution: TestExecutionOut) => void
}) {
  const navigate = useInternalNavigate()
  const { user } = useAuth()
  const [adding, setAdding] = useState(false)
  const [linkMode, setLinkMode] = useState<'internal' | 'external' | null>(null)
  const [internalDefects, setInternalDefects] = useState<DefectListOut[]>([])
  const [internalDefectId, setInternalDefectId] = useState('')
  const [loadingInternal, setLoadingInternal] = useState(false)
  const [key, setKey] = useState('')
  const [url, setUrl] = useState('')
  const [title, setTitle] = useState('')
  const [defectStatus, setDefectStatus] = useState('Open')
  const [notes, setNotes] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<unknown>(null)
  const [pendingRemove, setPendingRemove] = useState<TestRunDefectOut | null>(null)
  const [editingExternal, setEditingExternal] = useState<TestRunDefectOut | null>(null)

  useEffect(() => {
    if (!adding || linkMode !== 'internal') return
    const openStatuses = ['New', 'Triaged', 'Assigned', 'In Progress', 'Resolved', 'Retest', 'Reopened', 'Not a Defect Review', 'Ready for QA', 'QA Testing', 'Business Acceptance', 'Ready for Release', 'Production Verification', 'Deferred']
    const qs = new URLSearchParams({ page_size: '100' })
    openStatuses.forEach((status) => qs.append('status', status))
    let active = true
    setLoadingInternal(true)
    async function loadInternalDefects() {
      const defects = await api.getAll<DefectListOut>(`/api/defects?${qs.toString()}`)
      if (active) {
        const alreadyLinked = new Set((run.defects || []).filter(defect => defect.defect_url?.startsWith('/defects')).map((defect) => defect.defect_key))
        setInternalDefects(defects.filter((defect) => !alreadyLinked.has(defect.defect_key)))
        setError(null)
      }
    }
    loadInternalDefects().catch((reason) => { if (active) setError(reason) }).finally(() => { if (active) setLoadingInternal(false) })
    return () => { active = false }
  }, [adding, linkMode, run.defects])

  async function link(e: React.FormEvent) {
    e.preventDefault()
    if (!key.trim()) { setError(new Error('Defect key is required')); return }
    setBusy(true); setError(null)
    try {
      const created = await api.post<TestRunDefectOut>(`/api/test-execution/executions/${executionId}/runs/${run.id}/defects`, {
        defect_key: key.trim(), defect_url: url.trim() || null, title: title.trim() || null,
        defect_status: defectStatus || null, notes: notes.trim() || null,
      })
      onChanged([...(run.defects || []), created])
      setKey(''); setUrl(''); setTitle(''); setDefectStatus('Open'); setNotes(''); setAdding(false); setLinkMode(null)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  async function linkInternal(e: React.FormEvent) {
    e.preventDefault()
    if (!internalDefectId) { setError(new Error('Select an internal defect')); return }
    setBusy(true); setError(null)
    try {
      await api.post(`/api/defects/${internalDefectId}/link-execution`, { execution_id: executionId })
      const refreshed = await api.get<TestExecutionOut>(`/api/test-execution/executions/${executionId}`)
      const refreshedRun = refreshed.runs?.find((item) => item.id === run.id)
      onChanged(refreshedRun?.defects || run.defects || [])
      onExecutionChanged(refreshed)
      setInternalDefectId(''); setAdding(false); setLinkMode(null)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  function closeLinker() {
    setAdding(false)
    setLinkMode(null)
    setInternalDefectId('')
    setError(null)
  }

  async function unlink() {
    if (!pendingRemove) return
    setBusy(true); setError(null)
    try {
      const refreshed = await api.del<TestExecutionOut>(`/api/test-execution/executions/${executionId}/runs/${run.id}/defects/${pendingRemove.id}`)
      const refreshedRun = refreshed.runs?.find((item) => item.id === run.id)
      onChanged(refreshedRun?.defects || [])
      onExecutionChanged(refreshed)
      setPendingRemove(null)
    } catch (err) { setError(err); setPendingRemove(null) } finally { setBusy(false) }
  }

  function canUnlink(defect: TestRunDefectOut) {
    return canUnlinkExecutionDefect(user, defect.linked_by_id, canUnlinkDefects)
  }

  return (
    <div className="tm-defect-links">
      <div className="tm-defect-links-head"><strong>Linked Defects</strong><span>{run.defects?.length || 0}</span>{!readOnly && <button type="button" className="btn btn-sm" onClick={() => { setAdding((value) => !value); setLinkMode(null); setError(null) }}>+ Link defect</button>}</div>
      {(run.defects || []).length === 0 && <p className="muted small">No defects linked to this attempt.</p>}
      {(run.defects || []).map((defect) => (
        <div className="tm-defect-link" key={defect.id}>
          <div>
            {defect.defect_url?.startsWith('/defects') ? (
              <a
                href={defect.defect_url}
                onClick={(event) => {
                  event.preventDefault()
                  navigate(defect.defect_url!)
                }}
              >
                {defect.defect_key}
              </a>
            ) : defect.defect_url ? (
              <a href={defect.defect_url} target="_blank" rel="noreferrer">{defect.defect_key}</a>
            ) : (
              <strong>{defect.defect_key}</strong>
            )}
            <span>{defect.title || 'No title provided'}</span>
            {defect.notes && <small>{defect.notes}</small>}
          </div>
          {defect.defect_status && <Badge status={defect.defect_status} />}
          {canUpdateExternalDefects && !defect.defect_url?.startsWith('/defects') && <button type="button"
            className="btn btn-sm" disabled={busy} onClick={() => setEditingExternal(defect)}>Update status</button>}
          {canUnlink(defect) && <button type="button" className="tm-defect-unlink" title="Unlink defect" aria-label={`Unlink ${defect.defect_key}`} onClick={() => setPendingRemove(defect)}>×</button>}
        </div>
      ))}
      {adding && !linkMode && <div className="tm-defect-form tm-defect-link-choice">
        <strong>Choose defect source</strong>
        <p>Select an existing governed defect in QualityOps or add a reference from an external defect-management system.</p>
        <div>
          <button type="button" onClick={() => setLinkMode('internal')}><strong>Internal defect</strong><span>Link an existing governed QualityOps defect</span></button>
          <button type="button" onClick={() => setLinkMode('external')}><strong>External reference</strong><span>Add a defect maintained outside QualityOps</span></button>
        </div>
        <button type="button" className="btn btn-sm" onClick={closeLinker}>Cancel</button>
      </div>}
      {adding && linkMode === 'internal' && <form className="tm-defect-form" onSubmit={linkInternal}>
        <div className="tm-defect-form-heading"><div><strong>Link internal defect</strong><small>The selected governed defect will retain its lifecycle and ownership.</small></div><button type="button" className="link-btn" onClick={() => setLinkMode(null)}>Change source</button></div>
        <Field label="Internal Defect *"><SearchableSelect value={internalDefectId} onChange={setInternalDefectId} placeholder={loadingInternal ? 'Loading defects…' : 'Select an open defect…'} disabled={loadingInternal} options={internalDefects.map((defect) => ({ value: String(defect.id), label: `${defect.defect_key} · ${defect.title} · ${defect.status}` }))} /></Field>
        {!loadingInternal && !internalDefects.length && <p className="muted small">No open internal defects are available.</p>}
        <div className="tm-defect-form-actions"><button className="btn btn-primary btn-sm" disabled={busy || loadingInternal || !internalDefectId}>{busy ? 'Linking…' : 'Link internal defect'}</button><button type="button" className="btn btn-sm" onClick={closeLinker}>Cancel</button></div>
      </form>}
      {adding && linkMode === 'external' && <form className="tm-defect-form" onSubmit={link}>
        <div className="tm-defect-form-heading"><div><strong>Link external reference</strong><small>Use the identifier and URL from the external defect-management system.</small></div><button type="button" className="link-btn" onClick={() => setLinkMode(null)}>Change source</button></div>
        <div className="grid grid-2"><Field label="External Defect Reference *"><input required value={key} onChange={(e) => setKey(e.target.value)} placeholder="Enter external defect reference" /></Field><Field label="External Defect Status"><select value={defectStatus} onChange={(e) => setDefectStatus(e.target.value)}><option>Open</option><option>In Progress</option><option>Resolved</option><option>Closed</option><option>Reopened</option></select></Field></div>
        <Field label="External Defect URL"><input type="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://defects.example.com/item/12345" /></Field>
        <Field label="Title"><input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Brief defect summary" /></Field>
        <Field label="Notes"><textarea value={notes} onChange={(e) => setNotes(e.target.value)} /></Field>
        <div className="tm-defect-form-actions"><button className="btn btn-primary btn-sm" disabled={busy}>{busy ? 'Linking…' : 'Link external reference'}</button><button type="button" className="btn btn-sm" onClick={closeLinker}>Cancel</button></div>
      </form>}
      <ErrorText error={error} title="Defect linking failed" />
      {editingExternal && <ExternalDefectStatusModal executionId={executionId} link={editingExternal}
        onClose={() => setEditingExternal(null)} onSaved={updated => {
          onChanged(updated.runs?.find(item => item.id === run.id)?.defects || [])
          onExecutionChanged(updated); setEditingExternal(null)
        }} />}
      {pendingRemove && <ConfirmModal title="Unlink defect?" message={pendingRemove.defect_url?.startsWith('/defects')
        ? <p>Unlink governed defect <strong>{pendingRemove.defect_key}</strong> from this testcase execution? The defect and failed attempt remain in history. This testcase has a previous failed or blocked attempt. A successful retry must be recorded as <strong>Retest Passed</strong>.</p>
        : <p>Remove external defect reference <strong>{pendingRemove.defect_key}</strong> from Attempt #{run.attempt_no}? The external defect itself will not be deleted.</p>}
        confirmLabel="Unlink defect" cancelLabel="Keep link" destructive busy={busy} onConfirm={unlink} onCancel={() => setPendingRemove(null)} />}
    </div>
  )
}

function AttemptHistory({ executionId, readOnly, canUnlinkDefects, onExecutionChanged }: {
  executionId: number
  readOnly: boolean
  canUnlinkDefects: boolean
  onExecutionChanged: (execution: TestExecutionOut) => void
}) {
  const [runs, setRuns] = useState<TestExecutionRunOut[]>([])
  const [expandedId, setExpandedId] = useState<number | null>(null)
  const [error, setError] = useState<unknown>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let active = true
    setLoading(true)
    api.get<TestExecutionRunOut[]>(`/api/test-execution/executions/${executionId}/runs`)
      .then((r) => { if (!active) return; setRuns(r); if (r.length) setExpandedId(r[r.length - 1].id) })
      .catch((err) => { if (active) setError(err) })
      .finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [executionId])

  if (loading) return <p className="muted small">Loading attempt history...</p>
  if (error) return <ErrorText error={error} title="Could not load attempt history" />
  if (runs.length === 0) return <p className="muted small">No attempts recorded yet for this test case.</p>

  return (
    <div className="tm-attempt-history">
      <h4 style={{ marginBottom: 8 }}>Attempt History <span className="badge badge-gray">{runs.length}</span></h4>
      {[...runs].reverse().map((run) => (
        <div key={run.id} style={{ border: '1px solid #e2e2e2', borderRadius: 6, marginBottom: 8 }}>
          <button
            type="button"
            onClick={() => setExpandedId(expandedId === run.id ? null : run.id)}
            style={{ display: 'flex', alignItems: 'center', gap: 12, width: '100%', padding: '8px 12px', background: 'transparent', border: 'none', cursor: 'pointer', textAlign: 'left' }}
          >
            <strong>Attempt #{run.attempt_no}</strong>
            <Badge status={run.status} />
            <span className="muted small">{run.executed_by_name || 'Unknown runner'}</span>
            <span className="muted small">{run.defects?.length || 0} defect{run.defects?.length === 1 ? '' : 's'}</span>
            <span className="muted small" style={{ marginLeft: 'auto' }}>{run.executed_at ? formatDateTimeIST(run.executed_at) : '—'}</span>
            <span>{expandedId === run.id ? '▾' : '▸'}</span>
          </button>
          {expandedId === run.id && (
            <div style={{ padding: '0 12px 12px' }}>
              {run.actual_result ? <AuthenticatedMarkdown value={run.actual_result} basePath={`/api/test-execution/executions/${executionId}/runs/${run.id}/images`} /> : <p className="muted small">No actual result recorded.</p>}
              {run.test_run_artifacts && <p className="small"><strong>Test Run Artifacts:</strong> {run.test_run_artifacts}</p>}
              <DefectLinks executionId={executionId} run={run} readOnly={readOnly || run.id !== runs[runs.length - 1].id || !['Fail', 'Blocked'].includes(run.status)} canUnlinkDefects={canUnlinkDefects} canUpdateExternalDefects={!readOnly} onChanged={(defects) => setRuns((current) => current.map((item) => item.id === run.id ? { ...item, defects } : item))} onExecutionChanged={(updated) => {
                setRuns(updated.runs || [])
                onExecutionChanged(updated)
              }} />
              <ImageGallery
                basePath={`/api/test-execution/executions/${executionId}/runs/${run.id}/images`}
                readOnly={readOnly}
                emptyText="No screenshots attached to this attempt."
              />
            </div>
          )}
        </div>
      ))}
    </div>
  )
}

// CYC-006 -- upgrades an unexecuted, stale-pinned slot straight to the
// testcase's current Approved version. Fetching the testcase's own
// current_approved_version_id (not exposed on TestExecutionOut directly)
// requires one extra lookup, kept local to this small action rather than
// threading it through every caller.
function VersionUpgradeAction({ execution, onUpgraded }: {
  execution: TestExecutionOut
  onUpgraded: (e: TestExecutionOut) => void
}) {
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<unknown>(null)

  async function upgrade() {
    setBusy(true); setError(null)
    try {
      const testCase = await api.get<TestCaseOut>(`/api/test-repository/test-cases/${execution.test_case_id}`)
      if (!testCase.current_approved_version_id) throw new Error('This testcase no longer has an Approved version')
      const saved = await api.post<TestExecutionOut>(`/api/test-execution/executions/${execution.id}/upgrade-version`, {
        target_version_id: testCase.current_approved_version_id,
      })
      onUpgraded(saved)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  return (
    <>
      <button type="button" className="btn btn-sm" onClick={upgrade} disabled={busy} style={{ marginLeft: 8 }}>
        {busy ? 'Upgrading…' : 'Upgrade to latest Approved'}
      </button>
      <ErrorText error={error} />
    </>
  )
}

function RecordResultModal({ execution, readOnly, canUnlinkDefects, canAssign, canReassign, canRemove, removeBlockedReason, runnerCandidates, onAssigned, onExecutionChanged, onClose, onSaved, onRemoved }: {
  execution: TestExecutionOut
  readOnly: boolean
  canUnlinkDefects: boolean
  canAssign: boolean
  canReassign: boolean
  canRemove: boolean
  removeBlockedReason?: string
  runnerCandidates: UserOption[]
  onAssigned: (execution: TestExecutionOut) => void
  onExecutionChanged: (execution: TestExecutionOut) => void
  onClose: () => void
  onSaved: (e: TestExecutionOut) => void
  onRemoved: (id: number) => void
}) {
  // Deliberately blank, not pre-filled from execution's mirrored fields --
  // opening this form logs a fresh attempt, it does not edit the last one.
  const [status, setStatus] = useState('')
  const [actualResult, setActualResult] = useState('')
  const [artifacts, setArtifacts] = useState('')
  const [defectId, setDefectId] = useState('')
  const [defectUrl, setDefectUrl] = useState('')
  const [defectTitle, setDefectTitle] = useState('')
  const [defectStatus, setDefectStatus] = useState('Open')
  const [defectNotes, setDefectNotes] = useState('')
  const [resultImages, setResultImages] = useState<File[]>([])
  const [resultAttachments, setResultAttachments] = useState<File[]>([])
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)
  const [confirmRemove, setConfirmRemove] = useState(false)
  // 2026-08 Reassignment Requirement -- changing (or clearing) an already-
  // assigned runner needs a mandatory reason; hold the picked value here
  // until it's confirmed, same pattern as the cycle-level table control.
  const [pendingReassign, setPendingReassign] = useState<string | null>(null)
  const [reassignReason, setReassignReason] = useState('')
  // Reported directly: reassigning a runner had no visible log anywhere in
  // Test Execution -- the reason was captured and written to the audit
  // trail (reassignment.record_reassignment, entity_type="TEST_CASE"), but
  // that trail was only ever surfaced in Test Repository's own test case
  // activity tab, never here where the reassignment actually happens. Fetch
  // and show it directly under the runner panel instead.
  const [reassignmentHistory, setReassignmentHistory] = useState<ApprovalActionOut[]>([])
  const loadReassignmentHistory = useCallback(() => {
    api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CASE&entity_id=${execution.test_case_id}`)
      .then((items) => setReassignmentHistory(items.filter((item) => item.decision === 'Reassigned')))
      .catch(() => undefined)
  }, [execution.test_case_id])
  useEffect(() => { loadReassignmentHistory() }, [loadReassignmentHistory])

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!status) { setError(new Error('Select a result for this attempt')); return }
    const evidenceError = defectEvidenceError([...resultImages, ...resultAttachments])
    if (evidenceError) { setError(new Error(evidenceError)); return }
    setBusy(true); setError(null)
    try {
      const saved = await api.uploadFormFiles<TestExecutionOut>(
        `/api/test-execution/executions/${execution.id}/rich-result`,
        {
          status, actual_result: actualResult, test_run_artifacts: artifacts,
          defect_id: ['Fail', 'Blocked'].includes(status) ? defectId : '', defect_url: ['Fail', 'Blocked'].includes(status) ? defectUrl : '',
          defect_title: ['Fail', 'Blocked'].includes(status) ? defectTitle : '', defect_status: ['Fail', 'Blocked'].includes(status) ? defectStatus : '',
          defect_notes: ['Fail', 'Blocked'].includes(status) ? defectNotes : '',
        },
        [...resultImages, ...resultAttachments],
      )
      onSaved(saved)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  async function assign(value: string, reason?: string) {
    setBusy(true); setError(null)
    try {
      const saved = await api.patch<TestExecutionOut>(`/api/test-execution/executions/${execution.id}/assign`, {
        assigned_to_id: value ? Number(value) : null,
        ...(reason ? { reason } : {}),
      })
      onAssigned(saved)
      setPendingReassign(null)
      setReassignReason('')
      if (reason) loadReassignmentHistory()
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  function handleAssignChange(value: string) {
    if (execution.assigned_to_id) {
      setPendingReassign(value)
      setReassignReason('')
    } else {
      assign(value)
    }
  }

  async function remove() {
    setBusy(true); setError(null)
    try {
      await api.del(`/api/test-execution/executions/${execution.id}`)
      onRemoved(execution.id)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  const tc = execution.test_case
  // Reported directly, as a full spec: while any linked governed defect is
  // still active (not Deferred/Closed), the whole execution is locked --
  // display the defect id(s)/status and the explanatory message up front,
  // not just a disabled option buried in the Result dropdown below. See
  // constants.ts's executionStatusGate / backend's matching
  // _execution_status_gate for where this is actually enforced.
  const activeLinkedDefects = (execution.linked_defects || []).filter((defect) => defectBlocksExecution(defect, execution.id))
  const activeExternalDefects = activeExternalExecutionDefects(execution.runs)
  const hasPriorFailedOrBlocked = hasRetestEligibleHistory(execution.runs, execution.status)
  const validChangeRequestDisposition = (execution.linked_defects || []).some((defect) => defect.status === 'Change Request Raised' && !!defect.related_cr_number?.trim())
  return (
    <Modal title={`Record Result -- ${tc?.test_case_key || `Test Case #${execution.test_case_id}`}`} onClose={onClose} wide>
      {execution.pinned_version_id && (
        <WarningNotice className={`info-banner ${execution.is_pinned_stale ? 'warning' : ''}`} active={execution.is_pinned_stale}>
          This slot is pinned to <strong>v{execution.pinned_version_label}</strong>
          {execution.is_pinned_stale && !execution.run_count ? (
            <> -- a newer Approved version now exists. <VersionUpgradeAction execution={execution} onUpgraded={onSaved} /></>
          ) : execution.is_pinned_stale ? (
            <> -- a newer Approved version now exists, but this slot already has execution history and remains permanently pinned (CYC-006).</>
          ) : (
            <> -- the exact version selected when this testcase was added to the cycle, regardless of later edits.</>
          )}
        </WarningNotice>
      )}
      {tc && (
        <div className="tm-execution-case-summary">
          <div className="tm-execution-case-heading">
            <div><small>Test case definition</small><h4>{tc.test_case_key} <span className="badge badge-gray">{`v${execution.pinned_version_label || tc.version || '1.0'}`}</span></h4></div>
            <Badge status={tc.status} />
          </div>
          <div className="tm-case-detail-grid">
            <TestCaseDetail label="Pinned Version">
              <span className="badge badge-gray">{`v${execution.pinned_version_label || tc.version || '1.0'}`}</span>
              <small style={{ display: 'block', marginTop: 4 }}>The exact version this cycle slot was pinned to when added -- frozen once any attempt is recorded (SRS CYC-004/CYC-006).</small>
            </TestCaseDetail>
            <TestCaseDetail label="Epic ID" value={tc.epic_id} />
            <TestCaseDetail label="CR Number" value={tc.cr_number} />
            <TestCaseDetail label="Feature ID" value={tc.feature_id} />
            <TestCaseDetail label="User Story ID" value={tc.user_story_id} />
            <TestCaseDetail label="Test Type" value={tc.test_type} />
            <TestCaseDetail label="Module" value={tc.module_name} />
            <TestCaseDetail label="Repository Folder" value={tc.folder_name || 'Unfiled'} />
            <TestCaseDetail label="Priority">
              {tc.priority ? <Badge status={tc.priority} /> : '—'}
            </TestCaseDetail>
            <TestCaseDetail label="Repository Status" value={tc.status} />
            <TestCaseDetail label="Test Scenario" value={tc.test_scenario} wide />
            <TestCaseDetail label="Pre-Condition" value={tc.pre_condition} wide />
            <TestCaseDetail label="Description" value={tc.description} wide />
            <TestCaseDetail label="Created By" value={tc.created_by_name} />
            <TestCaseDetail label="Created At" value={tc.created_at ? formatDateTimeIST(tc.created_at) : '—'} />
            <TestCaseDetail label="Last Updated" value={tc.updated_at ? formatDateTimeIST(tc.updated_at) : '—'} />
          </div>
          <div className="tm-execution-steps">
            <h4>Test Steps <span>{tc.steps.length}</span></h4>
          {tc.steps.length > 0 ? (
            <table className="simple-table">
              <thead><tr><th>#</th><th>Step</th><th>Expected Result</th></tr></thead>
              <tbody>{tc.steps.map((s, i) => <tr key={s.id}><td>{s.step_no || i + 1}</td><td>{s.step_text || '—'}</td><td>{s.expected_result || '—'}</td></tr>)}</tbody>
            </table>
          ) : <p className="muted small">No steps are defined for this test case.</p>}
          </div>
        </div>
      )}
      <div className="tm-execution-result-heading"><h4>Execution Result</h4>{readOnly && <span>Read only</span>}</div>
      <div className={`tm-runner-panel ${execution.assigned_to_id ? '' : 'unassigned'}`}>
        <div><small>Assigned runner</small><strong>{execution.assigned_to_name || 'Unassigned'}</strong>{execution.assigned_at && <span>Assigned {formatDateTimeIST(execution.assigned_at)}{execution.assigned_by_name ? ` by ${execution.assigned_by_name}` : ''}</span>}</div>
        {(execution.assigned_to_id ? canReassign : canAssign) && <div className="tm-runner-control"><UserAssignSelect value={execution.assigned_to_id ? String(execution.assigned_to_id) : ''} onChange={handleAssignChange} users={runnerCandidates} placeholder="Assign QA runner…" disabled={busy} />{execution.assigned_to_id && <button type="button" className="btn btn-sm" disabled={busy} onClick={() => handleAssignChange('')}>Unassign</button>}</div>}
        {pendingReassign !== null && (
          <div className="tm-reassign-confirm">
            <input
              type="text"
              className="reassign-reason-input"
              placeholder="Reassignment reason (required)…"
              value={reassignReason}
              onChange={(e) => setReassignReason(e.target.value)}
              autoFocus
            />
            <button type="button" className="btn btn-sm btn-primary" disabled={busy || !reassignReason.trim()} onClick={() => assign(pendingReassign, reassignReason.trim())}>
              {busy ? 'Confirming…' : 'Confirm'}
            </button>
            <button type="button" className="btn btn-sm" disabled={busy} onClick={() => { setPendingReassign(null); setReassignReason('') }}>Cancel</button>
          </div>
        )}
      </div>
      {reassignmentHistory.length > 0 && (
        <div className="tm-reassignment-history">
          <h5>Reassignment history <span className="badge badge-gray">{reassignmentHistory.length}</span></h5>
          <ul>
            {reassignmentHistory.map((item) => (
              <li key={item.id}>
                <strong>{item.previous_state || 'Unassigned'} → {item.new_state || 'Unassigned'}</strong>
                <span> · {item.actor_name || 'Unknown'} · {formatDateTimeIST(item.created_at)}</span>
                {item.comments && <p>{item.comments}</p>}
              </li>
            ))}
          </ul>
        </div>
      )}
      {!execution.assigned_to_id && <div className="info-banner">A workspace QA Engineer or QA Lead must assign this testcase before an execution attempt can be recorded.</div>}
      {execution.assigned_to_id && readOnly && <div className="info-banner">Only the assigned runner can record the next attempt. Any QA Engineer or QA Lead in this workspace can reassign the testcase when needed.</div>}
      {activeLinkedDefects.length > 0 && (
        <WarningNotice className="info-banner warning">
          <strong>Verification required:</strong> Linked defect verification does not cover this execution
          {' '}({activeLinkedDefects.map((d) => `${d.defect_key} · ${d.status}`).join(', ')}). The execution
          status cannot be changed until verification requirements are met. Check the environment in Edit Cycle. Build numbers remain visible as audit evidence, but do not need to match the cycle build.
        </WarningNotice>
      )}
      {activeExternalDefects.length > 0 && <div className="info-banner warning">
        External defects still need resolution: {activeExternalDefects.map(defect => `${defect.defect_key} · ${defect.defect_status || 'Open'}`).join(', ')}.
        Confirm their status in the external tracker, then use Update status in Attempt History to record Resolved or Closed before retesting.
      </div>}
      {activeLinkedDefects.length === 0 && activeExternalDefects.length === 0 && hasPriorFailedOrBlocked && (
        <div className="info-banner">
          {validChangeRequestDisposition ? <>The finding was converted to a referenced Change Request. Preserve the original failed attempt and select <strong>NA</strong> for the current scope.</> : <>The linked defect verification requirements are satisfied. Please retest the test case and select <strong>Retest Passed</strong> if it passes, or <strong>Fail</strong> if it fails again.</>}
        </div>
      )}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '4px 0 16px' }}>
        <span className="muted small">Latest result:</span>
        <Badge status={execution.status} />
        {execution.executed_at && <span className="muted small">as of {formatDateTimeIST(execution.executed_at)}</span>}
      </div>
      <AttemptHistory executionId={execution.id} readOnly={readOnly} canUnlinkDefects={canUnlinkDefects} onExecutionChanged={onExecutionChanged} />
      {!readOnly && (
        <form onSubmit={submit} style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid #e2e2e2' }}>
          <h4>Log New Attempt</h4>
          <Field label="Result *">
            <select required value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="" disabled>Select result...</option>
              {TEST_EXECUTION_STATUSES.filter((s) =>
                s !== 'Not Executed' && (s !== 'Retest Passed' || hasPriorFailedOrBlocked)
              ).map((s) => {
                const blocked = executionStatusGate(execution.linked_defects, execution.runs, s, defectId, execution.status, execution.id)
                return <option key={s} value={s} disabled={!!blocked}>{s}{blocked ? ' (locked)' : ''}</option>
              })}
            </select>
            {status && executionStatusGate(execution.linked_defects, execution.runs, status, defectId, execution.status, execution.id) && (
              <small className="tm-inline-defect-gate-note">{executionStatusGate(execution.linked_defects, execution.runs, status, defectId, execution.status, execution.id)}</small>
            )}
          </Field>
          <Field label="Actual Result">
            <JiraRichTextField value={actualResult} onChange={setActualResult} onImagesChange={setResultImages} />
          </Field>
          <Field label="Execution Evidence">
            <div className="defect-evidence">
              <label className="btn btn-sm">+ Add attachments
                <input
                  type="file" multiple hidden
                  accept={DEFECT_EVIDENCE_EXTENSIONS.join(',')}
                  onChange={(event) => {
                    const files = Array.from(event.target.files || [])
                    if (files.length) setResultAttachments(current => [...current, ...files])
                    event.target.value = ''
                  }}
                />
              </label>
              {resultAttachments.length > 0 && <div className="defect-files">{resultAttachments.map((file, index) => (
                <button type="button" key={`${file.name}-${file.size}-${index}`} disabled={busy}
                  onClick={() => setResultAttachments(current => current.filter((_, fileIndex) => fileIndex !== index))}>
                  {file.name} ✕
                </button>
              ))}</div>}
              <small className="muted">Documents, images, MP4, MOV, WebM, or AVI; maximum 25 MB per file.</small>
            </div>
          </Field>
          <Field label="Test Run Artifacts">
            <input value={artifacts} onChange={(e) => setArtifacts(e.target.value)} placeholder="Link, filename, or reference" />
          </Field>
          {['Fail', 'Blocked'].includes(status) && <div className="tm-new-attempt-defect">
            <div className="tm-new-attempt-defect-head">
              <strong>Link a defect to this attempt</strong>
              <span>
                {status === 'Fail' && (execution.runs || []).some((run) => run.status === 'Fail')
                  ? 'Required -- reopen the existing defect, link another active one, or reference a newly created one'
                  : 'Optional · More defects can be linked from Attempt History'}
              </span>
            </div>
            <div className="grid grid-2"><Field label="Defect Reference"><input value={defectId} onChange={(e) => setDefectId(e.target.value)} placeholder="Enter defect reference" /></Field><Field label="Defect Status"><select value={defectStatus} onChange={(e) => setDefectStatus(e.target.value)}><option>Open</option><option>In Progress</option><option>Resolved</option><option>Closed</option><option>Reopened</option></select></Field></div>
            <Field label="Defect URL"><input type="url" value={defectUrl} onChange={(e) => setDefectUrl(e.target.value)} placeholder="https://defects.example.com/item/12345" /></Field>
            <Field label="Defect Title"><input value={defectTitle} onChange={(e) => setDefectTitle(e.target.value)} placeholder="Short defect summary" /></Field>
            <Field label="Defect Notes"><textarea value={defectNotes} onChange={(e) => setDefectNotes(e.target.value)} /></Field>
          </div>}
          <ErrorText error={error} />
          <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
            <button className="btn btn-primary" disabled={busy || !status || actualResult.length > 10000}>{busy ? 'Saving...' : 'Save Attempt'}</button>
            <button type="button" className="btn" onClick={onClose}>Cancel</button>
            {canRemove && (
              <button type="button" className="btn btn-danger" onClick={() => setConfirmRemove(true)} disabled={busy}>Remove from Cycle</button>
            )}
          </div>
          {!canRemove && removeBlockedReason && <p className="muted small" style={{ marginTop: 8 }}>{removeBlockedReason}</p>}
        </form>
      )}
      {readOnly && (
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <button type="button" className="btn" onClick={onClose}>Close</button>
          {canRemove && (
            <button type="button" className="btn btn-danger" onClick={() => setConfirmRemove(true)}>Remove from Cycle</button>
          )}
        </div>
      )}
      {confirmRemove && (
        <ConfirmModal
          title="Remove test case from cycle?"
          message={<p>Remove <strong>{tc?.test_case_key || `Test Case #${execution.test_case_id}`}</strong> and its recorded result from this cycle?</p>}
          confirmLabel="Remove from cycle" cancelLabel="Keep in cycle" destructive busy={busy}
          onConfirm={remove} onCancel={() => setConfirmRemove(false)}
        />
      )}
    </Modal>
  )
}

function BulkExecutionModal({ cycleId, executions, onClose, onExecuted }: {
  cycleId: number
  executions: TestExecutionOut[]
  onClose: () => void
  onExecuted: (executions: TestExecutionOut[]) => void
}) {
  type BulkExecutionStage = 'edit' | 'confirm' | 'executing' | 'success' | 'error'
  const [selectedExecutions] = useState(executions)
  const [stage, setStage] = useState<BulkExecutionStage>('edit')
  const [status, setStatus] = useState('')
  const [actualResult, setActualResult] = useState('')
  const [artifacts, setArtifacts] = useState('')
  const [defectId, setDefectId] = useState('')
  const [defectUrl, setDefectUrl] = useState('')
  const [defectTitle, setDefectTitle] = useState('')
  const [defectStatus, setDefectStatus] = useState('Open')
  const [defectNotes, setDefectNotes] = useState('')
  const [error, setError] = useState<unknown>(null)
  const [progress, setProgress] = useState(0)
  const [progressMessage, setProgressMessage] = useState('Waiting to start')

  // Same lock/gate as the single-execution path (executionStatusGate) --
  // checked for the whole selection so a blocked bulk status change is
  // caught before Confirm rather than after the backend rejects it (which
  // still happens regardless, see _execution_status_gate).
  const defectBlocked = selectedExecutions
    .map((execution) => ({ execution, violation: executionStatusGate(execution.linked_defects, execution.runs, status, defectId, execution.status, execution.id) }))
    .filter((row): row is { execution: TestExecutionOut; violation: string } => !!row.violation)

  function review(e: React.FormEvent) {
    e.preventDefault()
    if (!status) { setError(new Error('Select an execution result')); return }
    if (actualResult.length > 10000) { setError(new Error('Actual Result cannot exceed 10,000 characters')); return }
    if (defectBlocked.length) {
      setError(new Error(
        `Cannot record '${status}': ` + defectBlocked
          .map((row) => `${row.execution.test_case?.test_case_key || `#${row.execution.test_case_id}`} (${row.violation})`)
          .join('; '),
      ))
      return
    }
    setError(null)
    setStage('confirm')
  }

  async function execute() {
    setError(null)
    setStage('executing')
    setProgress(8)
    setProgressMessage('Validating testcase ownership and readiness…')
    const startedAt = Date.now()
    const timer = window.setInterval(() => {
      setProgress((current) => {
        const next = Math.min(88, current + (current < 50 ? 10 : 5))
        setProgressMessage(next >= 62 ? 'Recording retained execution attempts…' : 'Validating the complete selection…')
        return next
      })
    }, 280)
    try {
      const saved = await api.post<TestExecutionOut[]>(`/api/test-execution/cycles/${cycleId}/executions/bulk-result`, {
        execution_ids: selectedExecutions.map((execution) => execution.id),
        status,
        actual_result: actualResult || null,
        test_run_artifacts: artifacts || null,
        defect_id: ['Fail', 'Blocked'].includes(status) ? defectId || null : null,
        defect_url: ['Fail', 'Blocked'].includes(status) ? defectUrl || null : null,
        defect_title: ['Fail', 'Blocked'].includes(status) ? defectTitle || null : null,
        defect_status: ['Fail', 'Blocked'].includes(status) && defectId ? defectStatus : null,
        defect_notes: ['Fail', 'Blocked'].includes(status) ? defectNotes || null : null,
      })
      const remainingDisplayTime = Math.max(0, 750 - (Date.now() - startedAt))
      if (remainingDisplayTime) await new Promise((resolve) => window.setTimeout(resolve, remainingDisplayTime))
      window.clearInterval(timer)
      setProgress(100)
      setProgressMessage(`${saved.length} testcase attempt${saved.length !== 1 ? 's' : ''} recorded as ${status}`)
      onExecuted(saved)
      setStage('success')
    } catch (err) {
      window.clearInterval(timer)
      setError(err)
      setStage('error')
    }
  }

  const errorReason = error instanceof Error ? error.message : String(error || 'The server did not provide an error reason.')
  const selectionCount = selectedExecutions.length
  const title = stage === 'executing' ? 'Executing selected testcases'
    : stage === 'success' ? `${selectionActionLabel(selectionCount, 'execution')} completed`
      : stage === 'error' ? `${selectionActionLabel(selectionCount, 'execution')} stopped`
        : stage === 'confirm' ? `Confirm ${selectionCount > 1 ? 'bulk ' : ''}execution`
          : `${selectionActionLabel(selectionCount, 'execute')} ${selectionCount} testcase${selectionCount !== 1 ? 's' : ''}`
  const preview = selectedExecutions.slice(0, 6).map((execution) => execution.test_case?.test_case_key || `#${execution.test_case_id}`)

  return (
    <Modal title={title} onClose={onClose} closeDisabled={stage === 'executing'} variant="dialog" preventBackdropClose wide>
      {stage === 'edit' && (
        <form onSubmit={review}>
          <div className="tm-bulk-confirm-count"><strong>{selectedExecutions.length}</strong><span>assigned testcase{selectedExecutions.length !== 1 ? 's' : ''} selected for a new attempt</span></div>
          <Field label="Execution Result *">
            <select required value={status} onChange={(event) => setStatus(event.target.value)}>
              <option value="" disabled>Select result…</option>
              {TEST_EXECUTION_STATUSES.filter((item) =>
                item !== 'Not Executed'
                && (item !== 'Retest Passed' || selectedExecutions.every((execution) => hasRetestEligibleHistory(execution.runs, execution.status)))
              ).map((item) => <option key={item} value={item}>{item}</option>)}
            </select>
          </Field>
          <Field label="Common Actual Result">
            <JiraRichTextField value={actualResult} onChange={setActualResult} onImagesChange={() => undefined} allowImages={false} />
          </Field>
          <Field label="Common Test Run Artifact">
            <input maxLength={255} value={artifacts} onChange={(event) => setArtifacts(event.target.value)} placeholder="Shared link, build number, filename, or reference" />
          </Field>
          {['Fail', 'Blocked'].includes(status) && <div className="tm-new-attempt-defect">
            <div className="tm-new-attempt-defect-head"><strong>Link one shared defect</strong><span>Optional · Added to every selected attempt</span></div>
            <div className="grid grid-2"><Field label="Defect Reference"><input value={defectId} onChange={(event) => setDefectId(event.target.value)} placeholder="Enter defect reference" /></Field><Field label="Defect Status"><select value={defectStatus} onChange={(event) => setDefectStatus(event.target.value)}><option>Open</option><option>In Progress</option><option>Resolved</option><option>Closed</option><option>Reopened</option></select></Field></div>
            <Field label="Defect URL"><input type="url" value={defectUrl} onChange={(event) => setDefectUrl(event.target.value)} placeholder="https://defects.example.com/item/12345" /></Field>
            <Field label="Defect Title"><input maxLength={255} value={defectTitle} onChange={(event) => setDefectTitle(event.target.value)} placeholder="Short defect summary" /></Field>
            <Field label="Defect Notes"><textarea maxLength={5000} value={defectNotes} onChange={(event) => setDefectNotes(event.target.value)} /></Field>
          </div>}
          <div className="info-banner">{selectionActionLabel(selectionCount, 'execution')} records the same result as a separate retained attempt on every selected testcase. Add testcase-specific screenshots or defects from the individual runner afterward.</div>
          <ErrorText error={error} />
          <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
            <button className="btn btn-primary">Review {selectionCount > 1 ? 'bulk ' : ''}execution</button>
            <button type="button" className="btn" onClick={onClose}>Cancel</button>
          </div>
        </form>
      )}
      {stage === 'confirm' && (
        <div className="tm-bulk-confirm">
          <div className="tm-bulk-confirm-count"><strong>{selectedExecutions.length}</strong><span>new attempt{selectedExecutions.length !== 1 ? 's' : ''} will be recorded as {status}</span></div>
          <p>Selected testcases: {preview.join(', ')}{selectedExecutions.length > preview.length ? ` and ${selectedExecutions.length - preview.length} more` : ''}.</p>
          <ul>
            <li>Existing attempts and evidence will remain unchanged.</li>
            <li>The operation is atomic: validation failure means no testcase is updated.</li>
            <li>Only testcases currently assigned to you can be executed together.</li>
          </ul>
          <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
            <button className="btn btn-primary" onClick={execute}>Confirm and execute</button>
            <button className="btn" onClick={() => setStage('edit')}>Back</button>
            <button className="btn" onClick={onClose}>Cancel</button>
          </div>
        </div>
      )}
      {(stage === 'executing' || stage === 'success') && (
        <div className={`tm-operation-state ${stage === 'success' ? 'success' : ''}`} aria-live="polite">
          <div className="tm-operation-icon">{stage === 'success' ? '✓' : '↻'}</div>
          <strong>{progressMessage}</strong>
          <div className="tm-progress-track" role="progressbar" aria-label={`${selectionActionLabel(selectionCount, 'execution')} progress`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={progress}><span style={{ width: `${progress}%` }} /></div>
          <div className="tm-progress-meta"><span>{progress < 100 ? 'Please keep this dialog open' : 'The new attempts are now visible in this cycle'}</span><strong>{progress}%</strong></div>
          {stage === 'success' && <button className="btn btn-primary" onClick={onClose}>Done</button>}
        </div>
      )}
      {stage === 'error' && (
        <div className="tm-operation-state error" role="alert">
          <div className="tm-operation-icon">!</div>
          <strong>No execution attempt was recorded</strong>
          <p className="muted small">The complete selection remains unchanged because this operation is atomic.</p>
          <div className="tm-progress-track" role="progressbar" aria-label={`${selectionActionLabel(selectionCount, 'execution')} stopped progress`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={progress}><span style={{ width: `${progress}%` }} /></div>
          <div className="tm-progress-meta"><span>Stopped during validation or saving</span><strong>{progress}%</strong></div>
          <div className="tm-operation-error"><strong>Exact reason</strong><p>{errorReason}</p></div>
          <div className="action-error-guidance"><strong>What to do</strong><p>Resolve the listed assignment or approval issue, or select only eligible testcases, then try again.</p></div>
          <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
            <button className="btn btn-primary" onClick={execute}>Try again</button>
            <button className="btn" onClick={() => { setError(null); setStage('edit') }}>Change result</button>
            <button className="btn" onClick={onClose}>Close</button>
          </div>
        </div>
      )}
    </Modal>
  )
}

interface BulkRemoveResult {
  removed_count: number
  removed_execution_ids: number[]
  removed_test_case_keys: string[]
  removed_attempt_count: number
  removed_evidence_count: number
}

function BulkRemoveModal({ cycleId, cycleKey, executions, eligibility, onClose, onRemoved }: {
  cycleId: number
  cycleKey: string
  executions: TestExecutionOut[]
  eligibility: (execution: TestExecutionOut) => { eligible: boolean; reason?: string }
  onClose: () => void
  onRemoved: (result: BulkRemoveResult) => void
}) {
  type BulkRemoveStage = 'confirm' | 'removing' | 'success' | 'error'
  const [selectedExecutions] = useState(executions)
  const [stage, setStage] = useState<BulkRemoveStage>('confirm')
  const [progress, setProgress] = useState(0)
  const [progressMessage, setProgressMessage] = useState('Waiting for confirmation')
  const [error, setError] = useState<unknown>(null)
  const [result, setResult] = useState<BulkRemoveResult | null>(null)
  // Reported directly (refined by Scenario 1's self-remove carve-out): a
  // slot is only removable once its full eligibility rule passes -- Admin
  // always; QA Lead Group any not-yet-executed slot; a plain QA_ENGINEER
  // only one they personally added, and only before it's been executed;
  // anything with recorded history, Admin only. See removeFromCycleEligibility
  // in the parent component for the exact rule. Mirrors TestRepository.tsx's
  // deletableSelectedIds/governedSelectedIds split -- the request stays
  // atomic (all removable ids in one call) but silently excludes what the
  // backend would reject anyway, rather than letting the whole batch fail
  // on one blocked item.
  const removableExecutions = selectedExecutions.filter((execution) => eligibility(execution).eligible)
  const blockedExecutions = selectedExecutions.filter((execution) => !eligibility(execution).eligible)
  const runCount = selectedExecutions.reduce((total, execution) => total + (execution.run_count || execution.runs?.length || 0), 0)
  const defectCount = selectedExecutions.reduce((total, execution) => total + (execution.runs || []).reduce((runTotal, run) => runTotal + (run.defects?.length || 0), 0), 0)
  const preview = selectedExecutions.slice(0, 6).map((execution) => execution.test_case?.test_case_key || `#${execution.test_case_id}`)

  async function remove() {
    if (!removableExecutions.length) return
    setError(null)
    setStage('removing')
    setProgress(8)
    setProgressMessage('Validating cycle membership and permissions…')
    const startedAt = Date.now()
    const timer = window.setInterval(() => {
      setProgress((current) => {
        const next = Math.min(88, current + (current < 50 ? 10 : 5))
        setProgressMessage(next >= 62 ? 'Removing testcase history and evidence…' : 'Preparing the atomic removal…')
        return next
      })
    }, 280)
    try {
      const saved = await api.post<BulkRemoveResult>(`/api/test-execution/cycles/${cycleId}/executions/bulk-remove`, {
        execution_ids: removableExecutions.map((execution) => execution.id),
      })
      const remainingDisplayTime = Math.max(0, 750 - (Date.now() - startedAt))
      if (remainingDisplayTime) await new Promise((resolve) => window.setTimeout(resolve, remainingDisplayTime))
      window.clearInterval(timer)
      setProgress(100)
      setProgressMessage(`${saved.removed_count} testcase${saved.removed_count !== 1 ? 's' : ''} removed from ${cycleKey}`)
      setResult(saved)
      onRemoved(saved)
      setStage('success')
    } catch (err) {
      window.clearInterval(timer)
      setError(err)
      setStage('error')
    }
  }

  const errorReason = error instanceof Error ? error.message : String(error || 'The server did not provide an error reason.')
  const selectionCount = selectedExecutions.length
  const title = stage === 'removing' ? 'Removing testcases from cycle'
    : stage === 'success' ? `${selectionActionLabel(selectionCount, 'removal')} completed`
      : stage === 'error' ? `${selectionActionLabel(selectionCount, 'removal')} stopped`
        : `Remove ${selectedExecutions.length} testcase${selectedExecutions.length !== 1 ? 's' : ''} from ${cycleKey}?`

  return (
    <Modal title={title} onClose={onClose} closeDisabled={stage === 'removing'} variant="dialog" preventBackdropClose>
      {stage === 'confirm' && (
        <div className="tm-bulk-confirm">
          <div className="tm-bulk-confirm-count"><strong>{removableExecutions.length}</strong><span>testcase{removableExecutions.length !== 1 ? 's' : ''} will leave this test cycle</span></div>
          <p>Selected testcases: {preview.join(', ')}{selectedExecutions.length > preview.length ? ` and ${selectedExecutions.length - preview.length} more` : ''}.</p>
          {blockedExecutions.length > 0 && (
            <p className="muted small">
              {blockedExecutions.length} of the {selectedExecutions.length} selected will be skipped -- you're not
              eligible to remove {blockedExecutions.length !== 1 ? 'them' : 'it'} right now:{' '}
              {blockedExecutions.slice(0, 5).map((execution) => execution.test_case?.test_case_key || `#${execution.test_case_id}`).join(', ')}
              {blockedExecutions.length > 5 ? ` and ${blockedExecutions.length - 5} more` : ''}.
            </p>
          )}
          <div className="action-error-dialog" role="alert">
            <div className="action-error-dialog-icon">!</div>
            <div><strong>This permanently removes lifecycle history</strong><span>Removal impact</span><p>{runCount} execution attempt{runCount !== 1 ? 's' : ''}, {defectCount} linked defect{defectCount !== 1 ? 's' : ''}, and all attached execution evidence for these cycle entries will be deleted. Repository testcase definitions are not deleted.</p></div>
          </div>
          <p className="muted small">The database operation is atomic. If validation or saving fails, every selected cycle entry remains unchanged.</p>
          <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
            <button className="btn btn-danger" onClick={remove} disabled={!removableExecutions.length}>Remove from cycle{removableExecutions.length ? ` (${removableExecutions.length})` : ''}</button>
            <button className="btn" onClick={onClose}>Keep testcases</button>
          </div>
        </div>
      )}
      {(stage === 'removing' || stage === 'success') && (
        <div className={`tm-operation-state ${stage === 'success' ? 'success' : ''}`} aria-live="polite">
          <div className="tm-operation-icon">{stage === 'success' ? '✓' : '↻'}</div>
          <strong>{progressMessage}</strong>
          <div className="tm-progress-track" role="progressbar" aria-label={`${selectionActionLabel(selectionCount, 'removal')} progress`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={progress}><span style={{ width: `${progress}%` }} /></div>
          <div className="tm-progress-meta"><span>{progress < 100 ? 'Please keep this dialog open' : `${result?.removed_attempt_count || 0} attempts and ${result?.removed_evidence_count || 0} evidence files removed`}</span><strong>{progress}%</strong></div>
          {stage === 'success' && <button className="btn btn-primary" onClick={onClose}>Done</button>}
        </div>
      )}
      {stage === 'error' && (
        <div className="tm-operation-state error" role="alert">
          <div className="tm-operation-icon">!</div>
          <strong>Nothing was removed</strong>
          <p className="muted small">The complete selection remains in the cycle because this operation is atomic.</p>
          <div className="tm-progress-track" role="progressbar" aria-label={`${selectionActionLabel(selectionCount, 'removal')} stopped progress`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={progress}><span style={{ width: `${progress}%` }} /></div>
          <div className="tm-progress-meta"><span>Stopped during validation or saving</span><strong>{progress}%</strong></div>
          <div className="tm-operation-error"><strong>Exact reason</strong><p>{errorReason}</p></div>
          <div className="action-error-guidance"><strong>What to do</strong><p>Confirm that the project is active and every selected testcase still belongs to this cycle, then try again.</p></div>
          <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
            <button className="btn btn-primary" onClick={remove}>Try again</button>
            <button className="btn" onClick={onClose}>Close</button>
          </div>
        </div>
      )}
    </Modal>
  )
}

export default function TestExecution() {
  const [searchParams, setSearchParams] = useSearchParams()
  const { user } = useAuth()
  // SRS PRJ-005/GOV-001 -- a project's own membership role can further
  // restrict a QA_ENGINEER/QA_LEAD on THIS specific project, same pattern as
  // TestRepository.tsx's own `myAccess`. Defaults permissive while loading.
  const [myAccess, setMyAccess] = useState<TestProjectMyAccessOut | null>(null)
  const canExec = hasRole(user, ...CAN_EXEC_ROLES) && (myAccess?.can_execute ?? true)
  // 2026-08 -- reported directly: role gate shared by Delete Cycle and
  // Remove-from-cycle (single + bulk) now, both QA Lead Group only. Was
  // previously `hasRole(user, ...CAN_EXEC_ROLES)` for canDeleteCycle, which
  // doesn't include AGM_QA even though myAccess.can_manage_execution_
  // governance already correctly reflects AGM_QA on the backend -- fixed
  // here since it's the exact permission this change is about.
  const canManageExecutionGovernance = hasRole(user, ...QA_LEAD_GROUP_ROLES) && (myAccess?.can_manage_execution_governance ?? false)
  const canDeleteCycle = canManageExecutionGovernance
  const canManageRunners = hasRole(user, ...CAN_EXEC_ROLES)
    && hasWorkspaceRole(user, 'QA_ENGINEER', 'QA_LEAD', 'CHIEF_MANAGER_QA', 'AGM_QA')
  // 2026-08 Reassignment Requirement -- initially narrowed reassigning an
  // already-assigned runner to the current runner / workspace QA Executive /
  // Admin, same as every other reassignment flow. Reported directly again:
  // "for test execution reassignment of testcase can be perform by any QA
  // user, otherwise it will be hectic for qa lead" -- unlike Functional/
  // Performance tester and SAST/DAST analyst reassignment, runner
  // reassignment stays on the SAME broad canManageRunners gate as the first
  // assignment (mirrors backend's assign_execution/bulk_assign_executions,
  // which now call _require_qa_assignment_manager unconditionally). A
  // reason is still mandatory once a runner is already assigned -- this
  // only affects who can see/use the control, not whether a reason is
  // required. Kept as a function (not a plain boolean) since every call
  // site already expects one, and other reassignment flows in this same
  // file use the same shape.
  const canReassignExecution = useCallback((_execution: TestExecutionOut) => canManageRunners, [canManageRunners])
  // Reported directly, refined by Scenario 1 ("tester add testcase in
  // lifecycle, but not executed it, just added ... might be by mistake ...
  // now system should allow to remove from lifecycle as there are no test
  // execution history"): whoever ADDED a testcase to the cycle (execution.
  // added_by_id) may remove their own addition themselves, but only while
  // it still has zero execution history -- self-correcting a same-person,
  // zero-consequence mistake without needing a QA Lead. Once a specific
  // slot has recorded history it must be retained. Other untouched slots
  // in the same cycle stay removable under their ownership/QA Lead gate.
  const removeFromCycleEligibility = useCallback((execution: TestExecutionOut): { eligible: boolean; reason?: string } => {
    return executionRemovalEligibility(user, execution, canManageExecutionGovernance)
  }, [canManageExecutionGovernance, user])
  const [projects, setProjects] = useState<TestProjectOut[]>([])
  const [projectId, setProjectId] = useState<number | ''>('')
  const [cycles, setCycles] = useState<TestCycleOut[]>([])
  const [cycleId, setCycleId] = useState<number | ''>('')
  // Reported directly: "Create Test Cycle Folder, in which I can give
  // access department based or user level, same behaviour like project
  // has. Under this folder create test cycle." Flat folders, restrict-not-
  // widen access (see backend models.TestCycleFolder's own docstring).
  // '' means "All cycles", CYCLE_UNFILED means the Unfiled pseudo-folder.
  const [cycleFolders, setCycleFolders] = useState<TestCycleFolderOut[]>([])
  const [cycleFolderTotals, setCycleFolderTotals] = useState<{ unfiled_count: number; total: number }>({ unfiled_count: 0, total: 0 })
  const [selectedCycleFolder, setSelectedCycleFolder] = useState<number | typeof CYCLE_UNFILED | ''>('')
  const [showNewCycleFolder, setShowNewCycleFolder] = useState(false)
  const [editingCycleFolder, setEditingCycleFolder] = useState<TestCycleFolderOut | null>(null)
  const [managingCycleFolderAccess, setManagingCycleFolderAccess] = useState<TestCycleFolderOut | null>(null)
  const [cycleFolderToDelete, setCycleFolderToDelete] = useState<TestCycleFolderOut | null>(null)
  const [deletingCycleFolder, setDeletingCycleFolder] = useState(false)
  const [departments, setDepartments] = useState<DepartmentOut[]>([])
  // SRS 7.2 pagination rollout -- the folder-tree-style "everything at
  // Full-repository and full execution-ID fetches are intentionally absent;
  // the Add Test Cases modal queries its own database-filtered candidates.
  // their own small dedicated endpoints (see loadExecutionExtras below)
  // instead of being derived from the complete (now paginated) execution
  // list.
  const [executionSummary, setExecutionSummary] = useState<TestExecutionSummaryOut | null>(null)
  const cycleFoldersRequest = useRef(0)
  const executionSummaryRequest = useRef(0)
  const [error, setError] = useState<unknown>(null)
  const [showNewCycle, setShowNewCycle] = useState(false)
  const [editingCycle, setEditingCycle] = useState<TestCycleOut | null>(null)
  const [showAddCases, setShowAddCases] = useState(false)
  const [editingExecution, setEditingExecution] = useState<TestExecutionOut | null>(null)
  const [resultFilter, setResultFilter] = useState('')
  const [assignmentFilter, setAssignmentFilter] = useState<'all' | 'mine' | 'unassigned'>('all')
  const [cycleToDelete, setCycleToDelete] = useState<TestCycleOut | null>(null)
  const [deletingCycle, setDeletingCycle] = useState(false)
  const [selectedExecutionIds, setSelectedExecutionIds] = useState<Set<number>>(new Set())
  const [bulkAssigneeId, setBulkAssigneeId] = useState('')
  const [bulkAssignReason, setBulkAssignReason] = useState('')
  const [bulkAssigning, setBulkAssigning] = useState(false)
  // 2026-08 Reassignment Requirement -- the inline per-row runner picker
  // used to fire the PATCH immediately on change; reassigning an already-
  // assigned slot now needs a mandatory reason first, so a change against an
  // already-assigned row is held here until confirmed instead.
  const [reassignRunnerDraft, setReassignRunnerDraft] = useState<{ execution: TestExecutionOut; value: string } | null>(null)
  const [reassignRunnerReason, setReassignRunnerReason] = useState('')
  const [reassigningRunner, setReassigningRunner] = useState(false)
  const [showBulkExecution, setShowBulkExecution] = useState(false)
  const [bulkRemoveExecutions, setBulkRemoveExecutions] = useState<TestExecutionOut[] | null>(null)
  const [cycleActivity, setCycleActivity] = useState<ApprovalActionOut[]>([])
  const [showActivity, setShowActivity] = useState(false)
  const [cycleSidebarCollapsed, setCycleSidebarCollapsed] = useState(false)
  const [users, setUsers] = useState<UserOption[]>([])
  const [exportingCycle, setExportingCycle] = useState(false)
  const exportJobController = useRef<AbortController | null>(null)
  const [functionalRequestOptions, setFunctionalRequestOptions] = useState<LinkedRequestRef[]>([])
  const [linkingExistingExecution, setLinkingExistingExecution] = useState<TestExecutionOut | null>(null)
  // 2026-08 -- reported directly: "once test cycle completed, then test
  // cycle is locked to edit. that is okay, but give option to link QA
  // request." A Completed cycle stays frozen for everything else (Edit
  // Cycle stays hidden below), but the QA Request it's filed against can
  // still be replaced afterward for traceability -- see
  // LinkCycleRequestModal, a narrower standalone form for just that one
  // field, and the matching backend allowance in update_cycle.
  const [linkingCycleRequest, setLinkingCycleRequest] = useState<TestCycleOut | null>(null)
  const [qaLeadUnlinkCycle, setQALeadUnlinkCycle] = useState<TestCycleOut | null>(null)

  useEffect(() => () => {
    exportJobController.current?.abort()
  }, [])

  useEffect(() => {
    // A project picker must not silently omit projects after the first page.
    api.getAll<TestProjectOut>('/api/test-projects?include_inactive=true').then((p) => {
      setProjects(p)
      const requested = Number(searchParams.get('project')) || null
      setProjectId((current) => resolvePreferredProjectId(p, requested, current, user?.id))
    }).catch(setError)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams, user?.id])

  // Loaded once, up front, rather than only when the (rarely-opened) folder
  // access modal is reachable -- same tradeoff TestProjects.tsx already
  // made for its own ManageViewAccessModal's department picker.
  useEffect(() => {
    api.get<DepartmentOut[]>('/api/departments').then(setDepartments).catch(() => setDepartments([]))
  }, [])

  // A parent workspace can display projects owned by a child. Load runner
  // candidates against the cycle's creating workspace and clear the old
  // project list immediately so a fast assignment cannot submit a stale user.
  useEffect(() => {
    if (!projectId) { setUsers([]); return }
    let active = true
    setUsers([])
    // Project changes can render before the replacement cycle list arrives.
    // Never combine the new project with a cycle from the previous project.
    if (cycleId && !cycles.some(cycle => cycle.id === cycleId && cycle.project_id === projectId)) return
    api.get<UserOption[]>(`/api/test-projects/eligible-users?runner_only=true&project_id=${projectId}${cycleId ? `&cycle_id=${cycleId}` : ''}`)
      .then((rows) => { if (active) setUsers(rows) })
      .catch((failure) => { if (active) setError(failure) })
    return () => { active = false }
  }, [projectId, cycleId, cycles])

  // Request-link options are loaded only when a control that needs them is
  // reachable. Runner candidates are handled separately above because their
  // workspace boundary must change atomically with the selected project.
  useEffect(() => {
    if ((showNewCycle || editingCycle || linkingCycleRequest) && projectId) {
      // A Completed request is eligible only for trace-recovery linking to
      // an already Completed cycle. Pass the actual cycle so the options
      // endpoint applies the same status rule as the eventual PATCH.
      const optionCycleId = linkingCycleRequest?.id ?? editingCycle?.id
      const query = optionCycleId ? `?${new URLSearchParams({ cycle_id: String(optionCycleId) }).toString()}` : ''
      api.get<LinkedRequestRef[]>(`/api/test-execution/projects/${projectId}/functional-request-options${query}`)
        .then(setFunctionalRequestOptions)
        .catch(setError)
    }
  }, [showNewCycle, editingCycle, linkingCycleRequest, projectId])

  useEffect(() => {
    if (!projectId) { setMyAccess(null); return }
    let active = true
    api.get<TestProjectMyAccessOut>(`/api/test-projects/${projectId}/my-access`)
      .then((access) => { if (active) setMyAccess(access) })
      .catch(() => { if (active) setMyAccess(null) })
    return () => { active = false }
  }, [projectId])

  // Reported directly: "Create Test Cycle Folder ... Under this folder
  // create test cycle." folderParam mirrors TestRepository.tsx's own
  // summaryFolderParam calculation -- numeric folder id, the literal
  // 'unfiled', or omitted for every cycle this user can see across the
  // whole project.
  const loadCycles = useCallback(async (pid: number, folderParam?: string, isCurrent: () => boolean = () => true) => {
    try {
      const qs = new URLSearchParams()
      if (folderParam) qs.set('folder_id', folderParam)
      const c = await api.getAll<TestCycleOut>(`/api/test-execution/projects/${pid}/cycles?${qs.toString()}`)
      if (!isCurrent()) return
      setCycles(c)
      const requestedCycle = Number(searchParams.get('cycle'))
      setCycleId(c.some((cycle) => cycle.id === requestedCycle) ? requestedCycle : (c.length ? c[0].id : ''))
    } catch (err) { if (isCurrent()) setError(err) }
  }, [searchParams])
  const loadCycleFolders = useCallback(async (pid: number) => {
    const request = ++cycleFoldersRequest.current
    try {
      const data = await api.get<TestCycleFolderListOut>(`/api/test-execution/projects/${pid}/cycle-folders`)
      if (request !== cycleFoldersRequest.current) return
      setCycleFolders(data.folders)
      setCycleFolderTotals({ unfiled_count: data.unfiled_count, total: data.total })
      setError(null)
    } catch (err) { if (request === cycleFoldersRequest.current) setError(err) }
  }, [])
  const cycleFolderParam = selectedCycleFolder === '' ? undefined : selectedCycleFolder === CYCLE_UNFILED ? 'unfiled' : String(selectedCycleFolder)
  // A direct result link can target a cycle outside the folder currently
  // expanded in the navigator. Switch to All cycles before resolving it so
  // the requested cycle is guaranteed to be present in loadCycles.
  useEffect(() => {
    if (searchParams.get('execution') && selectedCycleFolder !== '') setSelectedCycleFolder('')
  }, [searchParams, selectedCycleFolder])
  useEffect(() => {
    setCycleFolders([]); setCycleFolderTotals({ unfiled_count: 0, total: 0 })
    if (projectId) loadCycleFolders(projectId)
    else cycleFoldersRequest.current++
  }, [projectId, loadCycleFolders])
  useEffect(() => {
    let active = true
    if (projectId) loadCycles(projectId, cycleFolderParam, () => active)
    else { setCycles([]); setCycleId('') }
    return () => { active = false }
  }, [projectId, cycleFolderParam, loadCycles])

  // SRS 7.2 pagination rollout -- the main execution list is now
  // server-paginated/server-filtered (status/assignment become query params
  // instead of an in-browser .filter() over the whole cycle).
  const {
    items: executions, page, pageSize, total, totalPages, hasNext, hasPrevious,
    loading: executionsLoading, setPage, setPageSize, reload: reloadExecutions,
  } = usePaginatedList<TestExecutionOut>(
    cycleId ? `/api/test-execution/cycles/${cycleId}/executions` : '',
    {
      status: resultFilter ? [resultFilter] : undefined,
      // Preserves the original ascending-by-id (add order) list order --
      // every other paginated list in this app defaults to newest-first,
      // which would reorder testcases within a cycle unexpectedly here.
      sortOrder: 'asc',
      extra: { assignment: assignmentFilter !== 'all' ? assignmentFilter : undefined },
    },
    { cursor: true },
  )
  const loadExecutionExtras = useCallback(async (cid: number) => {
    const request = ++executionSummaryRequest.current
    try {
      const summaryData = await api.get<TestExecutionSummaryOut>(`/api/test-execution/cycles/${cid}/executions/summary`)
      if (request === executionSummaryRequest.current) {
        setExecutionSummary(summaryData)
        setError(null)
      }
    } catch (err) { if (request === executionSummaryRequest.current) setError(err) }
  }, [])
  const refreshExecutions = useCallback(() => {
    reloadExecutions()
    if (cycleId) loadExecutionExtras(cycleId)
  }, [reloadExecutions, loadExecutionExtras, cycleId])
  useEffect(() => {
    let active = true
    setExecutionSummary(null)
    if (cycleId) {
      loadExecutionExtras(cycleId)
      api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CYCLE&entity_id=${cycleId}`)
        .then((result) => { if (active) setCycleActivity(result) })
        .catch(() => { if (active) setCycleActivity([]) })
    } else {
      executionSummaryRequest.current++
      setCycleActivity([])
    }
    return () => { active = false }
  }, [cycleId, loadExecutionExtras])

  useEffect(() => () => {
    cycleFoldersRequest.current++
    executionSummaryRequest.current++
  }, [])
  // Defect traceability deep-link -- fetches the specific execution by id
  // directly (PAG-006-style) rather than searching the loaded page, since
  // the target row may not be on whatever page/filter happens to be active.
  useEffect(() => {
    const requestedExecution = Number(searchParams.get('execution'))
    if (!requestedExecution) return
    const requestedProject = Number(searchParams.get('project'))
    const requestedCycle = Number(searchParams.get('cycle'))
    // Wait for the workspace selectors to match the deep link before opening
    // Record Result. This prevents a result from appearing over whichever
    // project/cycle happened to be selected previously.
    if (requestedProject && projectId !== requestedProject) return
    if (requestedCycle && Number(cycleId) !== requestedCycle) return
    let active = true
    api.get<TestExecutionOut>(`/api/test-execution/executions/${requestedExecution}`)
      .then((target) => {
        if (!active) return
        setEditingExecution(target)
        setSearchParams((params) => { params.delete('execution'); return params }, { replace: true })
      })
      .catch((err) => {
        if (!active) return
        setError(err)
        setSearchParams((params) => { params.delete('execution'); return params }, { replace: true })
      })
    return () => { active = false }
  }, [searchParams, setSearchParams, projectId, cycleId])
  // Selection is only ever meaningful against whatever's currently loaded --
  // same reasoning as Test Repository's own equivalent effect.
  useEffect(() => {
    setSelectedExecutionIds(new Set())
  }, [resultFilter, assignmentFilter, page, pageSize])
  useEffect(() => {
    setSelectedExecutionIds(new Set())
    setShowBulkExecution(false)
    setBulkRemoveExecutions(null)
    setShowActivity(false)
  }, [cycleId, projectId])

  // SRS 7.2 pagination rollout -- every one of these used to be computed
  // in-browser from the complete (unpaginated) cycle execution list; now
  // they all come from executionSummary (see loadExecutionExtras above),
  // which stays accurate regardless of which page/status/assignment filter
  // the main list currently has selected. "Visible" now means "on the
  // current page" -- the list itself already IS the filtered/paginated
  // result (status/assignment are server-side query params now), so no
  // separate `filteredExecutions` client-filter step is needed any more.
  const cycleAuditActivity = useMemo(() => cycleActivity.filter((item) => (
    item.decision === 'Commented'
    || ['Cycle', 'Cycle Details', 'Lifecycle', 'Request Link', 'Testcase Scope'].includes(item.step_name || '')
  )), [cycleActivity])
  const filteredExecutions = executions
  const executedCount = executionSummary?.executed_count ?? 0
  const passCount = (executionSummary?.status_counts.Pass || 0) + (executionSummary?.status_counts['Retest Passed'] || 0)
  const passRate = executedCount ? Math.round((passCount / executedCount) * 100) : 0
  const attentionCount = (executionSummary?.status_counts.Fail || 0) + (executionSummary?.status_counts.Blocked || 0)
  const assignedCount = executionSummary?.assigned_count ?? 0
  const unassignedCount = executionSummary?.unassigned_count ?? 0
  const myAssignmentCount = executionSummary?.mine_count ?? 0
  const totalRunCount = executionSummary?.total_run_count ?? 0
  const cycleExecutionTotal = executionSummary?.total ?? 0
  const progressRate = cycleExecutionTotal ? Math.round((executedCount / cycleExecutionTotal) * 100) : 0
  const selectedCycle = cycles.find((c) => c.id === cycleId)
  const canEditSelectedCycle = canExec && !!selectedCycle?.workspace_writable
  const cycleIsLocked = !!selectedCycle && TEST_CYCLE_LOCKED_STATUSES.includes(selectedCycle.status)
  const cycleIsCompleted = selectedCycle?.status === 'Completed'
  const selectedProject = projects.find((project) => project.id === projectId)
  const projectIsActive = !!selectedProject?.is_active
  const projectCanContribute = projectIsActive && !!selectedProject?.workspace_contributable
  const runnerCandidates = useMemo(() => users.filter((candidate) => (
    isSelectableUser(candidate)
  )), [users])
  const executionContextError = selectedCycle && (!selectedCycle.environment?.trim() || !selectedCycle.build?.trim())
    ? 'Set the environment and tested build in Edit Cycle before recording execution.' : undefined
  const canExecuteRow = useCallback((execution: TestExecutionOut) => (
    canEditSelectedCycle && projectIsActive && !executionContextError && selectedCycle?.status === 'In Progress'
    && execution.assigned_to_id === user?.id
  ), [canEditSelectedCycle, projectIsActive, executionContextError, selectedCycle?.status, user])
  const canSelectRow = useCallback((execution: TestExecutionOut) => (
    !!selectedCycle?.workspace_writable && !cycleIsLocked && (canManageRunners || canExecuteRow(execution))
  ), [canExecuteRow, canManageRunners, cycleIsLocked, selectedCycle?.workspace_writable])
  const selectableExecutions = filteredExecutions.filter(canSelectRow)
  const selectedExecutions = executions.filter((execution) => selectedExecutionIds.has(execution.id))
  const bulkExecutionEligible = selectedExecutions.length > 0 && selectedExecutions.every(canExecuteRow)
  const allVisibleSelected = selectableExecutions.length > 0
    && selectableExecutions.every((execution) => selectedExecutionIds.has(execution.id))

  function toggleExecutionSelection(executionId: number) {
    setSelectedExecutionIds((current) => {
      const next = new Set(current)
      if (next.has(executionId)) next.delete(executionId); else next.add(executionId)
      return next
    })
  }

  function toggleVisibleExecutions() {
    setSelectedExecutionIds((current) => {
      const next = new Set(current)
      if (allVisibleSelected) selectableExecutions.forEach((execution) => next.delete(execution.id))
      else selectableExecutions.forEach((execution) => next.add(execution.id))
      return next
    })
  }

  async function assignRunner(execution: TestExecutionOut, value: string, reason?: string) {
    setError(null)
    try {
      const saved = await api.patch<TestExecutionOut>(`/api/test-execution/executions/${execution.id}/assign`, {
        assigned_to_id: value ? Number(value) : null,
        ...(reason ? { reason } : {}),
      })
      refreshExecutions()
      setEditingExecution((current) => current?.id === saved.id ? saved : current)
      if (cycleId) api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CYCLE&entity_id=${cycleId}`).then(setCycleActivity).catch(() => undefined)
      return true
    } catch (err) { setError(err); return false }
  }

  // 2026-08 Reassignment Requirement -- first assignment (execution
  // currently unassigned) still applies immediately, same as before.
  // Changing (or clearing) an already-assigned runner is a reassignment:
  // hold the picked value and require a reason before it's sent.
  function handleRunnerChange(execution: TestExecutionOut, value: string) {
    if (execution.assigned_to_id) {
      setReassignRunnerDraft({ execution, value })
      setReassignRunnerReason('')
    } else {
      assignRunner(execution, value)
    }
  }

  async function confirmReassignRunner() {
    if (!reassignRunnerDraft || !reassignRunnerReason.trim()) return
    setReassigningRunner(true)
    const ok = await assignRunner(reassignRunnerDraft.execution, reassignRunnerDraft.value, reassignRunnerReason.trim())
    setReassigningRunner(false)
    if (ok) { setReassignRunnerDraft(null); setReassignRunnerReason('') }
  }

  async function bulkAssignSelected() {
    if (!cycleId || !bulkAssigneeId || selectedExecutionIds.size === 0) return
    setBulkAssigning(true); setError(null)
    try {
      await api.post<TestExecutionOut[]>(`/api/test-execution/cycles/${cycleId}/executions/bulk-assign`, {
        execution_ids: Array.from(selectedExecutionIds),
        assigned_to_id: Number(bulkAssigneeId),
        ...(bulkAssignReason.trim() ? { reason: bulkAssignReason.trim() } : {}),
      })
      refreshExecutions()
      setSelectedExecutionIds(new Set())
      setBulkAssigneeId('')
      setBulkAssignReason('')
      api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CYCLE&entity_id=${cycleId}`).then(setCycleActivity).catch(() => undefined)
    } catch (err) { setError(err) } finally { setBulkAssigning(false) }
  }

  async function deleteCycle() {
    if (!cycleToDelete) return
    const cycle = cycleToDelete
    setError(null)
    setDeletingCycle(true)
    try {
      await api.del(`/api/test-execution/cycles/${cycle.id}`)
      const remaining = cycles.filter((c) => c.id !== cycle.id)
      setCycles(remaining)
      setCycleId(remaining[0]?.id || '')
      setCycleToDelete(null)
    } catch (err) { setError(err); setCycleToDelete(null) } finally { setDeletingCycle(false) }
  }

  async function deleteCycleFolder() {
    if (!cycleFolderToDelete || !projectId) return
    const folder = cycleFolderToDelete
    setError(null)
    setDeletingCycleFolder(true)
    try {
      await api.del(`/api/test-execution/cycle-folders/${folder.id}`)
      if (selectedCycleFolder === folder.id) setSelectedCycleFolder('')
      loadCycleFolders(projectId)
      setCycleFolderToDelete(null)
    } catch (err) { setError(err); setCycleFolderToDelete(null) } finally { setDeletingCycleFolder(false) }
  }

  async function exportCycle() {
    if (!cycleId || !selectedCycle) return
    setExportingCycle(true); setError(null)
    try {
      const queued = await api.post<{ id: string }>(`/api/test-execution/cycles/${cycleId}/export-xlsx/jobs`)
      const controller = new AbortController()
      exportJobController.current?.abort()
      exportJobController.current = controller
      await waitForJob(queued.id, { signal: controller.signal })
      await api.downloadFile(
        `/api/jobs/${queued.id}/download`,
        `${selectedCycle.cycle_key}_test_lifecycle.xlsx`,
      )
    } catch (err) {
      if (!(err instanceof Error && err.name === 'AbortError')) setError(err)
    } finally {
      exportJobController.current = null
      setExportingCycle(false)
    }
  }

  // Reported directly: "MAKE child hierarchy based, more easier to
  // visulaize" -- `cycles` (already scoped to whichever folder/pseudo-
  // folder is currently selected -- see loadCycles/cycleFolderParam above)
  // now renders nested directly under that one selected row in the tree
  // below, instead of in an entirely separate list sitting past the whole
  // folder section with no visual link back to which folder it belongs to.
  // Folders themselves stay flat (no sub-folders -- that was a deliberate,
  // separate decision, see ORACLE_MIGRATION_2026-07.md section 147) -- only
  // "which cycles are these" is now shown as a visual parent/child
  // relationship, not the folders themselves.
  const nestedCycleList = (
    <ul className="tm-cycle-nested">
      {cycles.map((cycle) => (
        <li className="tm-cycle-row" key={cycle.id}>
          <button type="button" className={cycleId === cycle.id ? 'active' : ''} aria-current={cycleId === cycle.id ? 'true' : undefined} onClick={() => setCycleId(cycle.id)} title={`Open ${cycle.name} (${cycle.cycle_key}) · ${cycle.status}`}>
            <span className="tm-cycle-row-copy">
              <i aria-hidden="true" />
              <span>
                <strong>{cycle.name}</strong>
                <span className="tm-cycle-row-meta"><small>{cycle.cycle_key}</small><Badge status={cycle.status} /></span>
              </span>
            </span>
          </button>
          {canDeleteCycle && cycle.workspace_writable && projectIsActive && !TEST_CYCLE_LOCKED_STATUSES.includes(cycle.status) && <button className="tm-cycle-delete" title={`Delete ${cycle.name}`} aria-label={`Delete ${cycle.name}`} onClick={() => setCycleToDelete(cycle)}><IconTrash aria-hidden="true" /></button>}
        </li>
      ))}
      {cycles.length === 0 && <li className="tm-cycle-empty">No cycles here yet.</li>}
      {canExec && projectCanContribute && (
        <li><button type="button" className="tm-cycle-nested-add" onClick={() => setShowNewCycle(true)}><IconPlus aria-hidden="true" /> Create cycle</button></li>
      )}
    </ul>
  )

  return (
    <div className="tm-page">
      <ErrorText error={error} />
      <PageHeader
        eyebrow="Test Case Management · Design · Organize · Execute · Trace"
        title="Test Execution" count={cycleExecutionTotal}
        subtitle="Organize test cycles, execute step-by-step, capture evidence, and connect failures to defects."
        actions={(
          <div style={{ display: 'flex', gap: 8 }}>
            <ProjectSelect
              projects={projects}
              value={projectId}
              onChange={(nextProjectId) => {
                setProjectId(nextProjectId)
                setCycleId('')
                setCycles([])
                setSelectedCycleFolder('')
              }}
              placeholder={projects.length === 0 ? 'No Test Projects yet' : 'Select a project...'}
              style={{ minWidth: 220 }}
            />
            {canExec && projectId && projectCanContribute && (
              <button className="btn" onClick={() => setShowNewCycle(true)}>+ Cycle</button>
            )}
          </div>
        )}
      />
      {projectId && !projectIsActive && (
        <div className="info-banner">This project is inactive. Existing cycles and results are read-only until the project is reactivated.</div>
      )}
      {projectId && projectIsActive && !projectCanContribute && (
        <div className="info-banner">Test Execution is read-only in this workspace. Contributor access is required to create cycles or record results.</div>
      )}
      {projectId && (
        <div className={`tm-workspace tm-execution-workspace tm-execution-refined${cycleSidebarCollapsed ? ' cycle-sidebar-collapsed' : ''}`}>
          <aside className="tm-tree-panel tm-cycle-panel">
            <div className="tm-cycle-sidebar-head">
              {!cycleSidebarCollapsed && <div className="tm-cycle-sidebar-title"><span aria-hidden="true"><IconWorkflow /></span><div><small>Execution workspace</small><strong>Cycle navigator</strong></div></div>}
              <div className="tm-cycle-sidebar-tools">
                {!cycleSidebarCollapsed && <span title={`${cycleFolderTotals.total} total cycles`}>{cycleFolderTotals.total}</span>}
                <button
                  type="button"
                  className="tm-tree-collapse"
                  onClick={() => setCycleSidebarCollapsed((collapsed) => !collapsed)}
                  aria-expanded={!cycleSidebarCollapsed}
                  aria-label={cycleSidebarCollapsed ? 'Expand test cycles' : 'Collapse test cycles'}
                  title={cycleSidebarCollapsed ? 'Expand test cycles' : 'Collapse test cycles'}
                >{cycleSidebarCollapsed ? '›' : '‹'}</button>
              </div>
            </div>
            {/* Reported directly: "Create Test Cycle Folder, in which I can
                give access department based or user level, same behaviour
                like project has. Under this folder create test cycle."
                Flat -- no nesting -- same `.tm-folder-row`/`.link-btn`
                styling Test Repository's own folder tree already uses
                (this aside shares its `tm-tree-panel` class). A folder with
                a lock icon has at least one access grant and is RESTRICTED
                to those departments/users -- see backend
                models.TestCycleFolder's own docstring. Whichever row is
                currently selected shows its own cycles nested directly
                beneath it (nestedCycleList, computed above) -- see that
                variable's own comment for why. */}
            {!cycleSidebarCollapsed && <>
              <div className="tm-cycle-scope-label">Cycle views</div>
              <ul className="plain-list tm-cycle-scope-list">
              <li className="tm-cycle-scope-item">
                <div className="tm-folder-row">
                  <button type="button" className={`link-btn ${selectedCycleFolder === '' ? 'active' : ''}`} onClick={() => setSelectedCycleFolder('')}>
                    <IconGrid aria-hidden="true" /> <span className="tm-cycle-link-label">All cycles</span> <em>{cycleFolderTotals.total}</em>
                  </button>
                </div>
                {selectedCycleFolder === '' && nestedCycleList}
              </li>
              <li className="tm-cycle-scope-item">
                <div className="tm-folder-row">
                  <button type="button" className={`link-btn ${selectedCycleFolder === CYCLE_UNFILED ? 'active' : ''}`} onClick={() => setSelectedCycleFolder(CYCLE_UNFILED)}>
                    <IconInbox aria-hidden="true" /> <span className="tm-cycle-link-label">Unfiled</span> <em>{cycleFolderTotals.unfiled_count}</em>
                  </button>
                </div>
                {selectedCycleFolder === CYCLE_UNFILED && nestedCycleList}
              </li>
              </ul>
              <div className="tm-cycle-folder-label"><span>Folders</span><em>{cycleFolders.length}</em></div>
              <ul className="plain-list tm-cycle-folder-list">
              {cycleFolders.map((f) => (
                <li key={f.id}>
                  <div className="tm-folder-row">
                    <button type="button" className={`link-btn ${selectedCycleFolder === f.id ? 'active' : ''}`} onClick={() => setSelectedCycleFolder(f.id)}>
                      {f.access_grants.length ? <IconLock className="restricted" aria-hidden="true" /> : <IconFolder aria-hidden="true" />} <span className="tm-cycle-link-label">{f.name}</span> <em>{f.cycle_count}</em>
                    </button>
                    {canExec && f.workspace_writable && projectIsActive && (
                      <div className="tm-folder-actions">
                        <button type="button" className="tm-folder-action" title="Manage access" aria-label={`Manage access for ${f.name}`} onClick={() => setManagingCycleFolderAccess(f)}><IconLock aria-hidden="true" /></button>
                        <button type="button" className="tm-folder-action" title="Rename folder" aria-label={`Rename ${f.name}`} onClick={() => setEditingCycleFolder(f)}>✎</button>
                        {canManageExecutionGovernance && (
                          <button type="button" className="tm-folder-action tm-folder-delete" title="Delete folder" aria-label={`Delete ${f.name}`} onClick={() => setCycleFolderToDelete(f)}>×</button>
                        )}
                      </div>
                    )}
                  </div>
                  {selectedCycleFolder === f.id && nestedCycleList}
                </li>
              ))}
              </ul>
            </>}
            {!cycleSidebarCollapsed && canExec && projectCanContribute && <button type="button" className="tm-tree-add" onClick={() => setShowNewCycleFolder(true)}><IconPlus aria-hidden="true" /> Add folder</button>}
          </aside>
          <section className="tm-main-panel">
          {cycleId ? (
            <>
              <div className="tm-cycle-header tm-cycle-command tm-cycle-command-refined">
                <div className="tm-cycle-command-copy">
                  <span>{selectedCycle?.cycle_key}</span>
                  <h3>{selectedCycle?.name}</h3>
                  <span className="badge badge-gray">{selectedCycle?.workspace_writable ? "Your workspace" : `${selectedCycle?.origin_workspace_name || "Other workspace"} · Read-only`}</span>
                  <p>{selectedCycle?.description || 'Execute and monitor the selected test set.'}</p>
                  <div className="tm-cycle-context-row">
                    <div className="tm-cycle-meta">
                      {selectedCycle && (canEditSelectedCycle && projectIsActive && !cycleIsCompleted ? (
                        <CycleStatusControl cycle={selectedCycle} executionTotal={cycleExecutionTotal} executedCount={executedCount} failedCount={executionSummary?.status_counts.Fail || 0} blockedCount={executionSummary?.status_counts.Blocked || 0} onChanged={(saved) => {
                          setCycles((current) => current.map((cycle) => cycle.id === saved.id ? saved : cycle))
                          api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CYCLE&entity_id=${saved.id}`).then(setCycleActivity).catch(() => undefined)
                        }} onError={setError} />
                      ) : (
                        <Badge status={selectedCycle?.status} />
                      ))}
                      {selectedCycle?.cycle_type && <span className="badge badge-gray">{selectedCycle.cycle_type}</span>}
                      {selectedCycle?.environment && <span className="badge badge-gray">{selectedCycle.environment}</span>}
                      {selectedCycle?.build && <span className="badge badge-gray">Build {selectedCycle.build}</span>}
                      {selectedCycle?.owner_name && <span className="badge badge-gray">Owner: {selectedCycle.owner_name}</span>}
                      {selectedCycle?.reexecution_of_cycle_key && <span className="badge badge-gray">Re-execution of {selectedCycle.reexecution_of_cycle_key}</span>}
                    </div>
                    {selectedCycle?.linked_request_key && (
                      <div className="tm-cycle-request-link">
                        <b>Linked {selectedCycle.linked_request_type}</b><strong>{selectedCycle.linked_request_key}</strong>
                        {selectedCycle.linked_request_type === 'Functional' && !selectedCycle.linked_request_change_allowed && <span className="badge badge-gray">Link locked</span>}
                        {canEditSelectedCycle && projectIsActive && selectedCycle.linked_request_qa_lead_unlink_allowed && <button type="button" className="tm-cycle-request-link-action tm-cycle-request-link-action--danger" onClick={() => setQALeadUnlinkCycle(selectedCycle)}>QA Lead override</button>}
                        {canEditSelectedCycle && projectIsActive && selectedCycle.status === 'Completed' && selectedCycle.linked_request_change_allowed && <button type="button" className="tm-cycle-request-link-action" onClick={() => setLinkingCycleRequest(selectedCycle)}>Change link</button>}
                      </div>
                    )}
                    {!selectedCycle?.linked_request_key && (
                      <span className="badge badge-gray">Standalone</span>
                    )}
                    {!selectedCycle?.linked_request_key && canEditSelectedCycle && projectIsActive && selectedCycle?.status === 'Completed' && (
                      <div className="tm-cycle-request-link tm-cycle-request-link--empty">
                        <button type="button" className="tm-cycle-request-link-action" onClick={() => setLinkingCycleRequest(selectedCycle)}>Link QA Request</button>
                      </div>
                    )}
                  </div>
                </div>
                <div className="tm-cycle-command-actions">
                  {canEditSelectedCycle && projectIsActive && !cycleIsLocked && <button className="btn" onClick={() => selectedCycle && setEditingCycle(selectedCycle)}>Edit Cycle</button>}
                  <button className="btn" onClick={exportCycle} disabled={exportingCycle}>
                    {exportingCycle ? 'Exporting…' : 'Export Lifecycle'}
                  </button>
                  {canEditSelectedCycle && projectIsActive && !cycleIsLocked && <button className="btn btn-primary" onClick={() => setShowAddCases(true)}>+ Add test cases</button>}
                </div>
                {cycleIsLocked && (
                  <div className="info-banner">
                    {selectedCycle?.status === 'Blocked'
                      ? <>This cycle is <strong>Blocked</strong>. Assignment, editing, execution, testcase, defect, evidence, and ordinary link changes are disabled until Resume Execution.{selectedCycle.linked_request_qa_lead_unlink_allowed ? ' A QA Lead Group member may still use the audited override shown above to remove an incorrect request association.' : ''}</>
                      : <>This cycle is <strong>Completed</strong> and read-only. No further changes are allowed, except linking or updating the QA Request it's filed against.</>}
                  </div>
                )}
              </div>
              {executionContextError && <div role="alert" className="info-banner">{executionContextError}</div>}
              <section className="tm-execution-snapshot" aria-label="Cycle execution overview">
                <div className="tm-snapshot-progress">
                  <div className="tm-snapshot-progress-copy">
                    <small>Execution progress</small>
                    <strong>{executedCount}<em> / {cycleExecutionTotal}</em></strong>
                    <span>testcases executed</span>
                  </div>
                  <div className="tm-snapshot-progress-detail">
                    <div className="tm-snapshot-track" role="progressbar" aria-label="Cycle completion" aria-valuemin={0} aria-valuemax={100} aria-valuenow={progressRate}>
                      <i style={{ width: `${progressRate}%` }} />
                    </div>
                    <p>{cycleExecutionTotal - executedCount > 0 ? `${cycleExecutionTotal - executedCount} testcase${cycleExecutionTotal - executedCount === 1 ? '' : 's'} remaining · ${totalRunCount} total attempts` : `All testcases have an execution result · ${totalRunCount} total attempts`}</p>
                  </div>
                </div>
                <div className="tm-snapshot-metrics">
                  <div data-tone="success"><small>Pass rate</small><strong>{passRate}%</strong><span>{passCount} passed</span></div>
                  <div data-tone={attentionCount ? 'warning' : 'neutral'}><small>Needs attention</small><strong>{attentionCount}</strong><span>{executionSummary?.status_counts.Fail || 0} failed · {executionSummary?.status_counts.Blocked || 0} blocked</span></div>
                  <div data-tone={unassignedCount ? 'warning' : 'success'}><small>Assignment</small><strong>{assignedCount}<em> / {cycleExecutionTotal}</em></strong><span>{unassignedCount ? `${unassignedCount} unassigned` : 'Fully assigned'}</span></div>
                  <div data-tone="info"><small>My queue</small><strong>{myAssignmentCount}</strong><span>Assigned to me</span></div>
                </div>
              </section>
              <section className="tm-testcase-workbench">
              <div className="tm-workbench-head">
                <div><small>Execution workspace</small><h4>Cycle Testcases <span>{total} of {cycleExecutionTotal}</span></h4><p>Assign owners, record results, review defects, and track every attempt.</p></div>
                <div className="tm-assignment-filters">
                  <button className={assignmentFilter === 'all' ? 'active' : ''} onClick={() => setAssignmentFilter('all')}>All <em>{cycleExecutionTotal}</em></button>
                  <button className={assignmentFilter === 'mine' ? 'active' : ''} onClick={() => setAssignmentFilter('mine')}>Mine <em>{myAssignmentCount}</em></button>
                  <button className={assignmentFilter === 'unassigned' ? 'active' : ''} onClick={() => setAssignmentFilter('unassigned')}>Unassigned <em>{unassignedCount}</em></button>
                </div>
              </div>
              <div className="tm-result-tabs">
                <button className={!resultFilter ? 'active' : ''} onClick={() => setResultFilter('')}>All <span>{cycleExecutionTotal}</span></button>
                {TEST_EXECUTION_STATUSES.map((s) => <button key={s} className={resultFilter === s ? 'active' : ''} onClick={() => setResultFilter(s)}>{s} <span>{executionSummary?.status_counts[s] || 0}</span></button>)}
              </div>
              {selectedCycle && <LinkedDefects query={`cycle_id=${selectedCycle.id}`} title="Cycle Defects" />}
              {canEditSelectedCycle && projectIsActive && !cycleIsLocked && (
                <div className="tm-bulk-bar" role="region" aria-label={selectedExecutionIds.size > 1 ? 'Bulk testcase lifecycle actions' : 'Testcase lifecycle actions'}>
                  <strong>{selectedExecutionIds.size ? `${selectedExecutionIds.size} testcase${selectedExecutionIds.size !== 1 ? 's' : ''} selected` : 'Select one or more rows to assign, execute, or remove'}</strong>
                  <button type="button" className="btn btn-sm" disabled={!selectableExecutions.length} onClick={toggleVisibleExecutions}>{allVisibleSelected ? 'Clear visible' : `Select visible (${selectableExecutions.length})`}</button>
                  {selectedExecutionIds.size > 0 && <button type="button" className="btn btn-sm" onClick={() => setSelectedExecutionIds(new Set())}>Clear selection</button>}
                  {canManageRunners && selectedExecutionIds.size > 0 && (() => {
                    // Reassigning a runner is open to any QA Engineer/QA
                    // Lead/Chief Manager QA/Admin here, same as first
                    // assignment (reported directly: "for test execution
                    // reassignment of testcase can be perform by any QA
                    // user, otherwise it will be hectic for qa lead") --
                    // only the mandatory reason differs once a row already
                    // has a runner.
                    const bulkHasReassignment = selectedExecutions.some((execution) => !!execution.assigned_to_id)
                    return (
                      <div className="tm-bulk-assign-group">
                        <UserAssignSelect
                          value={bulkAssigneeId}
                          onChange={setBulkAssigneeId}
                          placeholder="Assign selected to…"
                          users={runnerCandidates}
                          style={{ minWidth: 190 }}
                        />
                        {bulkHasReassignment && (
                          <input
                            type="text"
                            className="reassign-reason-input"
                            placeholder="Reassignment reason (required)…"
                            value={bulkAssignReason}
                            onChange={(e) => setBulkAssignReason(e.target.value)}
                          />
                        )}
                        <button
                          type="button"
                          className="btn btn-sm"
                          disabled={!selectedExecutionIds.size || !bulkAssigneeId || bulkAssigning || (bulkHasReassignment && !bulkAssignReason.trim())}
                          onClick={bulkAssignSelected}
                        >
                          {bulkAssigning ? 'Assigning…' : bulkHasReassignment ? `Reassign (${selectedExecutionIds.size})` : `Assign (${selectedExecutionIds.size})`}
                        </button>
                      </div>
                    )
                  })()}
                  <button type="button" className="btn btn-sm btn-primary" disabled={!bulkExecutionEligible} title={selectedExecutionIds.size && !bulkExecutionEligible ? 'Execution requires every selected testcase to be assigned to you' : undefined} onClick={() => setShowBulkExecution(true)}>{selectionActionLabel(selectedExecutionIds.size, 'execute')}{selectedExecutionIds.size ? ` (${selectedExecutionIds.size})` : ''}</button>
                  {/* Scenario 1: visible to any exec-capable user now, not just QA Lead
                      Group -- a plain QA_ENGINEER may still remove testcases THEY added
                      before execution (removeFromCycleEligibility/BulkRemoveModal do the
                      actual per-item filtering; this button just needs someone who could
                      plausibly have something eligible to remove). */}
                  {(canManageExecutionGovernance || canExec) && <button type="button" className="btn btn-sm btn-danger" disabled={!selectedExecutionIds.size} onClick={() => setBulkRemoveExecutions(selectedExecutions)}>Remove from cycle{selectedExecutionIds.size ? ` (${selectedExecutionIds.size})` : ''}</button>}
                </div>
              )}
              <div className="tm-execution-table">
              <Table<TestExecutionOut>
                rowKey="id"
                onRowClick={setEditingExecution}
                server={{ page, pageSize, total, totalPages, hasNext, hasPrevious, onPageChange: setPage, onPageSizeChange: setPageSize, loading: executionsLoading }}
                columns={[
                  { key: 'select', header: <input type="checkbox" aria-label="Select all visible testcases" checked={allVisibleSelected} disabled={!selectableExecutions.length} onChange={toggleVisibleExecutions} onClick={(event) => event.stopPropagation()} />, filterable: false, render: (execution) => <input type="checkbox" aria-label={`Select ${execution.test_case?.test_case_key || `testcase ${execution.test_case_id}`}`} checked={selectedExecutionIds.has(execution.id)} disabled={!canSelectRow(execution)} title={canSelectRow(execution) ? 'Select for lifecycle actions' : execution.assigned_to_id ? `Assigned to ${execution.assigned_to_name || 'another runner'}` : 'Assign a runner before execution'} onChange={() => toggleExecutionSelection(execution.id)} onClick={(event) => event.stopPropagation()} /> },
                  { key: 'test_case', header: 'Test Case', render: (e) => <span className="tm-hierarchy-cell"><strong>{e.test_case?.test_case_key || `#${e.test_case_id}`}</strong><small>{[e.test_case?.module_name, `pinned v${e.pinned_version_label || e.test_case?.version || '1.0'}`].filter(Boolean).join(' · ')}{e.is_pinned_stale && <span className="badge badge-yellow" style={{ marginLeft: 6 }} title="A newer Approved version exists">Stale</span>}</small></span>, filterValue: (e) => `${e.test_case?.test_case_key || e.test_case_id} ${e.test_case?.module_name || ''}` },
                  { key: 'scenario', header: 'Scenario', render: (e) => e.test_case?.test_scenario || '—', filterValue: (e) => e.test_case?.test_scenario || '' },
                  { key: 'assigned_to_name', header: 'Assigned To', render: (e) => (selectedCycle?.workspace_writable && projectIsActive && !cycleIsLocked && (e.assigned_to_id ? canReassignExecution(e) : canManageRunners)) ? <div className="tm-table-assignee" onClick={(event) => event.stopPropagation()}><UserAssignSelect value={e.assigned_to_id ? String(e.assigned_to_id) : ''} onChange={(value) => handleRunnerChange(e, value)} users={runnerCandidates} placeholder="Assign runner…" />{e.assigned_to_id && <button type="button" title="Unassign" onClick={() => handleRunnerChange(e, '')}>×</button>}</div> : <span className={e.assigned_to_name ? '' : 'muted'}>{e.assigned_to_name || 'Unassigned'}</span>, filterValue: (e) => e.assigned_to_name || 'Unassigned' },
                  { key: 'quick_run', header: 'Actions', filterable: false, render: (execution) => <InlineExecutionActions execution={execution} executionContextError={executionContextError} canExecute={canExecuteRow(execution)} onLinkExisting={setLinkingExistingExecution} onError={setError} onChanged={() => refreshExecutions()} /> },
                  { key: 'run_count', header: 'Runs', render: (e) => <span className={`tm-run-count ${e.run_count ? 'has-runs' : ''}`}>{e.run_count || 0}</span> },
                  { key: 'status', header: 'Latest Result', render: (e) => <Badge status={e.status} /> },
                  { key: 'defects', header: 'Defects', render: (e) => { const defects = (e.runs || []).flatMap((run) => run.defects || []); return defects.length ? <span className="tm-table-defects">{defects.slice(-2).map((defect) => defect.defect_key).join(', ')}{defects.length > 2 ? ` +${defects.length - 2}` : ''}</span> : '—' }, filterValue: (e) => (e.runs || []).flatMap((run) => run.defects || []).map((defect) => defect.defect_key).join(' ') },
                  { key: 'executed_by_name', header: 'Last Runner', render: (e) => <span className="tm-hierarchy-cell"><strong>{e.executed_by_name || '—'}</strong><small>{e.executed_at ? formatDateTimeIST(e.executed_at) : 'Not run yet'}</small></span>, filterValue: (e) => e.executed_by_name || '' },
                ]}
                rows={filteredExecutions}
              />
              </div>
              </section>
              <section className={`tm-activity-panel ${showActivity ? 'open' : ''}`}>
                <button type="button" className="tm-activity-toggle" onClick={() => setShowActivity((current) => !current)} aria-expanded={showActivity}>
                  <span><strong>Test Cycle Activity & Audit History</strong><small>Cycle comments, details, request links, and lifecycle changes only</small></span>
                  <em>{cycleAuditActivity.length}</em><b>{showActivity ? 'Hide' : 'Show'}</b>
                </button>
                {showActivity && <JiraActivity
                  readOnly={!selectedCycle?.workspace_writable}
                  ownerWorkspaceId={selectedCycle?.origin_workspace_id || selectedProject?.qa_workspace_id}
                  entityType="TEST_CYCLE"
                  entityId={Number(cycleId)}
                  items={cycleAuditActivity}
                  onPosted={(item) => setCycleActivity((prev) => [...prev, item])}
                />}
              </section>
            </>
          ) : (
            <div className="tm-empty"><strong>Select or create a test cycle</strong><span>Cycles group test cases for a release, sprint, or regression run.</span></div>
          )}
          </section>
        </div>
      )}
      {showNewCycle && projectId && projectCanContribute && (
        <CycleModal
          project={selectedProject!}
          requests={functionalRequestOptions}
          users={users}
          folders={cycleFolders}
          defaultFolderId={typeof selectedCycleFolder === 'number' ? selectedCycleFolder : ''}
          onClose={() => setShowNewCycle(false)}
          onSaved={(c) => {
            loadCycleFolders(projectId)
            const matchesCurrentView = cycleFolderParam === undefined ? true
              : cycleFolderParam === 'unfiled' ? c.folder_id == null
              : Number(cycleFolderParam) === c.folder_id
            if (matchesCurrentView) {
              setCycles((prev) => [c, ...prev])
              setCycleId(c.id)
            } else {
              // Created into a different folder than the one currently open
              // in the sidebar -- switch to it so the new cycle is visible
              // and selected (the folder-scoped effect reloads `cycles` and
              // picks it, since it's the newest -- see loadCycles).
              setSelectedCycleFolder(c.folder_id ?? CYCLE_UNFILED)
            }
            setShowNewCycle(false)
          }}
        />
      )}
      {linkingExistingExecution && cycleId && <LinkExistingDefectModal execution={linkingExistingExecution} onClose={() => setLinkingExistingExecution(null)} onLinked={() => { refreshExecutions(); setLinkingExistingExecution(null) }} />}
      {editingCycle && projectId && projectIsActive && (
        <CycleModal
          project={selectedProject!}
          requests={functionalRequestOptions}
          users={users}
          folders={cycleFolders}
          defaultFolderId={typeof selectedCycleFolder === 'number' ? selectedCycleFolder : ''}
          editing={editingCycle}
          onClose={() => setEditingCycle(null)}
          onSaved={(saved) => {
            loadCycleFolders(projectId)
            const matchesCurrentView = cycleFolderParam === undefined ? true
              : cycleFolderParam === 'unfiled' ? saved.folder_id == null
              : Number(cycleFolderParam) === saved.folder_id
            if (matchesCurrentView) {
              setCycles((current) => current.map((cycle) => cycle.id === saved.id ? saved : cycle))
            } else {
              // Moved to a folder outside the current view -- drop it from
              // the local list and follow it to wherever it landed.
              setCycles((current) => current.filter((cycle) => cycle.id !== saved.id))
              setSelectedCycleFolder(saved.folder_id ?? CYCLE_UNFILED)
            }
            setEditingCycle(null)
          }}
        />
      )}
      {showNewCycleFolder && projectId && projectCanContribute && (
        <NewCycleFolderModal
          projectId={projectId}
          onClose={() => setShowNewCycleFolder(false)}
          onSaved={() => { loadCycleFolders(projectId); setShowNewCycleFolder(false) }}
        />
      )}
      {editingCycleFolder && (
        <NewCycleFolderModal
          projectId={editingCycleFolder.project_id}
          editing={editingCycleFolder}
          onClose={() => setEditingCycleFolder(null)}
          onSaved={() => { if (projectId) loadCycleFolders(projectId); setEditingCycleFolder(null) }}
        />
      )}
      {managingCycleFolderAccess && (
        <CycleFolderAccessModal
          folder={managingCycleFolderAccess}
          departments={departments}
          onClose={() => setManagingCycleFolderAccess(null)}
          onChanged={(grants) => {
            setCycleFolders((current) => current.map((f) => f.id === managingCycleFolderAccess.id ? { ...f, access_grants: grants } : f))
            setManagingCycleFolderAccess((current) => current ? { ...current, access_grants: grants } : current)
          }}
        />
      )}
      {cycleFolderToDelete && (
        <ConfirmModal
          title="Delete folder?"
          message={<p>Delete <strong>{cycleFolderToDelete.name}</strong> from this project? Only an empty folder (no test cycles in it) can be deleted.</p>}
          confirmLabel="Delete folder" cancelLabel="Keep folder" destructive busy={deletingCycleFolder}
          onConfirm={deleteCycleFolder} onCancel={() => setCycleFolderToDelete(null)}
        />
      )}
      {linkingCycleRequest && projectIsActive && (
        <LinkCycleRequestModal
          cycle={linkingCycleRequest}
          project={selectedProject!}
          requests={functionalRequestOptions}
          onClose={() => setLinkingCycleRequest(null)}
          onSaved={(saved) => { setCycles((current) => current.map((cycle) => cycle.id === saved.id ? saved : cycle)); setLinkingCycleRequest(null) }}
        />
      )}
      {qaLeadUnlinkCycle && projectIsActive && (
        <QALeadGroupUnlinkRequestModal
          cycle={qaLeadUnlinkCycle}
          onClose={() => setQALeadUnlinkCycle(null)}
          onSaved={(saved) => {
            setCycles((current) => current.map((cycle) => cycle.id === saved.id ? saved : cycle))
            setQALeadUnlinkCycle(null)
            api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CYCLE&entity_id=${saved.id}`).then(setCycleActivity).catch(() => undefined)
          }}
        />
      )}
      {showAddCases && cycleId && projectIsActive && (
        <AddCasesModal
          cycleId={cycleId}
          canAssign={canManageRunners}
          requiresScopeChangeReason={selectedCycle?.status === 'In Progress' || totalRunCount > 0}
          runnerCandidates={runnerCandidates}
          onClose={() => setShowAddCases(false)}
          onAdded={() => {
            refreshExecutions()
            api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CYCLE&entity_id=${cycleId}`).then(setCycleActivity).catch(() => undefined)
            setShowAddCases(false)
          }}
        />
      )}
      {showBulkExecution && cycleId && selectedExecutions.length > 0 && (
        <BulkExecutionModal
          cycleId={Number(cycleId)}
          executions={selectedExecutions}
          onClose={() => { setShowBulkExecution(false); setSelectedExecutionIds(new Set()) }}
          onExecuted={() => {
            refreshExecutions()
            api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CYCLE&entity_id=${cycleId}`).then(setCycleActivity).catch(() => undefined)
          }}
        />
      )}
      {bulkRemoveExecutions && cycleId && selectedCycle && (
        <BulkRemoveModal
          cycleId={Number(cycleId)}
          cycleKey={selectedCycle.cycle_key}
          executions={bulkRemoveExecutions}
          eligibility={removeFromCycleEligibility}
          onClose={() => { setBulkRemoveExecutions(null); setSelectedExecutionIds(new Set()) }}
          onRemoved={() => {
            refreshExecutions()
            api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CYCLE&entity_id=${cycleId}`).then(setCycleActivity).catch(() => undefined)
          }}
        />
      )}
      {editingExecution && (
        <RecordResultModal
          execution={editingExecution}
          readOnly={!canEditSelectedCycle || !projectIsActive || cycleIsLocked || editingExecution.assigned_to_id !== user?.id}
          canUnlinkDefects={canExec && !!selectedCycle?.workspace_writable && projectIsActive && !cycleIsLocked}
          canAssign={canManageRunners && !!selectedCycle?.workspace_writable && projectIsActive && !cycleIsLocked}
          canReassign={!!selectedCycle?.workspace_writable && projectIsActive && !cycleIsLocked && canReassignExecution(editingExecution)}
          canRemove={!!selectedCycle?.workspace_writable && projectIsActive && !cycleIsLocked && removeFromCycleEligibility(editingExecution).eligible}
          removeBlockedReason={removeFromCycleEligibility(editingExecution).reason}
          runnerCandidates={runnerCandidates}
          onAssigned={(saved) => {
            refreshExecutions()
            setEditingExecution(saved)
            if (cycleId) api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CYCLE&entity_id=${cycleId}`).then(setCycleActivity).catch(() => undefined)
          }}
          onExecutionChanged={(saved) => {
            refreshExecutions()
            setEditingExecution(saved)
            if (cycleId) api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CYCLE&entity_id=${cycleId}`).then(setCycleActivity).catch(() => undefined)
          }}
          onClose={() => setEditingExecution(null)}
          onSaved={() => {
            refreshExecutions()
            setEditingExecution(null)
            if (cycleId) api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_CYCLE&entity_id=${cycleId}`).then(setCycleActivity).catch(() => undefined)
          }}
          onRemoved={() => { refreshExecutions(); setEditingExecution(null) }}
        />
      )}
      {reassignRunnerDraft && (
        <Modal title="Reassign Runner" onClose={() => { setReassignRunnerDraft(null); setReassignRunnerReason('') }}>
          <p>
            Reassign <strong>{reassignRunnerDraft.execution.test_case?.test_case_key || `Testcase #${reassignRunnerDraft.execution.test_case_id}`}</strong> from{' '}
            <strong>{reassignRunnerDraft.execution.assigned_to_name || 'Unassigned'}</strong> to{' '}
            <strong>{reassignRunnerDraft.value ? runnerCandidates.find((r) => String(r.id) === reassignRunnerDraft.value)?.full_name || 'a new runner' : 'Unassigned'}</strong>?
          </p>
          <Field label="Reassignment reason (required)">
            <textarea rows={3} value={reassignRunnerReason} onChange={(e) => setReassignRunnerReason(e.target.value)} autoFocus />
          </Field>
          <ErrorText error={error} />
          <div className="modal-actions">
            <button type="button" className="btn" disabled={reassigningRunner} onClick={() => { setReassignRunnerDraft(null); setReassignRunnerReason('') }}>Cancel</button>
            <button type="button" className="btn btn-primary" disabled={reassigningRunner || !reassignRunnerReason.trim()} onClick={confirmReassignRunner}>
              {reassigningRunner ? 'Reassigning…' : 'Confirm reassignment'}
            </button>
          </div>
        </Modal>
      )}
      {cycleToDelete && (
        <ConfirmModal
          title="Delete test cycle?"
          message={<div>
            <p>Delete <strong>{cycleToDelete.name}</strong>?</p>
            <p className="muted small">
              Only an empty cycle can be deleted. Remove unexecuted testcases first. Recorded execution history and evidence must remain in the cycle.
            </p>
          </div>}
          confirmLabel="Delete cycle" cancelLabel="Keep cycle" destructive busy={deletingCycle}
          onConfirm={deleteCycle} onCancel={() => setCycleToDelete(null)}
        />
      )}
    </div>
  )
}
