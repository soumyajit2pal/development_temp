import React, { useCallback, useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useInternalNavigate } from '../../hooks/useRequestNavigation'
import { api } from '../../api'
import { formatDateIST } from '../../time'
import { useAuth } from '../../context/AuthContext'
import { Modal, Field, ErrorText, PageHeader, Badge } from '../../components/Common'
import SearchableSelect from '../../components/SearchableSelect'
import UserAssignSelect from '../../components/UserAssignSelect'
import { hasRole, isSelectableUser, QA_LEAD_GROUP_ROLES } from '../../constants'
import {
  ApplicationMasterOut, TestProjectOut, TestProjectSummaryCountsOut, ApprovalActionOut, DepartmentOut,
  UserOut, UserOption, TestProjectViewGrantOut, TestProjectWorkspaceOptionOut,
} from '../../types'
import JiraActivity from '../../components/JiraActivity'
import ClearableSearchInput from '../../components/ClearableSearchInput'
import ConfirmModal from '../../components/ConfirmModal'

// Project Management module -- one Test Project per Application, by
// explicit product decision (reuses the existing Application Name Master
// list rather than a second, parallel "application name" concept). This is
// the entry point for the whole Test Management feature (Project
// Management / Test Repository / Test Execution): Test Repository and Test
// Execution both start with "pick a Project" before showing anything else.
const CAN_MANAGE_ROLES = ['QA_ENGINEER', 'QA_LEAD']

// SRS PRJ-001/PRJ-005 -- editing a project's own record (name/department/
// application/description/owner) is restricted to that project's Owner, or
// system QA_LEAD/Admin -- a QA_ENGINEER who isn't this specific project's
// owner can no longer edit its details, even though they still manage
// Projects in general (create, request activation/deactivation). Mirrors
// backend deps.py::can_manage_project exactly.
function canEditProjectDetails(user: UserOut | null | undefined, project: TestProjectOut): boolean {
  return project.workspace_writable && (
    hasRole(user, ...QA_LEAD_GROUP_ROLES) || (hasRole(user, 'QA_ENGINEER') && project.owner_id === user?.id)
  )
}

function NewProjectModal({ applications, departments, users, currentUserId, onClose, onCreated }: {
  applications: ApplicationMasterOut[]
  departments: DepartmentOut[]
  users: UserOption[]
  currentUserId?: number
  onClose: () => void
  onCreated: (p: TestProjectOut) => void
}) {
  const [applicationId, setApplicationId] = useState<number | ''>('')
  const [name, setName] = useState('')
  const [department, setDepartment] = useState('')
  const [description, setDescription] = useState('')
  const [ownerId, setOwnerId] = useState<number | ''>(currentUserId ?? '')
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)

  function pickApplication(idStr: string) {
    const id = idStr ? Number(idStr) : ''
    setApplicationId(id)
    const app = applications.find((a) => a.id === id)
    if (app) {
      setName(app.name)
      setDepartment(departments.some((item) => item.name === app.department) ? (app.department || '') : '')
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!applicationId) { setError(new Error('Select an application')); return }
    if (!name.trim()) { setError(new Error('Project name cannot be blank')); return }
    if (!department) { setError(new Error('Select a department')); return }
    setBusy(true)
    setError(null)
    try {
      const created = await api.post<TestProjectOut>('/api/test-projects', {
        name: name.trim(),
        application_master_id: applicationId,
        department,
        description: description.trim() || null,
        owner_id: ownerId || null,
      })
      onCreated(created)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  return (
    <Modal title="New Test Project" onClose={onClose}>
      <form onSubmit={submit}>
        <Field label="Application *">
          {/* Searchable -- same growing-list case as Application Name in the
              QA Request wizard (this reuses that same approved-name list). */}
          <SearchableSelect
            value={applicationId === '' ? '' : String(applicationId)}
            onChange={pickApplication}
            placeholder="Select an approved application…"
            options={applications.map((a) => ({ value: String(a.id), label: a.name }))}
          />
          <small className="muted">Required. The project, its Test Cycles, and the Functional QA Request must use the same application.</small>
        </Field>
        <Field label="Project Name *">
          <input required maxLength={150} value={name} onChange={(e) => setName(e.target.value)} />
          <small className="muted">{name.length}/150 characters</small>
        </Field>
        <Field label="Department (from Application)">
          <SearchableSelect disabled value={department} onChange={setDepartment} placeholder={applicationId !== '' ? "Mapped from selected application" : "Select an application first"} options={departments.map((item) => ({ value: item.name, label: item.name }))} />
          {applicationId !== '' && <small className="muted">Department is controlled by the selected Application.</small>}
        </Field>
        {/* SRS PRJ-001/PRJ-005 -- the owner is auto-added as a project member
            with role "Owner" and is the only person (besides QA Lead/Admin)
            who can add/remove other members. Defaults to whoever is creating
            the project. */}
        <Field label="Owner">
          <UserAssignSelect
            value={ownerId === '' ? '' : String(ownerId)}
            onChange={(v) => setOwnerId(v ? Number(v) : '')}
            placeholder="-- Select owner --"
            users={users.filter(isSelectableUser)}
          />
        </Field>
        <Field label="Description">
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
        <ErrorText error={error} />
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Creating...' : 'Create Project'}</button>
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
        </div>
      </form>
    </Modal>
  )
}

// Reported directly: "Once Project is created, give option to edit
// details." Before this, the only post-creation action on a Project was
// Activate/Deactivate -- name, linked Application, department, and
// description could never be changed again. Mirrors NewProjectModal's own
// fields/behavior (including auto-filling name/department when an
// Application is picked), just pre-filled from the existing project and
// PATCHing instead of POSTing.
function EditProjectModal({ project, applications, departments, users, onClose, onUpdated }: {
  project: TestProjectOut
  applications: ApplicationMasterOut[]
  departments: DepartmentOut[]
  users: UserOption[]
  onClose: () => void
  onUpdated: (p: TestProjectOut) => void
}) {
  const [applicationId, setApplicationId] = useState<number | ''>(project.application_master_id ?? '')
  const [name, setName] = useState(project.name)
  const [department, setDepartment] = useState(project.department || '')
  const [description, setDescription] = useState(project.description || '')
  const [ownerId, setOwnerId] = useState<number | ''>(project.owner_id ?? '')
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)

  function pickApplication(idStr: string) {
    const id = idStr ? Number(idStr) : ''
    setApplicationId(id)
    const app = applications.find((a) => a.id === id)
    if (app) {
      setName(app.name)
      setDepartment(departments.some((item) => item.name === app.department) ? (app.department || '') : '')
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    if (!applicationId) { setError(new Error('Select an application')); return }
    if (!name.trim()) { setError(new Error('Project name cannot be blank')); return }
    if (!department) { setError(new Error('Select a department')); return }
    setBusy(true)
    setError(null)
    try {
      const updated = await api.patch<TestProjectOut>(`/api/test-projects/${project.id}`, {
        name: name.trim(),
        application_master_id: applicationId,
        department,
        description: description.trim() || null,
        owner_id: ownerId || null,
      })
      onUpdated(updated)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  return (
    <Modal title={`Edit ${project.project_key}`} onClose={onClose}>
      <form onSubmit={submit}>
        <Field label="Application *">
          <SearchableSelect
            value={applicationId === '' ? '' : String(applicationId)}
            onChange={pickApplication}
            placeholder="Select an approved application…"
            options={applications.map((a) => ({ value: String(a.id), label: a.name }))}
          />
          <small className="muted">Required. Existing unlinked projects must be mapped before they can continue through Test Lifecycle.</small>
        </Field>
        <Field label="Project Name *">
          <input required maxLength={150} value={name} onChange={(e) => setName(e.target.value)} />
          <small className="muted">{name.length}/150 characters</small>
        </Field>
        <Field label="Department (from Application)">
          <SearchableSelect disabled value={department} onChange={setDepartment} placeholder={applicationId !== '' ? "Mapped from selected application" : "Select an application first"} options={departments.map((item) => ({ value: item.name, label: item.name }))} />
          {applicationId !== '' && <small className="muted">Department is controlled by the selected Application.</small>}
        </Field>
        <Field label="Owner">
          <UserAssignSelect
            value={ownerId === '' ? '' : String(ownerId)}
            onChange={(v) => setOwnerId(v ? Number(v) : '')}
            placeholder="-- Select owner --"
            users={users.filter(isSelectableUser)}
          />
        </Field>
        <Field label="Description">
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
        <ErrorText error={error} />
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Saving...' : 'Save changes'}</button>
          <button type="button" className="btn" onClick={onClose}>Cancel</button>
        </div>
      </form>
    </Modal>
  )
}

// 2026-08 -- reported directly: "one logged in user can [only] show
// projects which are under that user department only. now add ... view
// only access to department as well as particular user ... if any project
// cross departmental, then if i add another department as view only
// access then they atleast know the status." Grants read-only visibility
// into THIS project (its Test Execution/Repository/Reports, plus its
// Defects) to a department or a specific user who isn't otherwise in
// scope for it -- see backend models.TestProjectViewGrant's own docstring.
// Gated the same as EditProjectModal (canEditProjectDetails -- Owner, QA
// Lead Group, or Admin), not a separate permission tier.
export function ManageViewAccessModal({ project, departments, directoryUsers, onClose }: {
  project: TestProjectOut
  departments: DepartmentOut[]
  directoryUsers?: UserOption[]
  onClose: () => void
}) {
  const [grants, setGrants] = useState<TestProjectViewGrantOut[]>([])
  const [allUsers, setAllUsers] = useState<UserOption[]>([])
  const [workspaces, setWorkspaces] = useState<TestProjectWorkspaceOptionOut[]>([])
  const [loaded, setLoaded] = useState(false)
  const [grantType, setGrantType] = useState<'department' | 'user' | 'workspace'>('department')
  const [department, setDepartment] = useState('')
  const [userId, setUserId] = useState('')
  const [workspaceId, setWorkspaceId] = useState('')
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    Promise.all([
      api.get<TestProjectViewGrantOut[]>(`/api/test-projects/${project.id}/view-access`),
      // Full active directory, deliberately NOT the QA-only eligible-users
      // list this page otherwise uses -- the whole point of a view grant is
      // reaching someone OUTSIDE the project's own department.
      directoryUsers ? Promise.resolve(directoryUsers) : api.get<UserOption[]>('/api/auth/user-options'),
      api.get<TestProjectWorkspaceOptionOut[]>(`/api/test-projects/${project.id}/view-access-workspaces`),
    ]).then(([g, u, w]) => { setGrants(g); setAllUsers(u); setWorkspaces(w); setLoaded(true) }).catch((err) => { setError(err); setLoaded(true) })
  }, [project.id, directoryUsers])

  async function addGrant(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    if (grantType === 'department' && !department) { setError(new Error('Select a department')); return }
    if (grantType === 'user' && !userId) { setError(new Error('Select a user')); return }
    if (grantType === 'workspace' && !workspaceId) { setError(new Error('Select a workspace')); return }
    setBusy(true)
    try {
      const created = await api.post<TestProjectViewGrantOut>(`/api/test-projects/${project.id}/view-access`, {
        department: grantType === 'department' ? department : null,
        user_id: grantType === 'user' ? Number(userId) : null,
        workspace_id: grantType === 'workspace' ? Number(workspaceId) : null,
      })
      setGrants((prev) => [...prev, created])
      setDepartment(''); setUserId(''); setWorkspaceId('')
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  async function removeGrant(grant: TestProjectViewGrantOut) {
    setBusy(true)
    setError(null)
    try {
      await api.del(`/api/test-projects/${project.id}/view-access/${grant.id}`)
      setGrants((prev) => prev.filter((g) => g.id !== grant.id))
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  // A department already granted, or a user already in the project's own
  // department, can't be granted again (the backend rejects both -- see
  // create_project_view_grant) -- filtered out of the pickers up front
  // rather than letting the request round-trip just to show that error.
  const grantedDepartments = new Set(grants.filter((g) => g.department).map((g) => g.department))
  const grantedUserIds = new Set(grants.filter((g) => g.user_id != null).map((g) => g.user_id))
  const grantedWorkspaceIds = new Set(grants.filter((g) => g.workspace_id != null).map((g) => g.workspace_id))
  const departmentOptions = departments.filter((d) => d.name !== project.department && !grantedDepartments.has(d.name))
  const userOptions = allUsers.filter((u) => isSelectableUser(u) && !grantedUserIds.has(u.id)
    && !(u.departments && u.departments.length ? u.departments : (u.department ? [u.department] : [])).includes(project.department || ''))
  const workspaceOptions = workspaces.filter((workspace) => !grantedWorkspaceIds.has(workspace.id))

  return (
    <Modal title={`Project sharing — ${project.project_key}`} onClose={onClose}>
      <p className="muted small">
        Sharing with a workspace lets eligible users create test cases and cycles. Each workspace can change only its own records; other workspaces’ records remain read-only. Sharing with an individual user or department grants viewing access only.
      </p>
      {!loaded ? <p className="muted">Loading...</p> : (
        <div className="tm-view-access-list">
          {grants.length === 0 && <p className="muted small">No access granted yet.</p>}
          {grants.map((grant) => (
            <div key={grant.id} className="tm-view-access-row">
              <span>
                {grant.department ? <><strong>{grant.department}</strong> <small className="muted">(department)</small></>
                  : grant.workspace_id ? <><strong>{grant.workspace_name || `Workspace #${grant.workspace_id}`}</strong> <small className="muted">(workspace)</small></>
                  : <><strong>{grant.user_name || `User #${grant.user_id}`}</strong> <small className="muted">(user)</small></>}
              </span>
              <button type="button" className="btn btn-sm btn-danger" disabled={busy} onClick={() => removeGrant(grant)}>Remove</button>
            </div>
          ))}
        </div>
      )}
      <form onSubmit={addGrant} style={{ marginTop: 14 }}>
        <div className="pill-tabs" style={{ marginBottom: 10 }}>
          <button type="button" className={grantType === 'department' ? 'active' : ''} onClick={() => setGrantType('department')}>Team / department</button>
          <button type="button" className={grantType === 'user' ? 'active' : ''} onClick={() => setGrantType('user')}>Particular user</button>
          <button type="button" className={grantType === 'workspace' ? 'active' : ''} onClick={() => setGrantType('workspace')}>Workspace</button>
        </div>
        {grantType === 'department' ? (
          <Field label="Team / department">
            <SearchableSelect value={department} onChange={setDepartment} placeholder="Select team or department…" options={departmentOptions.map((d) => ({ value: d.name, label: d.name }))} />
          </Field>
        ) : grantType === 'user' ? (
          <Field label="User">
            <UserAssignSelect value={userId} onChange={setUserId} placeholder="Select user…" users={userOptions} />
          </Field>
        ) : (
          <Field label="Workspace">
            <SearchableSelect value={workspaceId} onChange={setWorkspaceId} placeholder="Select workspace…" options={workspaceOptions.map((workspace) => ({ value: String(workspace.id), label: `${workspace.name} (${workspace.workspace_key})` }))} />
          </Field>
        )}
        <ErrorText error={error} />
        <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
          <button className="btn btn-primary" disabled={busy}>{busy ? 'Granting...' : 'Grant view access'}</button>
          <button type="button" className="btn" onClick={onClose}>Close</button>
        </div>
      </form>
    </Modal>
  )
}

// PRJ-003 -- archiving is deliberately final-feeling (separate from the
// two-step activate/deactivate approval flow above): QA Lead/Admin only, an
// optional reason for the audit trail, and always also forces is_active
// False on the backend.
function ArchiveProjectModal({ project, onClose, onDone }: {
  project: TestProjectOut
  onClose: () => void
  onDone: (p: TestProjectOut) => void
}) {
  const [reason, setReason] = useState('')
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)

  async function submit() {
    setBusy(true)
    setError(null)
    try {
      const updated = await api.post<TestProjectOut>(`/api/test-projects/${project.id}/archive`, {
        reason: reason.trim() || null,
      })
      onDone(updated)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  return (
    <Modal title={`Archive ${project.project_key}?`} onClose={onClose} variant="dialog" preventBackdropClose>
      <p>
        Archiving <strong>{project.project_key} · {project.name}</strong> also deactivates it. Existing folders,
        test cases, cycles, executions, and activity are retained but the project can no longer be used for new
        test work until it's unarchived.
      </p>
      <Field label="Reason (optional)">
        <textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Why is this project being archived?" />
      </Field>
      <ErrorText error={error} />
      <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
        <button className="btn btn-danger" disabled={busy} onClick={submit}>{busy ? 'Archiving…' : 'Archive project'}</button>
        <button className="btn" disabled={busy} onClick={onClose}>Cancel</button>
      </div>
    </Modal>
  )
}

function UnarchiveProjectModal({ project, onClose, onDone }: {
  project: TestProjectOut
  onClose: () => void
  onDone: (p: TestProjectOut) => void
}) {
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)

  async function submit() {
    setBusy(true)
    setError(null)
    try {
      const updated = await api.post<TestProjectOut>(`/api/test-projects/${project.id}/unarchive`, {})
      onDone(updated)
    } catch (err) { setError(err) } finally { setBusy(false) }
  }

  return (
    <Modal title={`Restore ${project.project_key} from archive?`} onClose={onClose} variant="dialog" preventBackdropClose>
      <p>
        <strong>{project.project_key} · {project.name}</strong> will come back as Inactive, not Active --
        reactivating it for new work is still a separate step.
      </p>
      <ErrorText error={error} />
      <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
        <button className="btn btn-primary" disabled={busy} onClick={submit}>{busy ? 'Restoring…' : 'Restore project'}</button>
        <button className="btn" disabled={busy} onClick={onClose}>Cancel</button>
      </div>
    </Modal>
  )
}

export default function TestProjects() {
  const navigate = useInternalNavigate()
  const [searchParams, setSearchParams] = useSearchParams()
  const { user } = useAuth()
  const canManage = hasRole(user, ...CAN_MANAGE_ROLES)
  // Reported directly: "Project Activation, deactivation should need
  // approval from QA lead." QA Lead (Admin bypasses via hasRole) can still
  // flip is_active immediately, same as before -- only a QA Engineer's
  // toggle now goes through a request/approve step (see changeProjectStatus
  // and the new Approve/Reject flow below).
  // Executive bypass: CHIEF_MANAGER_QA/AGM_QA can act on this QA Lead
  // checkpoint, same as Admin -- see ORACLE_MIGRATION_2026-07.md section 59.
  const canReview = hasRole(user, ...QA_LEAD_GROUP_ROLES)
  const [projects, setProjects] = useState<TestProjectOut[]>([])
  const [applications, setApplications] = useState<ApplicationMasterOut[]>([])
  const [departments, setDepartments] = useState<DepartmentOut[]>([])
  const [users, setUsers] = useState<UserOption[]>([])
  const [error, setError] = useState<unknown>(null)
  const [showNew, setShowNew] = useState(false)
  const [summaries, setSummaries] = useState<Record<number, { cases: number; cycles: number }>>({})
  const [activityProject, setActivityProject] = useState<TestProjectOut | null>(null)
  const [activity, setActivity] = useState<ApprovalActionOut[]>([])
  const [statusProject, setStatusProject] = useState<TestProjectOut | null>(null)
  const [editProject, setEditProject] = useState<TestProjectOut | null>(null)
  const [viewAccessProject, setViewAccessProject] = useState<TestProjectOut | null>(null)
  const [archiveProject, setArchiveProject] = useState<TestProjectOut | null>(null)
  const [unarchiveProject, setUnarchiveProject] = useState<TestProjectOut | null>(null)
  const [statusBusy, setStatusBusy] = useState(false)
  const [projectFilter, setProjectFilter] = useState<'active' | 'inactive' | 'archived' | 'all'>('active')
  // Reported directly, alongside the approval workflow above: "Search under
  // project is not working" -- this page never had a search box at all, only
  // the Active/Inactive/All pill-tabs, so typing anywhere did nothing.
  const [search, setSearch] = useState('')
  const [activationReview, setActivationReview] = useState<{ project: TestProjectOut; decision: 'APPROVE' | 'REJECT' } | null>(null)
  const [reviewComments, setReviewComments] = useState('')
  const [reviewBusy, setReviewBusy] = useState(false)

  async function openActivity(project: TestProjectOut) {
    setActivityProject(project)
    try { setActivity(await api.get<ApprovalActionOut[]>(`/api/approvals?entity_type=TEST_PROJECT&entity_id=${project.id}`)) }
    catch (err) { setError(err); setActivity([]) }
  }

  const load = useCallback(async () => {
    try {
      const [p, a, d, u, summaryCounts] = await Promise.all([
        // This client-filtered gallery must include every project.
        api.getAll<TestProjectOut>('/api/test-projects?include_inactive=true'),
        api.get<ApplicationMasterOut[]>('/api/application-names'),
        api.get<DepartmentOut[]>('/api/departments'),
        // Test Management-scoped picker -- see constants.
        // the selected workspace on the backend; do not swap
        // this back to the app-wide /api/auth/user-options list.
        api.get<UserOption[]>('/api/test-projects/eligible-users'),
        api.get<TestProjectSummaryCountsOut[]>('/api/test-projects/summary-counts?include_inactive=true'),
      ])
      setProjects(p); setApplications(a); setDepartments(d); setUsers(u)
      setSummaries(Object.fromEntries(summaryCounts.map((summary) => [
        summary.project_id,
        { cases: summary.test_case_count, cycles: summary.cycle_count },
      ])))
    } catch (err) { setError(err) }
  }, [])
  useEffect(() => { load() }, [load])

  // Deep-link support, same pattern as Functional.tsx/SAST.tsx/etc.'s own
  // `?open=<request_id>` -- this page has no separate single-project detail
  // view to jump into (the pending-activation banner is shown inline per
  // row, see below), so "opening" a project here means filtering the list
  // down to just that one project_key instead. Used by the Pending
  // Approvals feed to land a QA Lead directly on the specific project
  // awaiting their activation/deactivation decision.
  useEffect(() => {
    const recordId = Number(searchParams.get('openId'))
    const openKey = searchParams.get('open')
    if (Number.isInteger(recordId) && recordId > 0) {
      api.get<TestProjectOut>(`/api/test-projects/${recordId}`).then((project) => {
        setProjects((current) => current.some((item) => item.id === project.id) ? current : [project, ...current])
        setProjectFilter('all')
        setSearch(project.project_key)
      }).catch(setError)
    } else if (openKey) {
      if (!projects.some((project) => project.project_key === openKey)) return
      setProjectFilter('all')
      setSearch(openKey)
    } else return
    setSearchParams((p) => { p.delete('open'); p.delete('openId'); return p }, { replace: true })
  }, [projects, searchParams, setSearchParams])

  const applicationNameById = useMemo(() => new Map(applications.map((a) => [a.id, a.name])), [applications])
  const archivedCount = projects.filter((project) => project.is_archived).length
  const activeCount = projects.filter((project) => project.is_active && !project.is_archived).length
  const inactiveCount = projects.filter((project) => !project.is_active && !project.is_archived).length
  const visibleProjects = useMemo(() => {
    let rows = projects.filter((project) => {
      if (projectFilter === 'all') return true
      if (projectFilter === 'archived') return project.is_archived
      if (project.is_archived) return false
      return projectFilter === 'active' ? project.is_active : !project.is_active
    })
    const q = search.trim().toLowerCase()
    if (q) {
      rows = rows.filter((project) => [
        project.name, project.project_key, project.department,
        project.application_master_id ? applicationNameById.get(project.application_master_id) : null,
      ].some((v) => String(v || '').toLowerCase().includes(q)))
    }
    return rows
  }, [projects, projectFilter, search, applicationNameById])

  async function changeProjectStatus() {
    if (!statusProject) return
    setStatusBusy(true)
    setError(null)
    try {
      const updated = await api.patch<TestProjectOut>(`/api/test-projects/${statusProject.id}`, {
        is_active: !statusProject.is_active,
      })
      setProjects((rows) => rows.map((project) => project.id === updated.id ? updated : project))
      setStatusProject(null)
    } catch (err) {
      setError(err)
    } finally {
      setStatusBusy(false)
    }
  }

  async function submitActivationReview() {
    if (!activationReview) return
    if (activationReview.decision === 'REJECT' && !reviewComments.trim()) {
      setError(new Error('Enter a reason for rejecting this request'))
      return
    }
    setReviewBusy(true)
    setError(null)
    try {
      const updated = await api.post<TestProjectOut>(`/api/test-projects/${activationReview.project.id}/activation-review`, {
        decision: activationReview.decision,
        comments: reviewComments.trim() || null,
      })
      setProjects((rows) => rows.map((project) => project.id === updated.id ? updated : project))
      setActivationReview(null)
      setReviewComments('')
    } catch (err) {
      setError(err)
    } finally {
      setReviewBusy(false)
    }
  }

  return (
    <div className="tm-page">
      <ErrorText error={error} />
      <PageHeader
        eyebrow="Test Case Management · Design · Organize · Execute · Trace"
        title="Test Projects" count={visibleProjects.length}
        subtitle="Workspaces for reusable test cases, test cycles, and execution results. Each test project can be linked to an application."
        actions={canManage && (
          <button className="btn btn-primary" onClick={() => setShowNew(true)}>+ New Test Project</button>
        )}
      />
      <div className="toolbar tm-project-toolbar" style={{ marginBottom: 14 }}>
        <ClearableSearchInput
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onClear={() => setSearch('')}
          clearLabel="Clear project search"
          wrapperClassName="search-grow"
          placeholder="Search projects by name, key, department, or application…"
          aria-label="Search projects"
        />
        <div className="pill-tabs" aria-label="Filter projects by status">
          <button className={projectFilter === 'active' ? 'active' : ''} onClick={() => setProjectFilter('active')}>
            Active <span>{activeCount}</span>
          </button>
          <button className={projectFilter === 'inactive' ? 'active' : ''} onClick={() => setProjectFilter('inactive')}>
            Inactive <span>{inactiveCount}</span>
          </button>
          <button className={projectFilter === 'archived' ? 'active' : ''} onClick={() => setProjectFilter('archived')}>
            Archived <span>{archivedCount}</span>
          </button>
          <button className={projectFilter === 'all' ? 'active' : ''} onClick={() => setProjectFilter('all')}>
            All <span>{projects.length}</span>
          </button>
        </div>
      </div>
      <div className="tm-project-grid">
        {visibleProjects.map((project) => (
          <article className="tm-project-card" key={project.id}>
            <div className="tm-project-card-head">
              <span className="tm-project-key">{project.project_key}</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                {project.shared_with_you && (
                  <span className="badge badge-blue" title="The project owner or an authorized project manager shared view access with you, your department, or your active workspace.">Shared with you</span>
                )}
                {!project.workspace_writable && (
                  <span className="badge badge-gray" title="This project is visible here, but its settings belong to another workspace or your current access is read-only.">Project settings read-only</span>
                )}
                <Badge status={project.is_archived ? 'Archived' : project.is_active ? 'Active' : 'Inactive'} />
              </span>
            </div>
            <h3 title={project.name}>{project.name}</h3>
            <p title={project.description || undefined}>{project.description || 'Test design and execution workspace for this application.'}</p>
            <div className="tm-project-stats">
              <div><strong>{summaries[project.id]?.cases ?? '—'}</strong><span>Test cases</span></div>
              <div><strong>{summaries[project.id]?.cycles ?? '—'}</strong><span>Test cycles</span></div>
              <div><strong>{project.department || '—'}</strong><span>Department</span></div>
              <div><strong>{project.owner_name || '—'}</strong><span>Owner</span></div>
            </div>
            {project.is_archived && (
              <div className="info-banner">
                <strong>Archived</strong> by {project.archived_by_name || 'a QA Lead'}
                {project.archived_at && ` on ${formatDateIST(project.archived_at)}`}
                {project.archived_reason && ` — ${project.archived_reason}`}
              </div>
            )}
            {project.pending_is_active != null && (
              <div className="info-banner">
                <strong>{project.pending_is_active ? 'Reactivation' : 'Deactivation'} requested</strong> by{' '}
                {project.pending_requested_by_name || 'a QA Engineer'} — pending QA Lead approval.
              </div>
            )}
            <div className="tm-project-actions">
              <button onClick={() => navigate(`/test-repository?project=${project.id}`)}>Open repository</button>
              <button onClick={() => navigate(`/test-execution?project=${project.id}`)}>View execution</button>
              <details className="tm-project-more">
                <summary>More <span>⌄</span></summary>
                <div>
                  <button onClick={() => openActivity(project)}>Activity</button>
                  {!project.is_archived && !project.view_only && canEditProjectDetails(user, project) && (
                    <button onClick={() => setEditProject(project)}>Edit project</button>
                  )}
                  {!project.view_only && canEditProjectDetails(user, project) && (
                    <button onClick={() => setViewAccessProject(project)}>Share project…</button>
                  )}
                  {!project.is_archived && project.workspace_writable && (project.pending_is_active != null ? (
                    canReview && (
                      <>
                        <button className="primary" onClick={() => setActivationReview({ project, decision: 'APPROVE' })}>Approve request</button>
                        <button className="danger" onClick={() => setActivationReview({ project, decision: 'REJECT' })}>Reject request</button>
                      </>
                    )
                  ) : canReview ? (
                    <button className={project.is_active ? 'danger' : ''} onClick={() => setStatusProject(project)}>
                      {project.is_active ? 'Deactivate' : 'Reactivate'}
                    </button>
                  ) : canManage && (
                    <button onClick={() => setStatusProject(project)}>
                      {project.is_active ? 'Request deactivation' : 'Request reactivation'}
                    </button>
                  ))}
                  {project.workspace_writable && canReview && (
                    project.is_archived
                      ? <button onClick={() => setUnarchiveProject(project)}>Unarchive</button>
                      : <button className="danger" onClick={() => setArchiveProject(project)}>Archive</button>
                  )}
                </div>
              </details>
            </div>
          </article>
        ))}
        {visibleProjects.length === 0 && (
          <div className="tm-empty">
            <strong>{projectFilter === 'inactive' ? 'No inactive projects' : projectFilter === 'active' ? 'No active projects' : projectFilter === 'archived' ? 'No archived projects' : 'No projects yet'}</strong>
            <span>{projectFilter === 'inactive' ? 'Deactivated projects will appear here.' : projectFilter === 'archived' ? 'Archived projects will appear here.' : 'Create or reactivate a project to begin organizing test cases and execution cycles.'}</span>
          </div>
        )}
      </div>
      {showNew && (
        <NewProjectModal
          applications={applications}
          departments={departments}
          users={users}
          currentUserId={user?.id}
          onClose={() => setShowNew(false)}
          onCreated={(p) => { setProjects((prev) => [p, ...prev]); setShowNew(false) }}
        />
      )}
      {editProject && (
        <EditProjectModal
          project={editProject}
          applications={applications}
          departments={departments}
          users={users}
          onClose={() => setEditProject(null)}
          onUpdated={(p) => { setProjects((prev) => prev.map((project) => project.id === p.id ? p : project)); setEditProject(null) }}
        />
      )}
      {viewAccessProject && (
        <ManageViewAccessModal
          project={viewAccessProject}
          departments={departments}
          onClose={() => setViewAccessProject(null)}
        />
      )}
      {archiveProject && (
        <ArchiveProjectModal
          project={archiveProject}
          onClose={() => setArchiveProject(null)}
          onDone={(p) => { setProjects((prev) => prev.map((project) => project.id === p.id ? p : project)); setArchiveProject(null) }}
        />
      )}
      {unarchiveProject && (
        <UnarchiveProjectModal
          project={unarchiveProject}
          onClose={() => setUnarchiveProject(null)}
          onDone={(p) => { setProjects((prev) => prev.map((project) => project.id === p.id ? p : project)); setUnarchiveProject(null) }}
        />
      )}
      {activityProject && (
        <Modal title={`${activityProject.project_key} · Activity`} onClose={() => setActivityProject(null)} wide>
          <JiraActivity ownerWorkspaceId={activityProject.qa_workspace_id} entityType="TEST_PROJECT" entityId={activityProject.id} items={activity} onPosted={(item) => setActivity((prev) => [...prev, item])} />
        </Modal>
      )}
      {statusProject && (
        <Modal
          title={canReview
            ? (statusProject.is_active ? 'Deactivate project?' : 'Reactivate project?')
            : (statusProject.is_active ? 'Request deactivation?' : 'Request reactivation?')}
          onClose={() => setStatusProject(null)}
          variant="dialog"
          preventBackdropClose
        >
          <p>
            {canReview ? (
              statusProject.is_active
                ? `Deactivate ${statusProject.project_key} · ${statusProject.name}? Existing folders, test cases, cycles, executions, and activity will be retained, but no new test work can be added.`
                : `Reactivate ${statusProject.project_key} · ${statusProject.name} so it can be used for new repository and execution work again?`
            ) : (
              statusProject.is_active
                ? `Ask a QA Lead to deactivate ${statusProject.project_key} · ${statusProject.name}? This won't take effect until a QA Lead approves it.`
                : `Ask a QA Lead to reactivate ${statusProject.project_key} · ${statusProject.name}? This won't take effect until a QA Lead approves it.`
            )}
          </p>
          <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
            <button className={canReview && statusProject.is_active ? 'btn btn-danger' : 'btn btn-primary'} disabled={statusBusy} onClick={changeProjectStatus}>
              {statusBusy ? 'Updating…' : canReview ? (statusProject.is_active ? 'Deactivate' : 'Reactivate') : 'Send request'}
            </button>
            <button className="btn" disabled={statusBusy} onClick={() => setStatusProject(null)}>Cancel</button>
          </div>
        </Modal>
      )}
      {activationReview && (
        <Modal
          title={`${activationReview.decision === 'APPROVE' ? 'Approve' : 'Reject'} ${activationReview.project.pending_is_active ? 'reactivation' : 'deactivation'} request?`}
          onClose={() => { setActivationReview(null); setReviewComments('') }}
          variant="dialog"
          preventBackdropClose
        >
          <p>
            {activationReview.project.pending_requested_by_name || 'A QA Engineer'} requested{' '}
            {activationReview.project.pending_is_active ? 'reactivating' : 'deactivating'}{' '}
            <strong>{activationReview.project.project_key} · {activationReview.project.name}</strong>.
          </p>
          <Field label={activationReview.decision === 'REJECT' ? 'Reason (required)' : 'Comments (optional)'}>
            <textarea
              value={reviewComments}
              onChange={(e) => setReviewComments(e.target.value)}
              placeholder={activationReview.decision === 'REJECT' ? 'Why is this request being rejected?' : 'Optional note for the audit trail'}
            />
          </Field>
          <ErrorText error={error} />
          <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
            <button
              className={activationReview.decision === 'APPROVE' ? 'btn btn-primary' : 'btn btn-danger'}
              disabled={reviewBusy}
              onClick={submitActivationReview}
            >
              {reviewBusy ? 'Submitting…' : activationReview.decision === 'APPROVE' ? 'Approve' : 'Reject'}
            </button>
            <button className="btn" disabled={reviewBusy} onClick={() => { setActivationReview(null); setReviewComments('') }}>Cancel</button>
          </div>
        </Modal>
      )}
    </div>
  )
}
